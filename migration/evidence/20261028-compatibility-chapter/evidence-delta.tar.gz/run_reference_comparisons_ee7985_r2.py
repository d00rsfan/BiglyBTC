from pathlib import Path
import subprocess,hashlib,json,time,sys
W=Path(__file__).resolve().parent
assert not (W/'reference-comparisons-ee7985-r2.json').exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases=[('existing','existing-storage-oracle/amendments/same-admission-upload/run.py','existing-completion-metadata-ee7985-r1.json','existing-storage-oracle/runs/run-r2-ee7985',['--phase','all']),('allocation','allocation-original-oracle/run.py','allocation-completion-metadata-ee7985-r1.json','allocation-original-oracle/runs/run-r2-ee7985',[])]
record={'source_commit':'ee7985e4b78f1d8c9d89f727f29f3a025f3c63fc','actual_build_source_commit':'7405a61a7a605c9962cc7a630b06fef25c0a5c66','status':'RUNNING','commands':[]}
for name,script,completion,out,extra in cases:
 argv=[sys.executable,str(W/script),'--completion',str(W/completion),'--completion-sha256',sha(W/completion),'--output',str(W/out),*extra]
 row={'name':name,'argv':argv,'state':'started','script_sha256':sha(W/script),'completion_sha256':sha(W/completion),'output':str(W/out)}
 record['commands'].append(row);(W/'reference-comparisons-ee7985-r2.json').write_text(json.dumps(record,indent=2)+'\n')
 t=time.monotonic()
 with (W/(name+'-comparison-ee7985-r2.stdout')).open('xb') as stdout,(W/(name+'-comparison-ee7985-r2.stderr')).open('xb') as stderr:
  child=subprocess.run(argv,cwd=W.parents[1],stdout=stdout,stderr=stderr)
 row.update(state='finished',exit=child.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(W/(name+'-comparison-ee7985-r2.stdout')),stderr_sha256=sha(W/(name+'-comparison-ee7985-r2.stderr')))
 result=W/out/'result.json'
 if result.exists():
  data=json.loads(result.read_bytes());row.update(result_sha256=sha(result),result_status=data.get('status'),actual_cases=data.get('actual_cases'))
 (W/'reference-comparisons-ee7985-r2.json').write_text(json.dumps(record,indent=2)+'\n')
record['status']='PASS' if all(r['exit']==0 and r.get('result_status','').startswith('PASS_ACTUAL_') for r in record['commands']) else 'FAIL'
(W/'reference-comparisons-ee7985-r2.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));sys.exit(0 if record['status']=='PASS' else 1)
