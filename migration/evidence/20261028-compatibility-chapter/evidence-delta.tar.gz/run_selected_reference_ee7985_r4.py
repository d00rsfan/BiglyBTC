from pathlib import Path
import subprocess,json,hashlib,time,sys
W=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
script=W/'existing-storage-oracle/amendments/original-linear-allocation/run.py';completion=W/'existing-completion-metadata-ee7985-r1.json'
argv=[sys.executable,str(script),'--completion',str(completion),'--completion-sha256',sha(completion),'--phase','selected','--output',str(W/'existing-storage-oracle/runs/run-r4-selected-ee7985')]
r={'source_commit':'ee7985e4b78f1d8c9d89f727f29f3a025f3c63fc','actual_build_source_commit':'7405a61a7a605c9962cc7a630b06fef25c0a5c66','argv':argv,'script_sha256':sha(script),'status':'RUNNING'}
receipt=W/'selected-comparison-ee7985-r4.json';assert not receipt.exists();receipt.write_text(json.dumps(r,indent=2)+'\n');t=time.monotonic()
with (W/'selected-comparison-ee7985-r4.stdout').open('xb') as stdout,(W/'selected-comparison-ee7985-r4.stderr').open('xb') as stderr:
 child=subprocess.run(argv,cwd=W.parents[1],stdout=stdout,stderr=stderr)
r.update(exit=child.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(W/'selected-comparison-ee7985-r4.stdout'),stderr_sha256=sha(W/'selected-comparison-ee7985-r4.stderr'))
result=W/'existing-storage-oracle/runs/run-r4-selected-ee7985/result.json'
if result.exists():
 m=json.loads(result.read_bytes());r.update(result_sha256=sha(result),result_status=m['status'],actual_cases=m.get('actual_cases'))
r['status']='PASS' if child.returncode==0 and r.get('actual_cases')==7 else 'FAIL';receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));sys.exit(child.returncode)
