"""Bind actual passed build to a clean source-equal metadata-only descendant."""
from pathlib import Path
import argparse,hashlib,json,subprocess
W=Path(__file__).resolve().parent
N=Path('/home/yurii/Java/BiglyBTC')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--build-run',required=True);p.add_argument('--attempt',required=True);a=p.parse_args()
assert '/' not in a.build_run and '/' not in a.attempt
B=W/a.build_run
commands=json.loads((B/'commands.json').read_bytes())
assert {x['name'] for x in commands}>={'build','tests'} and all(x['exit']==0 for x in commands)
git=lambda *x:subprocess.check_output(['git',*x],cwd=N)
assert not git('status','--porcelain')
cid=git('rev-parse','HEAD').decode().strip()
graph={x:sha(N/x) for x in git('ls-files','-z','--','preview/native').decode().split('\0') if x}
receipt=B/'build-receipt.json';build=json.loads(receipt.read_bytes())
assert build['exit']==0 and build['source_manifest_sha256']==sha(B/'build-source.json')
built_cid=build['source_commit']
subprocess.run(['git','merge-base','--is-ancestor',built_cid,cid],cwd=N,check=True)
assert not git('diff',built_cid,cid,'--','preview/native')
changed=git('diff','--name-only',built_cid,cid).decode().splitlines()
assert all(not p.startswith('preview/native/') for p in changed)
assert not git('ls-files','--others','--exclude-standard','--','preview/native')
qualified=json.loads((B/'result.json').read_bytes())
assert qualified['status']=='PASS_GCC40_WITH_EXPLICIT_UNCHANGED_RESULT_REUSE'
assert qualified['source_commit']==built_cid and qualified['tests']==40
assert len(qualified['unchanged_passed_tests_reused'])==39 and qualified['actually_reexecuted_tests']==['managed-download']
assert qualified['reuse_before_sha256']==sha(B/'reuse-before.json') and qualified['current_xml_sha256']==sha(B/'tests.xml')
assert qualified['source_manifest_sha256']==sha(B/'build-source.json')
assert json.loads((B/'build-source.json').read_bytes())==graph
driver=N/'build/persistent-peer-accounting-20261021/bound-gcc/tests/biglybtc-managed-download-tests'
assert driver.name in build['command']
for name,recipe in [('existing','existing-storage-oracle/amendments/same-admission-upload'),('allocation','allocation-original-oracle')]:
    R=W/recipe
    own=json.loads((R/'manifest.json').read_bytes())
    artifacts=own.get('artifacts') or own.get('artifacts_sha256')
    assert artifacts
    for rel,digest in artifacts.items():assert sha(R/rel)==digest,(name,rel)
    inputs=json.loads((R/'inputs.json').read_bytes())
    for rel,digest in inputs['immutable_producer_paths'].items():assert graph[rel]==digest,(name,rel,'immutable source changed')
    record=json.loads((R/'completion.example.json').read_bytes())
    record.update(source_commit=cid,driver=str(driver),driver_sha256=sha(driver),tracked_source_sha256=graph,
        producer_source_sha256={rel:graph[rel] for rel in inputs['producer_paths']},build_receipt=str(receipt),build_receipt_sha256=sha(receipt),
        build_source_commit=built_cid,source_association={'kind':'metadata_only_source_equal_descendant','runtime_source_commit':cid,
        'actual_build_source_commit':built_cid,'tracked_native_tree_sha256':sha(B/'build-source.json'),
        'descendant_ancestor_verified':True,'changed_paths':changed,'native_graph_byte_exact':True,
        'gcc_gate_result':str(B/'result.json'),'gcc_gate_result_sha256':sha(B/'result.json'),
        'gcc_gate_scope':'39 explicitly reused unchanged suites plus1 actual managed-download; no claim40 reruns'})
    out=W/(name+'-completion-'+a.attempt+'.json');assert not out.exists()
    out.write_text(json.dumps(record,indent=2)+'\n');print(name,str(out),sha(out))
