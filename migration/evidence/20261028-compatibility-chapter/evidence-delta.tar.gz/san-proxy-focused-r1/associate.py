import hashlib,json,re,xml.etree.ElementTree as ET
from pathlib import Path
W=Path('/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027')
R=W/'san-final-r3'; O=W/'san-proxy-focused-r1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries=ET.parse(R/'tests.xml').getroot().findall('.//testcase')
plan=json.loads((R/'plan.json').read_bytes())
assert len(entries)==40 and {x.attrib['name'] for x in entries}==set(plan['tests'])
bad=[x for x in entries if any(x.find(k) is not None for k in ('failure','error','skipped'))]
assert len(bad)==1 and bad[0].attrib['name']=='network-proxy-owner' and bad[0].attrib['status']=='fail'
assert all(x.attrib.get('status')=='run' for x in entries if x not in bad)
text=bad[0].find('system-out').text or ''
key=lambda v:v[0]+('('+v[1]+')' if v[1] else '')
passes=re.findall(r'^PASS\s*:\s+NetworkProxyOwnerTests::(\w+)\(([^)]*)\)\s*$',text,re.M)
failed=re.findall(r'^FAIL!\s*:\s+NetworkProxyOwnerTests::(\w+)\(([^)]*)\)',text,re.M)
passed={key(x) for x in passes}-{'initTestCase','cleanupTestCase'}
fail={key(x) for x in failed}
assert len(passed)==12 and fail=={'actualRemoteWebSeedPayload(SOCKS5-remote-name)'}
assert re.findall(r'Totals:\s+(\d+) passed,\s+(\d+) failed,\s+(\d+) skipped',text)==[('14','1','0')]
assert '********* Finished testing of NetworkProxyOwnerTests *********' in text and ('cleanupTestCase','') in passes
f=json.loads((O/'result.json').read_bytes()); focused=(O/'stdout.log').read_text()
target={key(x) for x in re.findall(r'^PASS\s*:\s+NetworkProxyOwnerTests::(\w+)\(([^)]*)\)\s*$',focused,re.M)}-{'initTestCase','cleanupTestCase'}
assert target==fail and f['exit_code']==0 and f['source_and_binary_unchanged'] is True
assert re.findall(r'Totals:\s+(\d+) passed,\s+(\d+) failed,\s+(\d+) skipped',focused)==[('3','0','0')]
pattern=r'ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:|SUMMARY: UndefinedBehaviorSanitizer'
assert not re.search(pattern,focused) and not re.search(pattern,(R/'tests.log').read_text(errors='replace'))
commands=json.loads((R/'commands.json').read_bytes())
assert next(x for x in commands if x['name']=='tests')['exit']==8
record={'schema':1,'status':'ALL_40_SUITES_COVERED_WITH_EXPLICIT_UNCHANGED_PROXY_CASE_REUSE',
 'source_commit':f['source_commit'],'original_ctest_exit':8,'original_wrapper_or_suite_success_invented':False,
 'actual_unchanged_passed_suites':[x.attrib['name'] for x in entries if x not in bad],
 'proxy':{'original_status':'FAIL_14_PASS_1_FAIL_0_SKIP','prior_subject_passes':len(passed),
 'focused_subject_passes':len(target),'unique_subject_cases':len(passed|target),
 'whole_proxy_suite_exit_zero_claimed':False,'focused_row':sorted(target),'focused_exit':0,
 'unresolved_limitation':'Original failed row unplanned proxy destination; failing endpoint unrecorded. No source cause/fix claim.'},
 'sanitizer_environment':f['sanitizer_environment'],'no_sanitizer_diagnostic_in_observed_logs':True,
 'inputs':{str(p):sha(p) for p in (R/'tests.xml',R/'tests.log',R/'commands.json',R/'build-receipt.json',R/'build-source.json',R/'registered-tests.json',O/'command.json',O/'result.json',O/'stdout.log',O/'associate.py')},
 'original_fail_history_unchanged':True,'builds':0,'whole_40_reruns':0}
p=O/'case-reuse-association.json'
assert not p.exists()
p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'association_sha256':sha(p),'prior_passed_suites':len(record['actual_unchanged_passed_suites']),'proxy_subject_cases':len(passed|target)}))
