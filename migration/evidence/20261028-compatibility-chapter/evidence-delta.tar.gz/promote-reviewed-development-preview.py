from pathlib import Path
import hashlib,json,os,shutil,subprocess
W=Path(__file__).resolve().parent;R=W.parents[1];N=R.parent/'BiglyBTC';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();git=lambda root,*a:subprocess.check_output(['git',*a],cwd=root)
assert git(R,'rev-parse','HEAD').decode().strip()=='cb8c6cb9bb97916cbc7e80338a017200ffc3e71f' and sha(R/'.git/index')=='ac45601f3bed2b3a3d2ac91d715e4b052108a5b7478de62bb67f165ce0de30d4'
cid=git(N,'rev-parse','HEAD').decode().strip();assert cid=='61fc63b5bcb783dd82b3bafb9eb62ecee578cc02' and not git(N,'status','--porcelain')
allowed={'preview/native/tests/file_operation_dialog_tests.cpp','preview/native/tests/network_proxy_owner_tests.cpp'};assert set(git(N,'diff','--name-only','ee7985e4b78f1d8c9d89f727f29f3a025f3c63fc',cid).decode().splitlines())==allowed
proofs={}
for lane in ['gcc','clang']:
 p=W/('portable-'+lane+'-ee798-r2/addendum-r1/result.json');d=json.loads(p.read_bytes());assert d['status']=='PRIVATE_RUNTIME_COVERED_WITH_EXPLICIT_UNCHANGED_CASE_REUSE_NOT_PROMOTED' and d['shipping_approved'] is False
 assert any(x['name']=='provider-traffic-runtime-deployment' and x['cases']==11 and x['status']=='PASS' for x in d['cohort']);proofs[lane]={'path':str(p),'sha256':sha(p),'result':d}
visual=json.loads((W/'visual-review/corrected-capture-comparison.json').read_bytes());assert visual['identical_across_three_lanes'] and not visual['inspection_pending']
for lane in ['gcc','clang','san']:
 p=W/('focused-final-'+lane+'-r2/result-recovered.json');d=json.loads(p.read_bytes());assert d['file_dialog_qt_cases']==4 and d['production_and_other_registered_images_unchanged'];proofs[lane+'-focused']={'path':str(p),'sha256':sha(p)}
assert json.loads((W/'san-proxy-focused-r1/case-reuse-association.json').read_bytes())
def bundle(path):
 d=json.loads((path/'BUILD_MANIFEST.json').read_bytes());assert {p.relative_to(path).as_posix() for p in path.rglob('*') if p.is_file()}==set(d['files_sha256'])|{'BUILD_MANIFEST.json'}
 for s,h in d['files_sha256'].items():
  p=path/s;assert p.resolve().is_relative_to(path.resolve()) and sha(p)==h
 return sha(path/'BUILD_MANIFEST.json'),len(d['files_sha256'])
old=N/'dist';oldhash,count=bundle(old);assert oldhash=='e34ade281e7c8548c837968f7c095042d93862a4e1312f790feba464de3ba421' and count==118
candidate=Path(proofs['gcc']['result']['candidate']);newhash,newcount=bundle(candidate);assert newhash==proofs['gcc']['result']['manifest_sha256']
stage=N/'build/compatibility-preview-promotion-20261028';backup=W/'previous-published-dist-20261028';assert not stage.exists() and not backup.exists();assert old.stat().st_dev==W.stat().st_dev
shutil.copytree(candidate,stage,symlinks=True);assert bundle(stage)==(newhash,newcount)
os.rename(old,backup)
try:os.rename(stage,old);assert bundle(old)==(newhash,newcount) and bundle(backup)==(oldhash,118)
except BaseException:
 if old.exists():os.rename(old,stage)
 os.rename(backup,old);raise
runtime=W/'promotion-runtime';runtime.mkdir();env={k:v for k,v in os.environ.items() if not k.startswith(('BIGLYBTC_','LD_'))};env.update(QT_QPA_PLATFORM='offscreen',LD_DEBUG='libs')
for k in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR']:
 p=runtime/k.lower();p.mkdir(mode=0o700);env[k]=str(p)
with (runtime/'normal-launcher-usage.log').open('wb') as log:r=subprocess.run([str(old/'BiglyBTC')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=30)
assert r.returncode==2;log=(runtime/'normal-launcher-usage.log').read_text();assert 'Usage: BiglyBTC --profile ABSOLUTE_PROFILE' in log
assert 'calling init: '+str(old/'usr/lib/biglybtc/lib/libtorrent-rasterbar.so.2.0') in log
provider=old/'usr/lib/biglybtc/lib/libtorrent-rasterbar.so.2.0.12';assert sha(provider)=='98279a468e0fa5147876b6f22f8947f432c294dfc02fb50cf179fc9472b3b51f'
receipt={'status':'DEVELOPMENT_PREVIEW_PROMOTED_WITH_EXPLICIT_RUNTIME_LIMITATIONS','fixture_source_commit':cid,'application_source_unchanged_since':'ee7985e4b78f1d8c9d89f727f29f3a025f3c63fc','application_qualified_source':'7405a61a7a605c9962cc7a630b06fef25c0a5c66','dist':str(old),'manifest_sha256':newhash,'leaves':newcount,'previous_dist':str(backup),'previous_manifest_sha256':oldhash,'previous_leaves':118,'source_test_only_bridge':sorted(allowed),'proofs':proofs,'postpromotion_usage_exit':r.returncode,'postpromotion_usage_log_sha256':sha(runtime/'normal-launcher-usage.log'),'provider_sha256':sha(provider),'shipping_approved':False,'known_limits':['Unresolved stock-provider SOCKS5 CONNECT0.0.0.0:0 observed; no arbitrary destination accepted, CF03/08open.','Prior generated-file read exception unestablished; all required subject positives explicitly associated, original failures retained.','Original emptyV2/hybrid creator defects; broader client/plugin/performance parity unclaimed.'],'original_head':git(R,'rev-parse','HEAD').decode().strip(),'original_index_sha256':sha(R/'.git/index'),'original_client_signalled_or_attached':False,'real_profile_or_payload_selected':False}
(W/'dist-promotion.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':receipt['status'],'manifest':newhash,'leaves':newcount,'rollback':str(backup),'usage_exit':r.returncode}))
