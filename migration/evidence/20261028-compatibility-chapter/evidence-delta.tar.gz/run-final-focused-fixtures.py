from pathlib import Path
import argparse,hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;N=Path('/home/yurii/Java/BiglyBTC');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=N)
p=argparse.ArgumentParser();p.add_argument('--lane',choices=['gcc','clang','san'],required=True);a=p.parse_args();lane=a.lane
B={'gcc':N/'build/persistent-peer-accounting-20261021/bound-gcc','clang':N/'build/saved-services-20261018/clang','san':N/'build/saved-services-20261018/sanitized-desktop'}[lane]
O=W/('focused-final-'+lane+'-r2');O.mkdir();CID=git('rev-parse','HEAD').decode().strip();assert CID=='61fc63b5bcb783dd82b3bafb9eb62ecee578cc02' and not git('status','--porcelain')
changed=git('diff','--name-only','ee7985e4b78f1d8c9d89f727f29f3a025f3c63fc',CID).decode().splitlines();assert set(changed)=={'preview/native/tests/file_operation_dialog_tests.cpp','preview/native/tests/network_proxy_owner_tests.cpp'}
source={s:sha(N/s) for s in git('ls-files','-z','--','preview/native').decode().split('\0') if s};(O/'build-source.json').write_text(json.dumps(source,indent=2)+'\n')
query=json.loads(subprocess.check_output(['ctest','--test-dir',str(B),'--show-only=json-v1']))
paths=set()
required=set(json.loads((W/'gcc-r8/plan.json').read_bytes())['tests'])
chosen=[test for test in query['tests'] if test['name'] in required];assert len(chosen)==40
for test in chosen:
 for arg in test['command']:
  q=Path(arg)
  if q.is_absolute() and q.is_file():paths.add(str(q))
for rel in ['app/BiglyBTC','app/BiglyBTC-headless','biglybtc-preview-smoke','app/BiglyBTC-plugin-azlocprov.so','app/BiglyBTC-plugin-SpeedScheduler.so']:paths.add(str(B/rel))
before={s:sha(s) for s in sorted(paths)};(O/'image-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
private=W/'portable-gcc-ee798-r2/runtime/candidate/usr/lib/biglybtc';captures=O/'captures';captures.mkdir();runtime=O/'xdg-runtime';runtime.mkdir(mode=0o700)
env={k:v for k,v in os.environ.items() if k not in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS','LD_PRELOAD','LD_AUDIT']};env.update(QT_QPA_PLATFORM='offscreen',QT_SCALE_FACTOR='1',BIGLYBTC_FILEOPS_CAPTURE_DIRECTORY=str(captures),XDG_RUNTIME_DIR=str(runtime),LD_LIBRARY_PATH=str(private/'lib')+':'+str(private/'qt/lib'),QT_PLUGIN_PATH=str(private/'qt/plugins'),QT_QPA_PLATFORM_PLUGIN_PATH=str(private/'qt/plugins/platforms'))
if lane=='san':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
rows=[]
def run(name,command):
 start=time.monotonic()
 with (O/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=N,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 row={'name':name,'command':list(map(str,command)),'exit':r.returncode,'seconds':time.monotonic()-start};rows.append(row);(O/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(lane,name,r.returncode,flush=True);assert r.returncode==0
 assert git('rev-parse','HEAD').decode().strip()==CID and not git('status','--porcelain') and all(sha(N/s)==h for s,h in source.items())
run('build',['nice','-n','5','cmake','--build',str(B),'--parallel','1','--target','biglybtc-file-operation-dialog-tests','biglybtc-network-proxy-owner-tests'])
run('file-dialog',[str(B/'tests/biglybtc-file-operation-dialog-tests'),'interruptedReplacementReviewShowsFreshBackupAndLeavesConsentUntransferred','explicitReplacementShowsRetainedPreimageAndRequiresFreshConsent','-o',str(O/'file-dialog.txt')+',txt','-o',str(O/'file-dialog.xml')+',junitxml'])
run('proxy',[str(B/'tests/biglybtc-network-proxy-owner-tests'),'actualRemoteWebSeedPayload:SOCKS5-remote-name','actualRemoteWebSeedPayload:SOCKS5-redirected-name','-o',str(O/'proxy.txt')+',txt','-o',str(O/'proxy.xml')+',junitxml'])
for name in ['file-dialog','proxy']:
 r=ET.parse(O/(name+'.xml')).getroot();assert int(r.attrib['failures'])==0 and int(r.attrib.get('errors','0'))==0 and len(list(r.iter('testcase')))==4
allowed={str(B/'tests/biglybtc-file-operation-dialog-tests'),str(B/'tests/biglybtc-network-proxy-owner-tests')};differences={s:{'before':h,'after':sha(s)} for s,h in before.items() if sha(s)!=h};assert set(differences)<=allowed,differences
result={'status':'PASS_FOCUSED_TEST_ONLY_LAYOUT_AND_DIAGNOSTICS','lane':lane,'source_commit':CID,'application_source_unchanged_since':'ee7985e4b78f1d8c9d89f727f29f3a025f3c63fc','application_and_other_registered_images_unchanged':True,'changed_images':differences,'commands':rows,'captures':{q.name:sha(q) for q in captures.glob('*.png')},'sanitizer_environment':{k:env[k] for k in ['ASAN_OPTIONS','UBSAN_OPTIONS'] if k in env}}
assert set(result['captures'])=={'file-operation-replacement-preview.png','file-operation-recovery-review.png'};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(lane,'focused complete',flush=True)
