#pragma once
#include <cstdint>
namespace biglybtc::app::country_bundle {
inline constexpr char Basename[] = "BiglyBTC-plugin-azlocprov.so";
inline constexpr char Sha256[] = "dbe306d4ed1eb3e54ff52f322f285a09d00d07939bd2e271c4c75917e9d917ba";
inline constexpr std::uint64_t Bytes = 39456;
inline constexpr char Version[] = "0.1.0";
}
