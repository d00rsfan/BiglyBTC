#pragma once
#include <cstdint>
#include <string_view>
namespace biglybtc::app::scheduler_bundle {
inline constexpr auto Sha256="736860113143539cc658a14219246f6d4468e64d0da6a21c21108dcf828ea5d3";
inline constexpr std::uint64_t Bytes=60936;
inline constexpr auto Version="0.1.0";
}
