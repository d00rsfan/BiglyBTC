Root-reviewed two explicit phases, source-only at freeze; root separately authorized actual GCC execution. No build/reconfigure/promotion in wrapper/qualifier. Current input is exactee798 metadata descendant of actual7405 build; full944tracked source graph identical. Producer amendment checks ancestry +no native/stager diff, preserves original actual build receipt/CID and writes a separate source-association sidecar. Qualifier81f7 remains byte-exact.

GCC uses pinned actual gcc-final-r4 build/catalog and explicit39+1 PASS reuse receipt, not invented full40 rerun. Clang waits actual full40 PASS result/XML from root same-source lane, requires explicit actual gate SHA/source/build/catalog; future hashes are never guessed. DEB configure may be ON for install/smoke targets, but recipe builds no DEB and runs no build beyond Ninja dry-run; dirty generated deps refuse, never silently settle/rebuild.

W=/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027; H=$W/portable-final/amendments/metadata-build-association. Exact current input SHA f411e77d3459147f041efb48d51ca9392ecc92688ae6e7861144dd07ad6d3ddd.

nice -n5 python3 $H/root_execute.py prepare --lane gcc --input-sha256 f411e77d3459147f041efb48d51ca9392ecc92688ae6e7861144dd07ad6d3ddd --output $W/portable-gcc-ee798-r1

Inspect actual prepared.json/completion/source-association/log, then use printed exact prepared SHA:
nice -n5 python3 $H/root_execute.py qualify --lane gcc --input-sha256 f411e77d3459147f041efb48d51ca9392ecc92688ae6e7861144dd07ad6d3ddd --prepared-sha256 ACTUAL_PREPARED64 --output $W/portable-gcc-ee798-r1

Clang prepare additionally supplies --build-receipt ACTUAL --source-map ACTUAL --catalog ACTUAL --gate ACTUAL_PASS_RESULT --gate-sha256 ACTUAL64 with --lane clang and fresh output; qualify uses same phase/actual prepared SHA. Existing actual buildroot /home/yurii/Java/BiglyBTC/build/saved-services-20261018/clang.

Space guard before preparation and qualification: two full baseline-size trees +all frozen binary sizes +512MiB W headroom, /tmp512MiB headroom. Actual olddist is104789025 nonlink bytes (~101MiB), both provider/Qt aliases remain exact. Earlier free snapshot W3.66GB/tmp8.14GB is observational only; guard rechecks after compilers and before copies. Run lanes sequentially to avoid duplicate transient working sets. Keep each result/candidate/full previous-dist rollback; no cleanup of failed outputs/inactive profiles here. Current olddist118/e34ade, originalHEAD/index and provider98279/catalog5901 are checked before/after, including failure.

Actual qualifiers: normal noargs boundary, offscreen preview8s controlled stop, smoke+9positive suites+11deployment controls; screenshots retained under OUTPUT/runtime/verification/captures. Original-manifest deployment uses approved original DSO as BASE; copied privatepositive owners independently prove staged image. Visual review/promotion is root-only later; wrapper never changes dist.

Performance: CHAPTER asks final applicable observations but portable runtime times/Qt row counts are correctness observations, not equivalent-workload performance evidence. Existing file-operation inode read counters and target-scoped disk-latency actual tests supply bounded work/latency observations. CF08 CPU/private-memory/throughput/noise repeats and public-swarm comparison remain open with P04/P11/P12; proposed percentages are not approved chapter acceptance constants. Do not label this chapter or portable bundle whole performance-closed. If root wants additional finite in-chapter observation, record actual wrapper wall timings+hardware/load as descriptive only; no new major benchmark/provider work required for this bounded milestone.

Historical parent ADOPTION.md remains for full retained gates; its earlier script paths are superseded by this root wrapper. Every failed command persists; expected preview124 remains controlled-stop only.
