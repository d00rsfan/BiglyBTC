#!/usr/bin/env python3
"""Root-only explicit prepare/qualify phases. No build, reconfigure or promotion."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/compatibility-chapter-20261027'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(value,why):
    if not value:raise ValueError(why)
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root)
def field(value):
    path=Path(value['path']);need(path.is_absolute() and not path.is_symlink() and path.resolve(strict=True)==path and sha(path)==value['sha256'],'Changed/noncanonical input: '+str(path));return path

def protect(inputs):
    need(git(N,'rev-parse','HEAD').decode().strip()==inputs['qualification_source_commit'] and not git(N,'status','--porcelain'),'Native source changed/dirty')
    need(git(R,'rev-parse','HEAD').decode().strip()==inputs['original_head'] and sha(R/'.git/index')==inputs['original_index_sha256'],'Original HEAD/index changed')
    expected=json.loads(field(inputs['expected_source']).read_bytes())
    need({p:sha(N/p) for p in git(N,'ls-files','-z','--','preview/native').decode().split('\0') if p}==expected,'Final tracked source differs')
    d=N/'dist';m=json.loads((d/'BUILD_MANIFEST.json').read_bytes());need(sha(d/'BUILD_MANIFEST.json')==inputs['old_dist_manifest_sha256'] and len(m['files_sha256'])==118,'Old published dist changed')
    for name,pin in m['files_sha256'].items():
        p=d/name;need(p.resolve(strict=True).is_relative_to(d) and p.is_file() and sha(p)==pin,'Published dist leaf changed')
    need(sha(W/'provider-traffic-v3/install/lib/libtorrent-rasterbar.so.2.0.12')==inputs['provider_sha256'],'Exact provider changed')
    need(sha(N/'preview/native/engine/runtime-binding/provider-traffic-runtime.json')==inputs['provider_manifest_sha256'],'Exact runtime approval changed')
    return sum(p.stat().st_size for p in d.rglob('*') if p.is_file() and not p.is_symlink())

def space(dist_bytes,binaries=()):
    # Two complete trees plus frozen input copies and explicit work/log headroom.
    required=2*dist_bytes+sum(Path(p).stat().st_size for p in set(binaries))+512*1024*1024
    free=shutil.disk_usage(W).free;temporary=shutil.disk_usage('/tmp').free
    need(free>=required and temporary>=512*1024*1024,'Insufficient owned staging headroom; coordinate cleanup separately')
    return {'required_w_bytes':required,'available_w_bytes':free,'required_tmp_bytes':512*1024*1024,'available_tmp_bytes':temporary,'cleanup_performed':False}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('phase',choices=('prepare','qualify'))
    p.add_argument('--lane',choices=('gcc','clang'),required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--input',type=Path,default=H/'current-input.json');p.add_argument('--input-sha256',required=True)
    p.add_argument('--build-receipt',type=Path);p.add_argument('--source-map',type=Path);p.add_argument('--catalog',type=Path)
    p.add_argument('--gate',type=Path);p.add_argument('--gate-sha256');p.add_argument('--prepared-sha256')
    a=p.parse_args();own=json.loads((H/'manifest.json').read_bytes())
    for name,pin in own['artifacts_sha256'].items():need(sha(H/name)==pin,'Frozen wrapper/recipe changed: '+name)
    inputs=json.loads(field({'path':str(a.input),'sha256':a.input_sha256}).read_bytes());dist_bytes=protect(inputs)
    out=a.output;need(out.is_absolute() and out.is_relative_to(W) and out.parent.resolve(strict=True)==out.parent,'Owned canonical output parent required')
    env={k:v for k,v in os.environ.items() if k not in ('ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','LD_PRELOAD','LD_AUDIT','PYTHONPATH','PYTHONHOME')};env['PYTHONDONTWRITEBYTECODE']='1'
    rows=[]
    def run(name,argv,timeout):
        row={'name':name,'argv':list(map(str,argv))};rows.append(row);start=time.monotonic();child=None
        with (out/(name+'.log')).open('x') as log:
            try:
                child=subprocess.Popen(row['argv'],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                while child.poll() is None:
                    left=timeout-(time.monotonic()-start);need(left>0,'Deadline: '+name)
                    try:child.wait(timeout=min(30,left))
                    except subprocess.TimeoutExpired:print(name+' active; full log retained',flush=True)
            finally:
                if child is not None and child.poll() is None:
                    os.killpg(child.pid,signal.SIGTERM)
                    try:child.wait(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                log.flush();row.update(exit=None if child is None else child.returncode,seconds=time.monotonic()-start,log_sha256=sha(out/(name+'.log')));save(out/(a.phase+'-commands.json'),rows)
        need(child is not None and child.returncode==0,'Actual command failed: '+name)
    if a.phase=='prepare':
        need(not out.exists() and not out.is_symlink(),'Fresh attempt only');out.mkdir(mode=0o700)
        refs=inputs['gcc_actual_inputs'];gcc={name:field(value) for name,value in refs.items()}
        if a.lane=='gcc':
            need(not any((a.build_receipt,a.source_map,a.catalog,a.gate,a.gate_sha256)),'GCC uses pinned actual7405 receipts only')
            receipt,source,catalog=gcc['build-receipt.json'],gcc['build-source.json'],gcc['registered-tests.json'];gate=gcc['result.json']
            result=json.loads(gate.read_bytes());need(result['status']=='PASS_GCC40_WITH_EXPLICIT_UNCHANGED_RESULT_REUSE' and result['tests']==40 and result['all_reused_command_inputs_and_generated_binding_bytes_unchanged'] is True,'Exact reviewed GCC39+1 reuse required')
            need(all(row['exit']==0 for row in json.loads(gcc['commands.json'].read_bytes())),'GCC actual build/focused test failed')
        else:
            need(all((a.build_receipt,a.source_map,a.catalog,a.gate,a.gate_sha256)),'Clang requires actual completed receipt/source/catalog/gate + exact gate SHA')
            receipt,source,catalog=a.build_receipt,a.source_map,a.catalog;gate=field({'path':str(a.gate),'sha256':a.gate_sha256})
            result=json.loads(gate.read_bytes());need(result['status']=='PASS_COHERENT_CONSUMER_LANE' and result['lane']=='clang' and result['source_commit']==inputs['qualification_source_commit'] and result['tests']==40 and all(x['exit']==0 for x in result['commands']),'Clang actual complete40 gate must pass')
            wanted=json.loads(gcc['result.json'].read_bytes());names=set(wanted['actually_reexecuted_tests']+wanted['unchanged_passed_tests_reused'])
            cases=ET.parse(gate.parent/'tests.xml').getroot().findall('.//testcase');need({x.attrib['name'] for x in cases}==names and all(x.find('failure') is None and x.find('skipped') is None and x.attrib.get('status')=='run' for x in cases),'Actual Clang40 no-skips XML required')
        save(out/'space-before.json',space(dist_bytes))
        run('prepare-completion',[sys.executable,H/'prepare_completion.py','--source-commit',inputs['qualification_source_commit'],'--lane',a.lane,'--build-root',inputs['build_roots'][a.lane],'--source-map',source,'--build-receipt',receipt,'--ctest-catalog',catalog,'--output',out/'completion.json'],120)
        completion=json.loads((out/'completion.json').read_bytes());save(out/'space-after-completion.json',space(dist_bytes,completion['binary_sha256']))
        association=out/'completion.source-association.json';actual=json.loads(association.read_bytes())
        record={'schema':1,'status':'PREPARED_NOT_EXECUTED','lane':a.lane,'source_commit':inputs['qualification_source_commit'],'actual_build_source_commit':actual['actual_build_source_commit'],'input':str(a.input),'input_sha256':a.input_sha256,'completion_sha256':sha(out/'completion.json'),'association_sha256':sha(association),'gate':str(gate),'gate_sha256':sha(gate),'recipe_sha256':sha(H/'qualify.py'),'promoted':False}
        save(out/'prepared.json',record);protect(inputs)
        print(json.dumps({'prepared':str(out/'prepared.json'),'prepared_sha256':sha(out/'prepared.json'),'completion_sha256':record['completion_sha256'],'actual_build_source_commit':actual['actual_build_source_commit'],'next':'Use explicit qualify phase after root review; no candidate/runtime executed.'}),flush=True)
    else:
        need(out.is_dir() and not out.is_symlink() and a.prepared_sha256,'Existing root-reviewed prepared attempt required')
        prepared=field({'path':str(out/'prepared.json'),'sha256':a.prepared_sha256});record=json.loads(prepared.read_bytes())
        need(record['status']=='PREPARED_NOT_EXECUTED' and record['lane']==a.lane and record['input_sha256']==a.input_sha256 and record['source_commit']==inputs['qualification_source_commit'],'Wrong prepared lane/source')
        field({'path':record['gate'],'sha256':record['gate_sha256']});need(sha(out/'completion.json')==record['completion_sha256'] and sha(out/'completion.source-association.json')==record['association_sha256'],'Prepared completion/association changed')
        completion=json.loads((out/'completion.json').read_bytes());save(out/'space-before-qualification.json',space(dist_bytes,completion['binary_sha256']))
        try:
            run('private-runtime',["nice","-n","5",sys.executable,H/'qualify.py','--completion',out/'completion.json','--completion-sha256',record['completion_sha256'],'--output',out/'runtime'],1800)
            value=json.loads((out/'runtime/verification/result.json').read_bytes());need(value['status']=='PRIVATE_RUNTIME_QUALIFIED_NOT_PROMOTED' and value['source']==record['source_commit'] and value['lane']==a.lane,'Incomplete private runtime result')
            save(out/'result.json',{'status':value['status'],'source_commit':record['source_commit'],'actual_build_source_commit':record['actual_build_source_commit'],'completion_sha256':record['completion_sha256'],'runtime_result_sha256':sha(out/'runtime/verification/result.json'),'candidate':value['candidate'],'rollback':value['rollback'],'promoted':False})
            print(json.dumps({'status':value['status'],'lane':a.lane,'source':value['source'],'candidate':value['candidate'],'captures':len(value['captures']),'promoted':False}),flush=True)
        finally:protect(inputs)
if __name__=='__main__':main()
