#!/usr/bin/env python3
"""Finish only uncovered frozen portable cases; retain the failed complete attempt."""
import argparse,hashlib,importlib.util,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
W=Path('/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027')
P=W/'portable-clang-ee798-r2'; V=P/'runtime/verification'
Q=W/'portable-final/amendments/clang-settled-build'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(value,reason):
    if not value:raise ValueError(reason)
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

def rows(text,success=True):
    # QTest prints method(data) rather than method()(data).
    found=re.findall(r'^PASS\s*:\s+NetworkProxyOwnerTests::(\w+)\(([^\n]*)\)\s*$',text,re.M)
    values=[m+('('+tag+')' if tag else '') for m,tag in found]
    need(len(values)==len(set(values)),'Repeated actual QTest row')
    totals=re.findall(r'Totals:\s+(\d+) passed,\s+(\d+) failed,\s+(\d+) skipped',text)
    need(len(totals)==1 and int(totals[0][0])==len(values),'Unaccounted actual QTest rows')
    if success:need(totals[0][1:] == ('0','0') and not re.search(r'^(?:FAIL!|SKIP)\s*:',text,re.M),'QTest failure/skip')
    return set(values)-{'initTestCase','cleanupTestCase'},totals[0]

def inventory():
    functions=(P/'proxy-case-inventory/functions.log').read_text().splitlines()
    need(all(re.fullmatch(r'\w+\(\)',x) for x in functions),'Unexpected function inventory')
    methods=[x[:-2] for x in functions];expected={}
    for line in (P/'proxy-case-inventory/datatags.log').read_text().splitlines():
        parts=line.split(' ',2);need(len(parts)>=2 and parts[0]=='NetworkProxyOwnerTests' and parts[1] in methods,'Unexpected actual data inventory')
        key=parts[1]+('('+parts[2]+')' if len(parts)==3 else '')
        need(key not in expected,'Duplicate actual data tag');expected[key]=parts[1]
    need(set(expected.values())==set(methods),'Incomplete function/data inventory')
    prefix,total=rows((V/'cohort-network-proxy-owner.log').read_text(),False)
    need(total==('14','1','0'),'Prior failure record changed')
    trace,unused=rows((P/'diagnostic-proxy-redirect-r1/stdout.log').read_text())
    failed='actualRemoteWebSeedPayload(SOCKS5-redirected-name)'
    need(trace=={failed},'Targeted reproduction does not cover exact failed method')
    need(prefix<=set(expected) and trace<=set(expected),'Unknown observed row')
    covered=prefix|trace;missing=set(expected)-covered
    remaining=[m for m in methods if any(expected[k]==m for k in missing)]
    need(all({k for k,m in expected.items() if m==method}<=missing for method in remaining),'Partially covered method would repeat cases')
    return expected,prefix,trace,missing,remaining

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--manifest-sha256',required=True);a=p.parse_args()
    need(os.getpriority(os.PRIO_PROCESS,0)>=5,'Run nice -n5')
    need(sha(H/'manifest.json')==a.manifest_sha256,'Wrong reviewed resume manifest')
    own=json.loads((H/'manifest.json').read_bytes())
    for n,pin in own['artifacts_sha256'].items():need(sha(H/n)==pin,'Changed resume artifact '+n)
    inputs=json.loads((H/'inputs.json').read_bytes())
    for path,pin in inputs['files_sha256'].items():need(sha(path)==pin,'Changed prior evidence '+path)
    old=module('portable_unchanged_qualifier',Q/'qualify.py');root=module('portable_unchanged_root',Q/'root_execute.py')
    root_inputs=json.loads((Q/'current-input.json').read_bytes());root.protect(root_inputs)
    frozen=json.loads((V/'frozen-inputs.json').read_bytes());completion=json.loads((P/'completion.json').read_bytes())
    def protect():
        root.protect(root_inputs)
        for origin,value in frozen.items():
            need(sha(value['path'])==value['sha256'],'Frozen copied input changed '+origin)
            need(sha(origin)==value['sha256'],'Original frozen input changed '+origin)
        for path,pin in completion['binary_sha256'].items():need(sha(path)==pin,'Original built input changed')
        for path,pin in completion['fixture_sha256'].items():need(sha(path)==pin,'Original fixture changed')
        need(old.bundle(P/'runtime/candidate')[0]==inputs['candidate_manifest_sha256'],'Staged candidate changed')
        need(old.bundle(P/'runtime/previous-dist')[0]==old.OLD_DIST_SHA,'Complete rollback changed')
        need(sha(old.DSO)==old.DSO_SHA and sha(old.PROVIDER)==old.PROVIDER_SHA and sha(old.N/'preview/native/engine/runtime-binding/provider-traffic-source-build-record.json')==old.RECORD_SHA,'Approved source/provider record changed')
    protect()
    previous=json.loads((V/'commands.json').read_bytes())
    need(previous[-1]['name']=='cohort-network-proxy-owner' and previous[-1]['exit_code']==1,'Prior complete attempt failure must remain explicit')
    for row in previous:
        need(sha(V/(row['name']+'.log'))==row['log_sha256'],'Changed prior command log')
        if row is not previous[-1]:need(row['exit_code']==row['expected_exit'] and not row['timed_out'] and row['failure'] is None,'Cannot reuse unsuccessful prior command')
    inv=json.loads((P/'proxy-case-inventory/receipt.json').read_bytes())
    need(all(r['exit_code']==0 and sha(r['log'])==r['log_sha256'] for r in inv['commands']),'Invalid actual inventory')
    diagnostic=json.loads((P/'diagnostic-proxy-redirect-r1/result.json').read_bytes())
    need(diagnostic['exit_code']==0 and sha(P/'diagnostic-proxy-redirect-r1/stdout.log')==diagnostic['stdout_sha256'] and sha(P/'diagnostic-proxy-redirect-r1/syscalls.log')==diagnostic['trace_sha256'],'Invalid actual targeted reproduction')
    managed_path=Path(frozen[next(k for k in frozen if Path(k).name=='biglybtc-network-proxy-owner-tests')]['path'])
    need(inv['binary_sha256']==sha(managed_path) and diagnostic['binary_sha256']==sha(managed_path) and diagnostic['provider_sha256']==old.DSO_SHA,'Inventory/targeted producer identity changed')
    expected,prefix,trace,missing,remaining=inventory()
    need(not missing and not remaining,'All proxy cases must already have actual positive coverage')
    need(a.output.is_absolute() and a.output.is_relative_to(W) and a.output.parent.resolve(strict=True)==a.output.parent and not a.output.exists() and not a.output.is_symlink(),'Fresh canonical owned output only')
    out=a.output;out.mkdir(mode=0o700);commands=[];captures=out/'captures';captures.mkdir()
    for path in (V/'captures').glob('*.png'):shutil.copy2(path,captures/path.name)
    env={k:v for k,v in os.environ.items() if not k.startswith('BIGLYBTC_') and k not in ('LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH','QT_SCALE_FACTOR','QT_AUTO_SCREEN_SCALE_FACTOR','PYTHONPATH','PYTHONHOME','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS')}
    private=P/'runtime/candidate/usr/lib/biglybtc';candidate=P/'runtime/candidate';sample=Path(json.loads((V/'generated-profile-archive.json').read_bytes())['source'])
    need(sample.is_dir(),'Original owned sample absent')
    env.update(PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',QT_SCALE_FACTOR='1',LD_LIBRARY_PATH=':'.join(map(str,[private/'lib',private/'qt/lib',candidate/'dependencies/libtorrent/usr/lib/x86_64-linux-gnu'])),QT_PLUGIN_PATH=str(private/'qt/plugins'),QT_QPA_PLATFORM_PLUGIN_PATH=str(private/'qt/plugins/platforms'),BIGLYBTC_PREVIEW_PROFILE=str(sample/'profile'),BIGLYBTC_PREVIEW_CAPTURE=str(sample/'classic-preview.png'),BIGLYBTC_CAPTURE_DIR=str(captures),BIGLYBTC_FILEOPS_CAPTURE_DIRECTORY=str(captures))
    for key in ('XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR'):env[key]=str(sample/key.lower())
    def run(name,argv,timeout=300):
        start=time.monotonic();child=None;error=None;path=out/(name+'.log')
        try:
            with path.open('x') as log:
                child=subprocess.Popen(list(map(str,argv)),cwd=old.N,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                while child.poll() is None:
                    left=timeout-(time.monotonic()-start);need(left>0,'Command timed out '+name)
                    try:child.wait(timeout=min(30,left))
                    except subprocess.TimeoutExpired:print(name+' active; raw log retained',flush=True)
                need(child.returncode==0,'Command failed '+name)
        except BaseException as e:error=str(e);raise
        finally:
            if child is not None and child.poll() is None:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            commands.append({'name':name,'argv':list(map(str,argv)),'exit_code':None if child is None else child.returncode,'seconds':time.monotonic()-start,'failure':error,'log_sha256':sha(path) if path.exists() else None,'sanitizer_environment':{}});save(out/'commands.json',commands)
        return path.read_text()
    try:
        save(out/'case-plan.json',{'expected':expected,'prior_successful_cases':sorted(prefix),'targeted_successful_cases':sorted(trace),'remaining_cases':sorted(missing),'remaining_methods':remaining,'original_failure_preserved':True,'whole_proxy_suite_exit_zero_claimed':False})
        catalog={v['name']:v for v in json.loads((V/'ctest_catalog.json').read_bytes())['tests']};cohort=[]
        for name in ('provider-payload-counter','selected-swarm-admission','persistent-native-peer-session','managed-download'):
            text=(V/('cohort-'+name+'.log')).read_text();totals=re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped',text);need(len(totals)==1,'Missing prior successful cohort totals');cohort.append({'name':name,'status':'UNCHANGED_PRIOR_PASS','qt_rows':int(totals[0]),'log_sha256':sha(V/('cohort-'+name+'.log'))})
        union=prefix|trace;need(union==set(expected),'Proxy required case coverage incomplete')
        cohort.append({'name':'network-proxy-owner','status':'ALL_REQUIRED_CASES_PASS_WITH_EXPLICIT_UNCHANGED_CASE_REUSE','required_cases':len(expected),'prior_successful_cases':len(prefix),'targeted_reproduction_cases':len(trace),'unique_covered_cases':len(union),'whole_suite_exit_zero_claimed':False,'original_full_run_status':'FAIL_UNRESOLVED_REDIRECT_PROXY_DESTINATION','coverage':{'prior':str(V/'cohort-network-proxy-owner.log'),'targeted':str(P/'diagnostic-proxy-redirect-r1/stdout.log')}})
        for name in ('network-binding-owner','torrent-intake-file-options-ui','file-operation-dialog','torrent-creation-dialog'):
            command=[frozen[catalog[name]['command'][0]]['path'],*catalog[name]['command'][1:]];text=run('cohort-'+name,command);totals=re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped',text);need(len(totals)==1,'Missing successful Qt totals '+name);cohort.append({'name':name,'status':'PASS','qt_rows':int(totals[0])})
        actual_captures={p.name:p for p in captures.glob('*.png')};retained=set(json.loads((Q/'retained-captures.json').read_bytes()));need(retained|{'torrent-intake-file-destinations.png','torrent-intake-tracker-tiers.png','file-operation-preview.png','torrent-creation-preview.png'}<=actual_captures.keys(),'Required actual GUI captures absent')
        deploy=[frozen.get(arg,{'path':arg})['path'] for arg in catalog[old.DEPLOY]['command']];deploy[deploy.index('--provider')+1]=str(old.DSO)
        original_preload=catalog[old.DEPLOY]['command'];preloads=original_preload[original_preload.index('--preload')+1].split(':');deploy[deploy.index('--preload')+1]=':'.join(frozen[str(Path(p).resolve(strict=True))]['path'] for p in preloads)
        text=run('cohort-'+old.DEPLOY,deploy,240);receipt=json.loads(text.strip().splitlines()[-1]);need(receipt.get('mode')=='traffic' and type(receipt.get('cases')) is int,'Wrong actual relocation receipt');copy=out/'relocation';shutil.copytree(Path(receipt['receipt']).parent,copy);relocation=json.loads((copy/'result.json').read_bytes())
        need(relocation['provider_sha256']==old.DSO_SHA and relocation['provider']==str(old.DSO) and relocation['provider_unchanged'] is True and len(relocation['cases'])==receipt['cases'] and all(row['exit_code']==0 for row in relocation['cases']) and {row['case'] for row in relocation['cases']}=={'copied','moved-before-load','open-denied','mapped-inode-mismatch','hash-content-mismatch','actual-fifo','actual-same-bytes-replaced-inode','actual-loaded-name-missing','actual-distro-copy','preload','mapped-interposition-after-env-removed'},'Incomplete original11 actual controls')
        cohort.append({'name':old.DEPLOY,'status':'PASS','cases':receipt['cases'],'base_provider':str(old.DSO),'direct_staged_provider_test':False,'receipt_sha256':sha(copy/'result.json')})
        protect();smoke=re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped',(V/'smoke-private-runtime.log').read_text());need(len(smoke)==1,'Missing reused smoke totals')
        result={'schema':1,'status':'PRIVATE_RUNTIME_COVERED_WITH_EXPLICIT_UNCHANGED_CASE_REUSE_NOT_PROMOTED','source':completion['source_commit'],'lane':'clang','candidate':str(candidate),'manifest_sha256':inputs['candidate_manifest_sha256'],'rollback':str(P/'runtime/previous-dist'),'completion_sha256':sha(P/'completion.json'),'recipe_manifest_sha256':a.manifest_sha256,'prior_failed_attempt':str(P/'runtime/failure.json'),'unresolved_limitation':'Original full network-proxy-owner process had14PASS/1FAIL: SOCKS5 redirect unplanned destination. Exact single-row reproduction passed; original failing endpoint unknown. No source cause/fix or full-suite exit0 is claimed.','cohort':cohort,'smoke_qt_rows':int(smoke[0]),'captures':{n:sha(v) for n,v in actual_captures.items()},'loader_stage_launch_smoke_reused_commands_sha256':sha(V/'commands.json'),'provider_sha256':old.DSO_SHA,'provider_manifest_sha256':old.PROVIDER_SHA,'record_sha256':old.RECORD_SHA,'builds':0,'shipping_approved':False,'promoted':False,'manual_wayland_or_public_or_causal_credit':False}
        save(out/'result.json',result);print(json.dumps({'status':result['status'],'cases':len(union),'cohorts':len(cohort),'captures':len(actual_captures),'result':str(out/'result.json')}),flush=True)
    except BaseException as e:save(out/'failure.json',{'status':'FAIL','reason':str(e),'original_failure_preserved':True,'promoted':False});raise
    finally:protect()
if __name__=='__main__':main()
