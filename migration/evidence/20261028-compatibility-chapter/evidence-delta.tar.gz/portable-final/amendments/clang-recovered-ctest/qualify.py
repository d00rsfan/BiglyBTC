#!/usr/bin/env python3
"""Exact traffic-V3 portable qualification; root-frozen inputs, no build or promotion."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time

N = Path('/home/yurii/Java/BiglyBTC')
W = Path('/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027')
DSO = W / 'provider-traffic-v3/install/lib/libtorrent-rasterbar.so.2.0.12'
DSO_SHA = '98279a468e0fa5147876b6f22f8947f432c294dfc02fb50cf179fc9472b3b51f'
PROVIDER = N / 'preview/native/engine/runtime-binding/provider-traffic-runtime.json'
PROVIDER_SHA = '5901b34eeb25370106bdbf6185a80f0c86c62a837bf2e455f5619921db665760'
RECORD_SHA = '91218c17d3e74bb79a0fea0cfbbf3734e3422895e59f46fad4cb6b17e2927fd0'
OLD_DIST_SHA = 'e34ade281e7c8548c837968f7c095042d93862a4e1312f790feba464de3ba421'
DEPLOY = 'provider-traffic-runtime-deployment'
TESTS = {'provider-payload-counter': 'biglybtc-provider-payload-counter-tests',
         'selected-swarm-admission': 'biglybtc-selected-swarm-admission-tests',
         'persistent-native-peer-session': 'biglybtc-persistent-session-tests',
         'managed-download': 'biglybtc-managed-download-tests',
         'network-proxy-owner': 'biglybtc-network-proxy-owner-tests',
         'network-binding-owner': 'biglybtc-network-binding-owner-tests',
         'torrent-intake-file-options-ui': 'biglybtc-torrent-intake-dialog-tests',
         'file-operation-dialog': 'biglybtc-file-operation-dialog-tests',
         'torrent-creation-dialog': 'biglybtc-torrent-creation-dialog-tests'}
PRODUCTS = ['BiglyBTC', 'BiglyBTC-headless', 'biglybtc-preview-smoke']
PRODUCT_PATHS = {'BiglyBTC': 'app/BiglyBTC', 'BiglyBTC-headless': 'app/BiglyBTC-headless',
                 'biglybtc-preview-smoke': 'biglybtc-preview-smoke'}
MODULES = {'biglybtc_country_module': 'app/BiglyBTC-plugin-azlocprov.so',
           'biglybtc_scheduler_module': 'app/BiglyBTC-plugin-SpeedScheduler.so'}
WAYLAND_PREVIEW_SHA = '794cccedccbd20d4bd0c0f44d9447f3ffe2a5703fd9995a2a424d0a427085809'
CONTROLS = ['biglybtc-provider-traffic-runtime-deployment-driver',
            'biglybtc-runtime-interposition-driver', 'biglybtc-runtime-interposer']


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def pinned(path, pin):
    path = Path(path)
    require(re.fullmatch('[0-9a-f]{64}', pin) is not None, 'Missing full SHA256')
    require(path.is_absolute() and path.is_file() and not path.is_symlink()
            and path.resolve(strict=True) == path and sha(path) == pin,
            'Changed/noncanonical frozen input: ' + str(path))
    return path


def bundle(path):
    raw = path / 'BUILD_MANIFEST.json'
    value = json.loads(raw.read_text())
    for rel, digest in value['files_sha256'].items():
        leaf = path / rel
        require(not Path(rel).is_absolute() and '..' not in Path(rel).parts
                and leaf.resolve(strict=True).is_relative_to(path.resolve(strict=True))
                and leaf.is_file() and sha(leaf) == digest, 'Bundle byte/path mismatch: ' + rel)
    require({str(p.relative_to(path)) for p in path.rglob('*') if p.is_file()}
            == set(value['files_sha256']) | {'BUILD_MANIFEST.json'}, 'Bundle inventory mismatch')
    return sha(raw), value


def source(commit, expected, run):
    require(re.fullmatch('[0-9a-f]{40}', commit) is not None, 'Full source commit required')
    current = run('source-head', ['git', 'rev-parse', 'HEAD'], 30).strip()
    require(current == commit, 'Root source changed before private staging')
    run('source-clean', ['git', 'diff', '--quiet', commit, '--', 'preview/native',
                        'preview/migration/tools/stage_preview.py'], 30)
    tracked = run('source-tracked', ['git', 'ls-files', '-z', '--', 'preview/native'], 30).split('\0')
    untracked = run('source-untracked', ['git', 'ls-files', '--others', '--exclude-standard', '--', 'preview/native'], 30)
    require(not untracked.strip(), 'Nonignored untracked native source is not committed authority')
    actual = {}
    for name in sorted(x for x in tracked if x):
        leaf = Path(name)
        require(not leaf.is_absolute() and '..' not in leaf.parts, 'Unsafe tracked source name')
        p = N / leaf
        require(p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p,
                'Native tracked source must be a canonical regular file')
        actual[name] = sha(p)
    require(actual == expected, 'Complete native source map differs from root completion')
    return actual


def actual_init(text, path):
    # The normal launcher supplies canonical Qt LD_LIBRARY_PATH entries; the
    # preview wrapper may legitimately resolve the same image through the
    # installed $ORIGIN/../qt RPATH. Compare actual initialized canonical image,
    # never a search/trying-file line or a merely matching basename.
    expected = path.resolve(strict=True)
    for candidate in re.findall(r'calling init:\s+(.+?)\s*$', text, re.MULTILINE):
        actual = Path(candidate)
        try:
            if actual.is_absolute() and actual.resolve(strict=True) == expected:
                return True
        except (OSError, RuntimeError):
            pass
    return False


def file_field(value):
    require(type(value) is dict and set(value) == {'path', 'sha256'}, 'Exact file field required')
    return pinned(value['path'], value['sha256'])


def qualify(args, logs, run, env, state):
    require(os.getpriority(os.PRIO_PROCESS, 0) >= 5, 'Run this recipe with nice -n5')
    completion_path = pinned(args.completion, args.completion_sha256)
    completion = json.loads(completion_path.read_bytes())
    keys = {'schema', 'status', 'recipe_sha256', 'source_commit', 'source_map', 'build_root',
            'cmake_cache_sha256', 'primary_configure_receipt', 'primary_binding_header',
            'primary_build_receipt', 'ctest_catalog', 'binary_sha256', 'fixture_sha256',
            'instrumentation', 'sanitizer_environment', 'lane'}
    require(set(completion) == keys and completion['schema'] == 1
            and completion['status'] == 'ROOT_FROZEN_FINAL_PORTABLE_INPUTS'
            and completion['lane'] in ('gcc', 'clang')
            and completion['recipe_sha256'] == sha(Path(__file__)), 'Incomplete/wrong root completion')
    save(logs / 'completion.json', completion)
    state['source'] = completion['source_commit']
    source_map_path = file_field(completion['source_map'])
    expected_source = json.loads(source_map_path.read_bytes())
    require(type(expected_source) is dict and expected_source, 'Complete source map required')
    before = source(completion['source_commit'], expected_source, run)
    save(logs / 'source-map.json', before)
    build = Path(completion['build_root'])
    require(build.is_absolute() and build.is_dir() and build.resolve(strict=True) == build
            and build.is_relative_to(N / 'build'), 'Canonical existing native build required')
    pinned(build / 'CMakeCache.txt', completion['cmake_cache_sha256'])
    cache = (build / 'CMakeCache.txt').read_text()
    require('CMAKE_GENERATOR:INTERNAL=Ninja' in cache and 'BIGLYBTC_BUNDLE_QT:BOOL=ON' in cache
            and 'BIGLYBTC_PAYLOAD_COUNTER_TEST_LANE:STRING=Qualified' in cache
            and 'BIGLYBTC_CAUSAL_QUALIFICATION_TESTS:BOOL=OFF' in cache, 'Wrong bound Qt/counter/causal cache')
    configure = file_field(completion['primary_configure_receipt'])
    header = file_field(completion['primary_binding_header'])
    require(configure == build / 'engine/runtime-binding/configure-receipt.json'
            and header == build / 'engine/runtime-binding/persistent_runtime_config.hpp', 'Wrong generated binding paths')
    expected_receipt = {'manifest_sha256': PROVIDER_SHA, 'artifact_sha256': DSO_SHA,
        'artifact': str(DSO), 'provider_queue_observer': True, 'provider_traffic_v3': True,
        'causal_qualified': False, 'purpose': 'source-bound-qualification-only'}
    actual_receipt = json.loads(configure.read_bytes())
    require(actual_receipt == expected_receipt and all(type(actual_receipt[k]) is type(v)
            for k, v in expected_receipt.items()), 'Wrong actual primary configure receipt')
    pinned(PROVIDER, PROVIDER_SHA)
    pinned(PROVIDER.with_name('provider-traffic-source-build-record.json'), RECORD_SHA)
    pinned(DSO, DSO_SHA); require(DSO.stat().st_size == 9090088, 'Wrong traffic-V3 size')
    require(DSO_SHA in header.read_text() and PROVIDER_SHA in header.read_text()
            and '#define BIGLYBTC_PERSISTENT_RUNTIME_BOUND 1' in header.read_text(), 'Wrong compiled binding header')
    actual_build_path = file_field(completion['primary_build_receipt'])
    actual_build = json.loads(actual_build_path.read_bytes())
    require(type(actual_build.get('exit')) is int and actual_build['exit'] == 0
            and actual_build.get('source_manifest_sha256') == completion['source_map']['sha256']
            and type(actual_build.get('command')) is list and '--build' in actual_build['command']
            and str(build) in actual_build['command'], 'Wrong actual source-bound primary build receipt')
    targets = PRODUCTS + list(TESTS.values()) + CONTROLS + list(MODULES)
    require(set(targets) <= set(actual_build['command']), 'Root build did not cover every needed target')
    # Deliberately no build, autogen settle, reconfigure or stale-product repair.
    dry = run('no-stale-products', ['cmake', '--build', build, '--target', *targets, '--', '-n'], 60)
    require('no work to do' in dry.lower(), 'Stale output; root must rebuild separately and freeze NEW completion')
    catalog_file = file_field(completion['ctest_catalog'])
    catalog_text = run('test-catalog', ['ctest', '--test-dir', build, '--show-only=json-v1'], 60)
    catalog_value = json.loads(catalog_text)
    require(catalog_value == json.loads(catalog_file.read_bytes()), 'Actual catalog differs from root completion')
    catalog = {v['name']: v for v in catalog_value['tests']}
    require(set(TESTS) <= catalog.keys() and DEPLOY in catalog, 'Missing actual registered portable cohort')
    deploy = list(catalog[DEPLOY]['command'])
    require('--mode' in deploy and deploy[deploy.index('--mode') + 1] == 'traffic'
            and deploy[deploy.index('--provider') + 1] == str(DSO)
            and deploy[deploy.index('--manifest') + 1] == str(PROVIDER), 'Wrong exact webseed deployment command')
    fixture_paths = [N / 'preview/migration/tools/stage_preview.py', N / 'preview/native/packaging/preview.py',
                     Path(deploy[2]), PROVIDER, build / 'qt-runtime.json',
                     build / 'app/generated/country_approval.hpp', build / 'app/generated/scheduler_approval.hpp']
    require(fixture_paths[2].name == 'runtime_deployment_tests.py', 'Unexpected actual deployment fixture')
    require(type(completion['fixture_sha256']) is dict
            and set(completion['fixture_sha256']) == {str(p) for p in fixture_paths}, 'Exact fixture pins required')
    for path in fixture_paths: pinned(path, completion['fixture_sha256'][str(path)])
    qt_plan = json.loads((build / 'qt-runtime.json').read_bytes())
    require(qt_plan['qt_version'] == '6.12.0' and qt_plan['variant'] == 'bundled-qt', 'Exact private Qt6.12 plan required')
    require(sha(fixture_paths[1]) == WAYLAND_PREVIEW_SHA, 'Retain exact reviewed Wayland preview filter')
    paths = [build / PRODUCT_PATHS[name] for name in PRODUCTS] + [build / path for path in MODULES.values()]
    for name, target in TESTS.items():
        command = catalog[name]['command']
        require(Path(command[0]).name == target, 'Unexpected positive CTest executable')
        paths.append(Path(command[0]))
    for flag in ('--driver', '--interposition-driver', '--alternate'):
        paths.append(Path(deploy[deploy.index(flag) + 1]))
    preloads = deploy[deploy.index('--preload') + 1].split(':')
    require(all(preloads), 'Empty preload control path')
    preload_paths = [Path(p).resolve(strict=True) for p in preloads]
    paths.extend(preload_paths)
    require(type(completion['binary_sha256']) is dict
            and set(completion['binary_sha256']) == {str(p) for p in paths}, 'Exact built/control binary hashes required')
    for path in paths: pinned(path, completion['binary_sha256'][str(path)])
    require(set(p.name for p in paths) >= set(PRODUCTS) | set(TESTS.values())
            | {'biglybtc-provider-traffic-runtime-deployment-driver', 'biglybtc-runtime-interposition-driver'}, 'Missing frozen targets')
    # Actual ELF symbol/dependency checks prevent a false uninstrumented label.
    asan = ubsan = False
    needed = {}
    for index, path in enumerate(paths):
        symbols = run('input-elf-' + str(index), ['readelf', '--wide', '--dynamic', '--dyn-syms', path], 30)
        needed[str(path)] = set(re.findall(r'\(NEEDED\)\s+Shared library: \[([^]]+)\]', symbols))
        # A preload runtime's own exports are not proof that a target was instrumented.
        if path.is_relative_to(build):
            asan = asan or '__asan_init' in symbols or 'libasan.so' in symbols or 'libclang_rt.asan' in symbols
            ubsan = ubsan or '__ubsan_handle_' in symbols or 'libubsan.so' in symbols
    require(completion['instrumentation'] == {'address': asan, 'undefined': ubsan}, 'Actual instrumented binary/declaration mismatch')
    sanitizers = completion['sanitizer_environment']
    require(type(sanitizers) is dict and set(sanitizers) <= {'ASAN_OPTIONS', 'UBSAN_OPTIONS', 'LSAN_OPTIONS'}
            and all(type(value) is str for value in sanitizers.values()), 'Unexpected sanitizer environment')
    if asan:
        options = dict(item.split('=', 1) for item in sanitizers.get('ASAN_OPTIONS', '').split(':') if '=' in item)
        require(options.get('detect_leaks') == '1' and options.get('halt_on_error') == '1', 'Address/leak failure detection required')
    if ubsan:
        options = dict(item.split('=', 1) for item in sanitizers.get('UBSAN_OPTIONS', '').split(':') if '=' in item)
        require(options.get('halt_on_error') == '1' and options.get('print_stacktrace') == '1', 'Actual UBSan failure detection required')
    require(asan or 'ASAN_OPTIONS' not in sanitizers and 'LSAN_OPTIONS' not in sanitizers, 'ASan options for an uninstrumented cohort')
    require(ubsan or 'UBSAN_OPTIONS' not in sanitizers, 'UBSan options for an uninstrumented cohort')
    if 'LSAN_OPTIONS' in sanitizers:
        options = dict(item.split('=', 1) for item in sanitizers['LSAN_OPTIONS'].split(':') if '=' in item)
        require(options.get('exitcode', '23') != '0' and 'suppressions' not in options,
                'Leak reports must fail; no unpinned suppression file is accepted')
    for name, value in sanitizers.items():
        options = dict(item.split('=', 1) for item in value.split(':') if '=' in item)
        require(options.get('exitcode', '1') != '0' and 'suppressions' not in options,
                'Sanitizer errors must fail; no unpinned suppression path is accepted: ' + name)
    require(not asan and not ubsan and sanitizers == {}, 'Portable GCC/Clang product lane must be uninstrumented; sanitizer qualification remains separate')
    env.update(sanitizers)
    save(logs / 'sanitizer-environment.json', {'actual_address_instrumented': asan,
        'actual_undefined_instrumented': ubsan, 'environment': sanitizers})
    old_sha, old = bundle(N / 'dist'); require(old_sha == OLD_DIST_SHA and len(old['files_sha256']) == 118, 'Published dist baseline changed')
    state['baseline_verified'] = True
    save(logs / 'baseline.json', {'source': completion['source_commit'], 'dist_manifest_sha256': old_sha,
        'provider_sha256': DSO_SHA, 'provider_manifest_sha256': PROVIDER_SHA, 'record_sha256': RECORD_SHA,
        'recipe_sha256': sha(Path(__file__)), 'completion_sha256': args.completion_sha256,
        'configure_receipt_sha256': sha(configure), 'stager_sha256': sha(fixture_paths[0])})
    # Preserve a complete reviewed rollback; never rename/remove/modify dist.
    rollback = args.output / 'previous-dist'; shutil.copytree(N / 'dist', rollback, symlinks=True)
    require(bundle(rollback)[0] == old_sha, 'Complete rollback copy differs')
    bins = logs / 'test-bin'; bins.mkdir()
    frozen = {}
    for path in paths + fixture_paths:
        if str(path) in frozen: continue
        destination = bins / path.name; require(not destination.exists(), 'Repeated frozen input basename')
        shutil.copy2(path, destination); require(sha(path) == sha(destination), 'Qualification copy differs')
        frozen[str(path)] = str(destination)
    frozen_pins = {key: {'path': value, 'sha256': sha(Path(value))} for key, value in frozen.items()}
    save(logs / 'frozen-inputs.json', frozen_pins)
    for field in ('primary_configure_receipt', 'primary_binding_header', 'primary_build_receipt', 'ctest_catalog', 'source_map'):
        origin = file_field(completion[field]); shutil.copy2(origin, logs / (field + origin.suffix))
    candidate = args.output / 'candidate'
    run('stage', [sys.executable, fixture_paths[0], '--build', build, '--output', candidate,
        '--libtorrent-package', N / 'build/dependencies/packages/libtorrent-rasterbar2.0t64_2.0.12-1_amd64.deb',
        '--source-libtorrent', DSO, '--private-traffic-provider-manifest', PROVIDER], 300)
    candidate_sha, manifest = bundle(candidate); private = candidate / 'usr/lib/biglybtc'
    provider = manifest['libtorrent_runtime']
    require(provider['artifact_sha256'] == DSO_SHA and provider['artifact_bytes'] == 9090088
            and provider['instrumented'] is False and provider['causal_qualified'] is False
            and provider['shipping_approved'] is False and provider['runtime_manifest_sha256'] == PROVIDER_SHA
            and provider['source_build_record_sha256'] == RECORD_SHA
            and sha(private / 'lib/libtorrent-rasterbar.so.2.0.12') == DSO_SHA, 'Private exact provider differs')
    require(bundle(N / 'dist')[0] == old_sha, 'Published dist changed during staging')
    source(completion['source_commit'], before, lambda name, *a: run(name + '-after-stage', *a))
    for path in paths: pinned(path, completion['binary_sha256'][str(path)])
    for path in fixture_paths: pinned(path, completion['fixture_sha256'][str(path)])
    save(args.output / 'staged.json', {'status': 'STAGED_NOT_PROMOTED', 'source': completion['source_commit'], 'lane': completion['lane'],
        'candidate': str(candidate), 'manifest_sha256': candidate_sha, 'previous_dist_sha256': old_sha,
        'rollback': str(rollback), 'source_map_sha256': sha(logs / 'source-map.json'),
        'qualification_inputs_copied': True, 'completion_sha256': args.completion_sha256})
    print('STAGED_NOT_PROMOTED; all inputs frozen before shared cache may advance', flush=True)
    env.update(QT_QPA_PLATFORM='offscreen', QT_SCALE_FACTOR='1',
        LD_LIBRARY_PATH=':'.join(map(str, [private / 'lib', private / 'qt/lib', candidate / 'dependencies/libtorrent/usr/lib/x86_64-linux-gnu'])),
        QT_PLUGIN_PATH=str(private / 'qt/plugins'), QT_QPA_PLATFORM_PLUGIN_PATH=str(private / 'qt/plugins/platforms'))
    for name, path in [('BiglyBTC', private / 'bin/BiglyBTC'), ('BiglyBTC-headless', private / 'bin/BiglyBTC-headless'),
                       ('smoke', bins / 'biglybtc-preview-smoke'), *[(name, Path(frozen[catalog[name]['command'][0]])) for name in TESTS]]:
        loaded = run('loader-' + name, ['ldd', path], 30)
        require('not found' not in loaded, 'Unresolved frozen executable dependency: ' + name)
        # These exact three targets link biglybtc_ui + Qt6::Test, with no LT
        # engine library. Their actual direct ELF dependencies must agree.
        pure_ui = name in {'torrent-intake-file-options-ui', 'file-operation-dialog', 'torrent-creation-dialog'}
        original_path = (build / PRODUCT_PATHS[name]) if name in PRODUCT_PATHS else (build / PRODUCT_PATHS['biglybtc-preview-smoke']) if name == 'smoke' else Path(catalog[name]['command'][0])
        direct = needed[str(original_path)]
        if pure_ui:
            require({'libQt6Core.so.6', 'libQt6Gui.so.6', 'libQt6Widgets.so.6'} <= direct
                    and not any('libtorrent' in item for item in direct)
                    and 'libtorrent' not in loaded, 'Unexpected pure-UI dependency contract: ' + name)
        else:
            require(str(private / 'lib/libtorrent-rasterbar.so.2.0') in loaded,
                    'Executable did not load private traffic-V3: ' + name)
        # Qt6Test is the existing nonshipping test harness SDK exception below.
        # Every other actual Qt image must be the exact private candidate image.
        for library, origin in re.findall(r'^\s*(libQt6[^\s]+)\s+=>\s+(\S+)', loaded, re.MULTILINE):
            if library == 'libQt6Test.so.6': continue
            require(Path(origin).resolve(strict=True) == (private / 'qt/lib' / library).resolve(strict=True),
                    'Qt image escaped private runtime: ' + name + ' ' + library)
        for line in loaded.splitlines():
            if '/opt/Qt' in line:
                require(line.lstrip().startswith('libQt6Test.so.6 => '), 'Shipping Qt escaped private runtime')
    rpaths = {}; dynamic_logs = {}
    for relative in manifest['files_sha256']:
        leaf = candidate / relative
        if leaf.is_symlink() or leaf.read_bytes()[:4] != b'\x7fELF': continue
        dynamic = run('candidate-elf-' + str(len(rpaths)), ['readelf', '--dynamic', leaf], 30)
        dynamic_logs[relative] = dynamic
        relevant = [line.strip() for line in dynamic.splitlines() if '(RPATH)' in line or '(RUNPATH)' in line]
        require(all('/opt/Qt' not in line and str(build) not in line and '/tmp/' not in line
                    and str(W / 'provider-traffic-v3') not in line
                    and '/build/storage-20261025/provider-candidate' not in line for line in relevant), 'Nonportable runtime path: ' + relative)
        rpaths[relative] = relevant
    save(logs / 'all-elf-rpaths.json', rpaths); save(logs / 'all-elf-dynamic.json', dynamic_logs)
    runtime = lambda files: {k: v for k, v in files.items() if k.startswith('usr/lib/biglybtc/lib/') or k.startswith('usr/lib/biglybtc/qt/') or k.startswith('dependencies/libtorrent/usr/lib/')}
    require(sha(candidate / 'usr/bin/BiglyBTC-preview') == WAYLAND_PREVIEW_SHA, 'Installed preview/Wayland diagnostic handling changed')
    module_paths = {'usr/lib/biglybtc/lib/' + Path(path).name: build / path for path in MODULES.values()}
    for relative, origin in module_paths.items():
        require(sha(candidate / relative) == completion['binary_sha256'][str(origin)], 'Compiled approved module bytes changed during installation')
    prior_runtime, current_runtime = runtime(old['files_sha256']), runtime(manifest['files_sha256'])
    require(prior_runtime.keys() == current_runtime.keys(), 'Unexpected runtime inventory change')
    runtime_changed = [k for k in current_runtime if current_runtime[k] != prior_runtime[k]]
    require(all('libtorrent-rasterbar.so' in Path(k).name or k in module_paths for k in runtime_changed), 'Unexplained Qt/dependency runtime bytes changed')
    save(logs / 'runtime-comparison.json', {'files': len(current_runtime), 'unchanged': len(current_runtime)-len(runtime_changed), 'changed_exact_provider_aliases_or_bound_modules': runtime_changed})
    sample = Path(tempfile.mkdtemp(prefix='biglybtc-preview-', dir='/tmp')); sample.rmdir(); state['sample'] = str(sample)
    run('prepare-generated-profile', [candidate / 'BiglyBTC-preview', '--prepare', sample], 30)
    for key in ('XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_RUNTIME_DIR'):
        directory = sample / key.lower(); directory.mkdir(mode=0o700); env[key] = str(directory)
    env.update(BIGLYBTC_PREVIEW_PROFILE=str(sample / 'profile'), BIGLYBTC_PREVIEW_CAPTURE=str(sample / 'classic-preview.png'))
    sample_before_usage = {str(p.relative_to(sample)): sha(p) for p in sample.rglob('*') if p.is_file()}
    env['LD_DEBUG'] = 'libs'
    try: usage = run('normal-launcher-usage', [candidate / 'BiglyBTC'], 30, 2)
    finally: env.pop('LD_DEBUG', None)
    require(actual_init(usage, private / 'lib/libtorrent-rasterbar.so.2.0') and actual_init(usage, private / 'qt/lib/libQt6Core.so.6'), 'Actual normal-launcher dynamic loader escaped private runtime')
    require('Usage: BiglyBTC --profile ABSOLUTE_PROFILE' in usage, 'Unexpected normal launcher boundary')
    require({str(p.relative_to(sample)): sha(p) for p in sample.rglob('*') if p.is_file()} == sample_before_usage, 'Usage-only launcher touched the owned profile')
    env['LD_DEBUG'] = 'libs'
    try:
        preview_launch = run('preview-launcher-owned-bounded', ['timeout', '--signal=TERM', '--kill-after=5s', '8s', candidate / 'BiglyBTC-preview'], 20, 124)
    finally: env.pop('LD_DEBUG', None)
    require(actual_init(preview_launch, private / 'lib/libtorrent-rasterbar.so.2.0')
            and actual_init(preview_launch, private / 'qt/lib/libQt6Core.so.6')
            and actual_init(preview_launch, private / 'qt/plugins/platforms/libqoffscreen.so'),
            'Actual preview launcher did not initialize private Qt/offscreen/provider')
    generated = re.findall(r'BiglyBTC offline preview — generated sample data: (/tmp/biglybtc-preview-[^\s]+/profile)', preview_launch)
    require(len(generated) == 1, 'Actual preview generated-profile root missing')
    preview_sample = Path(generated[0]).parent
    require(preview_sample.parent == Path('/tmp') and preview_sample.name.startswith('biglybtc-preview-'), 'Preview profile scope')
    state['preview_sample'] = str(preview_sample)
    save(logs / 'preview-launcher-boundary.json', {'status': 'ACTUAL_PRIVATE_OFFSCREEN_START_CONTROLLED_STOP',
        'expected_timeout_exit': 124, 'generated_profile': generated[0], 'manual_ui_or_transfer_credit': False})
    smoke = run('smoke-private-runtime' , [bins / 'biglybtc-preview-smoke', '-o', '-,txt'], 300)
    total = re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped', smoke)
    require(len(total) == 1 and int(total[0]) >= 13, 'Incomplete retained smoke rows')
    captures = logs / 'captures'; captures.mkdir()
    expected_captures = json.loads((Path(__file__).parent / 'retained-captures.json').read_bytes())
    actual = {p.name: p for p in sample.glob('*.png')}
    require(set(expected_captures) <= actual.keys(), 'Missing earlier preview capture')
    for name, path in actual.items(): shutil.copy2(path, captures / name)
    results = []
    env['BIGLYBTC_CAPTURE_DIR'] = str(captures)
    env['BIGLYBTC_FILEOPS_CAPTURE_DIRECTORY'] = str(captures)
    for name in TESTS:
        command = [frozen[catalog[name]['command'][0]], *catalog[name]['command'][1:]]
        text = run('cohort-' + name, command, 300)
        totals = re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped', text)
        require(len(totals) == 1, 'Missing exact successful Qt totals: ' + name)
        results.append({'name': name, 'status': 'PASS', 'qt_rows': int(totals[0])})
    actual = {p.name: p for p in captures.glob('*.png')}
    required_dialogs = {'torrent-intake-file-destinations.png', 'torrent-intake-tracker-tiers.png', 'file-operation-preview.png', 'torrent-creation-preview.png'}
    require(required_dialogs <= actual.keys(), 'Missing current chapter GUI captures')
    # Preserve actual CTest command and manifest/path guard. Relocation's BASE
    # remains the original approved traffic-V3; its own copied/moved images are tested.
    # The private candidate itself was exercised by every positive owner above.
    deploy = [frozen.get(arg, arg) for arg in deploy]
    deploy[deploy.index('--provider') + 1] = str(DSO)
    deploy[deploy.index('--preload') + 1] = ':'.join(frozen[str(p)] for p in preload_paths)
    text = run('cohort-' + DEPLOY, deploy, 240)
    receipt = json.loads(text.strip().splitlines()[-1]); receipt_path = Path(receipt['receipt'])
    require(receipt.get('mode') == 'traffic' and type(receipt.get('cases')) is int, 'Wrong actual relocation receipt')
    copy = logs / 'relocation'; shutil.copytree(receipt_path.parent, copy)
    relocation = json.loads((copy / 'result.json').read_bytes())
    require(relocation['provider_sha256'] == DSO_SHA and relocation['provider'] == str(DSO)
            and relocation['provider_unchanged'] is True and len(relocation['cases']) == receipt['cases']
            and all(row['exit_code'] == 0 for row in relocation['cases'])
            and {row['case'] for row in relocation['cases']} == {'copied', 'moved-before-load', 'open-denied', 'mapped-inode-mismatch', 'hash-content-mismatch', 'actual-fifo', 'actual-same-bytes-replaced-inode', 'actual-loaded-name-missing', 'actual-distro-copy', 'preload', 'mapped-interposition-after-env-removed'}, 'Incomplete actual relocation controls')
    results.append({'name': DEPLOY, 'status': 'PASS', 'cases': receipt['cases'],
        'base_provider': str(DSO), 'direct_staged_provider_test': False, 'receipt_sha256': sha(copy / 'result.json')})
    require(bundle(N / 'dist')[0] == old_sha and bundle(candidate)[0] == candidate_sha
            and bundle(rollback)[0] == old_sha, 'Published/candidate/complete rollback changed')
    require(all(sha(Path(v)) == frozen_pins[k]['sha256'] for k, v in frozen.items()), 'Frozen input changed')
    require(sha(DSO) == DSO_SHA and sha(PROVIDER) == PROVIDER_SHA, 'Original approved deployment base changed')
    record = {'status': 'PRIVATE_RUNTIME_QUALIFIED_NOT_PROMOTED', 'source': completion['source_commit'], 'lane': completion['lane'],
        'candidate': str(candidate), 'manifest_sha256': candidate_sha, 'files': len(manifest['files_sha256']),
        'previous_dist_manifest_sha256': old_sha, 'source_map_sha256': sha(logs / 'source-map.json'),
        'completion_sha256': args.completion_sha256, 'configure_receipt_sha256': sha(logs / 'primary_configure_receipt.json'),
        'provider_sha256': DSO_SHA, 'provider_manifest_sha256': PROVIDER_SHA, 'record_sha256': RECORD_SHA, 'cohort': results,
        'smoke_qt_rows': int(total[0]), 'captures': {name: sha(captures / name) for name in actual},
        'all_elf_rpaths': len(rpaths), 'runtime_files': len(current_runtime), 'runtime_unchanged': len(current_runtime)-len(runtime_changed),
        'test_binaries_frozen_before_root_head_release': True, 'recipe_builds': 0,
        'instrumentation': completion['instrumentation'], 'sanitizer_environment': sanitizers,
        'nice': os.getpriority(os.PRIO_PROCESS, 0), 'promoted': False, 'rollback': str(rollback),
        'system_installation': False, 'original_profile_or_process_access': False,
        'shipping_approved': False, 'public_network_or_causal_credit': False}
    state['record'] = record; state['qualified'] = True
    return {'status': record['status'], 'source': record['source'], 'suites': len(results),
            'smoke_rows': int(total[0]), 'captures': len(actual), 'manifest': candidate_sha}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completion', type=Path, required=True)
    parser.add_argument('--completion-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    own = json.loads((here / 'manifest.json').read_bytes())
    for name, pin in own['artifacts_sha256'].items(): pinned(here / name, pin)
    require(args.output.is_absolute() and not args.output.exists() and not args.output.is_symlink()
            and args.output.parent.resolve(strict=True) == args.output.parent
            and args.output.is_relative_to(W), 'Fresh canonical owned W output required')
    args.output.mkdir(mode=0o700); logs = args.output / 'verification'; logs.mkdir()
    commands = []; state = {'qualified': False}
    env = {k: v for k, v in os.environ.items() if not k.startswith('BIGLYBTC_') and k not in
        ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH', 'QT_SCALE_FACTOR', 'QT_AUTO_SCREEN_SCALE_FACTOR',
         'PYTHONPATH', 'PYTHONHOME', 'ASAN_OPTIONS', 'UBSAN_OPTIONS', 'LSAN_OPTIONS')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    def run(name, argv, timeout=120, expected=0):
        started = time.monotonic(); timed_out = False; child = None; failure = None
        out_path = logs / (name + '.log')
        try:
            with out_path.open('x') as out:
                child = subprocess.Popen(list(map(str, argv)), cwd=N, env=env, stdout=out,
                                         stderr=subprocess.STDOUT, start_new_session=True)
                while True:
                    remaining = timeout - (time.monotonic() - started)
                    if remaining <= 0: timed_out = True; break
                    try: child.wait(timeout=min(30, remaining)); break
                    except subprocess.TimeoutExpired: print(name + ' running; full log retained', flush=True)
                require(not timed_out and child.returncode == expected, 'Command failed: ' + name)
        except BaseException as error:
            failure = str(error)
            raise
        finally:
            if child is not None and child.poll() is None:
                try: os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError: pass
                try: child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=5)
            if name == 'preview-launcher-owned-bounded' and out_path.is_file():
                roots = re.findall(r'BiglyBTC offline preview — generated sample data: (/tmp/biglybtc-preview-[^\s]+/profile)', out_path.read_text(errors='replace'))
                if len(roots) == 1:
                    owned = Path(roots[0]).parent
                    if owned.parent == Path('/tmp') and owned.name.startswith('biglybtc-preview-') and owned.resolve() == owned:
                        state['preview_sample'] = str(owned)
            commands.append({'name': name, 'argv': list(map(str, argv)), 'exit_code': None if child is None else child.returncode,
                'expected_exit': expected, 'timed_out': timed_out, 'failure': failure,
                'seconds': time.monotonic() - started, 'log_sha256': sha(out_path) if out_path.is_file() else None,
                'sanitizer_environment': {key: env[key] for key in ('ASAN_OPTIONS', 'UBSAN_OPTIONS', 'LSAN_OPTIONS') if key in env}})
            save(logs / 'commands.json', commands)
        return out_path.read_text()
    summary = None
    try:
        summary = qualify(args, logs, run, env, state)
    except BaseException as error:
        save(args.output / 'failure.json', {'status': 'FAIL', 'reason': str(error),
            'source': state.get('source'), 'completion_sha256': args.completion_sha256,
            'commands_sha256': sha(logs / 'commands.json') if (logs / 'commands.json').exists() else None,
            'promoted': False})
        raise
    finally:
        try:
            if state.get('sample') and Path(state['sample']).is_dir():
                # Retain this one generated fixture on success AND failure;
                # no /tmp scanning or unrelated original profile access occurs.
                sample = Path(state['sample']); archive = logs / 'generated-profile'
                shutil.copytree(sample, archive, symlinks=True)
                save(logs / 'generated-profile-archive.json', {'source': str(sample), 'archive': str(archive),
                    'files_sha256': {str(p.relative_to(archive)): sha(p) for p in sorted(archive.rglob('*')) if p.is_file() and not p.is_symlink()}})
            if state.get('preview_sample') and Path(state['preview_sample']).is_dir():
                sample = Path(state['preview_sample']); archive = logs / 'preview-launcher-generated-profile'
                shutil.copytree(sample, archive, symlinks=True)
                save(logs / 'preview-launcher-profile-archive.json', {'source': str(sample), 'archive': str(archive),
                    'files_sha256': {str(p.relative_to(archive)): sha(p) for p in sorted(archive.rglob('*')) if p.is_file() and not p.is_symlink()}})
            if state.get('baseline_verified'):
                require(bundle(N / 'dist')[0] == OLD_DIST_SHA, 'Published dist changed even on failed attempt')
        except BaseException as error:
            state['qualified'] = False
            save(args.output / 'finalization-failure.json', {'status': 'FAIL', 'reason': str(error), 'promoted': False})
            raise
    require(state['qualified'], 'Missing completed private qualification')
    save(logs / 'result.json', state['record'])
    print(json.dumps(summary, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
