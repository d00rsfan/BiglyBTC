#!/usr/bin/env python3
"""Freeze actual final portable inputs only after root's reviewed passed build."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
N=Path('/home/yurii/Java/BiglyBTC')
W=Path('/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def need(value,why):
    if not value: raise ValueError(why)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-commit',required=True)
    parser.add_argument('--lane',choices=('gcc','clang'),required=True)
    parser.add_argument('--build-root',type=Path,required=True)
    parser.add_argument('--source-map',type=Path,required=True)
    parser.add_argument('--build-receipt',type=Path,required=True)
    parser.add_argument('--ctest-catalog',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    own=json.loads((HERE/'manifest.json').read_bytes())
    for name,pin in own['artifacts_sha256'].items():need(sha(HERE/name)==pin,'Frozen portable source changed: '+name)
    spec=importlib.util.spec_from_file_location('final_portable_contract',HERE/'qualify.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
    git=lambda *argv:subprocess.check_output(['git',*argv],cwd=N)
    need(git('rev-parse','HEAD').decode().strip()==args.source_commit and not git('status','--porcelain'),'Clean root-frozen final source required')
    need(not git('ls-files','--others','--exclude-standard','--','preview/native'),'Untracked native source')
    source={p:sha(N/p) for p in git('ls-files','-z','--','preview/native').decode().split('\0') if p}
    need(json.loads(args.source_map.read_bytes())==source,'Actual final tracked source graph')
    # The one source amendment must be reviewed/adopted before recording inputs.
    need(sha(N/'preview/migration/tools/stage_preview.py')==own['source_sha256']['preview/migration/tools/stage_preview.py'],'Final exact traffic stager amendment is not adopted')
    need(sha(N/'preview/native/packaging/preview.py')==q.WAYLAND_PREVIEW_SHA,'Wayland preview fix changed')
    b=args.build_root.resolve(strict=True);need(b.is_relative_to(N/'build') and b==args.build_root,'Canonical existing build root')
    build=json.loads(args.build_receipt.read_bytes())
    targets=q.PRODUCTS+list(q.TESTS.values())+q.CONTROLS+list(q.MODULES)
    actual_build_commit=build.get('source_commit','')
    need(isinstance(actual_build_commit,str) and len(actual_build_commit)==40
        and all(c in '0123456789abcdef' for c in actual_build_commit),'Actual full build CID required')
    need(subprocess.run(['git','merge-base','--is-ancestor',actual_build_commit,args.source_commit],cwd=N).returncode==0
        and not git('diff',actual_build_commit,args.source_commit,'--','preview/native','preview/migration/tools/stage_preview.py'),
        'Only source-identical metadata descendants can reuse the actual build')
    need(build['exit']==0
        and build['source_manifest_sha256']==sha(args.source_map) and set(targets)<=set(build['command'])
        and build['command'][build['command'].index('--build')+1]==str(b),'Actual passed same-source build covering all portable targets')
    catalog={test['name']:test for test in json.loads(args.ctest_catalog.read_bytes())['tests']}
    need(set(q.TESTS)<=catalog.keys() and q.DEPLOY in catalog,'Actual final registered portable cohort')
    deploy=catalog[q.DEPLOY]['command']
    need(deploy[deploy.index('--mode')+1]=='traffic' and deploy[deploy.index('--provider')+1]==str(q.DSO)
         and deploy[deploy.index('--manifest')+1]==str(q.PROVIDER),'Exact traffic deployment fixture')
    binaries=[b/q.PRODUCT_PATHS[name] for name in q.PRODUCTS]+[b/path for path in q.MODULES.values()]
    binaries += [Path(catalog[name]['command'][0]) for name in q.TESTS]
    binaries += [Path(deploy[deploy.index(flag)+1]) for flag in ('--driver','--interposition-driver','--alternate')]
    binaries += [Path(path).resolve(strict=True) for path in deploy[deploy.index('--preload')+1].split(':')]
    for p in binaries:need(p.is_file() and not p.is_symlink() and p.resolve()==p,'Canonical actual built/control file: '+str(p))
    fixtures=[N/'preview/migration/tools/stage_preview.py',N/'preview/native/packaging/preview.py',Path(deploy[2]),q.PROVIDER,
              b/'qt-runtime.json',b/'app/generated/country_approval.hpp',b/'app/generated/scheduler_approval.hpp']
    field=lambda p:{'path':str(p.resolve(strict=True)),'sha256':sha(p)}
    completion={'schema':1,'status':'ROOT_FROZEN_FINAL_PORTABLE_INPUTS','recipe_sha256':sha(HERE/'qualify.py'),'lane':args.lane,
        'source_commit':args.source_commit,'source_map':field(args.source_map),'build_root':str(b),'cmake_cache_sha256':sha(b/'CMakeCache.txt'),
        'primary_configure_receipt':field(b/'engine/runtime-binding/configure-receipt.json'),
        'primary_binding_header':field(b/'engine/runtime-binding/persistent_runtime_config.hpp'),
        'primary_build_receipt':field(args.build_receipt),'ctest_catalog':field(args.ctest_catalog),
        'binary_sha256':{str(p):sha(p) for p in binaries},'fixture_sha256':{str(p):sha(p) for p in fixtures},
        'instrumentation':{'address':False,'undefined':False},'sanitizer_environment':{}}
    need(all(not os.environ.get(k) for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS')),'Primary GCC/Clang completion must not inherit sanitizer options')
    output=args.output.absolute();need(output.is_relative_to(W) and output.parent.resolve()==output.parent
        and output.parent.is_dir() and not output.exists() and not output.is_symlink(),'Fresh canonical owned completion path')
    association=output.with_suffix('.source-association.json')
    need(not association.exists() and not association.is_symlink(),'Fresh source association required')
    association.write_text(json.dumps({'schema':1,'actual_build_source_commit':actual_build_commit,
        'qualification_source_commit':args.source_commit,'build_receipt':str(args.build_receipt.resolve(strict=True)),
        'build_receipt_sha256':sha(args.build_receipt),'source_map_sha256':sha(args.source_map),
        'tracked_native_and_stager_identical':True,'actual_build_receipt_unchanged':True,
        'explanation':'Actual build CID retained; only metadata-only descendant with identical full source graph is associated.'},indent=2)+'\n')
    output.write_text(json.dumps(completion,indent=2)+'\n')
    print(json.dumps({'completion':str(output),'sha256':sha(output),'lane':args.lane,'source':args.source_commit,
                      'binary_inputs':len(completion['binary_sha256']),'runtime_executed':False},sort_keys=True))

if __name__=='__main__':main()
