Additive exact Clang recovered-gate association; root authorized actual execution.
Only root_execute.py Clang gate changes. Ordinary gate and old GCC branch remain.
New accepted case is exact root-reviewed recovered7826 receipt at its fixed path:
all40 actual XML cases/statuses plus complete CTest success summary, actual49-target
build exit0 and exact source map. CTest process exit remains unknown, wrapper143
preserved. No test execution/exit is invented. Producer and qualifier unchanged.
Current sourceee798 and actual Clang build sourceee798 are the same; source7405
GCC metadata association remains unchanged. Fresh private candidate only; olddist118
and previous failed GCC attempts untouched. No build/reconfigure/promotion.
