Source-only resume, root review required before execution.

The failed GCC r2 complete attempt remains FAIL: managed-download aborted after
42 actual Qt PASS rows with a generic QFile read failure. A controlled same-binary,
same-private-runtime strace reproduction passed both data rows (4 Qt rows), with
no resource errno. Cause remains unresolved; no source fix or full-suite exit0
is claimed. Outer exec exit143 is separately retained; its qualifier continued
and recorded the real managed child exit-6.

Actual -functions/-datatags inventories enumerate 56 managed subject cases:
41 prefix successes, 2 targeted successes (one overlaps), 14 uncovered cases in
8 untouched methods. The reviewed runner executes only those eight methods once,
requires every expected case and no extra/skipped case, then runs the five unrun
proxy/binding/GUI cohorts and the original exact11 deployment controls. It reuses
the recorded loader/stage/launcher/smoke and three completed owner cohorts only
after all frozen inputs, original build products, source, provider, candidate,
rollback and all prior command log hashes match. No build/copy of dist occurs.

Captures are accumulated in fresh addendum/captures; the original28 are pinned.
The final status explicitly says unchanged-case reuse and carries the unresolved
full-run limitation. It is not a replacement of r2 failure or shipping approval.
The base deployment uses the original approved98279 provider and its original
manifest guard; copied positive owners independently exercise the private image.

Execute after root review (fresh canonical output):
  nice -n5 python3 H/resume.py --manifest-sha256 MANIFEST_SHA \
    --output W/portable-gcc-ee798-r2/addendum-r1
H is this immutable directory; W is compatibility-chapter-20261027. Preserve all
failure logs. No rerun is authorized by this source file itself. Root retains
visual review and promotion; no manual Wayland/public/causal/performance credit.
