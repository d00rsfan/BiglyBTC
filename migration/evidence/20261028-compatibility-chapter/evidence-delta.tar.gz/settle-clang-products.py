from pathlib import Path
import hashlib,json,os,subprocess,time
W=Path(__file__).resolve().parent;N=Path('/home/yurii/Java/BiglyBTC');P=W/'clang-final-r2';O=W/'clang-final-settle-r1';O.mkdir()
B=N/'build/saved-services-20261018/clang';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=N)
CID=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain');graph=json.loads((P/'build-source.json').read_bytes());assert all(sha(N/k)==v for k,v in graph.items())
(O/'build-source.json').write_bytes((P/'build-source.json').read_bytes());catalog=json.loads((P/'registered-tests.json').read_bytes());names=set(json.loads((P/'plan.json').read_bytes())['tests']);chosen=[t for t in catalog['tests'] if t['name'] in names];assert len(chosen)==40
paths=set()
for t in chosen:
 for arg in t['command']:
  for s in arg.split(':'):
   p=Path(s)
   if p.is_absolute() and p.is_file():paths.add(str(p))
for rel in ['CMakeCache.txt','engine/runtime-binding/configure-receipt.json','engine/runtime-binding/persistent_runtime_config.hpp','qt-runtime.json']:paths.add(str(B/rel))
for s in git('ls-files','-z','--','preview/native').decode().split('\0'):
 if s:paths.add(str(N/s))
before={s:sha(s) for s in sorted(paths)};(O/'reuse-before.json').write_text(json.dumps(before,indent=2)+'\n')
command=json.loads((P/'build-receipt.json').read_text())['command'];command[command.index('--parallel')+1]='2';start=time.monotonic()
with (O/'build.log').open('wb') as log:r=subprocess.run(command,cwd=N,stdout=log,stderr=subprocess.STDOUT)
receipt={'exit':r.returncode,'command':command,'source_commit':CID,'source_manifest_sha256':sha(O/'build-source.json'),'seconds':time.monotonic()-start};(O/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Clang settle build',r.returncode,flush=True)
assert r.returncode==0
assert not git('status','--porcelain') and git('rev-parse','HEAD').decode().strip()==CID
changed={s:{'before':h,'after':sha(s)} for s,h in before.items() if sha(s)!=h};(O/'changed-inputs.json').write_text(json.dumps(changed,indent=2)+'\n');assert not changed,'Actual registered test input bytes changed; do not reuse affected tests blindly'
query=subprocess.check_output(['ctest','--test-dir',str(B),'--show-only=json-v1']);assert json.loads(query)==catalog;(O/'registered-tests.json').write_bytes(query)
prior=json.loads((P/'result-recovered.json').read_bytes());assert prior['tests']==40 and prior['source_commit']==CID
result={'status':'PASS_ALL_40_CASES_WITH_EXACT_UNCHANGED_INPUT_REUSE_AFTER_MOC_SETTLE','lane':'clang','source_commit':CID,'tests':40,'actual_tests_rerun':0,'reused_result':str(P/'result-recovered.json'),'reused_result_sha256':sha(P/'result-recovered.json'),'actual_prior_ctest_exit_code':None,'actual_prior_wrapper_exit':143,'actual_build_exit':0,'all_registered_command_input_bytes_unchanged':True,'input_count':len(before),'source_manifest_sha256':sha(O/'build-source.json'),'build_receipt_sha256':sha(O/'build-receipt.json')};(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
