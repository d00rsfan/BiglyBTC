Root-run only after final actual gates; no helper execution has occurred.

```
python3 build/compatibility-chapter-20261027/final-review-draft/archive_delta.py --output /home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027/final-retention-delta-r1
```

Output must be new and have an existing owned parent. The exact prior4026-member index/archive are verified by SHA. Unchanged old members are reused; identical new-path content references old members, and repeated new bytes have one tar member. Current checkpoint.json is always snapshotted. All reads are bounded and changed leaves fail; the produced tar is streamed back to verify every member hash. A failed attempt can leave a partial output: retain it and choose a new attempt namespace, never overwrite it.

The <=8MiB source/log/JSON/XML/raw metadata/proof/capture allowlist excludes provider source/build/install, candidate/rollback/build caches, compiled suffixes and ELF/PE/Java/archive magic, full network.trace, unknown binaries and archive copies. Output and prior delta-output trees are pruned. The index retains baseline pins and explicit current exclusions. It does not grant qualification, closure, provider authority or promotion. Root still verifies gate results, final source associations, original protections, export bytes and publication.

Original11 effectivePASS (four linked r3 +seven selected r4) and allocation2PASS are root-reported followups to the preserved earlier draft snapshot. Driver's final review supplies their exact receipts; this helper does not synthesize case credit. component-review-refs.json lists only the ten already annotated native IDs for appending final evidence references. Broad states, coverage and baseline fields remain unchanged. Finish this chapter, then stop.
