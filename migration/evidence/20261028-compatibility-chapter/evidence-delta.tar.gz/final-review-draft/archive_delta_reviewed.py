#!/usr/bin/env python3
"""Root-run only, after qualification: archive_delta.py --output NEW_DIRECTORY.

No qualification credit is inferred here. Snapshot bounded evidence from W;
reuse the exact prior archive/index, and never change either source tree.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

BASE_INDEX_SHA = "37d5c818eb3334e55daca2eb71378e9749d22be11f7822f56da75376be8ea33e"
BASE_ARCHIVE_SHA = "f59fdd798996aa084637794abd7578bb308b936976de36b4e26863bb1ec936f1"
MAX_BYTES = 8 * 1024 * 1024
TEXT = {".py", ".java", ".cpp", ".hpp", ".h", ".inc", ".patch", ".cmake",
        ".md", ".txt", ".json", ".jsonl", ".xml", ".yaml", ".yml", ".toml",
        ".tsv", ".csv", ".log", ".out", ".err", ".stdout", ".stderr"}
PROOF = {".torrent", ".config", ".dat", ".benc", ".png", ".svg"}
COMPILED = {".o", ".obj", ".a", ".so", ".dll", ".dylib", ".exe", ".class",
            ".jar", ".pyc", ".pyo", ".pch", ".gch", ".pdb", ".qm", ".lib"}
CACHES = {".git", "__pycache__", "cmakefiles", "_deps", "classes", "sdk"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def stamp(s):
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def snapshot(path):
    """Refuse a changed or redirected leaf; never archive a mixed snapshot."""
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_BYTES:
        raise ValueError("Not a bounded regular snapshot: " + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as f:
        if stamp(os.fstat(f.fileno())) != stamp(before):
            raise ValueError("Snapshot replaced: " + str(path))
        data = f.read(MAX_BYTES + 1)
        if stamp(os.fstat(f.fileno())) != stamp(before):
            raise ValueError("Snapshot changed: " + str(path))
    if stamp(path.lstat()) != stamp(before) or len(data) != before.st_size:
        raise ValueError("Snapshot changed: " + str(path))
    return data


def compiled_magic(data):
    return data[:4] in {b"\x7fELF", b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",
                        b"\xce\xfa\xed\xfe", b"\xcf\xfa\xed\xfe", b"BC\xc0\xde"} or data[:2] == b"MZ" or data.startswith((b"!<arch>\n", b"PK\x03\x04"))


def excluded_tree(path, root, output):
    if path == output or output in path.parents or (path / "archive-delta-index.json").is_file() or (path / "evidence-delta.tar.gz").is_file():
        return "collector output/prior delta tree"
    parts = path.relative_to(root).parts
    name = path.name.lower()
    if name.startswith("previous-published-dist-"):
        return "complete previous published dist rollback; manifest retained separately"
    if name in CACHES or (path / "CMakeCache.txt").is_file():
        return "compiled/cache tree"
    if name in {"build", "install", "rollback", "candidate", "copy-binaries", "dist"} or name.endswith("-build"):
        return "build/install/candidate/rollback/binary tree"
    if any(p.lower().startswith("provider") for p in parts[:-1]) and name in {"source", "src", "include", "build", "install"}:
        return "provider source/build/install tree"
    if any("candidate" in p.lower() or "rollback" in p.lower() for p in parts):
        return "candidate/rollback tree"
    return None


def reason_for_file(path, relative, size):
    name = path.name.lower()
    if size > MAX_BYTES:
        return "larger than8MiB; retain local fixture/digest reference"
    if name == "network.trace" or relative in {"bad-peer-diagnostic-r1/network.trace", "portable-clang-ee798-r2/diagnostic-proxy-redirect-r1/local-syscalls.log"}:
        return "private full network trace; retain owned excerpt and prior SHA review"
    if path.suffix.lower() in COMPILED or ".so." in name:
        return "compiled artifact"
    if name.endswith((".tar", ".tar.gz", ".tgz", ".tar.zst", ".zip", ".7z")):
        return "archive/copy excluded; prior archive is referenced"
    suffix = path.suffix.lower()
    if suffix in TEXT | PROOF or name in {"cmakelists.txt", "biglybt.statistics"}:
        return None
    if name.endswith((".log.gz", ".stdout.gz", ".stderr.gz")):
        return None
    if name == "owned-wire-excerpt.trace" or (suffix == ".bin" and (name.startswith("read-") or "proof" in relative.lower())):
        return None
    if name.endswith((".config.bak", ".dat.bak", ".dat.2", ".config.saving")):
        return None
    return "outside bounded source/log/metadata/proof/capture selection"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--output", type=Path, required=True, help="new owned directory; never an existing archive")
    parser.add_argument("--baseline-index", type=Path)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    baseline = args.baseline_index or root.parents[1] / "migration/evidence/20261027-compatibility-gcc-milestone/archive-index.json"
    base_archive = baseline.with_name("evidence.tar.gz")
    if file_digest(baseline) != BASE_INDEX_SHA or file_digest(base_archive) != BASE_ARCHIVE_SHA:
        raise ValueError("Prior archive/index pin mismatch")
    base = json.loads(baseline.read_bytes())
    if len(base["files"]) != 4026 or Path(base["local_durable_root"]).resolve() != root:
        raise ValueError("Prior member/root association mismatch")
    by_path = {x["path"]: x for x in base["files"]}
    by_sha = {x["sha256"]: x["path"] for x in base["files"]}
    output = args.output.absolute()
    if output.exists() or not output.parent.is_dir() or output == root or output in root.parents:
        raise ValueError("Output must be a new owned directory with an existing parent")
    output = output.parent.resolve(strict=True) / output.name
    records, excluded, stored, member_for_sha = [], [], [], {}
    unchanged = 0
    checkpoint_sha = None
    for directory, dirs, files in os.walk(root, followlinks=False):
        parent = Path(directory)
        for name in sorted(dirs[:]):
            path = parent / name
            reason = "symlink tree" if path.is_symlink() else excluded_tree(path, root, output)
            if reason:
                dirs.remove(name)
                excluded.append({"path": path.relative_to(root).as_posix(), "reason": reason, "tree": True})
        dirs.sort()
        for name in sorted(files):
            path = parent / name
            relative = path.relative_to(root).as_posix()
            st = path.lstat()
            reason = "not a regular leaf" if not stat.S_ISREG(st.st_mode) else reason_for_file(path, relative, st.st_size)
            if reason:
                excluded.append({"path": relative, "bytes": st.st_size, "reason": reason})
                continue
            data = snapshot(path)
            if compiled_magic(data):
                excluded.append({"path": relative, "bytes": len(data), "reason": "compiled artifact magic"})
                continue
            sha = digest(data)
            if relative == "checkpoint.json":
                checkpoint_sha = sha  # Always retain the exact final current checkpoint.
            elif relative in by_path and by_path[relative]["sha256"] == sha:
                unchanged += 1
                continue
            row = {"path": relative, "bytes": len(data), "sha256": sha}
            if relative != "checkpoint.json" and sha in by_sha:
                row["prior_member"] = by_sha[sha]
            else:
                if sha not in member_for_sha:
                    member_for_sha[sha] = relative
                    stored.append(row)
                row["member"] = member_for_sha[sha]
            records.append(row)
    if checkpoint_sha is None:
        raise ValueError("Missing bounded current checkpoint.json snapshot")
    output.mkdir(mode=0o700)
    archive = output / "evidence-delta.tar.gz"
    with archive.open("xb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as gz, tarfile.open(fileobj=gz, mode="w|") as tar:
        for row in stored:
            data = snapshot(root / row["path"])
            if digest(data) != row["sha256"]:
                raise ValueError("Changed during retention: " + row["path"])
            entry = tarfile.TarInfo(row["member"])
            entry.size, entry.mode, entry.mtime = len(data), 0o600, 0
            tar.addfile(entry, io.BytesIO(data))
    expected = {x["member"]: x for x in stored}
    with tarfile.open(archive, mode="r|gz") as tar:
        for entry in tar:
            row = expected.pop(entry.name, None)
            if row is None or not entry.isfile() or entry.size != row["bytes"]:
                raise ValueError("Unexpected archive member: " + entry.name)
            if digest(tar.extractfile(entry).read(MAX_BYTES + 1)) != row["sha256"]:
                raise ValueError("Archive member digest mismatch: " + entry.name)
    if expected:
        raise ValueError("Archive omitted members")
    index = {"schema": 1, "status": "RETAINED_DELTA_NOT_QUALIFICATION_APPROVAL", "local_durable_root": str(root),
             "collector_sha256": file_digest(Path(__file__)), "max_member_bytes": MAX_BYTES,
             "baseline": {"index_sha256": BASE_INDEX_SHA, "archive_sha256": BASE_ARCHIVE_SHA, "members": 4026,
                          "unchanged_selected_paths_reused": unchanged, "exclusions": "Preserved in the immutable prior index; current exclusions below are additive."},
             "checkpoint_sha256": checkpoint_sha, "files": records, "excluded": excluded,
             "archive": {"name": archive.name, "sha256": file_digest(archive), "bytes": archive.stat().st_size, "members": len(stored), "member_hashes_verified": True}}
    (output / "archive-delta-index.json").write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"output": str(output), "archive": index["archive"], "checkpoint_sha256": checkpoint_sha}, ensure_ascii=False))


if __name__ == "__main__":
    main()
