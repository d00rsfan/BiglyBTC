#!/usr/bin/env python3
"""Root-only linked/selected actual owners -> retained original READY getters."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/yurii/Java/BiglyBT')
NATIVE = ROOT.parent/'BiglyBTC'
JAVA = Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')
OUTPUT_ROOT = ROOT/'build/compatibility-chapter-20261027/existing-storage-oracle'
PARENT = ROOT/'build/compatibility-20261026/verified-seeding-oracle/run.py'
if hashlib.sha256(PARENT.read_bytes()).hexdigest() != 'f54dfeb41a9994f191498e73ba7372710866487327318bf39cbf690180b12348':
    raise ValueError('Frozen retained IO/fence utility changed')
spec = importlib.util.spec_from_file_location('retained_existing_seed_io', PARENT)
base = importlib.util.module_from_spec(spec); spec.loader.exec_module(base)
need,sha,files,decimal = base.need,base.sha,base.files,base.decimal
from proof import derive
CASES = [('linked',x,'complete') for x in ('single','multi','one-multi','v2-tail')]
CASES += [('selected',x,'complete') for x in ('linear-missing','compact-edges','reordered-edges','reordered-compact-edges','v2-missing')]
CASES += [('selected','compact-edges','corrupt'),('selected','linear-missing','stopped')]
PRIVATE = (b'BiglyBTC.verifiedSeeding',b'BiglyBTC.verifiedExistingScope',b'BiglyBTC.verifiedSeedGoal',b'BiglyBTC.verifiedSelectedScope')


def physical(path):
    value = base.physical(path); info = path.lstat()
    return {**value,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns,'mode':info.st_mode,'nlink':info.st_nlink}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completion',type=Path,required=True)
    parser.add_argument('--completion-sha256',required=True)
    parser.add_argument('--phase',choices=('all','linked','selected'),default='all')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    manifest=json.loads((HERE/'manifest.json').read_bytes())
    for name,digest in manifest['artifacts'].items(): need(sha(HERE/name)==digest,'Frozen recipe changed: '+name)
    inputs=json.loads((HERE/'inputs.json').read_bytes())
    for name,digest in inputs['files'].items(): need(sha(Path(name))==digest,'Pinned producer/helper input changed: '+name)
    retained=json.loads(Path(inputs['retention']).read_bytes()); classes=Path(inputs['classes'])
    need(retained['source_commit']==inputs['original_commit'] and retained['recompiled'] is False
         and len(retained['file_sha256'])==5432 and files(classes)==retained['file_sha256'],'Exact retained original5432 cohort')
    completion_path=args.completion.resolve(strict=True)
    need(completion_path.is_relative_to(OUTPUT_ROOT.parent) and sha(completion_path)==args.completion_sha256,'Exact root-reviewed completion record')
    completion=json.loads(completion_path.read_bytes())
    need(completion['schema']==1 and completion['status']=='ROOT_REVIEWED_MATCHING_SOURCE_BUILD'
         and completion['lane']=='gcc' and completion['sanitizers'] is False
         and completion['producer_manifest_sha256']==inputs['producer_manifest_sha256'],'Final reviewed producer/build association required')
    need(all(not os.environ.get(k) for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS')),'This retained JVM recipe uses actual uninstrumented primary GCC only')
    need(not Path(completion['driver']).is_symlink(),'Producer cannot be a caller alias')
    driver=Path(completion['driver']).resolve(strict=True)
    need(driver.name=='biglybtc-managed-download-tests' and os.access(driver,os.X_OK)
         and sha(driver)==completion['driver_sha256'] and not any(x in driver.read_bytes() for x in (b'__asan_init',b'__ubsan_handle_',b'__lsan_init')),'Actual uninstrumented matching-source producer')
    def git(*argv): return subprocess.check_output(['git',*argv],cwd=NATIVE)
    need(git('rev-parse','HEAD').decode().strip()==completion['source_commit'] and not git('status','--porcelain')
         and not git('ls-files','--others','--exclude-standard','--','preview/native'),'Clean exact root-frozen source')
    graph={name:sha(NATIVE/name) for name in git('ls-files','-z','--','preview/native').decode().split('\0') if name}
    need(graph==completion['tracked_source_sha256'],'Full exact tracked source map')
    producer=completion['producer_source_sha256']
    need(set(producer)==set(inputs['producer_paths']) and all(graph[name]==digest for name,digest in producer.items()),'Explicit final common-file composition association')
    for name,digest in inputs['immutable_producer_paths'].items(): need(producer[name]==digest,'Changed isolated producer contract: '+name)
    build_path=Path(completion['build_receipt']).resolve(strict=True)
    need(build_path.is_relative_to(OUTPUT_ROOT.parent) and build_path.name.endswith('-receipt.json')
         and sha(build_path)==completion['build_receipt_sha256'],'Actual frozen passed build receipt')
    build=json.loads(build_path.read_bytes());source_path=build_path.with_name(build_path.name[:-len('-receipt.json')]+'-source.json')
    need(build['exit']==0 and sha(source_path)==build['source_manifest_sha256']
         and json.loads(source_path.read_bytes())==graph,'Passed matching-source target build graph')
    need(driver.name in build['command'] and build['command'][build['command'].index('--build')+1]==str(driver.parent.parent),'Actual producer target/build directory')
    destination=args.output.absolute()
    need(destination.is_relative_to(OUTPUT_ROOT/'runs') and destination.resolve()==destination and not destination.exists(),'Fresh durable owned attempt')
    destination.mkdir(mode=0o700,parents=True)
    work=Path(tempfile.mkdtemp(prefix='biglybtc-existing-storage-',dir='/tmp'));work.chmod(0o700)
    env={k:v for k,v in os.environ.items() if k not in ('CLASSPATH','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','LD_PRELOAD','LD_AUDIT')}
    env.update(PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen')
    commands=[];chosen=[case for case in CASES if args.phase=='all' or case[0]==args.phase]
    result={'status':'RUNNING','recipe_sha256':sha(HERE/'manifest.json'),'completion_sha256':args.completion_sha256,
            'source_commit':completion['source_commit'],'driver_sha256':sha(driver),'original_commit':inputs['original_commit'],
            'original_recompiled':False,'real_original_profile_or_process_access':False,'phase':args.phase,'cases':{},'commands':commands,
            'scope':'Owned exported profiles only. Selected completion is distinct from full completion; no missing data is credited, no original payload transfer or full CF closure.'}
    def run(name,argv,timeout):
        row={'name':name,'argv':list(map(str,argv)),'timeout':timeout};commands.append(row)
        (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        with (work/(name+'.stdout')).open('xb') as out,(work/(name+'.stderr')).open('xb') as err:
            started=time.monotonic();child=None
            try:
                child=subprocess.Popen(row['argv'],cwd=work,env=env,stdout=out,stderr=err,start_new_session=True)
                while child.poll() is None:
                    left=timeout-(time.monotonic()-started);need(left>0,'Deadline: '+name)
                    try: child.wait(timeout=min(45,left))
                    except subprocess.TimeoutExpired: print('Existing storage READY active: '+name,flush=True)
            finally:
                if child is not None and child.poll() is None:
                    try: os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                    child.wait()
                out.flush();err.flush();row.update(exit=None if child is None else child.returncode,seconds=time.monotonic()-started,
                    stdout_sha256=sha(work/(name+'.stdout')),stderr_sha256=sha(work/(name+'.stderr')))
                (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        need(child is not None and child.returncode==0,'Actual command failed; retained logs: '+name)
        return (work/(name+'.stdout')).read_text(errors='replace')
    try:
        for name in ('classes','empty-sourcepath','cases','native-before-java'): (work/name).mkdir(mode=0o700)
        shutil.copyfile(completion_path,work/'root-completion.json');shutil.copyfile(build_path,work/'build-receipt.json');shutil.copyfile(source_path,work/'build-source.json')
        sys.path.insert(0,str(ROOT/'migration/tools'))
        from handoff import decode
        from peer_interop import jvm,unused_port
        def document(path):
            raw=path.read_bytes();raw=gzip.decompress(raw) if raw.startswith(b'\x1f\x8b') else raw
            need(len(raw)<=4*1024*1024,'Bounded owned document');doc,spans=decode(raw);need(isinstance(doc,dict),'Actual dictionary');return doc,spans
        run('javac-ready-helper',[JAVA/'javac','-J-XX:ActiveProcessorCount=1','--release','8','-encoding','UTF-8','-proc:none','-implicit:none',
            '-sourcepath',work/'empty-sourcepath','-cp',classes,'-d',work/'classes',ROOT/'migration/fixtures/java/ReferenceFence.java',
            ROOT/'migration/fixtures/java/EngineOracle.java',HERE/'ExistingStorageReadyOracle.java'],90)
        helpers=files(work/'classes')
        need(set(helpers)=={'ReferenceFence.class','EngineOracle.class','EngineOracle$1.class','ExistingStorageReadyOracle.class'},'Thin helper compile only')
        cp=str(work/'classes')+os.pathsep+str(classes)
        for family,kind,outcome in chosen:
            name=family+'-'+kind+'-'+outcome;case=work/'cases'/name
            run('native-'+name,[driver,'--prepare-'+family+'-verified-seed',case,kind,outcome],120)
            receipt=json.loads((case/'native-receipt.json').read_bytes())
            need(receipt['schema']==(4 if family=='linked' else 5) and receipt['status']=='ACTUAL_NATIVE_VERIFIED_SEED_CASE','Actual exporter schema')
            profile=case/'profile';metadata=case/'source.torrent';payload=case/'payload'
            need(receipt['profile']==str(profile) and receipt['metadata']==str(metadata) and receipt['payloadRoot']==str(payload),'Exact unmerged generated paths')
            source,raw=document(metadata);inventory,inv_raw=document(profile/'downloads.config')
            need(inventory[b'unknown.future']==[7,b'raw'] and len(inventory[b'downloads'])==1,'Exact original unknown inventory node')
            row=inventory[b'downloads'][0];expected=derive(source,raw[(b'info',)],row,receipt,case,family,kind,outcome,physical)
            identity=expected['identity'];state=profile/'active'/(identity+'.dat');archive=profile/'torrents'/(identity+'.torrent');saved,saved_raw=document(state)
            need(receipt['state']==str(state) and receipt['archive']==str(archive) and archive.read_bytes()==metadata.read_bytes()
                 and saved_raw[(b'info',)]==raw[(b'info',)],'Raw source/full identity/state/archive path')
            for key in ((b'opaque.fixture',),(b'attributes',b'opaque.fixture')): need(saved_raw[key]==raw[key],'Native raw opaque source bytes')
            complete=outcome=='complete';need(row[b'torrent_hash']==bytes.fromhex(identity) and row[b'state']==(75 if complete else 70)
                and row[b'forceStart']==0 and not inventory.get(b'pause_data') and saved[b'attributes'][b'flags']&8
                and row[b'BiglyBTC.verifiedSeeding']==(2 if complete else 1),'Native original startup/force/pause/move intent')
            need(receipt['released'] is complete and receipt['sessionJoined'] is True and receipt['storageReleased'] is True
                and decimal(receipt['admission'],'Actual admission')>0 and receipt['phase']==(2 if complete else 3 if outcome=='stopped' else 4),'Actual owner outcome/join/fence')
            need(decimal(receipt['received'],'Actual received')==0 and row[b'downloaded']==0
                 and row[b'uploaded']>=decimal(receipt['sent'],'Actual sent prefix'),'No payload download/repair, exact retained upload prefix')
            bits=receipt['verifiedPieces'];need(isinstance(bits,list) and all(type(x) is int and x in (0,1) for x in bits),'Actual binary accepted bitfield')
            if outcome!='stopped': need(''.join(map(str,bits))==expected['bitmap'],'Native accepted bitfield equals authentic expected range outcome')
            else: need(not bits or ''.join(map(str,bits))==expected['bitmap'],'Cancellation cannot fabricate a partial bitfield')
            need(receipt['receiverCompleted'] is complete and (receipt['receiverSha256'].lower()==expected['receiverSha256']
                and decimal(receipt['sent'],'Actual upload')>0 if complete else receipt['receiverSha256']=='' and decimal(receipt['sent'],'No upload')==0),'Actual selected/full owned receiver payload')
            if family=='selected': need(row[b'BiglyBTC.verifiedSeedGoal']==1 and b'BiglyBTC.verifiedSelectedScope' in row
                and receipt['fullComplete'] is False and (not complete or receipt['selectedComplete'] is True),'Separate selected saved goal and actual full incompleteness')
            before=work/'native-before-java'/name;shutil.copytree(profile,before/'profile');shutil.copyfile(case/'native-receipt.json',before/'receipt.json')
            physical_before={value['path']:physical(Path(value['path'])) for value in expected['files'].values() if value['present']}
            missing=[value['path'] for value in expected['files'].values() if not value['present']]
            control_before={str(p.relative_to(profile)):sha(p) for p in (profile/'active'/identity).glob('*') if p.is_file()} if (profile/'active'/identity).exists() else {}
            private_before={key.decode():inv_raw[(b'downloads',0,key)].hex() if key in row else None for key in PRIVATE}
            source_sha=sha(metadata);port=unused_port();stdout=run('original-ready-'+name,[*jvm(case,cp,(port,)),'ExistingStorageReadyOracle',port],240)
            observed={'files':{}}
            for line in stdout.splitlines():
                cols=line.split('\t');tag=cols[0]
                if tag=='FILE':
                    need(len(cols)==13 and cols[5] in ('true','false') and cols[8] in ('true','false'),'Actual original indexed file getter')
                    index=int(cols[1]);need(index not in observed['files'],'Unique original index');observed['files'][index]=cols[2:]
                elif tag in ('IDENTITY','INTENT','FLAGS','READY','REMAINING','SAVE','TITLE'):
                    need(tag not in observed,'Unique original fact '+tag);observed[tag]=cols[1:]
            need(stdout.splitlines().count('PASS_ORIGINAL_EXISTING_STORAGE_READY\t1')==1
                and observed.get('IDENTITY')==[identity,expected['fullV1'],expected['fullV2'],str(expected['simple']).lower()]
                and observed.get('INTENT')==[str(row[b'state']),'false','false',str(row[b'position'])]
                and observed.get('READY')==[str(len(expected['bitmap'])),expected['bitmap']]
                and observed.get('REMAINING')==[str(expected['remaining']),str(expected['selectedRemaining'])]
                and observed.get('SAVE')==[expected['save'].encode().hex().upper()]
                and observed.get('TITLE')==[expected['title'].encode().hex().upper()]*2
                and len(observed.get('FLAGS',[]))==2 and int(observed['FLAGS'][0])&8 and observed['FLAGS'][1]=='true','Actual original identity/intent/READY/needed-vs-full getters')
            need(set(observed['files'])==set(expected['files']),'Exact original real index map')
            original_created_skipped_linear={}
            for index,value in expected['files'].items():
                p=value['physical'];original_present=value['present']
                if not value['present']:
                    # cb8 DiskManagerImpl1302-1304/1406-1427 allocates missing
                    # linear files even when skipped. This is ORIGINAL activity,
                    # after the native RO no-allocation proof above.
                    path=Path(value['path'])
                    need(family=='selected' and kind in ('linear-missing','v2-missing') and index==1
                         and value['kind']==1 and value['skipped'] and value['bytes']==32768
                         and path==case/'payload'/'selected'/'m.bin'
                         and path.exists() and not path.is_symlink() and path.resolve()==path,
                         'Only exact original-created skipped linear leaf is admissible')
                    info=path.lstat();need(stat.S_ISREG(info.st_mode) and info.st_uid==os.geteuid() and info.st_nlink==1
                         and info.st_dev==Path(expected['files'][0]['path']).stat().st_dev,
                         'Original-created leaf must be fresh owned regular single-link data on the same filesystem')
                    need(path.read_bytes()==bytes(value['bytes']), 'Original-created skipped linear extent must be exact zeros')
                    p=physical(path);need(p['bytes']==value['bytes'], 'Exact original allocation size')
                    original_present=True
                    original_created_skipped_linear[str(index)]={'path':str(path),'native_present':False,
                        'native_allocated':False,'original_created':True,'original_physical':p,'downloaded':value['downloaded'],
                        'verified_bitmap':expected['bitmap'],'scope':'Original allocation only; zeros are not authentic downloaded/verified source data'}
                wanted=[str(value['offset']),str(value['bytes']),'0',str(value['skipped']).lower(),str(value['kind']),
                    str(value['downloaded']),str(original_present).lower(),str(p['bytes']) if p else '-1',value['path'].encode().hex().upper(),p['sha256'].upper() if p else '-','false']
                need(observed['files'][index]==wanted,'Actual original mapping/storage/progress/presence: '+str(index))
            need(physical_before=={p:physical(Path(p)) for p in physical_before} and all((str(1) in original_created_skipped_linear and original_created_skipped_linear[str(1)]['path']==p) or (not Path(p).exists() and not Path(p).is_symlink()) for p in missing)
                 and sha(metadata)==source_sha,'Original READY preserves exact authentic payload/missing ranges')
            for path in (state,archive):
                _,after=document(path);need(after[(b'info',)]==raw[(b'info',)] and after[(b'opaque.fixture',)]==raw[(b'opaque.fixture',)],'Original raw hashed/opaque source preserved')
            after,after_raw=document(profile/'downloads.config');need(len(after[b'downloads'])==1,'One post-close original row');after_row=after[b'downloads'][0]
            need(after_row[b'torrent_hash']==row[b'torrent_hash'] and after_row[b'save_dir']==row[b'save_dir'] and after_row[b'save_file']==row[b'save_file']
                 and after_row[b'state']==70 and after_row[b'forceStart']==0,'Actual original stopped path/identity switchback')
            private_after={key.decode():after_raw[(b'downloads',0,key)].hex() if key in after_row else None for key in PRIVATE}
            control_after={str(p.relative_to(profile)):sha(p) for p in (profile/'active'/identity).glob('*') if p.is_file()} if (profile/'active'/identity).exists() else {}
            result['cases'][name]={'status':'PASS','native_receipt':receipt,'independent_expected':expected,'original_observed':observed,
                'original_listener_port':port,'payload_physical':physical_before,'native_private_before':private_before,'original_private_after':private_after,
                'controls_before':control_before,'controls_after':control_after,'original_created_skipped_linear':original_created_skipped_linear,'native_reopen_executed':False}
            (work/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        need(files(work/'classes')==helpers and sha(driver)==completion['driver_sha256'],'Producer/helper changed during run')
        result.update(status='PASS_ACTUAL_EXISTING_STORAGE_ORIGINAL_READY',actual_cases=len(result['cases']),actual_original_processes=len(result['cases']),helper_class_sha256=helpers,prior_linked_result={'source_commit':'ee7985e4b78f1d8c9d89f727f29f3a025f3c63fc','result_sha256':inputs['prior_linked_result_sha256'],'passed_case_checks':4,'whole_prior_attempt_status':'FAIL'})
    except BaseException as error:
        result.update(status='FAIL',error=repr(error));raise
    finally:
        try: need(files(classes)==retained['file_sha256'] and all(sha(Path(p))==d for p,d in inputs['files'].items()),'Original cohort/frozen inputs changed')
        except BaseException as error: result.update(status='FAIL_COHORT',cohort_error=repr(error));raise
        finally:
            (work/'result.json').write_text(json.dumps(result,indent=2)+'\n')
            try:
                files(work);shutil.copytree(work,destination/'generated');(destination/'result.json').write_text(json.dumps(result,indent=2)+'\n')
            except BaseException:
                print('Archive incomplete; owned work retained at '+str(work),flush=True);raise
            else:
                shutil.rmtree(work);print('Retained actual attempt: '+str(destination),flush=True)


if __name__=='__main__': main()
