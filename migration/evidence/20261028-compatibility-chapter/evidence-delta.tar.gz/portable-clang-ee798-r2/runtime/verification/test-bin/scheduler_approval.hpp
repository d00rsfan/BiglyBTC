#pragma once
#include <cstdint>
#include <string_view>
namespace biglybtc::app::scheduler_bundle {
inline constexpr auto Sha256="d12f0edaeb954db04a2390d4f2bc0e5ffaddc98d0112eaca5ea83d00bf22e0cc";
inline constexpr std::uint64_t Bytes=62248;
inline constexpr auto Version="0.1.0";
}
