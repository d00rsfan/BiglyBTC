#pragma once
#include <cstdint>
namespace biglybtc::app::country_bundle {
inline constexpr char Basename[] = "BiglyBTC-plugin-azlocprov.so";
inline constexpr char Sha256[] = "7d6d593c4b2ec8cb96a33e03580b21a2ab900a20cd7e64571eb45336191e1676";
inline constexpr std::uint64_t Bytes = 32272;
inline constexpr char Version[] = "0.1.0";
}
