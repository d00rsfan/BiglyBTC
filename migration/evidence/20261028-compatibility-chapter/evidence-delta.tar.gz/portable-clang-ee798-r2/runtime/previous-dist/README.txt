BiglyBTC portable development client

Normal client: ./BiglyBTC --profile /absolute/path/to/profile
Pass an existing absolute profile directory without symbolic links.
For development, use a separate owned directory such as ~/.biglybtc-dev;
expand it to its absolute path when passing --profile. The launcher
does not create a profile, choose ports or copy the Java profile.
The original ~/.biglybt directory is never chosen automatically.

Offline generated-sample preview:
Run ./BiglyBTC-preview from this folder. Qt and the libtorrent runtime
are included alongside the application; no system installation is needed.
The four torrents are generated examples. Transfers are disabled.
Check My Torrents/Ctrl+1, My Tracker/Ctrl+2, My Shares/Ctrl+3, sorting and Files/Ctrl+I.
Saved service views are read-only; no tracker or share service is started.
Also check Refresh/F5, scaling, auxiliary tab closure and window close.
Each launch uses a fresh /tmp/biglybtc-preview-* sample profile.
The original ~/.biglybt profile is never opened by this launcher.
Full client/plugin migration and original-profile switching remain unfinished.

This folder uses the exact uninstrumented source-built libtorrent 2.0.12.
The extracted Debian package retains its metadata and license notices;
its shared objects resolve to the private source-built image.
