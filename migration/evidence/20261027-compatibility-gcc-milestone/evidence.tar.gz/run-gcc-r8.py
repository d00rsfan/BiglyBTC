from pathlib import Path
import subprocess,json,hashlib,time,re,os
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');b=n/'build/persistent-peer-accounting-20261021/bound-gcc';out=w/'gcc-r8';out.mkdir();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();git=lambda *x:subprocess.check_output(['git',*x],cwd=n);assert not git('status','--porcelain');graph={p:h(n/p) for p in git('ls-files','-z','--','preview/native').decode().split('\0') if p};(out/'build-source.json').write_text(json.dumps(graph,indent=2)+'\n');cid=git('rev-parse','HEAD').decode().strip();rows=[]
def configure():
 args=['cmake','-S',str(n/'preview/native'),'-B',str(b),'-DLibtorrentRasterbar_DIR='+str(w/'provider-traffic-v3/install/lib/cmake/LibtorrentRasterbar'),'-DBIGLYBTC_PERSISTENT_RUNTIME_MANIFEST='+str(n/'preview/native/engine/runtime-binding/provider-traffic-runtime.json')]
 with (out/'configure.log').open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 (out/'configure-command.json').write_text(json.dumps(dict(args=args,exit=r.returncode),indent=2)+'\n');assert r.returncode==0,'configure'
configure()
query=subprocess.run(['ctest','--test-dir',str(b),'--show-only=json-v1'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
(out/'registered-tests.json').write_bytes(query.stdout);registered=json.loads(query.stdout)['tests']
names=json.loads((w/'gcc-r3/plan.json').read_bytes())['tests'];names=[x for x in names if not x.startswith('provider-queue-runtime')]+['provider-traffic-runtime-inputs','provider-traffic-runtime-deployment','provider-payload-counter','managed-combined-counter-domain','selected-swarm-admission','original-storage-controls','original-storage-defaults','network-binding-owner']
chosen=[x for x in registered if x['name'] in names];assert len(chosen)==len(set(names)),set(names)-{x['name'] for x in chosen}
targets=sorted({Path(a).name for x in chosen for a in x['command'] if Path(a).name.startswith('biglybtc-') and '=' not in a}|{'BiglyBTC','BiglyBTC-headless','biglybtc-preview-smoke','biglybtc-file-operations-driver','biglybtc-torrent-creator-driver','biglybtc-queue-facts-replay','biglybtc-runtime-interposition-driver','biglybtc-runtime-interposer','biglybtc-network-proxy-foreign-marker','biglybtc-network-proxy-foreign-webseed-marker'})
(out/'plan.json').write_text(json.dumps(dict(source_commit=cid,tests=[x['name'] for x in chosen],targets=targets),indent=2)+'\n')
def run(name,args):
 t=time.monotonic();env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1')
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=n,env=env)
 row=dict(name=name,args=args,exit=r.returncode,seconds=round(time.monotonic()-t,3));rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert not git('status','--porcelain') and {p:h(n/p) for p in graph}==graph,'Source changed during qualification'
 if name=='build':(out/'build-receipt.json').write_text(json.dumps(dict(exit=r.returncode,command=args,source_commit=cid,source_manifest_sha256=h(out/'build-source.json')),indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
print('Build/test coherent batch:',len(chosen),'suites;',len(targets),'targets',flush=True)
run('build',['nice','-n','5','cmake','--build',str(b),'--parallel','3','--target',*targets,'--','-k','0'])
pattern='^('+ '|'.join(re.escape(x['name']) for x in chosen)+')$';run('tests',['ctest','--test-dir',str(b),'-j','1','-R',pattern,'--output-on-failure','--output-junit',str(out/'tests.xml')])
