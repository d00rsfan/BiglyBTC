from pathlib import Path
import shutil
w=Path(__file__).resolve().parent; n=Path('/home/yurii/Java/BiglyBTC')
for rel in ['ui/file_operation_presentation.hpp','app/file_operations_bridge.inc','engine/CMakeLists.txt']:
 for stage in ['before','work']:
  p=w/stage/'preview/native'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(n/'preview/native'/rel,p)
def edit(rel,fn):
 p=w/'work/preview/native'/rel;s=p.read_text();p.write_text(fn(s))
edit('engine/torrent_creator.hpp',lambda s:s.replace('  CreateFormat format = CreateFormat::V1; // Appended; legacy calls remain v1.','''  CreateFormat format = CreateFormat::V1; // Appended; legacy calls remain v1.
  std::string sourceTag; // Original info.source; changes the torrent identity.
  std::vector<std::string> urlSeeds, httpSeeds; // Original url-list/httpseeds, outside info.
  std::optional<bool> dhtBackup; // Omitted preserves the original default (enabled).
  bool extraHashes = false; // Original overall/per-file SHA1 and ED2K for v1/hybrid.
'''))
edit('ui/file_operation_presentation.hpp',lambda s:s.replace('  TorrentCreationFormat format=TorrentCreationFormat::V1;','''  TorrentCreationFormat format=TorrentCreationFormat::V1;
  QString sourceTag;
  QStringList urlSeeds,httpSeeds;
  bool dhtBackup=true,extraHashes=false;'''))
edit('app/file_operations_bridge.inc',lambda s:s.replace('      std::uint64_t sequence=0;std::optional<std::pair<std::uint64_t,std::uint64_t>> last;','''      options.sourceTag=request.options.sourceTag.toUtf8().toStdString();
      for(const auto& url:request.options.urlSeeds) options.urlSeeds.push_back(url.toUtf8().toStdString());
      for(const auto& url:request.options.httpSeeds) options.httpSeeds.push_back(url.toUtf8().toStdString());
      options.dhtBackup=request.options.dhtBackup;options.extraHashes=request.options.extraHashes;
      std::uint64_t sequence=0;std::optional<std::pair<std::uint64_t,std::uint64_t>> last;'''))
edit('engine/CMakeLists.txt',lambda s:s.replace('find_package(OpenSSL REQUIRED COMPONENTS Crypto)','find_package(OpenSSL 3.0 REQUIRED COMPONENTS Crypto)\ntarget_link_libraries(biglybtc_local_engine PRIVATE OpenSSL::Crypto)'))
edit('engine/torrent_creator.cpp',lambda s:s.replace('#include <libtorrent/version.hpp>','#include <libtorrent/version.hpp>\n#include <openssl/evp.h>\n#include <openssl/provider.h>'))
# Strict bounded validation precedes any scan/callback/effect.
validation='''  if (options.sourceTag.size() > 16384 || !utf8(options.sourceTag,true)) {
    fail(CreateErrorCode::Options,options.output,"Invalid source tag");
  }
  if(options.extraHashes && options.format==CreateFormat::V2) {
    fail(CreateErrorCode::Options,options.output,"Original extra hashes require V1 or hybrid");
  }
  if(options.urlSeeds.size()+options.httpSeeds.size()>64) fail(CreateErrorCode::Options,options.output,"Too many web seeds");
  for(const auto* seeds:{&options.urlSeeds,&options.httpSeeds}) for(const auto& url:*seeds) {
    const auto scheme=url.starts_with("http://")?7u:url.starts_with("https://")?8u:0u;
    const auto end=url.find_first_of("/?#",scheme);
    if(!scheme||url.size()>2048||url.size()<=scheme||(end!=url.npos&&end==scheme)||!utf8(url)
        ||std::any_of(url.begin(),url.end(),[](unsigned char c){return c<=0x20||c==0x7f;})) {
      fail(CreateErrorCode::Options,options.output,"Web seed must be a bounded HTTP(S) URL with an authority");
    }
  }
'''
edit('engine/torrent_creator.cpp',lambda s:s.replace('  std::size_t count = 0;\n  for (const auto& tier : options.trackerTiers)',validation+'  std::size_t count = 0;\n  for (const auto& tier : options.trackerTiers)'))
