from pathlib import Path
w=Path(__file__).resolve().parent;p=w/'work/preview/native/ui/torrent_creation_dialog.cpp';s=p.read_text()
s=s.replace('#include <QSignalBlocker>','#include <QSignalBlocker>\n#include <QScrollArea>')
s=s.replace('  QPointer<QLineEdit> source,output;','  QPointer<QLineEdit> source,output,sourceTag;')
s=s.replace('  QPointer<QPlainTextEdit> trackers,comment;','  QPointer<QPlainTextEdit> trackers,comment,urlSeeds,httpSeeds;')
s=s.replace('  QPointer<QCheckBox> privateTorrent,import;','  QPointer<QCheckBox> privateTorrent,import,dhtBackup,extraHashes;')
s=s.replace('privateTorrent.data(),import.data(),sourceBrowse.data()', 'privateTorrent.data(),import.data(),sourceTag.data(),urlSeeds.data(),httpSeeds.data(),dhtBackup.data(),extraHashes.data(),sourceBrowse.data()')
s=s.replace('if(!kind||!piece||!format||!source||!output||!trackers||!comment||!privateTorrent||!import','if(!kind||!piece||!format||!source||!output||!trackers||!comment||!privateTorrent||!import||!sourceTag||!urlSeeds||!httpSeeds||!dhtBackup||!extraHashes')
s=s.replace('    const auto choices=value.format==', '''    value.sourceTag=sourceTag->text();value.dhtBackup=dhtBackup->isChecked();
    value.extraHashes=extraHashes->isChecked()&&value.format!=TorrentCreationFormat::V2;
    if(value.sourceTag.toUtf8().size()>16384||value.sourceTag.contains(QChar::Null)) return {};
    std::size_t seedCount=0;
    for(const auto& pair:{std::pair{urlSeeds.data(),&value.urlSeeds},std::pair{httpSeeds.data(),&value.httpSeeds}}) {
      if(pair.first->toPlainText().size()>131072) return {};
      for(const auto& raw:pair.first->toPlainText().split(QChar('\\n'))) {
        const auto text=raw.trimmed();if(text.isEmpty()) continue;
        const QUrl url(text,QUrl::StrictMode);
        if(++seedCount>64||text.toUtf8().size()>2048||!url.isValid()||url.host().isEmpty()
            ||(url.scheme()!=QStringLiteral("http")&&url.scheme()!=QStringLiteral("https"))) return {};
        for(const auto c:text) if(c.isSpace()||c.unicode()<32||c.unicode()==127) return {};
        pair.second->push_back(text);
      }
    }
    const auto choices=value.format==''')
needle='  impl_->import=new QCheckBox';idx=s.index(needle)
s=s[:idx]+'''  impl_->sourceTag=new QLineEdit(this);impl_->sourceTag->setObjectName(QStringLiteral("torrent-creation-source-tag"));impl_->sourceTag->setMaxLength(16384);form->addRow(QStringLiteral("Source tag"),impl_->sourceTag);
  for(const auto& pair:{std::pair{&impl_->urlSeeds,QStringLiteral("URL seeds")},std::pair{&impl_->httpSeeds,QStringLiteral("HTTP seeds")}}) {
    *pair.first=new QPlainTextEdit(this);(*pair.first)->setMaximumHeight(70);
    (*pair.first)->setObjectName(pair.first==&impl_->urlSeeds?QStringLiteral("torrent-creation-url-seeds"):QStringLiteral("torrent-creation-http-seeds"));
    (*pair.first)->setPlaceholderText(QStringLiteral("One HTTP(S) URL per line"));form->addRow(pair.second,*pair.first);
  }
  impl_->dhtBackup=new QCheckBox(QStringLiteral("Permit DHT backup"),this);impl_->dhtBackup->setObjectName(QStringLiteral("torrent-creation-dht-backup"));impl_->dhtBackup->setChecked(true);form->addRow(QString{},impl_->dhtBackup);
  impl_->extraHashes=new QCheckBox(QStringLiteral("Include SHA1 and ED2K hashes (V1 / hybrid)"),this);impl_->extraHashes->setObjectName(QStringLiteral("torrent-creation-extra-hashes"));form->addRow(QString{},impl_->extraHashes);
'''+s[idx:]
s=s.replace('layout->addLayout(form);','''auto* fields=new QWidget(this);fields->setLayout(form);
  auto* scroll=new QScrollArea(this);scroll->setWidgetResizable(true);scroll->setFrameShape(QFrame::NoFrame);scroll->setWidget(fields);layout->addWidget(scroll);''')
s=s.replace('if(!impl_->bump()||impl_->piecesQueued){return;}impl_->piecesQueued=true;', 'if(!impl_->bump()||impl_->piecesQueued){return;}impl_->piecesQueued=true;')
p.write_text(s)
