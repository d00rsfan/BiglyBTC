from pathlib import Path
w=Path(__file__).resolve().parent
p=w/'work/preview/native/tests/torrent_creator_tests.cpp';s=p.read_text();at=s.index('    run("explicit v2')
s=s[:at]+'''    run("original source, webseed and DHT metadata remain in their exact dictionaries", [] {
      Area area;write(area.source(),"a");auto options=area.options();options.sourceTag="owned π";
      options.urlSeeds={"https://seeds.invalid/payload"};options.httpSeeds={"http://seeds.invalid/script"};options.dhtBackup=false;options.extraHashes=true;
      const auto result=createTorrent(options);CHECK(result);auto document=biglybtc::core::Document::parse(read(area.output()));CHECK(document);
      const auto* info=document->find("info");CHECK(info&&info->find("source")&&info->find("sha1")&&info->find("ed2k"));
      CHECK(info->find("source")->bytes==options.sourceTag);
      CHECK(info->find("sha1")->bytes==lt::hasher("a",1).final().to_string());
      const std::string expected="\\xbd\\xe5\\x2c\\xb3\\x1d\\xe3\\x3e\\x46\\x24\\x5e\\x05\\xfb\\xdb\\xd6\\xfb\\x24";
      CHECK(info->find("ed2k")->bytes==expected);
      CHECK(document->find("url-list")->children[0].bytes==options.urlSeeds[0]);
      CHECK(document->find("httpseeds")->children[0].bytes==options.httpSeeds[0]);
      CHECK(document->find("azureus_properties")->find("dht_backup_enable")->integer==0);
      auto without=options;without.output=area.root/"without.torrent";without.urlSeeds.clear();without.httpSeeds.clear();without.dhtBackup=true;
      const auto outside=createTorrent(without);CHECK(outside&&outside->selectedHash==result->selectedHash);
      without.output=area.root/"tag.torrent";without.sourceTag="another";const auto changed=createTorrent(without);CHECK(changed&&changed->selectedHash!=result->selectedHash);
      without.output=area.root/"invalid.torrent";without.format=CreateFormat::V2;expect(createTorrent(without),CreateErrorCode::Options);CHECK(!fs::exists(without.output));
      without.format=CreateFormat::V1;without.httpSeeds={"file:///no"};expect(createTorrent(without),CreateErrorCode::Options);CHECK(!fs::exists(without.output));
    });
    run("original extra hashes include actual empty leaves and hybrid virtual padding", [] {
      for(const auto format:{CreateFormat::V1,CreateFormat::Hybrid}) {
        Area area;const auto source=area.root/"bundle";fs::create_directory(source);write(source/"a","a");write(source/"b","");write(source/"c","b");
        auto options=area.options();options.source=source;options.format=format;options.pieceSize=32768;options.extraHashes=true;
        const auto result=createTorrent(options);CHECK(result);auto document=biglybtc::core::Document::parse(read(area.output()));CHECK(document);
        const auto* info=document->find("info");CHECK(info&&info->find("sha1")&&info->find("ed2k"));
        std::string stream="a";if(format==CreateFormat::Hybrid) stream.resize(32768,'\\0');stream+='b';
        CHECK(info->find("sha1")->bytes==lt::hasher(stream.data(),static_cast<int>(stream.size())).final().to_string());
        const auto* files=info->find("files");CHECK(files);std::size_t real=0;
        for(const auto& file:files->children){const auto* attr=file.find("attr");if(attr&&attr->bytes.find('p')!=std::string::npos) continue;
          CHECK(file.find("sha1")&&file.find("ed2k"));if(file.find("length")->integer==0){CHECK(file.find("sha1")->bytes==lt::hasher().final().to_string());CHECK(file.find("ed2k")->bytes==std::string("\\x31\\xd6\\xcf\\xe0\\xd1\\x6a\\xe9\\x31\\xb7\\x3c\\x59\\xd7\\xe0\\xc0\\x89\\xc0",16));}++real;
        }CHECK(real==3);
      }
    });
'''+s[at:];p.write_text(s)
p=w/'work/preview/native/tests/torrent_creation_dialog_tests.cpp';s=p.read_text();s=s.replace('  QVERIFY(capture(dialog));dialog.accept();','''  dialog.findChild<QLineEdit*>("torrent-creation-source-tag")->setText(QStringLiteral("owned π"));
  dialog.findChild<QPlainTextEdit*>("torrent-creation-url-seeds")->setPlainText(QStringLiteral("https://seed.invalid/data"));
  dialog.findChild<QPlainTextEdit*>("torrent-creation-http-seeds")->setPlainText(QStringLiteral("http://seed.invalid/script"));
  dialog.findChild<QCheckBox*>("torrent-creation-dht-backup")->setChecked(false);
  dialog.findChild<QCheckBox*>("torrent-creation-extra-hashes")->setChecked(true);
  QVERIFY(capture(dialog));dialog.accept();''',1)
s=s.replace('  QCOMPARE(request.session,quint64(8));','''  QCOMPARE(request.options.sourceTag,QStringLiteral("owned π"));QVERIFY(request.options.extraHashes);QVERIFY(!request.options.dhtBackup);
  QCOMPARE(request.options.urlSeeds,QStringList{QStringLiteral("https://seed.invalid/data")});QCOMPARE(request.options.httpSeeds,QStringList{QStringLiteral("http://seed.invalid/script")});
  QCOMPARE(request.session,quint64(8));''',1);p.write_text(s)
