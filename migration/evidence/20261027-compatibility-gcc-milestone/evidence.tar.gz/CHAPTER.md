# Current compatibility chapter

Latest authority: “lets finish current chapter”. The previous STOP boundary is revoked for this chapter; it is retained as history in the older receipts. No next major chapter is started.

Current ordinary work is implemented and checked against the original source rather than closed by changing the broad CF parents. First cohesive batch: held-profile Linux filename conversion; per-file move/retarget/revert and Linux Trash; ordinary LAN peer classes/rates; raw source-bound tracker/lifecycle queue observations, ratio and rate projections; creator 256MiB/source/webseed/DHT/optional hashes. These sources are staged and reviewed; qualification has not passed yet.

Followups in this same chapter: explicit pre-add indexed destinations/initial linkage and read-only linked scopes; selected/nonlinear existing-data goals; allocated stop/pause lifecycle; remaining decoder contexts; virtual/multisource creator; explicit collision/overwrite preimages; versioned file-operation cross-products; ordinary target-scoped disk latency; final applicable owned runtime/portable/performance observations. A source-only recipe supplies no runtime credit. Retain exact failing attempts and investigate concrete failure facts before reruns.

Existing external/tag/lightweight, Tor/I2P, plugin/service/media/remote/public-swarm and release-scale dependencies remain assigned to their original phases and CF rows. They are not declared complete by this chapter. Original empty-first hybrid/v2 defects stay reproduced limitations; unmodified original failures are not relabelled native success. If those dependencies block an exact closure criterion, record the criterion as open rather than advertise universal seamless compatibility.

Execution constraints: native main; running original, real profile and payload untouched; original ordinary HEAD/index preserved; three aggregate compiler jobs; source-only parallel workers; one coherent source build before broad affected checks; reuse passing unchanged-source evidence. Durable paths are under this repository build tree, not /tmp. Temporary generated private subjects are disposable.
