"""Freeze exact final GCC build/producer association after its actual pass."""
from pathlib import Path
import argparse,hashlib,json,subprocess
W=Path(__file__).resolve().parent
N=Path('/home/yurii/Java/BiglyBTC')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--build-run',required=True);p.add_argument('--attempt',required=True);a=p.parse_args()
assert '/' not in a.build_run and '/' not in a.attempt
B=W/a.build_run
commands=json.loads((B/'commands.json').read_bytes())
assert {x['name'] for x in commands}>={'build','tests'} and all(x['exit']==0 for x in commands)
git=lambda *x:subprocess.check_output(['git',*x],cwd=N)
assert not git('status','--porcelain')
cid=git('rev-parse','HEAD').decode().strip()
graph={x:sha(N/x) for x in git('ls-files','-z','--','preview/native').decode().split('\0') if x}
receipt=B/'build-receipt.json';build=json.loads(receipt.read_bytes())
assert build['exit']==0 and build['source_commit']==cid and build['source_manifest_sha256']==sha(B/'build-source.json')
assert json.loads((B/'build-source.json').read_bytes())==graph
driver=N/'build/persistent-peer-accounting-20261021/bound-gcc/tests/biglybtc-managed-download-tests'
assert driver.name in build['command']
for name,recipe in [('existing','existing-storage-oracle/amendments/same-admission-upload'),('allocation','allocation-original-oracle')]:
    R=W/recipe
    own=json.loads((R/'manifest.json').read_bytes())
    artifacts=own.get('artifacts') or own.get('artifacts_sha256')
    assert artifacts
    for rel,digest in artifacts.items():assert sha(R/rel)==digest,(name,rel)
    inputs=json.loads((R/'inputs.json').read_bytes())
    for rel,digest in inputs['immutable_producer_paths'].items():assert graph[rel]==digest,(name,rel,'immutable source changed')
    record=json.loads((R/'completion.example.json').read_bytes())
    record.update(source_commit=cid,driver=str(driver),driver_sha256=sha(driver),tracked_source_sha256=graph,
        producer_source_sha256={rel:graph[rel] for rel in inputs['producer_paths']},build_receipt=str(receipt),build_receipt_sha256=sha(receipt))
    out=W/(name+'-completion-'+a.attempt+'.json');assert not out.exists()
    out.write_text(json.dumps(record,indent=2)+'\n');print(name,str(out),sha(out))
