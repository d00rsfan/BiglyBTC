from pathlib import Path
import ast,difflib,hashlib,json
here=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
base=json.loads((here/'base.json').read_text());before={};source={};patches=[]
for path in sorted((here/'staging').rglob('*')):
 if not path.is_file():continue
 name=path.relative_to(here/'staging').as_posix();old=here/'before'/name;data=path.read_bytes();prior=old.read_bytes() if old.exists() else b''
 if old.exists() and prior==data:
  old.unlink();path.unlink();continue
 before[name]=sha(prior) if old.exists() else None;source[name]=sha(data)
 if old.exists():assert before[name]==base['before_sha256'][name],name
 else:assert name not in base['before_sha256'],name
 patch=''.join(difflib.unified_diff(prior.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+name if old.exists() else '/dev/null',tofile='b/'+name))
 target=here/'patches'/(name+'.patch');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(patch);patches.append(patch)
(here/'changes.patch').write_text(''.join(patches))
(here/'before_sha256.json').write_text(json.dumps(before,indent=2)+'\n');(here/'source_sha256.json').write_text(json.dumps(source,indent=2)+'\n')
for path in (here/'oracle').glob('*.py'):ast.parse(path.read_text())
artifacts={path.relative_to(here).as_posix():sha(path.read_bytes()) for path in sorted(here.rglob('*')) if path.is_file() and path.name!='manifest.json' and 'runs' not in path.relative_to(here).parts}
manifest={'schema':1,'status':'FROZEN_SOURCE_ONLY_NO_EXECUTION','native_base':base['native_head'],'original_base':'cb8c6cb9bb97916cbc7e80338a017200ffc3e71f','dependencies':{'selected_manifest_sha256':base['selected_manifest_sha256'],'decoder_context_manifest_sha256':base['decoder_context_manifest_sha256']},'changed_paths':len(source),'before_sha256':before,'source_sha256':source,'artifacts':artifacts}
(here/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'manifest_sha256':sha((here/'manifest.json').read_bytes()),'changed_paths':len(source),'new_paths':sum(value is None for value in before.values()),'source':source},indent=2))
