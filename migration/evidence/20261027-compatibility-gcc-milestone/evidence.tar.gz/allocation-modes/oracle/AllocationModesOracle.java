import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.net.URL;
import java.net.URLClassLoader;

/** Source-only recipe: retained original methods, inert interface calls, no Core or payload. */
public final class AllocationModesOracle {
    public static void main(String[] args) throws Throwable {
        if (args.length != 2 || System.getSecurityManager() != null) {
            throw new IllegalArgumentException("Exact helper/cohort roots required");
        }
        QueueOracleFence fence = new QueueOracleFence();
        System.setSecurityManager(fence);
        URL[] roots = {new File(args[0]).toURI().toURL(), new File(args[1]).toURI().toURL()};
        try (URLClassLoader loader = new URLClassLoader(roots, ClassLoader.getSystemClassLoader().getParent())) {
            Class<?> actual = loader.loadClass("com.biglybt.core.torrent.impl.TorrentOpenOptions");
            File origin = new File(actual.getProtectionDomain().getCodeSource().getLocation().toURI()).getCanonicalFile();
            if (!origin.equals(new File(args[1]).getCanonicalFile())) {
                throw new IllegalStateException("Original subject was shadowed");
            }
            try { loader.loadClass("AllocationModesOracle$Subject").getMethod("observe").invoke(null); }
            catch (InvocationTargetException error) { throw error.getCause(); }
        }
        if (System.getSecurityManager() != fence) { throw new IllegalStateException("Fence replaced"); }
        fence.verify();
    }
    public static final class Subject {
        private static Object neutral(Class<?> type) {
            if (!type.isPrimitive() || type == Void.TYPE) { return null; }
            if (type == Boolean.TYPE) { return false; }
            if (type == Long.TYPE) { return 0L; }
            if (type == Integer.TYPE) { return 0; }
            throw new IllegalStateException("Unexpected original primitive call");
        }
        public static void observe() {
            for (int mode : new int[]{5, 6}) {
                final long[] fas = {-1}; final int[] listeners = {0}, pause = {0}, force = {0};
                ClassLoader loader = Subject.class.getClassLoader();
                Object state = Proxy.newProxyInstance(loader, new Class<?>[]{com.biglybt.core.download.DownloadManagerState.class}, (proxy, method, values) -> {
                    if (method.getName().equals("setLongAttribute")) {
                        if (!values[0].equals(com.biglybt.core.download.DownloadManagerState.AT_FILE_ALLOC_STRATEGY)) {
                            throw new IllegalStateException("Unexpected original attribute");
                        }
                        fas[0] = ((Long)values[1]).longValue();
                    }
                    return neutral(method.getReturnType());
                });
                com.biglybt.core.download.DownloadManager download = (com.biglybt.core.download.DownloadManager)Proxy.newProxyInstance(loader,
                    new Class<?>[]{com.biglybt.core.download.DownloadManager.class}, (proxy, method, values) -> {
                        if (method.getName().equals("getDownloadState")) { return state; }
                        if (method.getName().equals("addListener")) { listeners[0]++; }
                        if (method.getName().equals("pause")) { pause[0]++; }
                        if (method.getName().equals("setForceStart")) { force[0]++; }
                        return neutral(method.getReturnType());
                    });
                int before = com.biglybt.core.torrent.impl.TorrentOpenOptions.addModePreCreate(mode);
                com.biglybt.core.torrent.impl.TorrentOpenOptions.addModeDuringCreate(mode, download);
                com.biglybt.core.torrent.impl.TorrentOpenOptions.addModePostCreate(mode, download);
                if (before != 75 || fas[0] != 2 || listeners[0] != (mode == 6 ? 1 : 0) || pause[0] != 0 || force[0] != 0) {
                    throw new AssertionError("Actual original allocation-mode projection differs");
                }
                System.out.println("OBS\tmode" + mode + "\tpre=" + before + "\tfas=" + fas[0]
                    + "\tlisteners=" + listeners[0] + "\tpause=" + pause[0] + "\tforce=" + force[0]);
            }
        }
    }
}
