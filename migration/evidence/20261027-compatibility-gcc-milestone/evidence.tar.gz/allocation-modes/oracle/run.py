#!/usr/bin/env python3
"""Root-run only: two actual original allocation-mode method traces, no Core/IO activation."""
import argparse, hashlib, json, os, shutil, subprocess, tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(root):
    result={}
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file(): result[path.relative_to(root).as_posix()]=sha(path)
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--attempt',required=True);args=parser.parse_args()
    assert args.attempt.startswith('run-') and '/' not in args.attempt
    dest=HERE/'runs'/args.attempt;assert not dest.exists();dest.parent.mkdir(exist_ok=True)
    dep=json.loads((HERE/'dependencies.json').read_text());fence=Path(dep['fence']);cohort=Path(dep['cohort']);retention=Path(dep['retention'])
    assert sha(fence)==dep['fence_sha256'] and sha(retention)==dep['retention_sha256']
    retained=json.loads(retention.read_text());assert retained['source_commit']=='cb8c6cb9bb97916cbc7e80338a017200ffc3e71f' and retained['recompiled'] is False
    assert inventory(cohort)==retained['file_sha256']
    work=Path(tempfile.mkdtemp(prefix='biglybtc-queue-oracle-',dir='/tmp'));(work/'classes').mkdir();(work/'empty-sourcepath').mkdir();(work/'tmp').mkdir()
    result={'status':'FAILED','scope':'actual original method projection only; no disk allocation/runtime equivalence','commands':[],'cohort_files':len(retained['file_sha256']),'original_commit':retained['source_commit'],'helper_sha256':sha(HERE/'AllocationModesOracle.java')}
    environment={key:value for key,value in os.environ.items() if key not in ('CLASSPATH','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','LD_PRELOAD')}
    def run(name,argv):
        row={'name':name,'argv':list(map(str,argv))};result['commands'].append(row)
        with (work/(name+'.stdout')).open('w') as out,(work/(name+'.stderr')).open('w') as err:
            process=subprocess.Popen(row['argv'],cwd=work,env=environment,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
            try: row['exit_code']=process.wait(timeout=45)
            except subprocess.TimeoutExpired: process.kill();row['exit_code']=process.wait();raise RuntimeError('Bounded original trace timed out')
        assert row['exit_code']==0,name
    try:
        java=Path('/usr/lib/jvm/java-17-openjdk-amd64/bin');run('javac-helpers',[java/'javac','-J-XX:ActiveProcessorCount=2','--release','8','-encoding','UTF-8','-proc:none','-implicit:none','-sourcepath',work/'empty-sourcepath','-cp',cohort,'-d',work/'classes',fence,HERE/'AllocationModesOracle.java'])
        for path in (work/'classes').rglob('*.class'): assert path.name.split('$',1)[0] in ('AllocationModesOracle.class','AllocationModesOracle','QueueOracleFence.class'),path
        run('original',[java/'java','-XX:ActiveProcessorCount=2','-Xmx128m','-Djava.security.manager=allow','-Dqueue.oracle.root='+str(work),'-Dqueue.oracle.cohort='+str(cohort),'-Djava.io.tmpdir='+str(work/'tmp'),'-Duser.home='+str(work/'forbidden-home'),'-Dazureus.config.path='+str(work/'forbidden-profile'),'-cp',work/'classes','AllocationModesOracle',work/'classes',cohort])
        rows=[line for line in (work/'original.stdout').read_text().splitlines() if line.startswith('OBS\t')]
        assert rows==['OBS\tmode5\tpre=75\tfas=2\tlisteners=0\tpause=0\tforce=0','OBS\tmode6\tpre=75\tfas=2\tlisteners=1\tpause=0\tforce=0'],rows
        result.update(status='PASS',observations=rows,classes_sha256=inventory(work/'classes'))
    finally:
        result['cohort_unchanged']=inventory(cohort)==retained['file_sha256']
        if not result['cohort_unchanged']: result['status']='FAILED'
        (work/'result.json').write_text(json.dumps(result,indent=2)+'\n');shutil.copytree(work,dest);shutil.rmtree(work)
    assert result['status']=='PASS';print(dest/'result.json')
if __name__=='__main__': main()
