#!/usr/bin/env python3
"""Root-only actual allocation completion -> original stopped getters (no READY)."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import secrets
import shutil
import signal
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/yurii/Java/BiglyBT')
W = ROOT/'build/compatibility-chapter-20261027'
NATIVE = ROOT.parent/'BiglyBTC'
JAVA = Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')
PARENT = ROOT/'build/compatibility-20261026/verified-seeding-oracle/run.py'
if hashlib.sha256(PARENT.read_bytes()).hexdigest() != 'f54dfeb41a9994f191498e73ba7372710866487327318bf39cbf690180b12348':
    raise ValueError('Frozen retained IO/fence utility changed')
spec = importlib.util.spec_from_file_location('retained_allocation_io', PARENT)
base = importlib.util.module_from_spec(spec); spec.loader.exec_module(base)
need,sha,files,decimal = base.need,base.sha,base.files,base.decimal


def physical(path):
    value = base.physical(path); info = path.lstat()
    return {**value,'mode':info.st_mode,'nlink':info.st_nlink,'mtime_ns':info.st_mtime_ns,'ctime_ns':info.st_ctime_ns}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completion',type=Path,required=True)
    parser.add_argument('--completion-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE/'manifest.json').read_bytes())
    for name,digest in manifest['artifacts'].items(): need(sha(HERE/name)==digest,'Frozen recipe changed: '+name)
    inputs = json.loads((HERE/'inputs.json').read_bytes())
    for name,digest in inputs['files'].items(): need(sha(Path(name))==digest,'Frozen producer/helper changed: '+name)
    retained = json.loads(Path(inputs['retention']).read_bytes()); classes = Path(inputs['classes'])
    need(retained['source_commit']==inputs['original_commit'] and retained['recompiled'] is False
         and len(retained['file_sha256'])==5432 and files(classes)==retained['file_sha256'],'Exact retained original5432 cohort')
    completion_path = args.completion.resolve(strict=True)
    need(completion_path.is_relative_to(W) and sha(completion_path)==args.completion_sha256,'Exact root-reviewed completion')
    completion = json.loads(completion_path.read_bytes())
    need(completion['schema']==1 and completion['status']=='ROOT_REVIEWED_MATCHING_SOURCE_BUILD'
         and completion['producer_manifest_sha256']==inputs['producer_manifest_sha256']
         and completion['lane']=='gcc' and completion['sanitizers'] is False,'Actual root-reviewed primary producer/build')
    need(not any(os.environ.get(k) for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS')),'Uninstrumented primary GCC recipe only')
    need(not Path(completion['driver']).is_symlink(),'Actual producer, no caller alias')
    driver = Path(completion['driver']).resolve(strict=True)
    need(driver.name=='biglybtc-managed-download-tests' and os.access(driver,os.X_OK) and sha(driver)==completion['driver_sha256']
         and not any(x in driver.read_bytes() for x in (b'__asan_init',b'__ubsan_handle_',b'__lsan_init')),'Actual uninstrumented producer executable')
    def git(*argv): return subprocess.check_output(['git',*argv],cwd=NATIVE)
    need(git('rev-parse','HEAD').decode().strip()==completion['source_commit'] and not git('status','--porcelain')
         and not git('ls-files','--others','--exclude-standard','--','preview/native'),'Clean exact root-frozen source')
    graph = {name:sha(NATIVE/name) for name in git('ls-files','-z','--','preview/native').decode().split('\0') if name}
    need(graph==completion['tracked_source_sha256'],'Full tracked matching-source graph')
    producer = completion['producer_source_sha256']
    need(set(producer)==set(inputs['producer_paths']) and all(graph[name]==value for name,value in producer.items()),'Exact final reviewed common-file composition')
    for name,digest in inputs['immutable_producer_paths'].items(): need(producer[name]==digest,'Changed isolated allocation producer: '+name)
    build_path = Path(completion['build_receipt']).resolve(strict=True)
    need(build_path.is_relative_to(W) and build_path.name.endswith('-receipt.json') and sha(build_path)==completion['build_receipt_sha256'],'Exact actual build receipt')
    build = json.loads(build_path.read_bytes()); source_path = build_path.with_name(build_path.name[:-len('-receipt.json')]+'-source.json')
    need(build['exit']==0 and sha(source_path)==build['source_manifest_sha256'] and json.loads(source_path.read_bytes())==graph,'Passed actual matching-source build')
    need(driver.name in build['command'] and build['command'][build['command'].index('--build')+1]==str(driver.parent.parent),'Actual producer target/build directory')
    destination = args.output.absolute()
    need(destination.is_relative_to(HERE/'runs') and destination.resolve()==destination and not destination.exists(),'Fresh durable attempt only')
    destination.mkdir(mode=0o700,parents=True)
    work = Path(tempfile.mkdtemp(prefix='biglybtc-allocation-handoff-',dir='/tmp')); work.chmod(0o700)
    env = {k:v for k,v in os.environ.items() if k not in ('CLASSPATH','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','LD_PRELOAD','LD_AUDIT')}
    env.update(PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen')
    commands=[]; cases={}
    result={'status':'RUNNING','recipe_sha256':sha(HERE/'manifest.json'),'completion_sha256':args.completion_sha256,
            'driver_sha256':sha(driver),'source_commit':completion['source_commit'],'original_commit':inputs['original_commit'],
            'original_recompiled':False,'real_original_profile_or_process_access':False,'commands':commands,'cases':{},
            'scope':'Two actual native allocation exports and original stopped GlobalManager getters. No initialize/READY, original zero-fill, network payload, seeding or whole-family credit.'}
    def run(name,argv,timeout):
        row={'name':name,'argv':list(map(str,argv)),'timeout':timeout}; commands.append(row)
        (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        with (work/(name+'.stdout')).open('xb') as out,(work/(name+'.stderr')).open('xb') as err:
            started=time.monotonic(); child=None
            try:
                child=subprocess.Popen(row['argv'],cwd=work,env=env,stdout=out,stderr=err,start_new_session=True)
                while child.poll() is None:
                    left=timeout-(time.monotonic()-started); need(left>0,'Deadline: '+name)
                    try: child.wait(timeout=min(45,left))
                    except subprocess.TimeoutExpired: print('Allocation handoff active: '+name,flush=True)
            finally:
                if child is not None and child.poll() is None:
                    try: os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError: pass
                    child.wait()
                out.flush();err.flush();row.update(exit_code=None if child is None else child.returncode,seconds=time.monotonic()-started,
                    stdout_sha256=sha(work/(name+'.stdout')),stderr_sha256=sha(work/(name+'.stderr')))
                (work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        need(child is not None and child.returncode==0,'Actual command failed; logs retained: '+name)
        return (work/(name+'.stdout')).read_text(errors='replace')
    try:
        for name in ('classes','empty-sourcepath','native-before-java'): (work/name).mkdir(mode=0o700)
        shutil.copyfile(completion_path,work/'root-completion.json');shutil.copyfile(build_path,work/'build-receipt.json');shutil.copyfile(source_path,work/'build-source.json')
        sys.path.insert(0,str(ROOT/'migration/tools'))
        from handoff import decode
        from peer_interop import jvm,unused_port
        def document(path):
            raw=path.read_bytes();raw=gzip.decompress(raw) if raw.startswith(b'\x1f\x8b') else raw
            need(len(raw)<=4*1024*1024,'Bounded owned document');doc,spans=decode(raw);need(isinstance(doc,dict),'Actual dictionary');return doc,spans
        run('javac-stopped-helper',[JAVA/'javac','-J-XX:ActiveProcessorCount=1','--release','8','-encoding','UTF-8','-proc:none','-implicit:none',
            '-sourcepath',work/'empty-sourcepath','-cp',classes,'-d',work/'classes',ROOT/'migration/fixtures/java/ReferenceFence.java',
            ROOT/'migration/fixtures/java/EngineOracle.java',HERE/'AllocationStoppedOracle.java'],90)
        helpers=files(work/'classes')
        need(set(helpers)=={'ReferenceFence.class','EngineOracle.class','EngineOracle$1.class','AllocationStoppedOracle.class'},'Thin helper-only compilation')
        cp=str(work/'classes')+os.pathsep+str(classes)
        for name,mode in (('stopped',5),('paused',6)):
            case=Path('/tmp')/('biglybtc-allocation-oracle-'+secrets.token_hex(16)+'-'+name)
            need(not case.exists() and not case.is_symlink(),'Fresh absent producer root');cases[name]=case
            run('native-'+name,[driver,'--prepare-allocated-profile',case,name],120)
            receipt=json.loads((case/'native-receipt.json').read_bytes())
            need(receipt['schema']==1 and receipt['mode']==mode and receipt['allocationComplete'] is True
                 and receipt['sessionJoined'] is True and receipt['storageReleased'] is True,'Actual completed owner work/join/fence')
            profile=case/'profile';metadata=case/'source.torrent';payload=case/'payload'/'sample.bin'
            need(receipt['profile']==str(profile) and receipt['metadata']==str(metadata),'Exact independent generated profile/source')
            source,raw=document(metadata); inventory,inv_raw=document(profile/'downloads.config')
            need(len(inventory[b'downloads'])==1,'One native saved allocation row');row=inventory[b'downloads'][0]
            identity=hashlib.sha1(raw[(b'info',)]).hexdigest().upper(); full=identity
            state=profile/'active'/(identity+'.dat');archive=profile/'torrents'/(identity+'.torrent');saved,saved_raw=document(state)
            need(receipt['hash'].upper()==identity and row[b'torrent_hash']==bytes.fromhex(identity)
                 and receipt['state']==str(state) and receipt['archive']==str(archive)
                 and archive.read_bytes()==metadata.read_bytes() and saved_raw[(b'info',)]==raw[(b'info',)],'Raw metadata/archive/full selected v1 identity')
            need(source[b'info'][b'name']==b'sample.bin' and b'files' not in source[b'info']
                 and 0<source[b'info'][b'length']<=8*1024*1024,'Finite simple real v1 layout')
            need(row[b'state']==70 and row[b'forceStart']==0 and row[b'allocated']==1 and row[b'BiglyBTC.allocationMode']==mode
                 and row[b'BiglyBTC.allocationState']==2 and saved[b'attributes'][b'fas']==2,'Final stopped original allocation and separate native completion')
            pauses=inventory.get(b'pause_data',[])
            need(pauses==([{b'hash':bytes.fromhex(identity),b'force':0,b'owner':1}] if mode==6 else []),'Exact original paused encoding for mode6 only')
            need(saved_raw[(b'opaque.source',)]==raw[(b'opaque.source',)] and saved_raw[(b'attributes',b'opaque')]==raw[(b'attributes',b'opaque')],'Native original opaque metadata bytes')
            resume=saved[b'resume'][b'data'];pieces=source[b'info'][b'pieces'];piece_size=source[b'info'][b'piece length'];size=source[b'info'][b'length']
            need(type(piece_size) is int and piece_size>0 and len(pieces)==20*((size+piece_size-1)//piece_size)
                 and resume[b'valid']==0 and resume[b'resume data']==bytes([2])*(len(pieces)//20),'Allocated bytes remain entirely RECHECK, not verified')
            data=payload.read_bytes();need(len(data)==size and data==bytes(size),'Actual whole output is zero-filled')
            need(any(hashlib.sha1(data[at:at+piece_size]).digest()!=pieces[(at//piece_size)*20:(at//piece_size+1)*20] for at in range(0,size,piece_size)),
                 'Independent advertised hashes do not certify allocated zeros')
            actual=physical(payload);exported=receipt['files'];need(len(exported)==1 and exported[0]['path']==str(payload)
                 and exported[0]['sha256'].lower()==actual['sha256'] and decimal(exported[0]['bytes'],'Actual bytes')==size
                 and decimal(exported[0]['dev'],'Actual device')==actual['dev'] and decimal(exported[0]['ino'],'Actual inode')==actual['ino'],'Actual producer physical receipt')
            before=work/'native-before-java'/name;shutil.copytree(profile,before/'profile');shutil.copyfile(case/'native-receipt.json',before/'native-receipt.json')
            source_sha=sha(metadata);port=unused_port()
            stdout=run('original-stopped-'+name,[*jvm(case,cp,(port,)),'AllocationStoppedOracle',port],180)
            observed={}
            for line in stdout.splitlines():
                cols=line.split('\t')
                if cols[0] in ('IDENTITY','ALLOCATION','SAVE','COUNTERS'):
                    need(cols[0] not in observed,'Unique actual original getter');observed[cols[0]]=cols[1:]
            need(stdout.splitlines().count('PASS_ORIGINAL_ALLOCATION_STOPPED\t1')==1
                 and observed.get('IDENTITY')==[identity,full]
                 and observed.get('ALLOCATION')==['70','false',str(mode==6).lower(),'true','2']
                 and observed.get('SAVE')==[str(payload).encode().hex().upper()]
                 and observed.get('COUNTERS')==[str(row[b'downloaded']),str(row[b'uploaded'])],'Actual stopped original identity/allocation/pause/getters')
            need(physical(payload)==actual and sha(metadata)==source_sha,'Original stopped reload leaves exact zero payload and source untouched')
            for path in (state,archive):
                _,after=document(path);need(after[(b'info',)]==raw[(b'info',)] and after[(b'opaque.source',)]==raw[(b'opaque.source',)],'Original raw hash/opaque metadata preserved')
            after,after_raw=document(profile/'downloads.config');need(len(after[b'downloads'])==1,'One original post-close row');post=after[b'downloads'][0]
            need(post[b'torrent_hash']==row[b'torrent_hash'] and post[b'state']==70 and post[b'forceStart']==0 and post[b'allocated']==1
                 and post[b'save_dir']==row[b'save_dir'] and post[b'save_file']==row[b'save_file'],'Actual post-Core.stop original saved identity/path/stop/allocation')
            private=lambda doc,spans:{key.decode():spans[(b'downloads',0,key)].hex() if key in doc[b'downloads'][0] else None for key in (b'BiglyBTC.allocationMode',b'BiglyBTC.allocationState',b'BiglyBTC.allocationSnapshot')}
            result['cases'][name]={'status':'PASS','native_receipt':receipt,'original_observed':observed,'physical':actual,
                'native_private_before':private(inventory,inv_raw),'original_private_after':private(after,after_raw),'listener_reservation':port,
                'native_reopen_executed':False,'original_initialized':False,'original_ready':False}
            (work/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        need(files(work/'classes')==helpers and sha(driver)==completion['driver_sha256'],'Actual helper/producer unchanged')
        result.update(status='PASS_ACTUAL_ALLOCATION_ORIGINAL_STOPPED',actual_cases=len(result['cases']),actual_original_processes=len(result['cases']),helper_class_sha256=helpers)
    except BaseException as error:
        result.update(status='FAIL',error=repr(error));raise
    finally:
        try: need(files(classes)==retained['file_sha256'] and all(sha(Path(p))==d for p,d in inputs['files'].items()),'Original cohort/frozen inputs unchanged')
        except BaseException as error:result.update(status='FAIL_COHORT',cohort_error=repr(error));raise
        finally:
            (work/'result.json').write_text(json.dumps(result,indent=2)+'\n')
            try:
                files(work);shutil.copytree(work,destination/'generated')
                for name,case in cases.items():
                    if case.exists():files(case);shutil.copytree(case,destination/'generated-cases'/name)
                (destination/'result.json').write_text(json.dumps(result,indent=2)+'\n')
            except BaseException:
                print('Archive incomplete; generated work/cases retained: '+str(work)+' '+str(cases),flush=True);raise
            else:
                shutil.rmtree(work)
                for case in cases.values():
                    if case.exists():shutil.rmtree(case)
                print('Retained actual attempt: '+str(destination),flush=True)


if __name__=='__main__':main()
