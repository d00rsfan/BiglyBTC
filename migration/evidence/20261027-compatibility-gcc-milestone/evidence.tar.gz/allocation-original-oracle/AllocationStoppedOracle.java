import com.biglybt.core.Core;
import com.biglybt.core.CoreFactory;
import com.biglybt.core.config.COConfigurationManager;
import com.biglybt.core.download.DownloadManager;
import com.biglybt.core.download.DownloadManagerState;
import com.biglybt.core.torrent.TOTorrent;
import com.biglybt.core.util.ByteFormatter;
import com.biglybt.pif.PluginManager;
import com.biglybt.pif.PluginManagerDefaults;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/** Stopped GlobalManager readback only: no initialize, READY or download. */
public final class AllocationStoppedOracle {
    private static void need(boolean value, String why) {
        if (!value) { throw new IllegalStateException(why); }
    }
    private static void guard() {
        need(System.getSecurityManager() instanceof ReferenceFence, "Strict reference fence required");
    }
    private static String hex(byte[] value) {
        return value == null ? "-" : ByteFormatter.encodeString(value);
    }
    private static String hex(String value) {
        return hex(value.getBytes(StandardCharsets.UTF_8));
    }
    static Core configuredStoppedCore(int listenPort) throws Exception {
        guard();
        Class.forName("com.biglybt.core.util.Debug");
        COConfigurationManager.setParameter("TCP.Listen.Port", listenPort);
        COConfigurationManager.setParameter("TCP.Listen.Port.Enable", false);
        COConfigurationManager.setParameter("UDP.Listen.Port.Enable", false);
        COConfigurationManager.setParameter("UDP.NonData.Listen.Port.Enable", false);
        COConfigurationManager.setParameter("Bind IP", "127.0.0.1");
        COConfigurationManager.setParameter("Enforce Bind IP", true);
        COConfigurationManager.setParameter("Check Bind IP On Start", false);
        COConfigurationManager.setParameter("IPV6 Enable Support", false);
        COConfigurationManager.setParameter("network.tcp.read.select.time", 25);
        COConfigurationManager.setParameter("network.tcp.write.select.time", 25);
        COConfigurationManager.setParameter("Use Resume", true);
        COConfigurationManager.setParameter("Rename Incomplete Files", true);
        COConfigurationManager.setParameter("Rename Incomplete Files Extension", ".az!");
        COConfigurationManager.setParameter("Move Completed When Done", false);
        COConfigurationManager.setParameter("Save Torrent Files", false);
        COConfigurationManager.setParameter("update.start", false);
        COConfigurationManager.setParameter("update.periodic", false);
        COConfigurationManager.setParameter("VersionCheck.CheckAtStart", false);
        PluginManagerDefaults defaults = PluginManager.getDefaults();
        for (String plugin : defaults.getDefaultPlugins()) {
            defaults.setDefaultPluginEnabled(plugin, false);
        }
        return CoreFactory.create();
    }

    private static void run(String[] args) throws Exception {
        guard(); need(args.length == 1, "One owned listener reservation required");
        int port = Integer.parseInt(args[0]); need(port > 0 && port <= 65535, "Owned reservation range");
        Path root = Paths.get(System.getProperty("biglybtc.test.root")).toRealPath();
        need(root.getParent().toString().equals("/tmp")
            && root.getFileName().toString().startsWith("biglybtc-allocation-oracle-"), "Generated owned case root required");
        Core core = configuredStoppedCore(port);
        boolean started = false;
        try {
            core.start(); started = true; guard();
            List<DownloadManager> rows = core.getGlobalManager().getDownloadManagers();
            need(rows.size() == 1, "Exactly one native allocated saved row required");
            DownloadManager manager = rows.get(0); TOTorrent torrent = manager.getTorrent();
            need(torrent != null && torrent.getTorrentType() == TOTorrent.TT_V1 && torrent.isSimpleTorrent(), "Finite ordinary single-file v1 profile");
            need(manager.getState() == DownloadManager.STATE_STOPPED && manager.getDiskManager() == null
                && manager.getPeerManager() == null, "Stopped lazy subject must not acquire disk or peer execution");
            System.out.println("IDENTITY\t" + hex(torrent.getHash()) + "\t" + hex(torrent.getFullHash(TOTorrent.TT_V1)));
            System.out.println("ALLOCATION\t" + manager.getState() + "\t" + manager.isForceStart()
                + "\t" + manager.isPaused() + "\t" + manager.isDataAlreadyAllocated()
                + "\t" + manager.getDownloadState().getLongAttribute(DownloadManagerState.AT_FILE_ALLOC_STRATEGY));
            System.out.println("SAVE\t" + hex(manager.getAbsoluteSaveLocation().toPath().toAbsolutePath().normalize().toString()));
            System.out.println("COUNTERS\t" + manager.getStats().getTotalDataBytesReceived() + "\t" + manager.getStats().getTotalDataBytesSent());
        } finally {
            if (started) { core.stop(); }
        }
        guard(); System.out.println("PASS_ORIGINAL_ALLOCATION_STOPPED\t1");
    }
    public static void main(String[] args) {
        try { run(args); System.exit(0); }
        catch (Throwable error) { error.printStackTrace(); System.exit(2); }
    }
}
