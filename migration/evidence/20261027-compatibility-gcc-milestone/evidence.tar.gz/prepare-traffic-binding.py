from pathlib import Path
import hashlib,json,re,shutil
W=Path(__file__).resolve().parent;N=W.parents[2]/'BiglyBTC';P=W/'provider-traffic-v3';OUT=W/'runtime-binding-traffic';OUT.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((P/'source-build-record.json').read_bytes());review=json.loads((P/'root-review.json').read_bytes());assert sha(P/'source-build-record.json')==review['record_sha256']
sources={};before={}
def put(rel,data):
 p=OUT/'staging'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data.encode() if isinstance(data,str) else data);sources[rel]=sha(p)
 old=N/rel;before[rel]=sha(old) if old.exists() else None
 if old.exists():b=OUT/'before'/rel;b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old,b)
B='preview/native/engine/runtime-binding/'
put(B+'provider-traffic-source-build-record.json',(P/'source-build-record.json').read_bytes())
manifest={k:record[k] for k in ('schema','causal_qualified','source_root','build_root','install_root','artifact','artifact_sha256','artifact_bytes')};manifest.update(purpose='source-bound-qualification-only',source_build_record='provider-traffic-source-build-record.json',source_build_record_sha256=review['record_sha256'])
put(B+'provider-traffic-runtime.json',json.dumps(manifest,indent=2)+'\n');pin=sources[B+'provider-traffic-runtime.json']
old=(N/(B+'verify_runtime_manifest_queue.py')).read_text()
new=old.replace('MANIFEST_SHA = \'f95542706a3b7324c6f2589d90d51a4374c92e7e245319b156f044aeec76a1d8\'',f'MANIFEST_SHA = {pin!r}')
new=new.replace("RECORD_SHA = '598a2501d1fb3175df4d7fe49e46add045ba78e79c9c0288b7d5b04b4cbaf087'",f'RECORD_SHA = {review["record_sha256"]!r}')
new=new.replace("PARENT_HELPER_SHA = 'b07b80c7aa6b0e1371f583eb15051b337cb4d8e96af76c65da5e20bcf6f00ab0'",f'PARENT_HELPER_SHA = {sha(N/(B+"verify_runtime_manifest_queue.py"))!r}')
new=new.replace("verify_runtime_manifest_webseed.py","verify_runtime_manifest_queue.py").replace("biglybtc_queue_parent","biglybtc_traffic_parent")
new=new.replace("/provider-queue'","/provider-traffic-v3'").replace("provider-queue-source-build-record.json","provider-traffic-source-build-record.json")
new=new.replace("old.parent_helpers()","old.parent().parent_helpers()")
new=new.replace("old_manifest=path.parent/'provider-webseed-runtime.json'","old_manifest=path.parent/'provider-queue-runtime.json'")
needle="('socks4a-tests',{'socks4a-provider'})";assert new.count(needle)==1;new=new.replace(needle,needle+",('traffic-tests',{'traffic-v3-owned-corrupt-duplicate'})")
needle="'socks4a-configure','socks4a-build','socks4a-tests']";assert new.count(needle)==1;new=new.replace(needle,"'socks4a-configure','socks4a-build','socks4a-tests','traffic-configure','traffic-build','traffic-tests']")
new=new.replace("'provider_queue_observer':True","'provider_queue_observer':True,'provider_traffic_v3':True")
put(B+'verify_runtime_manifest_traffic.py',new)
put(B+'PersistentRuntimeBinding.cmake',(N/(B+'PersistentRuntimeBinding.cmake')).read_text().replace('verify_runtime_manifest_queue.py','verify_runtime_manifest_traffic.py'))
rel='preview/native/engine/persistent_runtime_guard.cpp';s=(N/rel).read_text();needle='bool hashed(int descriptor) {';assert s.count(needle)==1
s=s.replace(needle,f'''bool relocatableTrafficProviderArtifact() {{
  return std::string_view(runtime_binding::manifest)=="{pin}"
      &&std::string_view(runtime_binding::sha256)=="{record['artifact_sha256']}"
      &&runtime_binding::bytes=={record['artifact_bytes']}ULL;
}}
'''+needle)
s=s.replace('&& !relocatableQueueProviderArtifact()))','&& !relocatableQueueProviderArtifact() && !relocatableTrafficProviderArtifact()))');put(rel,s)
T='preview/native/tests/'
s=(N/(T+'RuntimeDeploymentTests.cmake')).read_text();needle='OR _biglybtc_deployment_manifest STREQUAL "f95542706a3b7324c6f2589d90d51a4374c92e7e245319b156f044aeec76a1d8")';assert s.count(needle)==1;s=s.replace(needle,needle[:-1]+'\n      OR _biglybtc_deployment_manifest STREQUAL "'+pin+'")');put(T+'RuntimeDeploymentTests.cmake',s)
s=(N/(T+'NetworkProxyCapabilityTests.cmake')).read_text();needle='OR _biglybtc_socks4_manifest STREQUAL "f95542706a3b7324c6f2589d90d51a4374c92e7e245319b156f044aeec76a1d8")';assert s.count(needle)==1;s=s.replace(needle,needle[:-1]+'\n        OR _biglybtc_socks4_manifest STREQUAL "'+pin+'")');put(T+'NetworkProxyCapabilityTests.cmake',s)
s=(N/(T+'runtime_deployment_tests.py')).read_text();s=s.replace('"queue", "strict"','"queue", "traffic", "strict"');a=s.index('    elif args.mode == "queue":');b=s.index('    elif ',a+10);branch=s[a:b].replace('args.mode == "queue"','args.mode == "traffic"').replace('f95542706a3b7324c6f2589d90d51a4374c92e7e245319b156f044aeec76a1d8',pin).replace('7449ec6f503f4b8da26e61f4c0926ca414774f6b859405439eec2ebe227fbd9e',record['artifact_sha256']).replace('9085816',str(record['artifact_bytes'])).replace('Queue observer','Traffic V3');s=s[:b]+branch+s[b:];put(T+'runtime_deployment_tests.py',s)
s=(N/(T+'ProviderQueueRuntimeTests.cmake')).read_text().replace('f95542706a3b7324c6f2589d90d51a4374c92e7e245319b156f044aeec76a1d8',pin).replace('provider-queue','provider-traffic').replace('provider_queue_runtime_inputs_tests.py','provider_traffic_runtime_inputs_tests.py').replace('--mode queue','--mode traffic').replace('queue observer','traffic V3').replace('Queue observer','Traffic V3');put(T+'ProviderTrafficRuntimeTests.cmake',s)
s=(N/(T+'provider_queue_runtime_inputs_tests.py')).read_text().replace('provider-queue','provider-traffic').replace('verify_runtime_manifest_queue.py','verify_runtime_manifest_traffic.py').replace('provider-webseed-runtime.json','provider-queue-runtime.json').replace('QueueInputs','TrafficInputs');put(T+'provider_traffic_runtime_inputs_tests.py',s)
put(T+'CMakeLists.txt',(N/(T+'CMakeLists.txt')).read_text()+'\ninclude("${CMAKE_CURRENT_SOURCE_DIR}/ProviderTrafficRuntimeTests.cmake")\n')
(OUT/'manifest.json').write_text(json.dumps(dict(status='EXACT_PROVIDER_DIRECTLY_QUALIFIED_NATIVE_BINDING_UNEXECUTED',before_sha256=before,source_sha256=sources,artifact_sha256=record['artifact_sha256'],record_sha256=review['record_sha256'],runtime_manifest_sha256=pin,parent_queue_helper_preserved=True),indent=2)+'\n')
print('Prepared additive binding',pin,'for artifact',record['artifact_sha256'])
