"""Archive finished current-milestone evidence; never close the whole chapter."""
from pathlib import Path
import datetime,hashlib,json,os,stat,subprocess,tarfile
W=Path(__file__).resolve().parent;R=W.parents[1];N=R.parent/'BiglyBTC'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda root,*x:subprocess.check_output(['git',*x],cwd=root)
cid=git(N,'rev-parse','HEAD').decode().strip()
assert cid=='7405a61a7a605c9962cc7a630b06fef25c0a5c66' and not git(N,'status','--porcelain')
gcc=json.loads((W/'gcc-final-r4/result.json').read_bytes())
assert gcc['source_commit']==cid and gcc['tests']==40 and len(gcc['unchanged_passed_tests_reused'])==39
assert git(R,'rev-parse','HEAD').decode().strip()=='cb8c6cb9bb97916cbc7e80338a017200ffc3e71f'
assert sha(R/'.git/index')=='ac45601f3bed2b3a3d2ac91d715e4b052108a5b7478de62bb67f165ce0de30d4'
relative='migration/evidence/20261027-compatibility-gcc-milestone'
E=R/relative;E.mkdir()
index=[];skipped=[]
with tarfile.open(E/'evidence.tar.gz','w:gz',compresslevel=3) as archive:
    for directory,dirs,files in os.walk(W,followlinks=False):
        here=Path(directory);parts=here.relative_to(W).parts
        dirs[:]=sorted(d for d in dirs if d not in ('.git','__pycache__','CMakeFiles','compiler-tmp')
            and not (here/d).is_symlink()
            and not (len(parts)==1 and parts[0] in ('provider-traffic-v3','provider-queue') and d in ('source','build','install')))
        for name in sorted(files):
            p=here/name;rel=p.relative_to(W).as_posix();s=p.lstat()
            reason=None
            if not stat.S_ISREG(s.st_mode):reason='nonregular input retained locally'
            elif rel=='bad-peer-diagnostic-r1/network.trace':reason='host interface inventory; owned wire excerpt is archived instead'
            elif s.st_size>8*1024*1024:reason='large generated subject retained locally; actual digest/recipe retained'
            elif p.suffix in ('.pyc','.class','.o','.a','.so'):reason='compiled artifact; exact source/build/artifact pins retained'
            if reason is None:
                with p.open('rb') as f:magic=f.read(8)
                if magic.startswith(b'\x7fELF') or magic.startswith(b'!<arch>'):reason='compiled artifact; exact pins retained'
            if reason:
                skipped.append({'path':rel,'bytes':s.st_size,'reason':reason});continue
            pin=sha(p);archive.add(p,arcname=rel,recursive=False)
            index.append({'path':rel,'bytes':s.st_size,'sha256':pin})
(E/'archive-index.json').write_text(json.dumps({'files':index,'excluded':skipped,'local_durable_root':str(W)},indent=2)+'\n')
def observation(path):
    p=W/path;d=json.loads(p.read_bytes());return {'result':path,'sha256':sha(p),'status':d['status']}
observations={
 'filename':observation('filename-conversions/runs/run-r1/result.json'),
 'lan':observation('lan-oracle/run-r1/result.json'),
 'v1_file_operations':observation('library-workflows/runs/run-r1/result.json'),
 'raw_decoder':observation('decoder-oracle/amendments/bounded-fallback-helper/runs/run-r1/result.json'),
 'queue_scalars':observation('queue-idle/oracle/amendments/interface-provider/oracle/run-r1/result.json'),
 'versioned_file_operations':observation('versioned-fileops/runs/run-r1/result.json'),
 'creator_initial':observation('creator-virtual/runs/run-r1/result.json'),
 'creator_remaining':observation('creator-virtual/runs/run-r2-remaining/result.json'),
 'creator_nonempty':observation('creator-virtual/runs/run-r3-nonempty/result.json')}
chain=git(N,'log','--reverse','--format=%H','6f005c2af60224d16596747d5192b2bbc7ec267a..'+cid).decode().splitlines()
v={'status':'CURRENT_GCC_MILESTONE_COMPLETE_USER_REQUESTED_STOP','native_source':cid,
 'original_source':'cb8c6cb9bb97916cbc7e80338a017200ffc3e71f','source_commits':chain,
 'gcc':gcc,'observations':observations,'archive_sha256':sha(E/'evidence.tar.gz'),
 'archive_index_sha256':sha(E/'archive-index.json'),'archive_bytes':(E/'evidence.tar.gz').stat().st_size,
 'chapter_complete':False,'cf_parents_closed':[],'dist_promoted':False,
 'previous_dist_manifest_sha256':'e34ade281e7c8548c837968f7c095042d93862a4e1312f790feba464de3ba421',
 'original_head_unchanged':True,'original_index_sha256_unchanged':sha(R/'.git/index'),
 'pending':['Original linked/selected11 and allocation stopped2 readback recipes',
 'Final Clang and leak-enabled ASan/UBSan consumer qualification',
 'Private GCC/Clang portable runtime/launcher/GUI qualification and dist promotion',
 'Original creator empty-file Merkle/linkage defects and wider documented compatibility limits'],
 'boundary':'Finish current milestone then STOP. Resume only on a later user instruction.'}
(E/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
review=f'''# Current GCC milestone — stopped at user request

Native source `{cid}`; original baseline `cb8c6cb9bb97916cbc7e80338a017200ffc3e71f`.

The selected-existing directory traversal now requires directories with matching device/inode identities, retaining every ancestor replacement check. It previously called a regular-file predicate and refused every selected admission. Direct regression coverage accepts unrelated directory timestamp changes and refuses replacement of a higher ancestor even when the bottom parent and leaf inodes survive. Authentic selected read-only transfer now passes for linear missing data, C/R/X boundary layouts and V2; missing/unverified pieces remain unverified.

Receiver receipts wait for actual upload publication from the same retained admission after complete received-byte/hash verification. Corrupt-existing cases require the exact previously observed verification failure at close together with joined session and released storage. Positive/stopped cases retain the no-checkpoint-failure requirement. No counter is synthesized and no production encryption policy changes.

[GCC evidence](verification.json): 39 successful suites ran at `d14719ddd2714788dc8d0b66e7e6abbeac9f9aeb`. Only the selected-corrupt close expectation remained incorrect. The final commit changes one test file only; all registered commands, reused command inputs, compiled test images and generated runtime-binding/cache bytes were hashed before and after the incremental build. The corrected managed-download suite was actually rerun and passed. This is explicit reuse of unchanged results, not a claim that forty new runs happened at the final commit. Full logs and prior failures remain in the archive. GCC16/C++23/Qt6.12 were used with at most three compiler jobs.

Earlier bounded actual observations retain their own source commits: naming13 cases/39lines, LAN41, V1 file operations4 original READY reloads, raw decoder8565 comparisons, queue40 cases/84 scalars, and versioned file operations15 original READY reloads. Creator observations total ten distinct positive subjects and three original-accessor failures across thirteen attempted subjects. Empty-file hybrid root fixup throws in original `TOTorrentCreateV2Impl.setV2FileHashes`; the pure-V2 empty descriptor independently miscounts a linkage index. Failed cases remain failed. New nonempty V2/hybrid descriptor subjects pass the unchanged original helper. These observations do not establish universal filename, chooser/history, allocation or original-creator parity.

This milestone also retains the chapter's already committed allocation5/6, filename-context, file-operation/recovery, creator, queue/provider and LAN work. Its current native GCC checks pass; the chapter is **unfinished**. The original linked/selected11 and allocation2 recipes, secondary compiler/sanitizer lanes and private portable/dist qualification remain pending. No broader CF parent, integration baseline, external dependency or release approval advances. The previous118-leaf dist and narrow Wayland preview workaround remain in place. The running original was not interrupted and no real profile/payload was selected.

Latest user boundary: finish the current milestone, then stop. No further milestone, compiler lane, original subject or distribution promotion starts until resumed. Durable continuation: `build/compatibility-chapter-20261027/checkpoint.json`. Source capsules and complete large generated subjects remain in that durable build tree; compiled artifacts and the host-interface diagnostic trace are deliberately excluded from the public archive. The owned-loopback trace excerpt and exact artifact/record hashes are retained.
'''
(E/'REVIEW.md').write_text(review)
print(json.dumps({'evidence':relative,'files':len(index),'excluded':len(skipped),'archive_bytes':v['archive_bytes'],'source':cid}))
