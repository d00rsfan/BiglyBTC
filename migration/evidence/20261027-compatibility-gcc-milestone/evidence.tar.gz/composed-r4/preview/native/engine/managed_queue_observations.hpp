#pragma once
#include "biglybtc/queue_observations.hpp"
#include <atomic>
#include <mutex>
#include <vector>
namespace biglybtc::engine::detail {
// Worker reads and provider executor pushes; no LT/private pointer is retained.
class ManagedQueueObservations final {
public:
  explicit ManagedQueueObservations(unsigned protocol):facts_(protocol){}
  void restore(std::optional<std::string_view> aggregate,std::optional<std::int64_t> legacy) noexcept {
    if(aggregate){static_cast<void>(facts_.restoreAggregate(*aggregate));}
    else if(legacy){facts_.restoreLegacy(*legacy);}
  }
  void trackerOrder(const std::optional<std::vector<std::array<unsigned char,32>>>& order) noexcept {
    if(order){static_cast<void>(facts_.trackerOrder(*order));}
  }
  void installed() noexcept {installed_.store(true,std::memory_order_release);}
  void observe(const core::QueueObservation& event) noexcept {
    try {const std::lock_guard lock(mutex_);static_cast<void>(facts_.observe(event));}
    catch(...){failed_.store(true,std::memory_order_release);}
  }
  core::QueueObservedFacts facts(std::int64_t now) const noexcept {
    if(!installed_.load(std::memory_order_acquire)||failed_.load(std::memory_order_acquire)){return {};}
    try {const std::lock_guard lock(mutex_);return facts_.facts(now);}catch(...){return {};}
  }
  std::optional<core::QueueObservedDurations> settledDurations() const noexcept {
    if(!installed_.load(std::memory_order_acquire)||failed_.load(std::memory_order_acquire)){return {};}
    try{const std::lock_guard lock(mutex_);return facts_.settledDurations();}catch(...){return {};}
  }
private:
  mutable std::mutex mutex_;core::QueueOwnerObservations facts_;
  std::atomic<bool> installed_{false},failed_{false};
};
}
