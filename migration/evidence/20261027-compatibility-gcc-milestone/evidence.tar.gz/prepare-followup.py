from pathlib import Path
import json,hashlib,shutil,difflib,subprocess
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');out=w/'followup-r1';out.mkdir();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();steps=[]
def overlay(name,cap,before):
 d=json.loads((cap/'manifest.json').read_text());sources=d.get('source_sha256') or {k:v['source_sha256'] for k,v in d['paths'].items()}
 for rel,pin in sources.items():
  src=cap/'staging'/rel;assert h(src)==pin,(name,rel)
  dst=out/rel
  if not dst.exists() and (n/rel).exists():dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(n/rel,dst)
  original=(before/rel).read_text() if (before/rel).is_file() else ''
  expected=d.get('before_sha256',{}).get(rel,d.get('paths',{}).get(rel,{}).get('before_sha256'))
  if expected is not None:assert hashlib.sha256(original.encode()).hexdigest()==expected,(name,rel,'wrong before')
  current=dst.read_text() if dst.exists() else '';desired=src.read_text()
  if current==original:dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(desired)
  elif current!=desired:
   patch=''.join(difflib.unified_diff(original.splitlines(True),desired.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel,n=1));r=subprocess.run(['git','apply','--whitespace=nowarn','-'],cwd=out,input=patch.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0,(name,rel,r.stderr.decode())
  steps.append(dict(capsule=name,path=rel,sha256=h(dst)))
overlay('mmap-latency',w/'mmap-latency',w/'mmap-latency/before')
overlay('mmap-abort',w/'mmap-latency/amendments/abort-retirement',w/'mmap-latency/staging')
overlay('positive-seed-start',w/'queue-facts/amendments/positive-seed-start',w/'queue-facts/staging')
rel=Path('preview/native/tests/linear_to_compact_tests.cpp');p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);s=(n/rel).read_text();needle='check(core::encodeValue(*after.find("info"),st::compatibleConfigLimits())==sourceInfo&&';assert s.count(needle)==1;s=s.replace(needle,'const auto restoredInfo=core::encodeValue(*after.find("info"),st::compatibleConfigLimits());check(restoredInfo&&*restoredInfo==*sourceInfo&&');p.write_text(s);steps.append(dict(capsule='root-compile-assertion-fix',path=str(rel),sha256=h(p)))
(w/'followup-steps.json').write_text(json.dumps(steps,indent=2)+'\n');print('Prepared',len(steps),'operations;',len(set(x['path'] for x in steps)),'files; no native mutation')
