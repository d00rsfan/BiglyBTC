import com.biglybt.core.torrent.TOTorrent;
import com.biglybt.core.torrent.TOTorrentFactory;
import com.biglybt.core.torrent.TOTorrentFile;
import com.biglybt.core.util.TorrentUtils;
import java.io.File;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import java.util.List;

/** Original parser + actual original creator extra hashes, no Core/session. */
public final class CreatorMetadataOracle {
    static void need(boolean okay,String why) { if(!okay) throw new IllegalStateException(why); }
    static String hex(byte[] bytes) {
        if(bytes==null) return "-";
        char[] digits="0123456789abcdef".toCharArray();StringBuilder out=new StringBuilder(bytes.length*2);
        for(byte b:bytes){out.append(digits[(b&255)>>>4]);out.append(digits[b&15]);}return out.toString();
    }
    static byte[] bytes(Object value) { need(value instanceof byte[],"Expected actual original binary property");return (byte[])value; }
    static Map info(TOTorrent torrent) throws Exception {return (Map)torrent.serialiseToMap().get("info");}
    static void digest(Map actual,Map reference,String name,String scope) {
        byte[] a=bytes(actual.get(name)),b=bytes(reference.get(name));
        need(Arrays.equals(a,b),"Actual original-created "+scope+" "+name+" differs");
        System.out.println("EXTRA\t"+scope+"\t"+name+"\t"+hex(a));
    }
    static void run(String[] args) throws Exception {
        need(System.getSecurityManager() instanceof ReferenceFence&&args.length==3,"ReferenceFence: METADATA SOURCE v1|hybrid");
        System.setProperty("java.protocol.handler.pkgs","com.biglybt.core.util.protocol");Class.forName("com.biglybt.core.util.Debug");
        Path root=Paths.get(System.getProperty("biglybtc.test.root")).toRealPath();
        File input=new File(args[0]).getCanonicalFile(),source=new File(args[1]).getCanonicalFile();
        need(input.toPath().startsWith(root)&&source.toPath().startsWith(root),"Only owned generated inputs");
        int type=args[2].equals("v1")?TOTorrent.TT_V1:args[2].equals("hybrid")?TOTorrent.TT_V1_V2:-1;need(type!=-1,"Unsupported explicit format");
        TOTorrent actual=TOTorrentFactory.deserialiseFromBEncodedFile(input);
        need(actual.getTorrentType()==type,"Actual original decoded wrong format");
        TOTorrent reference=TOTorrentFactory.createFromFileOrDirWithFixedPieceLength(type,source,new URL("http://127.0.0.1:19123/announce"),true,actual.getPieceLength()).create();
        need(actual.getSize()==reference.getSize()&&actual.getPieceLength()==reference.getPieceLength()&&actual.getNumberOfPieces()==reference.getNumberOfPieces(),"Actual original logical geometry differs");
        need(Arrays.deepEquals(actual.getPieces(),reference.getPieces()),"Actual original piece hashes differ");
        Map a=info(actual),b=info(reference);digest(a,b,"sha1","overall");digest(a,b,"ed2k","overall");
        need(Arrays.equals(bytes(a.get("source")),"owned π".getBytes(StandardCharsets.UTF_8)),"Actual original source property differs");
        TOTorrentFile[] files=actual.getFiles(),wanted=reference.getFiles();need(files.length==wanted.length,"Actual original file/pad/empty cardinality differs");
        for(int index=0;index<files.length;++index){
            TOTorrentFile f=files[index],g=wanted[index];
            need(f.isPadFile()==g.isPadFile()&&f.getLength()==g.getLength()&&f.getOffsetInTorrent()==g.getOffsetInTorrent(),"Actual original file/pad geometry differs");
            if(!f.isPadFile()){
                need(Arrays.deepEquals(f.getPathComponents(),g.getPathComponents()),"Actual original file path differs");
                if(source.isDirectory()){
                    digest(f.getAdditionalProperties(),g.getAdditionalProperties(),"sha1","file:"+index);
                    digest(f.getAdditionalProperties(),g.getAdditionalProperties(),"ed2k","file:"+index);
                }
                if(type==TOTorrent.TT_V1_V2&&f.getLength()>0) need(Arrays.equals(f.getRootHash(),g.getRootHash()),"Actual original independent Merkle root differs");
            }
            System.out.println("FILE\t"+index+"\t"+f.getOffsetInTorrent()+"\t"+f.getLength()+"\t"+f.isPadFile()+"\t"+hex(f.getRelativePath().getBytes(StandardCharsets.UTF_8)));
        }
        List urls=actual.getAdditionalListProperty("url-list"),http=actual.getAdditionalListProperty("httpseeds");
        need(urls!=null&&urls.size()==1&&Arrays.equals(bytes(urls.get(0)),"https://seeds.invalid/payload".getBytes(StandardCharsets.UTF_8)),"Original URL seed projection differs");
        need(http!=null&&http.size()==1&&Arrays.equals(bytes(http.get(0)),"http://seeds.invalid/script".getBytes(StandardCharsets.UTF_8)),"Original HTTP seed projection differs");
        Map properties=actual.getAdditionalMapProperty(TOTorrent.AZUREUS_PROPERTIES);
        need(properties!=null&&Long.valueOf(0).equals(properties.get("dht_backup_enable"))&&!TorrentUtils.getDHTBackupEnabled(actual),"Original explicit DHT backup false differs");
        System.out.println("HASH\t"+hex(actual.getHash()));System.out.println("FULL_HASHES\t"+hex(actual.getFullHash(TOTorrent.TT_V1))+"\t"+hex(actual.getFullHash(TOTorrent.TT_V2)));
        System.out.println("FACTS\t"+actual.getTorrentType()+"\t"+actual.getSize()+"\t"+actual.getPieceLength()+"\t"+actual.getNumberOfPieces()+"\t"+actual.getPrivate());
        need(System.getSecurityManager() instanceof ReferenceFence,"Reference guard changed");System.out.println("ACTUAL_ORIGINAL_CREATOR_METADATA_HASHES_PASS");
    }
    public static void main(String[] args){try{run(args);System.exit(0);}catch(Throwable failure){failure.printStackTrace();System.exit(2);}}
}
