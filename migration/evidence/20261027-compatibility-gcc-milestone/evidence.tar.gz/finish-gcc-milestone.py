"""Recheck the corrected suite; reuse only proved unchanged successful inputs."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;N=Path('/home/yurii/Java/BiglyBTC')
B=N/'build/persistent-peer-accounting-20261021/bound-gcc'
P=W/'gcc-final-r3';O=W/'gcc-final-r4';O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *x:subprocess.check_output(['git',*x],cwd=N)
parent='d14719ddd2714788dc8d0b66e7e6abbeac9f9aeb'
assert git('rev-parse','HEAD').decode().strip()==parent and not git('status','--porcelain')
prior=json.loads((P/'commands.json').read_bytes())
assert prior[-1]['name']=='tests' and prior[-1]['exit']==8
cases=list(ET.parse(P/'tests.xml').getroot().iter('testcase'))
failed=[x.attrib['name'] for x in cases if x.find('failure') is not None or x.find('error') is not None]
assert len(cases)==40 and failed==['managed-download']
reused=sorted(x.attrib['name'] for x in cases if x.attrib['name'] not in failed)
catalog=json.loads((P/'registered-tests.json').read_bytes())
inputs={}
for test in catalog['tests']:
    if test['name'] not in reused:continue
    for raw in test['command']:
        value=raw.split('=',1)[-1] if raw.startswith('-D') else raw
        for item in value.split(':'):
            p=Path(item)
            if p.is_absolute() and p.is_file():inputs[str(p)]=sha(p)
for p in (B/'engine/runtime-binding/configure-receipt.json',B/'engine/runtime-binding/persistent_runtime_config.hpp',B/'CMakeCache.txt'):
    inputs[str(p)]=sha(p)
baseline={'source_commit':parent,'source_sha256':json.loads((P/'build-source.json').read_bytes()),
    'actual_prior_xml_sha256':sha(P/'tests.xml'),'actual_prior_commands_sha256':sha(P/'commands.json'),
    'ctest_catalog_sha256':sha(P/'registered-tests.json'),'reused_passed_tests':reused,'inputs_sha256':inputs}
(O/'reuse-before.json').write_text(json.dumps(baseline,indent=2)+'\n')
C=W/'final-gcc-amendments/selected-corrupt-close'
assert sha(C/'manifest.json')=='3eff8208229aa69c67280aa63a969714f330e4ccd99f85993c66a0361f879ed2'
m=json.loads((C/'manifest.json').read_bytes());rel='preview/native/tests/managed_download_tests.cpp'
assert sha(N/rel)==m['before_sha256'][rel] and sha(C/'staging'/rel)==m['source_sha256'][rel]
shutil.copyfile(C/'staging'/rel,N/rel)
subprocess.run(['git','add','--',rel],cwd=N,check=True)
assert hashlib.sha256(git('show',':'+rel)).hexdigest()==m['source_sha256'][rel]
subprocess.run(['git','-c','user.name=Codex','-c','user.email=codex@localhost','-c','commit.gpgsign=false','commit',
    '-m','Match selected verification close result to retained corruption'],cwd=N,check=True)
cid=git('rev-parse','HEAD').decode().strip()
graph={p:sha(N/p) for p in git('ls-files','-z','--','preview/native').decode().split('\0') if p}
assert set(graph)==set(baseline['source_sha256'])
assert {p for p in graph if graph[p]!=baseline['source_sha256'][p]}=={rel}
(O/'build-source.json').write_text(json.dumps(graph,indent=2)+'\n')
rows=[];env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1')
def verify():
    assert not git('status','--porcelain') and git('rev-parse','HEAD').decode().strip()==cid
    assert {p:sha(N/p) for p in graph}==graph
    assert all(sha(Path(p))==pin for p,pin in inputs.items()),'Reused test input changed'
def run(name,cmd):
    start=time.monotonic()
    with (O/(name+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=N,env=env,stdout=f,stderr=subprocess.STDOUT)
    rows.append({'name':name,'args':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,3)})
    (O/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');verify()
    if name=='build':(O/'build-receipt.json').write_text(json.dumps({'exit':r.returncode,'command':cmd,'source_commit':cid,
        'source_manifest_sha256':sha(O/'build-source.json')},indent=2)+'\n')
    print(name,r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
targets=json.loads((P/'plan.json').read_bytes())['targets']
run('build',['nice','-n','5','cmake','--build',str(B),'--parallel','3','--target',*targets,'--','-k','0'])
current=subprocess.check_output(['ctest','--test-dir',str(B),'--show-only=json-v1'])
assert current==(P/'registered-tests.json').read_bytes()
(O/'registered-tests.json').write_bytes(current)
run('tests',['nice','-n','5','ctest','--test-dir',str(B),'-j','1','-R','^managed-download$',
    '--no-tests=error','--verbose','--output-on-failure','--output-junit',str(O/'tests.xml')])
fresh=list(ET.parse(O/'tests.xml').getroot().iter('testcase'))
assert len(fresh)==1 and fresh[0].attrib['name']=='managed-download' and fresh[0].find('failure') is None
verify()
result={'status':'PASS_GCC40_WITH_EXPLICIT_UNCHANGED_RESULT_REUSE','source_commit':cid,'tests':40,
    'actually_reexecuted_tests':['managed-download'],'unchanged_passed_tests_reused':reused,
    'reuse_before_sha256':sha(O/'reuse-before.json'),'current_xml_sha256':sha(O/'tests.xml'),
    'source_manifest_sha256':sha(O/'build-source.json'),'only_source_change':rel,
    'all_reused_command_inputs_and_generated_binding_bytes_unchanged':True,
    'production_unchanged_from':parent,'chapter_complete':False,'user_boundary':'Finish current milestone then STOP'}
(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],cid,flush=True)
