from pathlib import Path
import hashlib,json,difflib,ast,subprocess
W=Path(__file__).resolve().parent;N=Path('/home/yurii/Java/BiglyBTC');CID='bf4348d3a681083d7b148bc65d344fae885dffac'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def nsha(p):
 d=hashlib.sha256(subprocess.check_output(['git','-C',str(N),'show',CID+':'+p])).hexdigest();assert d==sha(N/p);return d
assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD'],text=True).strip()==CID
# Latest216e is intentionally a manifest-only association; helper bodies are
# inherited from ba6 at the actual base oracle directory, not a guessed path.
P=W/'creator-virtual/amendments/descriptor-keys-order/oracle';B=W/'creator-virtual/oracle';D=B/'amendments/current-bf';assert not (D/'manifest.json').exists();D.mkdir(parents=True,exist_ok=True)
assert sha(P/'manifest.json')=='216e7b4225f36638b0b4be4063cfc5b0bcf9551489e8476ba9244d69e8b6a5e1';m=json.loads((P/'manifest.json').read_text())
for f,d in m['files_sha256'].items():assert sha(B/f)==d;(D/f).write_bytes((B/f).read_bytes())
ast.parse((D/'run.py').read_text());changes={}
for p,old in list(m['producer_paths'].items()):
 after=nsha(p)
 if old!=after:
  assert p=='preview/native/engine/virtual_creator.inc';before=subprocess.check_output(['git','-C',str(N),'show','f34be1d8b414c0be2c4b16b442d721765526c383^:'+p]);assert hashlib.sha256(before).hexdigest()==old
  expected=before.decode().replace('if(xs==x.npos||ys==y.npos) return xs==x.npos&&ys!=y.npos;x.remove_prefix','if(xs==x.npos||ys==y.npos){return xs==x.npos&&ys!=y.npos;}x.remove_prefix').replace('if(item.type!=core::Node::Type::Dictionary) return 0;','if(item.type!=core::Node::Type::Dictionary){return 0;}');assert expected==(N/p).read_text()
  (D/'producer-delta.patch').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),expected.splitlines(True),fromfile='reviewed216e/'+p,tofile=CID+'/'+p)));changes[p]={'before_sha256':old,'source_sha256':after,'scope':'Exactly two f34 braces-only -Werror repairs; branch/return/control order unchanged.'}
 m['producer_paths'][p]=after
m['original_creator_parent_manifest_sha256']=m['parent_manifest_sha256'];m['parent_manifest_sha256']=sha(P/'manifest.json');m['native_association_commit']=CID;m['status']='FROZEN_SOURCE_ASSOCIATION_ONLY_NO_EXECUTION';m['executions']=[];m['virtual_manifest_path']=str(W/'creator-virtual/amendments/descriptor-keys-order/manifest.json')
for p in [P/'manifest.json',B/'manifest.json',Path(m['virtual_manifest_path'])]:m['dependencies_sha256'][str(p)]=sha(p)
write(D/'association-review.json',{'status':'SOURCE_ONLY_REVIEWED_BINDING','native_commit':CID,'parent_manifest_sha256':sha(P/'manifest.json'),'producer_changes':changes,'unchanged_recipe_files':m['files_sha256'],'planned_subjects':11,'allocation_direct_producer_path_overlap':[],'root_execution_gate':'Actual current tracked source build receipt and exact four producer pins; root must review any enclosing graph change. No subjects executed.','scope':'Seven source cases +four virtual/BYO cases retained exactly; no rawinfo, linkage, hashing, ordering or original assertions changed.','helper_inheritance':'Latest216e is manifest-only; exact unchanged helpers copied from ba6 base oracle, now self-contained at this runnable location.'})
(D/'RUN.txt').write_text('Root only after matching coherent build:\npython3 '+str(D/'run.py')+' --driver BUILD/tests/biglybtc-torrent-creator-driver --source-commit ACTUAL_FULL_SOURCE --build-receipt PASSED_BUILD_RECEIPT --output FRESH_OWNED_OUTPUT\nFour producer leaves pinned to bf. Any changed leaf requires reviewed successor. Allocation currently has no direct overlap. Java/runner bytes and11subjects unchanged; no execution credit.\n')
m['association_artifacts_sha256']={p:sha(D/p) for p in ['producer-delta.patch','association-review.json','RUN.txt']};write(D/'manifest.json',m);print('creator',sha(D/'manifest.json'))
P=W/'versioned-fileops/oracle';D=P/'amendments/current-bf';assert not (D/'manifest.json').exists();D.mkdir(parents=True,exist_ok=True);assert sha(P/'manifest.json')=='337018f0db2e4bdfc25e0ce275be7eae07291f3dd73729df1206393642a33766';m=json.loads((P/'manifest.json').read_text())
for f,d in m['files_sha256'].items():assert sha(P/f)==d;(D/f).write_bytes((P/f).read_bytes())
for p in ['run.py','versioned_proof.py']:ast.parse((D/p).read_text())
changes={};patch=''
for p,old in list(m['producer_paths'].items()):
 after=nsha(p)
 if after!=old:
  before=W/'library-replacement/staging'/p;assert sha(before)==old
  patch+=''.join(difflib.unified_diff(before.read_text().splitlines(True),(N/p).read_text().splitlines(True),fromfile='reviewed3370/'+p,tofile=CID+'/'+p));changes[p]={'before_sha256':old,'source_sha256':after}
 m['producer_paths'][p]=after
context=json.loads((W/'decoder-context/manifest.json').read_text());recovery=json.loads((W/'library-replacement/amendments/review-unsealed/manifest.json').read_text())
assert changes['preview/native/adapters/file_operations.cpp']['source_sha256']==context['source_sha256']['preview/native/adapters/file_operations.cpp'];assert changes['preview/native/adapters/file_operations.hpp']['source_sha256']==recovery['source_sha256']['preview/native/adapters/file_operations.hpp']
added={}
for p in ['preview/native/adapters/torrent_intake.cpp','preview/native/adapters/torrent_intake.hpp','preview/native/adapters/original_filename_policy.hpp','preview/native/adapters/original_filename_policy.inc','preview/native/engine/torrent_creator.cpp','preview/native/engine/torrent_creator.hpp','preview/native/engine/virtual_creator.inc','preview/native/core/src/torrent_layout.cpp','preview/native/core/include/biglybtc/torrent_layout.hpp']:
 added[p]=nsha(p);m['producer_paths'][p]=added[p]
for p in list(added)[:4]:assert added[p]==context['source_sha256'][p]
(D/'producer-delta.patch').write_text(patch)
parent=sha(P/'manifest.json');m['parent_manifest_sha256']=parent;m['native_association_commit']=CID;m['status']='FROZEN_BF_ASSOCIATION_ONLY_PENDING_ALLOCATION_REVIEW';m['executions']=[]
for p in ['versioned-fileops/oracle/manifest.json','library-replacement/amendments/explicit-consent/manifest.json','library-replacement/amendments/review-unsealed/manifest.json','decoder-context/manifest.json','creator-virtual/oracle/amendments/current-bf/manifest.json']:m['dependencies_sha256'][str(W/p)]=sha(W/p)
write(D/'association-review.json',{'status':'SOURCE_ONLY_BF_BINDING_FUTURE_ALLOCATION_HELD','native_commit':CID,'parent_manifest_sha256':parent,'changed_producer_paths':changes,'added_dependency_producer_paths':added,'unchanged_recipe_files':m['files_sha256'],'planned_subjects':15,'scope_review':['file_operations cpp byte-exact context808 afterimage composing recoverydbc33 and explicit-consent8365','Header exact recoverydbc33 afterimage; exceptional review remains inactive in normal15fixture paths','New0/1 ShowAll field captures false default +same conversions; journals cleaned before originalhandoff','Driver/Java/Merkle/fullidentity/rawinfo/padabsence/path/pause/intent assertions unchanged','Actual producer calls productioncreator +importTorrent, so reviewed current dependency paths explicitly pinned'], 'allocation_pending_overlap':['preview/native/adapters/torrent_intake.cpp','preview/native/adapters/torrent_intake.hpp'],'final_association':'HOLD allocation-child source until new intake defaults/journal diff reviewed and immutable successor frozen. Current bf snapshot reviewed; future changed intake fails exact pins. No producer bytes/assertions changed.','execution_gate':'Root matching coherent source/build, then15new versioned mutation subjects; no oldv1 rerun or empty-first source limitation relabelling.'})
(D/'RUN.txt').write_text('Root only after matching coherent build:\npython3 '+str(D/'run.py')+' --driver BUILD/tests/biglybtc-file-operations-driver --source-commit ACTUAL_FULL_SOURCE --build-receipt PASSED_BUILD_RECEIPT --output FRESH_OWNED_OUTPUT\nBF only: pending allocation touches pinned intake cpp/hpp; HOLD allocation-child association for reviewed successor. Runner fails any changed producer pin. Java/runner/proof bytes,15new subjects and assertions unchanged. No execution credit.\n')
m['association_artifacts_sha256']={p:sha(D/p) for p in ['producer-delta.patch','association-review.json','RUN.txt']};write(D/'manifest.json',m);print('versioned',sha(D/'manifest.json'))
