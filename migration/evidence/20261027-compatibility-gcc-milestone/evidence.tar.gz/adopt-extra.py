from pathlib import Path
import hashlib,json,shutil,subprocess
W=Path(__file__).resolve().parent;N=W.parents[2]/'BiglyBTC';R=W.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=N,text=True)
assert git('rev-parse','HEAD').strip()=='76cf831a61ecc68ee72ec958bf3667945074d251'
assert not git('status','--porcelain')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='cb8c6cb9bb97916cbc7e80338a017200ffc3e71f'
assert sha(R/'.git/index')=='ac45601f3bed2b3a3d2ac91d715e4b052108a5b7478de62bb67f165ce0de30d4'
source=W/'extra-r6';description=json.loads((source/'composition.json').read_bytes())
backup=W/'extra-adoption-before';backup.mkdir();records={}
for rel,pin in description['files'].items():
    src=source/rel;dst=N/rel;assert sha(src)==pin
    before=sha(dst) if dst.exists() else None
    if before==pin:continue
    if dst.exists():
        saved=backup/rel;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,saved)
    records[rel]=dict(before_sha256=before,after_sha256=pin)
review=dict(status='SOURCE_REVIEWED_NOT_RUNTIME_QUALIFIED',parent=description['native_base'],capsules={x['capsule']:x['manifest_sha256'] for x in description['operations'] if 'manifest_sha256' in x},paths=records,
    review='Narrow checked-beforeimage composition; indexed raw info and full identity remain unchanged; private held target snapshots and mapped O_RDONLY scopes; virtual source nofollow final inventory and exclusive publication; explicit replace retains exact preimage with independent consent. Pending unsealed backup review remains recorded. Idle wall age separate from steady durations; equal millisecond sequences keep genuine source history. Exact new TrafficV3 provider source/artifact/SDK/direct wire fixtures reviewed, positive+wrongSDK+wrongimage binding passed. Decoder independent source review passed; runtime pending. Complete recovery, virtual, queuebadcounter, charset and versionedproducer sources compose narrowly. No final runtime/chapter claim.')
(W/'extra-adoption.json').write_text(json.dumps(review,indent=2)+'\n')
for rel,row in records.items():
    dst=N/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/rel,dst);assert sha(dst)==row['after_sha256']
print('Adopted',len(records),'reviewed files with fresh mtimes')
