from pathlib import Path
import subprocess,json,time,os
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');b=n/'build/persistent-peer-accounting-20261021/bound-gcc';out=w/'gcc-r2';out.mkdir();rows=[]
def run(name,args,timeout=None):
 t=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(list(map(str,args)),cwd=n,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 rows.append(dict(name=name,args=list(map(str,args)),exit=r.returncode,seconds=round(time.monotonic()-t,3)));(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('configure',['cmake','-S',n/'preview/native','-B',b,'-DLibtorrentRasterbar_DIR='+str(w/'provider-queue/install/lib/cmake/LibtorrentRasterbar'),'-DBIGLYBTC_PERSISTENT_RUNTIME_MANIFEST='+str(n/'preview/native/engine/runtime-binding/provider-queue-runtime.json')])
tests=json.loads(subprocess.check_output(['ctest','--test-dir',str(b),'--show-only=json-v1']));(out/'registered-tests.json').write_text(json.dumps(tests,indent=2)+'\n');need=['original-torrent-geometry','torrent-intake','torrent-intake-file-options','torrent-intake-file-options-ui','torrent-intake-file-options-worker','managed-storage','managed-download','managed-download-queue','managed-download-seeding','original-linear-to-compact','original-disk-io','file-operations','file-operation-dialog','file-priority-ui','file-operations-bridge','torrent-creator','torrent-creation-dialog','application-settings','network-policy','engine-live-settings','queue-policy','queue-rate-providers','queue-target-statistics','persistent-native-peer-session','scheduler-host-engine','network-proxy-capability','network-proxy-owner','provider-queue-runtime-inputs','provider-queue-runtime-deployment'];aliases={'queue-rate-providers':'queue-rate-provider','torrent-creation-dialog':'torrent-creation-ui','engine-live-settings':'engine-live-settings','scheduler-host-engine':'speed-scheduler-host-engine'}
names={x['name']:x for x in tests['tests']};chosen=[]
for name in need:
 actual=name if name in names else aliases.get(name,name)
 if actual in names:chosen.append(names[actual])
 else:print('UNMATCHED',name,flush=True)
targets=sorted({Path(arg).name for x in chosen for arg in x['command'] if Path(arg).name.startswith('biglybtc-') and not '=' in arg})
targets+=['BiglyBTC','biglybtc-file-operations-driver','biglybtc-torrent-creator-driver','biglybtc-queue-facts-replay','biglybtc-runtime-interposition-driver','biglybtc-runtime-interposer'];plan=dict(tests=[x['name'] for x in chosen],targets=targets,related=[x['name'] for x in tests['tests'] if any(k in x['name'] for k in ['scheduler','creation','operations','queue-rate','live-settings'])]);(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('Planned',len(chosen),'suites,',len(targets),'targets',flush=True)
run('build',['nice','-n','5','cmake','--build',b,'--parallel','3','--target',*targets])
