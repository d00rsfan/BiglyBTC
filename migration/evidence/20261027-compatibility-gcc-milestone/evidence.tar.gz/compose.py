from pathlib import Path
import json,hashlib,subprocess,difflib,shutil
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');out=w/'composed-r7';out.mkdir(exist_ok=True);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
def overlay(name,manifest,after,before=None,exclude=()):
 d=json.loads(manifest.read_text());sources=d.get('source_sha256',d.get('effective_provider_source_sha256'));
 if sources is None:sources={path:row['source_sha256'] for path,row in d['paths'].items()}
 assert sources,name
 for rel,pin in sources.items():
  if rel in exclude:continue
  dst=out/rel;src=after/rel;assert h(src)==pin,(name,rel)
  if not dst.exists():
   base=n/rel
   if base.exists():dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base,dst)
  original=(before/rel).read_text() if before and (before/rel).is_file() else ''
  if before is not None and rel in d.get('before_sha256',{}) and d['before_sha256'][rel] is not None:
   assert hashlib.sha256(original.encode()).hexdigest()==d['before_sha256'][rel],(name,'before',rel)
  current=dst.read_text() if dst.exists() else ''
  desired=src.read_text()
  if current==original:
   dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(desired)
  elif current==desired:pass
  else:
   patch=''.join(difflib.unified_diff(original.splitlines(True),desired.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel,n=1));r=subprocess.run(['git','apply','--whitespace=nowarn','-'],cwd=out,input=patch.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0,(name,rel,r.stderr.decode())
  rows.append({'capsule':name,'path':rel,'result_sha256':h(dst)})
# Whole-file sources are never copied over another staged afterimage: compose exact diffs.
overlay('filename-host',w/'filename-conversions/host-amendment/manifest.json',w/'filename-conversions/host-amendment/staging',w/'filename-conversions/host-amendment/before')
overlay('filename-conversions',w/'filename-conversions/manifest.json',w/'filename-conversions/staging',w/'filename-conversions/before')
overlay('ancestor-collision',w/'filename-conversions/amendments/ancestor-collision/manifest.json',w/'filename-conversions/amendments/ancestor-collision/staging',w/'filename-conversions/amendments/ancestor-collision/before')
overlay('library-workflows',w/'library-workflows/manifest.json',w/'library-workflows/staging',w/'library-workflows/before')
overlay('creator',w/'creator/manifest.json',w/'creator/work',w/'creator/before')
overlay('lan-rates',w/'lan-rates/manifest.json',w/'lan-rates/work',w/'lan-rates/before',exclude=('preview/native/engine/persistent_session.cpp',))
overlay('queue-facts',w/'queue-facts/manifest.json',w/'queue-facts/staging',w/'queue-facts/before')
overlay('queue-spsc',w/'queue-facts/amendments/spsc/manifest.json',w/'queue-facts/amendments/spsc/staging',w/'queue-facts/staging')
overlay('creator-oracle',w/'creator-oracle/manifest.json',w/'creator-oracle/staging',n)
overlay('lan-session',w/'lan-rates/manifest.json',w/'lan-rates/work',w/'lan-rates/before')
(w/'composition.json').write_text(json.dumps({'status':'PARTIAL_SOURCE_COMPOSITION_UNADOPTED','steps':rows},indent=2)+'\n');print('Composed',len(rows),'operations;',len({r['path'] for r in rows}),'files')
