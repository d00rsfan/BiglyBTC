from pathlib import Path
import hashlib,json,shutil
W=Path(__file__).resolve().parent;OLD=W/'provider-queue';P=W/'provider-traffic-v3';CAP=W/'queue-traffic-v3/provider'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((OLD/'source-build-record.json').read_bytes());manifest=json.loads((CAP/'manifest.json').read_bytes());assert sha(OLD/'source-build-record.json')==manifest['parent_record_sha256']
assert sha(Path(record['artifact']))==manifest['parent_artifact_sha256']
for rel,pin in record['source_inputs_sha256'].items():assert sha(OLD/'source'/rel)==pin
for rel,pin in manifest['artifact_sha256'].items():assert sha(CAP/rel)==pin
P.mkdir();shutil.copytree(OLD/'source',P/'source')
expected=dict(record['source_inputs_sha256'])
for rel,pin in manifest['source_sha256'].items():
 assert sha(P/'source'/rel)==manifest['before_sha256'][rel]
 shutil.copyfile(CAP/'staging'/rel,P/'source'/rel);assert sha(P/'source'/rel)==pin;expected[rel]=pin
for source,target in [(OLD/'queue-fixture','queue-fixture'),(OLD/'socks4a-fixture','socks4a-fixture'),(CAP/'qualification','traffic-fixture')]:shutil.copytree(source,P/target)
plan=json.loads((OLD/'source-plan.json').read_bytes());plan.update(parent_record_sha256=sha(OLD/'source-build-record.json'),parent_artifact_sha256=record['artifact_sha256'],capsule_sha256=sha(CAP/'manifest.json'),source_inputs_sha256=expected,required_exports=record['required_exports']+manifest['new_exports'])
(P/'source-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
script=(OLD/'run-provider.py').read_text().replace("for fixture in ['queue','socks4a']:","for fixture in ['queue','socks4a','traffic']:")
script=script.replace("'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-16','-DCMAKE_PREFIX_PATH='", "'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-16','-DCMAKE_PREFIX_PATH='")
(P/'run-provider.py').write_text(script)
print('Prepared exact fresh V3 provider',len(expected),'source leaves;',len(plan['required_exports']),'exports; old provider unchanged')
