"""Compose reviewed source capsules without changing the native checkout."""
from pathlib import Path
import difflib, hashlib, json, shutil, subprocess, sys

W=Path(__file__).resolve().parent
N=W.parents[2]/'BiglyBTC'
OUT=W/(sys.argv[1] if len(sys.argv)>1 else 'next-r1')
OUT.mkdir()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
operations=[]

def overlay(name, parent=None):
    capsule=W/name
    m=json.loads((capsule/'manifest.json').read_bytes())
    sources=m.get('source_sha256') or {p:d['source_sha256'] for p,d in m['paths'].items()}
    before=capsule/'before' if parent is None else W/parent
    for rel,pin in sources.items():
        source=capsule/'staging'/rel
        assert digest(source)==pin,(name,rel,'source')
        old=before/rel
        old_bytes=old.read_bytes() if old.exists() else b''
        expected=m.get('before_sha256',{}).get(rel,m.get('paths',{}).get(rel,{}).get('before_sha256'))
        assert expected is None and not old.exists() or expected==hashlib.sha256(old_bytes).hexdigest(),(name,rel,'before')
        target=OUT/rel
        if not target.exists() and (N/rel).exists():
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(N/rel,target)
        current=target.read_bytes() if target.exists() else b''
        desired=source.read_bytes()
        if current==old_bytes:
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(desired)
        elif current!=desired:
            patch=''.join(difflib.unified_diff(old_bytes.decode().splitlines(True),desired.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel,n=1))
            result=subprocess.run(['git','apply','--whitespace=nowarn','-'],input=patch.encode(),cwd=OUT,capture_output=True)
            assert result.returncode==0,(name,rel,result.stderr.decode())
        operations.append(dict(capsule=name,manifest_sha256=digest(capsule/'manifest.json'),path=rel,sha256=digest(target)))

overlay('filename-conversions/amendments/java-trim-nul-row')
overlay('intake-file-destinations')
overlay('intake-file-destinations/host-amendment')
overlay('filename-conversions/amendments/accepted-info-preimage')
overlay('creator-virtual')
overlay('creator-virtual/amendments/descriptor-keys-order')
overlay('library-workflows/amendments/packed-compact-fixture')
overlay('library-replacement')
overlay('library-replacement/amendments/explicit-consent')
overlay('queue-idle')
overlay('queue-facts/amendments/equal-millisecond')
(OUT/'composition.json').write_text(json.dumps(dict(native_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=N,text=True).strip(),operations=operations,files={p.relative_to(OUT).as_posix():digest(p) for p in sorted((OUT/'preview/native').rglob('*')) if p.is_file()}),indent=2)+'\n')
print('Composed',len(operations),'source operations without native writes:',OUT)
