from pathlib import Path
import subprocess,json,hashlib,time,re,os
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');b=n/'build/persistent-peer-accounting-20261021/bound-gcc';out=w/'decoder-gcc-r1';out.mkdir();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();git=lambda *x:subprocess.check_output(['git',*x],cwd=n);assert not git('status','--porcelain');graph={p:h(n/p) for p in git('ls-files','-z','--','preview/native').decode().split('\0') if p};(out/'build-source.json').write_text(json.dumps(graph,indent=2)+'\n');cid=git('rev-parse','HEAD').decode().strip();rows=[]
names=['original-torrent-geometry'];chosen=[{'name':names[0]}];targets=['biglybtc-torrent-layout-tests']
(out/'plan.json').write_text(json.dumps(dict(source_commit=cid,tests=names,targets=targets),indent=2)+'\n')
def run(name,args):
 t=time.monotonic();env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1')
 with (out/(name+'.log')).open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=n,env=env)
 row=dict(name=name,args=args,exit=r.returncode,seconds=round(time.monotonic()-t,3));rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert not git('status','--porcelain') and {p:h(n/p) for p in graph}==graph,'Source changed during qualification'
 if name=='build':(out/'build-receipt.json').write_text(json.dumps(dict(exit=r.returncode,command=args,source_commit=cid,source_manifest_sha256=h(out/'build-source.json')),indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
print('Build/test coherent batch:',len(chosen),'suites;',len(targets),'targets',flush=True)
run('build',['nice','-n','5','cmake','--build',str(b),'--parallel','3','--target',*targets,'--','-k','0'])
pattern='^('+ '|'.join(re.escape(x['name']) for x in chosen)+')$';run('tests',['ctest','--test-dir',str(b),'-j','1','-R',pattern,'--output-on-failure','--output-junit',str(out/'tests.xml')])
