"""Adopt only the explicitly reviewed final composed source batch on native main."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
W=Path(__file__).resolve().parent
R=W.parents[1]
N=R.parent/'BiglyBTC'
S=W/sys.argv[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda root,*a:subprocess.check_output(['git',*a],cwd=root)
assert git(R,'rev-parse','HEAD').decode().strip()=='cb8c6cb9bb97916cbc7e80338a017200ffc3e71f'
assert sha(R/'.git/index')=='ac45601f3bed2b3a3d2ac91d715e4b052108a5b7478de62bb67f165ce0de30d4'
assert git(N,'branch','--show-current').decode().strip()=='main' and not git(N,'status','--porcelain')
manifest=json.loads((S/'composition.json').read_bytes())
assert git(N,'rev-parse','HEAD').decode().strip()==manifest['native_base']=='6445069cae4f010f6c463452c91f10814b476ac6'
for op in manifest['operations']:
    assert sha(W/op['capsule']/'manifest.json')==op['manifest_sha256']
before=W/'recheck-source-before';before.mkdir()
paths=manifest['files'];old={}
for rel,pin in paths.items():
    assert rel.startswith('preview/') and '..' not in Path(rel).parts and sha(S/rel)==pin
    target=N/rel
    if target.exists():
        old[rel]=sha(target);(before/rel).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target,before/rel)
    else:old[rel]=None
for rel in paths:
    target=N/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(S/rel,target)
subprocess.run(['git','add','--',*paths],cwd=N,check=True)
for rel,pin in paths.items():assert hashlib.sha256(git(N,'show',':'+rel)).hexdigest()==pin
subprocess.run(['git','-c','user.name=Codex','-c','user.email=codex@localhost','-c','commit.gpgsign=false','commit','-m','Validate selected directory identities and await upload receipts'],cwd=N,check=True)
record={'source_commit':git(N,'rev-parse','HEAD').decode().strip(),'parent':manifest['native_base'],
        'composition_sha256':sha(S/'composition.json'),'before_sha256':old,'source_sha256':paths,
        'all_staged_blob_bytes_verified':True,'original_head_unchanged':True,'original_index_unchanged':True}
assert not git(N,'status','--porcelain')
(W/'recheck-source-adoption.json').write_text(json.dumps(record,indent=2)+'\n')
print('Adopted final source batch',record['source_commit'],len(paths),'paths')
