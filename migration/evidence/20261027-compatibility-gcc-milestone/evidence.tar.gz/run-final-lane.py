"""Integrator-owned coherent consumer qualification; no implicit source edits."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, time

W = Path(__file__).resolve().parent
N = Path('/home/yurii/Java/BiglyBTC')
LANES = {'gcc': N/'build/persistent-peer-accounting-20261021/bound-gcc',
         'clang': N/'build/saved-services-20261018/clang',
         'san': N/'build/saved-services-20261018/sanitized-desktop'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], cwd=N)
p = argparse.ArgumentParser()
p.add_argument('--lane', choices=LANES, required=True)
p.add_argument('--attempt', required=True)
p.add_argument('--jobs', type=int, choices=(1,2,3), default=3)
p.add_argument('--gcc-gate', type=Path)
a = p.parse_args()
assert '/' not in a.attempt and not git('status','--porcelain')
assert not git('ls-files','--others','--exclude-standard','--','preview/native')
B = LANES[a.lane]
O = W/a.attempt
O.mkdir()
CID = git('rev-parse','HEAD').decode().strip()
graph = {s: sha(N/s) for s in git('ls-files','-z','--','preview/native').decode().split('\0') if s}
(O/'build-source.json').write_text(json.dumps(graph,indent=2)+'\n')
if a.lane != 'gcc':
    assert a.gcc_gate is not None
    gate = json.loads((a.gcc_gate/'commands.json').read_bytes())
    assert all(x['exit']==0 for x in gate) and {x['name'] for x in gate}>={'build','tests'}
    assert json.loads((a.gcc_gate/'build-source.json').read_bytes())==graph
    assert json.loads((a.gcc_gate/'build-receipt.json').read_bytes())['source_commit']==CID
env = dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1',CMAKE_BUILD_PARALLEL_LEVEL='1')
for key in ('ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS'):
    env.pop(key,None)
if a.lane=='san':
    env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
rows=[]
def unchanged():
    assert not git('status','--porcelain') and git('rev-parse','HEAD').decode().strip()==CID
    assert {s:sha(N/s) for s in graph}==graph,'Source changed during qualification'
def run(name, command):
    start=time.monotonic()
    with (O/(name+'.log')).open('wb') as log:
        r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=N)
    row=dict(name=name,args=command,exit=r.returncode,seconds=round(time.monotonic()-start,3))
    rows.append(row);(O/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
    unchanged()
    if name=='build':
        (O/'build-receipt.json').write_text(json.dumps(dict(exit=r.returncode,command=command,source_commit=CID,source_manifest_sha256=sha(O/'build-source.json')),indent=2)+'\n')
    print(a.lane,name,r.returncode,flush=True)
    if r.returncode:
        raise SystemExit(r.returncode)
run('configure',['cmake','-S',str(N/'preview/native'),'-B',str(B),
    '-DLibtorrentRasterbar_DIR='+str(W/'provider-traffic-v3/install/lib/cmake/LibtorrentRasterbar'),
    '-DBIGLYBTC_PERSISTENT_RUNTIME_MANIFEST='+str(N/'preview/native/engine/runtime-binding/provider-traffic-runtime.json')])
query=subprocess.check_output(['ctest','--test-dir',str(B),'--show-only=json-v1'])
(O/'registered-tests.json').write_bytes(query)
catalog=json.loads(query)['tests']
names=set(json.loads((W/'gcc-r8/plan.json').read_bytes())['tests'])
chosen=[x for x in catalog if x['name'] in names]
assert len(chosen)==len(names)
targets=set(json.loads((W/'gcc-r8/plan.json').read_bytes())['targets'])
targets.update(('biglybtc_country_module','biglybtc_scheduler_module'))
(O/'plan.json').write_text(json.dumps(dict(source_commit=CID,lane=a.lane,jobs=a.jobs,tests=sorted(names),targets=sorted(targets)),indent=2)+'\n')
run('build',['nice','-n','5','cmake','--build',str(B),'--parallel',str(a.jobs),'--target',*sorted(targets),'--','-k','0'])
run('tests',['nice','-n','5','ctest','--test-dir',str(B),'-j','1','-R','^('+'|'.join(map(re.escape,sorted(names)))+')$',
    '--no-tests=error','--verbose','--output-on-failure','--output-junit',str(O/'tests.xml')])
(O/'result.json').write_text(json.dumps(dict(status='PASS_COHERENT_CONSUMER_LANE',lane=a.lane,source_commit=CID,tests=len(names),source_manifest_sha256=sha(O/'build-source.json'),commands=rows),indent=2)+'\n')
