"""Compose reviewed source capsules without changing the native checkout."""
from pathlib import Path
import difflib, hashlib, json, shutil, subprocess, sys

W=Path(__file__).resolve().parent
N=W.parents[2]/'BiglyBTC'
OUT=W/(sys.argv[1] if len(sys.argv)>1 else 'extra-r1')
OUT.mkdir()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
operations=[]

def overlay(name, parent=None):
    capsule=W/name
    m=json.loads((capsule/'manifest.json').read_bytes())
    sources=m.get('source_sha256') or {p:d['source_sha256'] for p,d in m['paths'].items()}
    before=capsule/'before' if parent is None else W/parent
    for rel,pin in sources.items():
        source=capsule/'staging'/rel
        assert digest(source)==pin,(name,rel,'source')
        old=before/rel
        old_bytes=old.read_bytes() if old.exists() else b''
        expected=m.get('before_sha256',{}).get(rel,m.get('paths',{}).get(rel,{}).get('before_sha256'))
        assert expected is None and not old.exists() or expected==hashlib.sha256(old_bytes).hexdigest(),(name,rel,'before')
        target=OUT/rel
        if not target.exists() and (N/rel).exists():
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(N/rel,target)
        current=target.read_bytes() if target.exists() else b''
        desired=source.read_bytes()
        if name=='library-replacement/amendments/review-unsealed' and rel=='preview/native/adapters/file_operations.cpp':
            prior=W/'library-replacement/amendments/explicit-consent'
            amendment=json.loads((prior/'manifest.json').read_bytes())
            priorPath=amendment.get('paths',{}).get(rel,{})
            oldPin=amendment.get('before_sha256',{}).get(rel,priorPath.get('before_sha256'))
            newPin=amendment.get('source_sha256',{}).get(rel,priorPath.get('source_sha256'))
            assert hashlib.sha256(old_bytes).hexdigest()==oldPin
            fixed=(prior/'staging'/rel).read_bytes();assert hashlib.sha256(fixed).hexdigest()==newPin
            old_bytes=fixed # exact already adopted8365 parent amendment

        if name=='library-replacement/amendments/review-unsealed' and rel=='preview/native/tests/file_operations_tests.cpp':
            marker=b'void perFileNonlinearMoveKeepsControlAndRetargetRefuses(){\n'
            comment=b'  // Offset0/length5/piece4 compact stores only the final one-byte tail.\n'
            assert current.count(marker+comment)==1 and desired.count(marker)==1
            if marker+comment not in desired:desired=desired.replace(marker,marker+comment)
        if current==old_bytes:
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(desired)
        elif current!=desired:
            patch=''.join(difflib.unified_diff(old_bytes.decode().splitlines(True),desired.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel,n=1))
            result=subprocess.run(['git','apply','--whitespace=nowarn','-'],input=patch.encode(),cwd=OUT,capture_output=True)
            if result.returncode:
                # Real three-way merge preserves already adopted narrow fixes.
                temp=OUT/'merge-inputs'/str(len(operations));temp.mkdir(parents=True)
                for leaf,content in [('current',current),('before',old_bytes),('desired',desired)]:
                    (temp/leaf).write_bytes(content)
                merged=subprocess.run(['git','merge-file','-p',str(temp/'current'),str(temp/'before'),str(temp/'desired')],capture_output=True)
                (temp/'result').write_bytes(merged.stdout)
                assert merged.returncode==0,(name,rel,'three-way conflict',merged.stderr.decode())
                target.write_bytes(merged.stdout)
        operations.append(dict(capsule=name,manifest_sha256=digest(capsule/'manifest.json'),path=rel,sha256=digest(target)))

overlay('library-replacement/amendments/review-unsealed')
overlay('decoder')
overlay('queue-traffic-v3/app')
overlay('queue-traffic-v3/app/amendments/incoming-owned-peer')
overlay('runtime-binding-traffic')
# Two braces correct concrete -Werror diagnostics without changing conditions.
rel='preview/native/engine/virtual_creator.inc';target=OUT/rel;target.parent.mkdir(parents=True,exist_ok=True);s=(N/rel).read_text()
for old,new in [('if(xs==x.npos||ys==y.npos) return xs==x.npos&&ys!=y.npos;x.remove_prefix(xs+1);y.remove_prefix(ys+1);}', 'if(xs==x.npos||ys==y.npos){return xs==x.npos&&ys!=y.npos;}x.remove_prefix(xs+1);y.remove_prefix(ys+1);}'),('if(item.type!=core::Node::Type::Dictionary) return 0;std::size_t count=0;', 'if(item.type!=core::Node::Type::Dictionary){return 0;}std::size_t count=0;')]:
 assert s.count(old)==1;s=s.replace(old,new)
target.write_text(s);operations.append(dict(capsule='root-virtual-warning-fix',path=rel,sha256=digest(target)))
rel='preview/native/tests/file_operations_driver.cpp';cap=W/'versioned-fileops';m=json.loads((cap/'manifest.json').read_bytes());assert digest(N/rel)==m['paths'][rel]['before_sha256'];target=OUT/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(cap/'staging'/rel,target);assert digest(target)==m['paths'][rel]['source_sha256'];operations.append(dict(capsule='versioned-fileops',manifest_sha256=digest(cap/'manifest.json'),path=rel,sha256=digest(target)))
rel='preview/native/tests/CMakeLists.txt';target=OUT/rel;s=(target if target.exists() else N/rel).read_text();old='target_link_libraries(biglybtc-file-operations-driver PRIVATE biglybtc_profile OpenSSL::Crypto)';assert s.count(old)==1;s=s.replace(old,'target_link_libraries(biglybtc-file-operations-driver PRIVATE biglybtc_profile OpenSSL::Crypto biglybtc_local_engine)');target.write_text(s);operations.append(dict(capsule='versioned-fileops-engine-link',path=rel,sha256=digest(target)))
rel='preview/native/tests/queue_facts_replay.cpp';target=OUT/rel;source=W/'queue-idle/oracle/amendments/interface-provider/oracle/queue_facts_replay.cpp';shutil.copyfile(source,target);operations.append(dict(capsule='queue-idle-original40-replay',path=rel,sha256=digest(target)))
(OUT/'composition.json').write_text(json.dumps(dict(native_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=N,text=True).strip(),operations=operations,files={p.relative_to(OUT).as_posix():digest(p) for p in sorted((OUT/'preview/native').rglob('*')) if p.is_file()}),indent=2)+'\n')
print('Composed',len(operations),'source operations without native writes:',OUT)
