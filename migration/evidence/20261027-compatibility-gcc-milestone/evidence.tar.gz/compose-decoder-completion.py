"""Compose reviewed source capsules without changing the native checkout."""
from pathlib import Path
import difflib, hashlib, json, shutil, subprocess, sys

W=Path(__file__).resolve().parent
N=W.parents[2]/'BiglyBTC'
OUT=W/(sys.argv[1] if len(sys.argv)>1 else 'extra-r1')
OUT.mkdir()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
operations=[]

def overlay(name, parent=None):
    capsule=W/name
    m=json.loads((capsule/'manifest.json').read_bytes())
    sources=m.get('source_sha256') or {p:d['source_sha256'] for p,d in m['paths'].items()}
    before=capsule/'before' if parent is None else W/parent
    for rel,pin in sources.items():
        source=capsule/'staging'/rel
        assert digest(source)==pin,(name,rel,'source')
        old=before/rel
        old_bytes=old.read_bytes() if old.exists() else b''
        expected=m.get('before_sha256',{}).get(rel,m.get('paths',{}).get(rel,{}).get('before_sha256'))
        assert expected is None and not old.exists() or expected==hashlib.sha256(old_bytes).hexdigest(),(name,rel,'before')
        target=OUT/rel
        if not target.exists() and (N/rel).exists():
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(N/rel,target)
        current=target.read_bytes() if target.exists() else b''
        desired=source.read_bytes()
        if name=='library-replacement/amendments/review-unsealed' and rel=='preview/native/adapters/file_operations.cpp':
            prior=W/'library-replacement/amendments/explicit-consent'
            amendment=json.loads((prior/'manifest.json').read_bytes())
            priorPath=amendment.get('paths',{}).get(rel,{})
            oldPin=amendment.get('before_sha256',{}).get(rel,priorPath.get('before_sha256'))
            newPin=amendment.get('source_sha256',{}).get(rel,priorPath.get('source_sha256'))
            assert hashlib.sha256(old_bytes).hexdigest()==oldPin
            fixed=(prior/'staging'/rel).read_bytes();assert hashlib.sha256(fixed).hexdigest()==newPin
            old_bytes=fixed # exact already adopted8365 parent amendment

        if name=='library-replacement/amendments/review-unsealed' and rel=='preview/native/tests/file_operations_tests.cpp':
            marker=b'void perFileNonlinearMoveKeepsControlAndRetargetRefuses(){\n'
            comment=b'  // Offset0/length5/piece4 compact stores only the final one-byte tail.\n'
            assert current.count(marker+comment)==1 and desired.count(marker)==1
            if marker+comment not in desired:desired=desired.replace(marker,marker+comment)
        if current==old_bytes:
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(desired)
        elif current!=desired:
            patch=''.join(difflib.unified_diff(old_bytes.decode().splitlines(True),desired.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel,n=1))
            result=subprocess.run(['git','apply','--whitespace=nowarn','-'],input=patch.encode(),cwd=OUT,capture_output=True)
            if result.returncode:
                # Real three-way merge preserves already adopted narrow fixes.
                temp=OUT/'merge-inputs'/str(len(operations));temp.mkdir(parents=True)
                for leaf,content in [('current',current),('before',old_bytes),('desired',desired)]:
                    (temp/leaf).write_bytes(content)
                merged=subprocess.run(['git','merge-file','-p',str(temp/'current'),str(temp/'before'),str(temp/'desired')],capture_output=True)
                (temp/'result').write_bytes(merged.stdout)
                assert merged.returncode==0,(name,rel,'three-way conflict',merged.stderr.decode())
                target.write_bytes(merged.stdout)
        operations.append(dict(capsule=name,manifest_sha256=digest(capsule/'manifest.json'),path=rel,sha256=digest(target)))

overlay('fallback-short')
overlay('decoder-node-constructor')
(OUT/'composition.json').write_text(json.dumps(dict(native_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=N,text=True).strip(),operations=operations,files={p.relative_to(OUT).as_posix():digest(p) for p in sorted((OUT/'preview/native').rglob('*')) if p.is_file()}),indent=2)+'\n')
print('Composed decoder completion',OUT)
