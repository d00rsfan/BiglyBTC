from pathlib import Path
import hashlib, json, shutil, subprocess
w = Path(__file__).resolve().parent
n = Path('/home/yurii/Java/BiglyBTC')
h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = '4f948e042df9467310a5752d4343b07915673f84'
parent = '7b6a5260edcd37c2bc4b227e99107dc779cfe51e'
run = w / 'next-portable/run-r2'
assert h(run / 'verification/result.json') == '4d8358c4f6089b950e550494636ddd49b3b59a001964e88f7d38c37fe041b01e'
r = json.loads((run / 'verification/result.json').read_text())
assert r['status'] == 'PRIVATE_RUNTIME_QUALIFIED_NOT_PROMOTED' and r['source'] == source and not r['promoted']
assert not r['system_installation'] and not r['original_profile_or_process_access']
hosted = json.loads((w / 'next-hosted/hosted-final.json').read_text())
assert len(hosted) == 2 and all(v['conclusion'] == 'success' and v['headSha'] == source for v in hosted)
d = json.loads((w / 'discovery-hosted-run-r3/results/result.json').read_text())
assert d['status'] == 'PASS' and not d['public_network'] and not d['shared_host_multicast_fallback']
assert d['artifact_sha256'] == r['provider_sha256'] and d['runtime_manifest_sha256'] == r['provider_manifest_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=n, text=True).strip() == parent
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=n)
subprocess.run(['git', 'diff', '--exit-code', source, '--', 'preview/native'], cwd=n, check=True, stdout=subprocess.DEVNULL)
expected = json.loads((run / 'verification/source-map.json').read_text())
assert h(run / 'verification/source-map.json') == r['source_map_sha256']
actual = {str(p.relative_to(n)): h(p) for p in (n / 'preview/native').rglob('*') if p.is_file()}
assert actual == expected
def verify(root):
    p = root / 'BUILD_MANIFEST.json'
    v = json.loads(p.read_text())
    for rel, sha in v['files_sha256'].items():
        leaf = root / rel
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
        assert leaf.resolve(strict=True).is_relative_to(root.resolve()) and leaf.is_file() and h(leaf) == sha
    assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == set(v['files_sha256']) | {'BUILD_MANIFEST.json'}
    return h(p)
dist = n / 'dist'
assert verify(dist) == r['previous_dist_manifest_sha256']
assert verify(run / 'candidate') == r['manifest_sha256']
publication = n / 'build/storage-20261025/next-portable/source4f948'
assert not publication.exists()
publication.mkdir(parents=True)
candidate = publication / 'candidate'
shutil.copytree(run / 'candidate', candidate, symlinks=True)
assert verify(candidate) == r['manifest_sha256']
rollback = publication / 'previous-dist'
dist.rename(rollback)
try:
    candidate.rename(dist)
    assert verify(dist) == r['manifest_sha256'] and verify(rollback) == r['previous_dist_manifest_sha256']
    receipt = dict(native_source=source, control_head=parent, dist=str(dist), rollback=str(rollback), old_manifest_sha256=r['previous_dist_manifest_sha256'], manifest_sha256=r['manifest_sha256'], manifest_files=r['files'], provider_sha256=r['provider_sha256'], private_receipt_sha256=h(run / 'verification/result.json'), hosted_source=source, discovery_run=40196523718, system_installation=False, original_profile_or_process_access=False)
    (publication / 'promotion.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (w / 'next-promotion.json').write_text(json.dumps(receipt, indent=2) + '\n')
except BaseException:
    if dist.exists():
        dist.rename(candidate)
    rollback.rename(dist)
    assert verify(dist) == r['previous_dist_manifest_sha256']
    raise
print('Promoted exact qualified source', source, 'files', r['files'], 'rollback', rollback)
