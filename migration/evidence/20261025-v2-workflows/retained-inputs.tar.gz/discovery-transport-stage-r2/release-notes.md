Development inputs for selected-swarm discovery qualification on an isolated GitHub runner. Contains exact source, SDK, provider and owned test fixtures; discovery runtime checks remain pending.

Bundle SHA256: 24f6ad223dc2e18bfc705b2b3a79121807d0eaf8385ea03692dba79c7c170e78
Provider SHA256: d367afd6499859c5a57d66bddd352a977ff76c7fb76b5925302c2c9008c7ddbd
