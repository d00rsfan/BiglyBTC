#!/usr/bin/env python3
"""One-job private product staging and deployment-only qualification; no promotion."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tempfile
import time
sys_source = '4f948e042df9467310a5752d4343b07915673f84'
N = Path('/home/yurii/Java/BiglyBTC')
W = Path('/home/yurii/Java/BiglyBT/build/storage-20261025')
HERE = W / 'next-portable'
B = N / 'build/persistent-peer-accounting-20261021/bound-gcc'
OUT = HERE / 'run-r2'
CANDIDATE = OUT / 'candidate'
DSO = W / 'provider-candidate/install/lib/libtorrent-rasterbar.so.2.0.12'
DSO_SHA = 'd367afd6499859c5a57d66bddd352a977ff76c7fb76b5925302c2c9008c7ddbd'
PROVIDER = N / 'preview/native/engine/runtime-binding/provider-runtime.json'
PROVIDER_SHA = 'e74def09b2257a266786b8ddb116382d300716687bf26bbe57072f5ff90e8737'
TESTS = {'provider-payload-counter': 'biglybtc-provider-payload-counter-tests',
         'selected-swarm-admission': 'biglybtc-selected-swarm-admission-tests',
         'persistent-native-peer-session': 'biglybtc-persistent-session-tests',
         'managed-download': 'biglybtc-managed-download-tests'}
CONTROL_TARGETS = ['biglybtc-runtime-deployment-driver', 'biglybtc-runtime-interposition-driver', 'biglybtc-runtime-interposer']

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def bundle(path):
    raw = path / 'BUILD_MANIFEST.json'
    value = json.loads(raw.read_text())
    for rel, digest in value['files_sha256'].items():
        leaf = path / rel
        require(not Path(rel).is_absolute() and '..' not in Path(rel).parts
                and leaf.resolve(strict=True).is_relative_to(path.resolve(strict=True))
                and leaf.is_file() and sha(leaf) == digest, 'Bundle byte/path mismatch: ' + rel)
    require({str(p.relative_to(path)) for p in path.rglob('*') if p.is_file()}
            == set(value['files_sha256']) | {'BUILD_MANIFEST.json'}, 'Bundle inventory mismatch')
    return sha(raw), value

def source():
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=N, text=True).strip() == sys_source,
            'Root source changed before private staging')
    require(subprocess.run(['git', 'diff', '--quiet', sys_source, '--', 'preview/native'], cwd=N).returncode == 0,
            'Native production source changed before staging')
    return {str(p.relative_to(N)): sha(p) for p in sorted((N / 'preview/native').rglob('*')) if p.is_file()}

def main():
    require(os.getpriority(os.PRIO_PROCESS, 0) >= 5, 'Run this recipe with nice -n5')
    before = source(); old_sha, old = bundle(N / 'dist')
    require(old_sha == 'bdee4d28fa24990920693782a186a8ec34fcafb772d3c7717aa886713fedc07e', 'Published dist baseline changed')
    require(sha(DSO) == DSO_SHA and DSO.stat().st_size == 9072560 and sha(PROVIDER) == PROVIDER_SHA,
            'Not the exact approved d367/e74 source provider')
    cache = (B / 'CMakeCache.txt').read_text()
    require('BIGLYBTC_BUNDLE_QT:BOOL=ON' in cache and 'BIGLYBTC_PAYLOAD_COUNTER_TEST_LANE:STRING=Qualified' in cache
            and 'BIGLYBTC_CAUSAL_QUALIFICATION_TESTS:BOOL=OFF' in cache, 'Wrong GCC cache/lane')
    OUT.mkdir(exist_ok=False)
    logs = OUT / 'verification'; logs.mkdir()
    save(logs / 'source-map.json', before)
    save(logs / 'baseline.json', {'source': sys_source, 'dist_manifest_sha256': old_sha,
        'dist_qualified_source': old.get('native_source', old.get('source_commit')),
        'provider_sha256': DSO_SHA, 'provider_manifest_sha256': PROVIDER_SHA,
        'recipe_sha256': sha(Path(__file__)),
        'stager_sha256': sha(N / 'preview/migration/tools/stage_preview.py')})
    commands = []
    env = {k: v for k, v in os.environ.items() if not k.startswith('BIGLYBTC_') and k not in
        ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH', 'QT_SCALE_FACTOR', 'QT_AUTO_SCREEN_SCALE_FACTOR', 'PYTHONPATH')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    def run(name, argv, timeout=120, expected=0):
        started = time.monotonic(); timed_out = False
        with (logs / (name + '.log')).open('x') as out:
            child = subprocess.Popen(list(map(str, argv)), cwd=N, env=env, stdout=out, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            while True:
                remaining = timeout - (time.monotonic() - started)
                if remaining <= 0:
                    timed_out = True
                    try:
                        os.killpg(child.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=5)
                    break
                try:
                    child.wait(timeout=min(30, remaining)); break
                except subprocess.TimeoutExpired:
                    print(name + ' running; full log retained', flush=True)
        commands.append({'name': name, 'argv': list(map(str, argv)), 'exit_code': child.returncode,
            'expected_exit': expected, 'timed_out': timed_out, 'seconds': time.monotonic() - started,
            'log_sha256': sha(logs / (name + '.log'))})
        save(logs / 'commands.json', commands)
        require(not timed_out and child.returncode == expected, 'Command failed: ' + name)
        print(name + ' PASS', flush=True)
        return (logs / (name + '.log')).read_text()
    products = ['BiglyBTC', 'BiglyBTC-headless', 'biglybtc-preview-smoke']
    targets = products + list(TESTS.values()) + CONTROL_TARGETS
    run('build-needed-products-and-loader-tests', ['cmake', '--build', B, '--parallel', '1', '--target', *targets], 1200)
    require(source() == before, 'Source changed during one-job build')
    dry = run('no-stale-products', ['cmake', '--build', B, '--target', *targets, '--', '-n'], 60)
    if 'no work to do' not in dry.lower():
        run('settle-qt-autogen', ['cmake', '--build', B, '--parallel', '1', '--target', *targets], 300)
        require(source() == before, 'Source changed during Qt autogen settle')
        dry = run('no-stale-products-after-settle', ['cmake', '--build', B, '--target', *targets, '--', '-n'], 60)
    require('no work to do' in dry.lower(), 'Stale executable after bounded autogen settle')
    catalog_text = run('test-catalog', ['ctest', '--test-dir', B, '--show-only=json-v1'], 60)
    catalog = {v['name']: v for v in json.loads(catalog_text)['tests']}
    require(set(TESTS) <= catalog.keys() and 'persistent-runtime-deployment-selected' in catalog,
            'Deployment cohort missing from registered GCC tests')
    run('stage', ['python3', N / 'preview/migration/tools/stage_preview.py', '--build', B, '--output', CANDIDATE,
        '--libtorrent-package', N / 'build/dependencies/packages/libtorrent-rasterbar2.0t64_2.0.12-1_amd64.deb',
        '--source-libtorrent', DSO, '--source-provider-manifest', PROVIDER], 300)
    candidate_sha, manifest = bundle(CANDIDATE)
    private = CANDIDATE / 'usr/lib/biglybtc'
    provider = manifest['libtorrent_runtime']
    require(provider['artifact_sha256'] == DSO_SHA and provider['artifact_bytes'] == 9072560
            and provider['instrumented'] is False and sha(private / 'lib/libtorrent-rasterbar.so.2.0.12') == DSO_SHA,
            'Private provider identity differs')
    require(bundle(N / 'dist')[0] == old_sha and source() == before, 'Published/source bytes changed during staging')
    # Freeze executables and Python/DSO controls before root may advance HEAD or
    # relink this shared cache. No qualification executable is run from the cache.
    bins = logs / 'test-bin'; bins.mkdir()
    paths = [B / 'biglybtc-preview-smoke']
    for name in TESTS:
        require(Path(catalog[name]['command'][0]).name == TESTS[name], 'Unexpected CTest executable')
        paths.append(Path(catalog[name]['command'][0]))
    deploy = list(catalog['persistent-runtime-deployment-selected']['command'])
    paths += [Path(deploy[deploy.index(flag) + 1]) for flag in ('--driver', '--interposition-driver', '--preload')]
    py = Path(deploy[2]); require(py.name == 'runtime_deployment_tests.py', 'Unexpected deployment recipe')
    paths.append(py)
    frozen = {}
    for path in paths:
        require(path.is_file() and not path.is_symlink(), 'Unsafe qualification binary/input')
        destination = bins / path.name; require(not destination.exists(), 'Repeated fixture basename')
        shutil.copy2(path, destination); require(sha(path) == sha(destination), 'Qualification copy differs')
        frozen[str(path)] = str(destination)
    save(logs / 'frozen-inputs.json', {k: {'path': v, 'sha256': sha(Path(v))} for k, v in frozen.items()})
    save(OUT / 'staged.json', {'status': 'STAGED_NOT_PROMOTED', 'source': sys_source,
        'candidate': str(CANDIDATE), 'manifest_sha256': candidate_sha, 'previous_dist_sha256': old_sha,
        'source_map_sha256': sha(logs / 'source-map.json'), 'qualification_inputs_copied': True})
    print('STAGED_NOT_PROMOTED ' + str(CANDIDATE), flush=True)
    env.update(QT_QPA_PLATFORM='offscreen', QT_SCALE_FACTOR='1',
        LD_LIBRARY_PATH=':'.join(map(str, [private / 'lib', private / 'qt/lib', CANDIDATE / 'dependencies/libtorrent/usr/lib/x86_64-linux-gnu'])),
        QT_PLUGIN_PATH=str(private / 'qt/plugins'), QT_QPA_PLATFORM_PLUGIN_PATH=str(private / 'qt/plugins/platforms'))
    # Verify actual loaded Qt/LT origin for every copied positive executable.
    for name, path in [('BiglyBTC', private / 'bin/BiglyBTC'), ('BiglyBTC-headless', private / 'bin/BiglyBTC-headless'),
                       ('smoke', bins / 'biglybtc-preview-smoke'), *[(name, Path(frozen[catalog[name]['command'][0]])) for name in TESTS]]:
        loaded = run('loader-' + name, ['ldd', path], 30)
        require('not found' not in loaded and str(private / 'lib/libtorrent-rasterbar.so.2.0') in loaded,
                'Executable did not load the private selected provider: ' + name)
        if 'libQt6Core.so.6' in loaded:
            require(str(private / 'qt/lib/libQt6Core.so.6') in loaded, 'QtCore escaped private runtime')
        for line in loaded.splitlines():
            if '/opt/Qt' in line:
                require(line.lstrip().startswith('libQt6Test.so.6 => '), 'Shipping Qt escaped private runtime')
    rpaths = {}; dynamic_logs = {}
    for relative in manifest['files_sha256']:
        leaf = CANDIDATE / relative
        if leaf.is_symlink() or leaf.read_bytes()[:4] != b'\x7fELF':
            continue
        dynamic = subprocess.check_output(['readelf', '--dynamic', str(leaf)], text=True)
        dynamic_logs[relative] = dynamic
        relevant = [line.strip() for line in dynamic.splitlines() if '(RPATH)' in line or '(RUNPATH)' in line]
        require(all('/opt/Qt' not in line and str(B) not in line and '/tmp/' not in line
                    and str(W / 'provider-candidate') not in line for line in relevant), 'Nonportable runtime path: ' + relative)
        rpaths[relative] = relevant
    save(logs / 'all-elf-rpaths.json', rpaths)
    save(logs / 'all-elf-dynamic.json', dynamic_logs)
    runtime = lambda files: {k: v for k, v in files.items() if k.startswith('usr/lib/biglybtc/lib/') or k.startswith('usr/lib/biglybtc/qt/') or k.startswith('dependencies/libtorrent/usr/lib/')}
    prior_runtime, current_runtime = runtime(old['files_sha256']), runtime(manifest['files_sha256'])
    require(prior_runtime.keys() == current_runtime.keys(), 'Unexpected runtime inventory change')
    runtime_changed = [k for k in current_runtime if current_runtime[k] != prior_runtime[k]]
    require(all('libtorrent-rasterbar.so' in Path(k).name for k in runtime_changed), 'Unexplained runtime bytes changed')
    save(logs / 'runtime-comparison.json', {'files': len(current_runtime), 'unchanged': len(current_runtime)-len(runtime_changed), 'changed_exact_selected_provider_aliases': runtime_changed})
    sample = Path(tempfile.mkdtemp(prefix='biglybtc-preview-', dir='/tmp')); sample.rmdir()
    run('prepare-generated-profile', ['python3', N / 'preview/native/packaging/preview.py', '--prepare', sample], 30)
    for key in ('XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_RUNTIME_DIR'):
        directory = sample / key.lower(); directory.mkdir(mode=0o700); env[key] = str(directory)
    env.update(BIGLYBTC_PREVIEW_PROFILE=str(sample / 'profile'), BIGLYBTC_PREVIEW_CAPTURE=str(sample / 'classic-preview.png'))
    sample_before_usage = {str(p.relative_to(sample)): sha(p) for p in sample.rglob('*') if p.is_file()}
    usage = run('normal-launcher-usage', [CANDIDATE / 'BiglyBTC'], 30, 2)
    require('Usage: BiglyBTC --profile ABSOLUTE_PROFILE' in usage, 'Unexpected normal launcher boundary')
    require({str(p.relative_to(sample)): sha(p) for p in sample.rglob('*') if p.is_file()} == sample_before_usage, 'Usage-only launcher touched the owned profile')
    smoke = run('smoke-private-runtime', [bins / 'biglybtc-preview-smoke', '-o', '-,txt'], 300)
    total = re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped', smoke)
    require(len(total) == 1 and int(total[0]) >= 13, 'Incomplete smoke rows')
    captures = logs / 'captures'; captures.mkdir()
    expected_captures = json.loads((W / 'remainder-portable/plan.json').read_text())['retained_capture_names']
    actual = {p.name: p for p in sample.glob('*.png')}
    require(set(expected_captures) <= actual.keys(), 'Missing earlier preview capture')
    for name, path in actual.items():
        shutil.copy2(path, captures / name)
    results = []
    for name, target in TESTS.items():
        command = [frozen[catalog[name]['command'][0]], *catalog[name]['command'][1:]]
        text = run('cohort-' + name, command, 300)
        totals = re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped', text)
        require(len(totals) == 1, 'Missing exact successful Qt totals: ' + name)
        results.append({'name': name, 'status': 'PASS', 'qt_rows': int(totals[0])})
    deploy = [frozen.get(arg, arg) for arg in deploy]
    deploy[deploy.index('--provider') + 1] = str(private / 'lib/libtorrent-rasterbar.so.2.0.12')
    text = run('cohort-persistent-runtime-deployment-selected', deploy, 240)
    receipt = json.loads(text.strip().splitlines()[-1]); receipt_path = Path(receipt['receipt'])
    copy = logs / 'relocation'; shutil.copytree(receipt_path.parent, copy)
    relocation = json.loads((copy / 'result.json').read_text())
    results.append({'name': 'persistent-runtime-deployment-selected', 'status': 'PASS', 'cases': receipt['cases'],
                    'receipt_sha256': sha(copy / 'result.json')})
    require(bundle(N / 'dist')[0] == old_sha and bundle(CANDIDATE)[0] == candidate_sha,
            'Published/private bundle changed during qualification')
    require(all(sha(Path(v)) == json.loads((logs / 'frozen-inputs.json').read_text())[k]['sha256'] for k, v in frozen.items()),
            'Frozen qualification inputs changed')
    record = {'status': 'PRIVATE_RUNTIME_QUALIFIED_NOT_PROMOTED', 'source': sys_source,
        'candidate': str(CANDIDATE), 'manifest_sha256': candidate_sha, 'files': len(manifest['files_sha256']),
        'previous_dist_manifest_sha256': old_sha, 'source_map_sha256': sha(logs / 'source-map.json'),
        'provider_sha256': DSO_SHA, 'provider_manifest_sha256': PROVIDER_SHA, 'cohort': results,
        'smoke_qt_rows': int(total[0]), 'captures': {name: sha(captures / name) for name in actual},
        'all_elf_rpaths': len(rpaths), 'runtime_files': len(current_runtime), 'runtime_unchanged': len(current_runtime)-len(runtime_changed), 'test_binaries_frozen_before_root_head_release': True,
        'build_jobs': 1, 'nice': os.getpriority(os.PRIO_PROCESS, 0), 'promoted': False,
        'system_installation': False, 'original_profile_or_process_access': False}
    save(logs / 'result.json', record)
    print(json.dumps({'status': record['status'], 'source': sys_source, 'suites': len(results),
                      'smoke_rows': int(total[0]), 'captures': len(actual), 'manifest': candidate_sha}), flush=True)
if __name__ == '__main__':
    main()
