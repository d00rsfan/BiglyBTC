#include "../adapters/original_torrent_identity_lt.hpp"
#include "../adapters/torrent_intake.hpp"
#include "../adapters/file_operations.hpp"
#include "../adapters/encoded_document.hpp"
#include "../engine/managed_storage.hpp"
#include "../engine/network_policy.hpp"
#include <libtorrent/hasher.hpp>
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdlib>
#include <filesystem>
#include <fcntl.h>
#include <iostream>
#include <optional>
#include <stdexcept>
#include <sys/stat.h>
#include <unistd.h>
#include <zlib.h>
namespace {
using namespace biglybtc;namespace fs=std::filesystem;namespace lt=libtorrent;
using Code=storage::ErrorCode;using Owner=engine::detail::ManagedStorage;
std::size_t assertions=0,families=0;
void check(bool value,const char* why){++assertions;if(!value){throw std::runtime_error(why);}}
template<class T>T take(std::expected<T,storage::Error> result){if(!result){throw std::runtime_error(result.error().message);}return std::move(*result);}
void done(std::expected<void,storage::Error> result){if(!result){throw std::runtime_error(result.error().message);}}
std::string b(std::string_view value){return std::to_string(value.size())+':'+std::string(value);}
std::string hashBytes(const core::TorrentHash& hash){const auto bytes=hash.bytes();return {reinterpret_cast<const char*>(bytes.data()),bytes.size()};}
core::Document doc(std::string value){auto d=core::Document::parse(std::move(value),storage::compatibleConfigLimits());check(d.has_value(),"literal document parse");return std::move(*d);}
void put(core::Document& d,std::string_view key,std::string value){check(d.replaceValue(key,std::move(value)).has_value(),"fixture outside-info edit");}
std::string encoded(const core::Node& n){auto value=core::encodeValue(n,storage::compatibleConfigLimits());check(value.has_value(),"fixture encode");return std::move(*value);}
void write(const fs::path& path,std::string_view bytes){fs::create_directories(path.parent_path());const int fd=::open(path.c_str(),O_WRONLY|O_CREAT|O_TRUNC|O_NOFOLLOW|O_CLOEXEC,0600);check(fd>=0,"owned fixture write");std::size_t offset=0;while(offset<bytes.size()){const auto n=::write(fd,bytes.data()+offset,bytes.size()-offset);if(n<0&&errno==EINTR){continue;}if(n<=0){::close(fd);throw std::runtime_error("fixture write failed");}offset+=static_cast<std::size_t>(n);}check(::close(fd)==0,"fixture write close");}
std::string read(const fs::path& path){const int fd=::open(path.c_str(),O_RDONLY|O_NOFOLLOW|O_CLOEXEC|O_NONBLOCK);check(fd>=0,"owned fixture read");std::string value;std::array<char,4096> buffer{};for(;;){const auto n=::read(fd,buffer.data(),buffer.size());if(n<0&&errno==EINTR){continue;}if(n<0){::close(fd);throw std::runtime_error("fixture read failed");}if(!n){break;}value.append(buffer.data(),static_cast<std::size_t>(n));}check(::close(fd)==0,"fixture read close");return value;}
std::string metainfo(bool hybrid,std::optional<std::string> selector={},char payload='x'){
  const auto root=lt::hasher256(&payload,1).final().to_string();const auto piece=lt::hasher(&payload,1).final().to_string();const std::string name="identity.bin";
  std::string info="d"+b("file tree")+"d"+b(name)+"d0:d"+b("length")+"i1e"+b("pieces root")+b(root)+"eee";
  if(hybrid){info+=b("length")+"i1e";}
  info+=b("meta version")+"i2e"+b("name")+b(name)+b("piece length")+"i16384e";
  if(hybrid){info+=b("pieces")+b(piece);}info+='e';
  const auto props="d"+(selector?b("hybrid_hash_v2")+*selector:std::string{})+b("future")+"li7e3:rawee";
  return "d"+b("azureus_private_properties")+props+b("info")+info+b("future.root")+"d1:xi9eee";
}
storage::OriginalTorrentIdentity identity(const std::string& bytes){auto source=doc(bytes);const lt::torrent_info metadata(lt::span<const char>(bytes.data(),bytes.size()),lt::from_span);return take(storage::originalTorrentIdentityFromLibtorrent(source,metadata));}
struct Area{
  fs::path root,profile,input,destination;std::optional<storage::ProfileLease> lease;
  Area(){char pattern[]="/tmp/biglybtc-identity-callers-XXXXXX";const auto* made=::mkdtemp(pattern);check(made,"owned fixture directory");root=made;profile=root/"profile";input=root/"input.torrent";destination=root/"payload-parent";check(::mkdir(profile.c_str(),0700)==0,"private profile");lease.emplace(take(storage::ProfileLease::acquire(profile)));}
  ~Area(){lease.reset();std::error_code error;fs::remove_all(root,error);}
  core::TorrentHash importMetadata(const std::string& source){write(input,source);return take(storage::importTorrent(*lease,input,destination,true));}
  fs::path state(const core::TorrentHash& key)const{return profile/"active"/(key.hex()+".dat");}
  core::LibrarySnapshot library()const{auto parsed=core::readLibrary(doc(read(profile/"downloads.config")));check(parsed&&parsed->issues.empty(),"published original inventory parses");return std::move(*parsed);}
  void noMutation()const{check(!fs::exists(profile/"active")&&!fs::exists(profile/"torrents")&&!fs::exists(profile/"BiglyBTC.torrent-import")&&!fs::exists(destination),"identity refusal precedes all intake/profile/payload effects");}
  void explicitFull32(const core::TorrentHash& from,const core::TorrentHash& to){auto inventory=doc(read(profile/"downloads.config"));const auto* rows=inventory.find("downloads");check(rows&&rows->children.size()==1,"one original selected row");auto row=doc(encoded(rows->children[0]));put(row,"torrent_hash",b(hashBytes(to)));put(inventory,"downloads","l"+row.serialize()+'e');write(state(to),read(state(from)));write(profile/"downloads.config",inventory.serialize());}
};
std::string gzip(std::string_view bytes){z_stream z{};check(::deflateInit2(&z,Z_BEST_SPEED,Z_DEFLATED,31,8,Z_DEFAULT_STRATEGY)==Z_OK,"fixture gzip init");std::string out(::deflateBound(&z,static_cast<uLong>(bytes.size())),'\0');z.next_in=reinterpret_cast<Bytef*>(const_cast<char*>(bytes.data()));z.avail_in=static_cast<uInt>(bytes.size());z.next_out=reinterpret_cast<Bytef*>(out.data());z.avail_out=static_cast<uInt>(out.size());const int result=::deflate(&z,Z_FINISH);const auto length=z.total_out;::deflateEnd(&z);check(result==Z_STREAM_END,"fixture gzip final");out.resize(length);return out;}
void interrupted(storage::FileOperationStage stage){if(stage==storage::FileOperationStage::JournalSynced){throw std::runtime_error("synthetic after-journal boundary");}}
void selectedImportAndOfflineOperations(){
  for(const bool hybrid:{false,true}){
    for(const std::optional<std::string>& selector:{std::optional<std::string>{},std::optional<std::string>{"i0e"},std::optional<std::string>{"i1e"},std::optional<std::string>{"i2e"}}){
      Area a;const auto input=metainfo(hybrid,selector);const auto expected=identity(input);const auto key=a.importMetadata(input);check(key==expected.originalKey&&key.bytes().size()==20,"new inventory always uses original selected20 convention");
      const lt::torrent_info subject(lt::span<const char>(input.data(),input.size()),lt::from_span);const auto hashes=subject.info_hashes();const bool useV2=!hybrid||(selector&&*selector=="i1e");const auto* digest=reinterpret_cast<const std::byte*>(useV2?hashes.v2.data():hashes.v1.data());check(std::equal(key.bytes().begin(),key.bytes().end(),digest),"published original key equals independently selected actual full digest prefix");
      auto original=doc(input),saved=doc(read(a.state(key)));check(take(storage::originalTorrentInfoSubject(saved))==take(storage::originalTorrentInfoSubject(original)),"intake retains exact unrewritten info");check(encoded(*saved.find("azureus_private_properties"))==encoded(*original.find("azureus_private_properties"))&&saved.find("future.root"),"selector and unknown properties survive new state");
      const auto plan=storage::prepareFileOperation(*a.lease,{key,storage::FileOperationKind::RemoveKeepData,{}});check(plan.has_value()&&plan->preview().missingFiles==1,"EVP file-operation identity accepts real original selected key read-only");
      const auto before=read(a.state(key));auto owner=Owner::prepare(*a.lease,key,{});
      if(hybrid&&useV2){check(!owner&&owner.error().code==Code::Unsupported&&!fs::exists(a.destination)&&read(a.state(key))==before,"selected-v2 hybrid active admission remains unavailable until swarm policy qualification");}
      else{check(owner.has_value()&&owner->identity().full==expected.full,"managed identity uses every actual LT digest");}
    }
  }
}
void duplicateAliasesAndMalformedSelectors(){
  {
    Area a;const auto first=metainfo(true,"i0e"),second=metainfo(true,"i1e");const auto key=a.importMetadata(first);const auto before=read(a.profile/"downloads.config"),state=read(a.state(key));write(a.input,second);
    const auto result=storage::importTorrent(*a.lease,a.input,a.root/"other",true);check(!result&&result.error().code==Code::Conflict,"alternate original hybrid key cannot duplicate a known full subject");check(read(a.profile/"downloads.config")==before&&read(a.state(key))==state&&!fs::exists(a.profile/"BiglyBTC.torrent-import")&&!fs::exists(a.state(identity(second).originalKey)),"alternate selected import fails before journal/new state and preserves first row");
  }
  {
    Area a;const auto alternate=identity(metainfo(true,"i1e"));write(a.profile/"downloads.config","d9:downloadsle10:pause_datal"+b(hashBytes(alternate.originalKey))+"ee");const auto before=read(a.profile/"downloads.config");write(a.input,metainfo(true));const auto result=storage::importTorrent(*a.lease,a.input,a.destination,true);check(!result&&result.error().code==Code::Conflict&&read(a.profile/"downloads.config")==before&&!fs::exists(a.profile/"active"),"unselected full alias held only by legacy pause ownership also refuses import");
  }
  for(const auto* selector:{"1:x","le"}){Area a;write(a.input,metainfo(true,std::string(selector)));const auto result=storage::importTorrent(*a.lease,a.input,a.destination,true);check(!result&&result.error().code==Code::InvalidFormat,"malformed known selector is never silently defaulted");a.noMutation();}
}
void explicit32AndRetainedIdentity(){
  Area a;const auto input=metainfo(false);const auto expected=identity(input);check(expected.full.v2.has_value(),"actual v2 evidence");const auto key=a.importMetadata(input);auto first=std::make_optional(take(Owner::prepare(*a.lease,key,{})));
  const auto full=core::TorrentHash::parse(std::string_view(reinterpret_cast<const char*>(expected.full.v2->data()),32));check(full.has_value(),"actual explicit32 key");a.explicitFull32(key,*full);
  const auto before=read(a.state(*full));const std::array<storage::OriginalTorrentIdentity,1> retained{{first->identity()}};
  auto conflict=Owner::prepare(*a.lease,*full,{}, {},retained);check(!conflict&&conflict.error().code==Code::Conflict&&read(a.state(*full))==before,"same full subject cannot be co-admitted through explicit32 alias before effects");
  auto offline=storage::prepareFileOperation(*a.lease,{*full,storage::FileOperationKind::RemoveKeepData,{}});check(offline.has_value(),"existing explicit32 file-operation reader policy retained");
  // Default standalone API asserts no other admissions. This is a read/prepare
  // compatibility fixture, not permission to run two handles simultaneously.
  first.reset();auto compatible=Owner::prepare(*a.lease,*full,{});check(compatible.has_value()&&compatible->identity().originalKey==key,"managed explicit32 reader policy retains original20 projected identity");
}
void cachedSelectionAndRecovery(){
  Area a;const auto key=a.importMetadata(metainfo(true,"i1e"));auto state=doc(read(a.state(key)));put(state,"azureus_private_properties","d14:hybrid_hash_v2i0e6:futureli7e3:rawee");write(a.state(key),state.serialize());
  write(a.profile/"active/cache.dat",gzip("d5:stateld4:hash"+b(hashBytes(key))+"4:azppd14:hybrid_hash_v2i1e6:futureli7e3:raweeeee"));
  const auto cacheBefore=read(a.profile/"active/cache.dat"),stateBefore=read(a.state(key));const auto target=a.root/"move-parent";fs::create_directory(target);
  auto plan=take(storage::prepareFileOperation(*a.lease,{key,storage::FileOperationKind::Relocate,target}));check(read(a.state(key))==stateBefore&&read(a.profile/"active/cache.dat")==cacheBefore,"cache-authoritative selected identity is a read-only prepare");
  auto confirmation=take(storage::confirmFileOperation(plan,plan.preview().approvalScopeDigest,false));const auto failed=storage::applyFileOperation(*a.lease,std::move(plan),confirmation,interrupted);check(!failed&&storage::hasPendingFileOperation(*a.lease),"generated recovery record retains authoritative cached selector");
  auto recovered=take(storage::recoverFileOperation(*a.lease));check(recovered&&recovered->recovered&&!storage::hasPendingFileOperation(*a.lease),"file-operation replay hydrates azpp before selected/full hash gate");
  const auto after=doc(read(a.state(key)));check(after.find("azureus_private_properties")->find("hybrid_hash_v2")->integer==1&&after.find("azureus_private_properties")->find("future")&&after.find("future.root"),"recovery publishes selected identity and unknown properties unchanged");check(a.library().downloads[0].saveDirectory==target.string(),"recovery changes only approved save parent");
}
void rawSubjectBinding(){
  const auto a=metainfo(true),b=metainfo(true,{},'y');auto source=doc(b);const lt::torrent_info first(lt::span<const char>(a.data(),a.size()),lt::from_span);
  auto mismatch=storage::originalTorrentIdentityFromLibtorrent(source,first);check(!mismatch&&mismatch.error().code==Code::Conflict,"actual LT hashes from a different raw info subject are refused");
  source=doc(a);const auto original=take(storage::originalTorrentInfoSubject(source));put(source,"info",std::string(original));check(!storage::originalTorrentIdentityFromLibtorrent(source,first),"rewriting even identical info does not manufacture original provenance");
}
}
int main(){try{selectedImportAndOfflineOperations();++families;duplicateAliasesAndMalformedSelectors();++families;explicit32AndRetainedIdentity();++families;cachedSelectionAndRecovery();++families;rawSubjectBinding();++families;std::cout<<"PASS "<<families<<" original-identity caller families, "<<assertions<<" assertions; generated data and actual LT/OpenSSL digests, no engine activation or Java equality credit\n";return 0;}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
