# Root adopts the new source and merges this registration after CF01 qualification.
# This driver is coordinated by run.py, never an unguarded standalone CTest run.
if(BIGLYBTC_LOCAL_ENGINE AND BIGLYBTC_DESKTOP AND NOT BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST STREQUAL "")
  add_executable(biglybtc-v2-managed-handoff-driver v2_managed_handoff_driver.cpp)
  target_link_libraries(biglybtc-v2-managed-handoff-driver PRIVATE
    biglybtc_local_engine biglybtc_profile LibtorrentRasterbar::torrent-rasterbar Qt6::Core)
  target_compile_options(biglybtc-v2-managed-handoff-driver PRIVATE -Wall -Wextra -Wpedantic -Werror)
endif()
