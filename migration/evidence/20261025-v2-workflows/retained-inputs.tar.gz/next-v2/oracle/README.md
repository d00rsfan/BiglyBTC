CF02 source-only extension of the maintained generated managed handoff.
CF01 frozen files are not changed. Root adopts after the dependent production
identity/mapped-v2 changes and runs one consolidated qualification batch.

```sh
python3 -B build/storage-20261025/next-v2/oracle/run.py \
  --reference-root /home/yurii/Java/BiglyBT \
  --driver /ABS/TO/biglybtc-v2-managed-handoff-driver \
  --work /tmp/biglybtc-managed-handoff-v2-UNIQUE
```

The native CLI is `WORK_ROOT PROFILE METADATA EXPECTED OUTPUT
partial|complete|layout MISSING_REAL_PIECE`. The runner chooses a non-tail real
piece actually absent in the original checked bitmap; the partial seed excludes
that one piece. Counts come from actual metadata/status rather than8/9 constants.
The bounded layout role never creates a session or changes a payload/profile.

Reuse unchanged ReferenceFence, EngineOracle, InteropOracle, MultiFileOracle and
MultiEngineOracle over the retained5432 Java17 class map. Compile only these small
fixture helpers plus V2MetadataOracle/V2ManagedOracle; no original rebuild.
V2MetadataOracle calls actual `selectHybridHashType(TT_V2)` and then serializes and
reloads the selected hybrid. Facts include both full hashes, actual selected20
identity, effective type and original index/offset/pad/path. New original-generated
U+10000/U+E000 names expose UTF16-vs-UTF8 ordering, retaining a nonaligned real tail
and a real empty file; those two cases receive layout-only credit.

Six actual profiles are planned: ordinary hybrid and pure-v2 single/multifile,
selected-v2 hybrid single, and pure-v2 multifile with one original-created selected
reordered real file spanning7 pieces. Standard producers remain unchanged. The
extra custom producer invokes actual original FMFile, never writes a resume map.
Each profile passes through actual managed partial stop/join, Java READY readback,
managed completion plus real upload to an independent owned leecher, then joined
close and actual Java logical-byte/empty-file readback. Virtual padding never
becomes a physical data fixture. Active paths keep the strict actual Java/LT
geometry gate; this recipe does not invent an index remapper.

Keep the original-only full-data pure-v2 multifile recheck before any native
participation. It must reproduce the retained8/9 result with bitmap111111110.
The real tail, virtual pad and real empty file remain present. On affected Java
RECHECK handoffs only that independently observed bad-tail bit may differ, with
its exact per-file byte intersections recorded. Such a result explicitly reports
a characterized original recheck gap, not full Java progress parity. Unexpected
gaps fail. Native verification, bytes, retirement and real counters stay strict.

Selected-hybrid success covers the original saved identity and owned-loopback
transfer only. It does not prove public selected-swarm exclusivity: root must
qualify that separate production mechanism from actual peer behavior. Metadata
layout observations likewise do not qualify writes or active range projection.

Commands, authored class hashes, raw stdout/stderr and actual native/original
observations stay under the fresh private work root, including failed commands.
Copy concise receipts/fixtures when qualified; do not archive unchanged Java
cohort binaries or entire builds. No original real profile/process/public network.
