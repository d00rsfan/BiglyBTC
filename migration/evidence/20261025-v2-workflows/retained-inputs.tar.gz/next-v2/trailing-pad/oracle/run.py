#!/usr/bin/env python3
"""Existing original producers -> current managed v2/hybrid -> actual Java READY.

Source-only recipe. No original core rebuild; root supplies the batched driver.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
JAVA = Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')
ORIGINAL = 'cb8c6cb9bb97916cbc7e80338a017200ffc3e71f'


def need(ok, why):
    if not ok:
        raise ValueError(why)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files(root):
    result = {}
    for path in sorted(root.rglob('*')):
        need(not path.is_symlink(), 'Symlink in owned inputs')
        if path.is_file():
            s = path.lstat()
            need(stat.S_ISREG(s.st_mode) and s.st_uid == os.geteuid() and s.st_nlink == 1, 'Unsafe generated leaf')
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


def rows(text):
    result = {'indices': {}, 'files': {}}
    for line in text.splitlines():
        r = line.split('\t')
        if r[0] == 'V2_META':
            need(len(r) == 9 and 'metadata' not in result, 'Bad actual metadata facts')
            result['metadata'] = dict(zip(('type', 'effective', 'selected', 'v1', 'v2', 'piece', 'pieces', 'logicalBytes'), r[1:]))
            for key in ('type', 'effective', 'piece', 'pieces', 'logicalBytes'):
                result['metadata'][key] = int(result['metadata'][key])
        elif r[0] == 'V2_INDEX':
            need(len(r) == 6 and int(r[1]) not in result['indices'], 'Bad actual source index')
            result['indices'][int(r[1])] = {'offset': int(r[2]), 'bytes': int(r[3]), 'pad': r[4] == 'true',
                'path': bytes.fromhex(r[5]).decode('utf-8')}
        elif r[0] == 'V2_READY':
            need(len(r) == 4 and 'ready' not in result, 'Bad actual READY facts')
            result['ready'] = {'done': int(r[1]), 'total': int(r[2]), 'bits': r[3]}
        elif r[0] == 'V2_PROGRESS':
            need(len(r) == 8 and 'progress' not in result, 'Bad actual original progress facts')
            result['progress'] = dict(zip(('completedLogical', 'totalLogical', 'remainingLogical',
                'completedPayload', 'completedPadding', 'totalPayload', 'totalPadding'), map(int, r[1:])))
        elif r[0] == 'V2_FILE':
            need(len(r) == 10 and int(r[1]) not in result['files'], 'Bad actual original file')
            result['files'][int(r[1])] = {'offset': int(r[2]), 'bytes': int(r[3]), 'pad': r[4] == 'true',
                'priority': int(r[5]), 'skipped': r[6] == 'true', 'kind': int(r[7]), 'downloaded': int(r[8]),
                'path': bytes.fromhex(r[9]).decode('utf-8')}
        elif r[0] == 'V2_INTENT':
            need(len(r) == 6 and 'intent' not in result, 'Bad actual intent'); result['intent'] = r[1:]
        elif r[0] == 'V2_COUNTERS':
            need(len(r) == 3 and 'counters' not in result, 'Bad actual original counters'); result['counters'] = tuple(map(int, r[1:]))
        elif r[0] == 'V2_ORIGINAL_STOPPED':
            need(len(r) == 1 and 'stopped' not in result, 'Bad original stop'); result['stopped'] = True
    need('metadata' in result and result['indices'], 'Missing actual source metadata')
    return result


def checked(value):
    need({'ready', 'files', 'intent', 'counters', 'progress', 'stopped'} <= value.keys(), 'Incomplete actual original READY observation')
    ready = value['ready']
    need(ready['total'] == value['metadata']['pieces'] and len(ready['bits']) == ready['total']
         and set(ready['bits']) <= {'0', '1'} and ready['bits'].count('1') == ready['done'], 'Bad original checked bitmap')
    need(set(value['files']) == set(value['indices']), 'Original file indices changed during actual reload')
    progress = value['progress']
    need(all(0 <= n <= (1 << 63) - 1 for n in progress.values()), 'Actual original progress is negative/overflowed')
    need(progress['completedLogical'] == progress['totalLogical'] - progress['remainingLogical']
         == progress['completedPayload'] + progress['completedPadding']
         and progress['totalLogical'] == progress['totalPayload'] + progress['totalPadding']
         == value['metadata']['logicalBytes'], 'Actual original logical/payload/padding observations disagree')
    need(progress['completedPayload'] == sum(f['downloaded'] for f in value['files'].values() if not f['pad'])
         and progress['completedPadding'] == sum(f['downloaded'] for f in value['files'].values() if f['pad'])
         and progress['totalPayload'] == sum(f['bytes'] for f in value['indices'].values() if not f['pad'])
         and progress['totalPadding'] == sum(f['bytes'] for f in value['indices'].values() if f['pad']),
         'Actual original per-file getters disagree with observed progress totals')
    return value


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--reference-root', type=Path, required=True)
    p.add_argument('--classes', type=Path, default=Path('/tmp/biglybtc-oracle/classes'))
    p.add_argument('--retention', type=Path, default=Path('/home/yurii/Java/BiglyBTC/build/dependencies/java-oracle-17-20261021/retention.json'))
    p.add_argument('--driver', type=Path, required=True)
    p.add_argument('--work', type=Path, required=True)
    p.add_argument('--ordering-only', action='store_true', help='Only actual Java-generated UTF16 raw hash/index probes; no transfer credit')
    args = p.parse_args()
    amendment = json.loads((HERE.parent / 'manifest.json').read_text())
    for name, digest in amendment['artifacts_sha256'].items():
        need(sha(HERE.parent / name) == digest, 'Changed ordering/accounting amendment: ' + name)
    baseline = Path(amendment['oracle_baseline_path'])
    need(sha(baseline / 'manifest.json') == amendment['dependencies_sha256']['oracle_manifest'], 'Changed frozen oracle baseline')
    manifest = json.loads((baseline / 'manifest.json').read_text())
    for name, digest in manifest['files'].items():
        need(sha(baseline / name) == digest, 'Changed oracle source: ' + name)
    ref = args.reference_root.resolve(strict=True)
    for name, digest in manifest['reference_sha256'].items():
        need(sha(ref / name) == digest, 'Changed retained helper/evidence: ' + name)
    for name, digest in manifest['original_source_sha256'].items():
        need(sha(ref / name) == digest, 'Changed pinned original source: ' + name)
    for name, digest in amendment['original_source_sha256'].items():
        need(sha(ref / name) == digest, 'Changed ordering/accounting original source: ' + name)
    need(sha(args.retention) == manifest['retention_sha256'], 'Changed retained original cohort identity')
    retention = json.loads(args.retention.read_text())
    need(retention['source_commit'] == ORIGINAL and retention['recompiled'] is False, 'Wrong original cohort')
    classes = args.classes.resolve(strict=True)
    need(classes == args.classes and classes.is_relative_to('/tmp') and files(classes) == retention['file_sha256'], 'Changed original5432 classes')
    driver = args.driver.resolve(strict=True)
    need(driver.is_file() and not args.driver.is_symlink(), 'Missing actual native driver')
    work = args.work.absolute()
    need(work.parent == Path('/tmp') and work.name.startswith('biglybtc-managed-handoff-v2-') and not work.exists()
         and not work.is_symlink() and work.resolve() == work, 'Fresh owned /tmp work required')
    work.mkdir(mode=0o700); (work / 'classes').mkdir(mode=0o700); (work / 'empty-sourcepath').mkdir(mode=0o700)
    commands = []
    env = {k: v for k, v in os.environ.items() if k not in ('CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'LD_PRELOAD')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'

    def run(name, argv, cwd, timeout=150):
        item = {'name': name, 'argv': list(map(str, argv)), 'cwd': str(cwd), 'timeout': timeout}
        commands.append(item); (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        with (work / (name + '.stdout')).open('wb') as out, (work / (name + '.stderr')).open('wb') as err:
            value = subprocess.run(item['argv'], cwd=cwd, env=env, stdout=out, stderr=err, timeout=timeout)
        need(value.returncode == 0, 'Actual command failed; logs retained: ' + name)
        return (work / (name + '.stdout')).read_text()

    helper_names = ('ReferenceFence.java', 'EngineOracle.java', 'InteropOracle.java', 'MultiFileOracle.java', 'MultiEngineOracle.java')
    sources = [ref / 'migration/fixtures/java' / name for name in helper_names] + [HERE / 'V2MetadataOracle.java', HERE / 'V2ManagedOracle.java']
    run('javac-fixture-helpers', [JAVA / 'javac', '-J-XX:ActiveProcessorCount=2', '--release', '8', '-encoding', 'UTF-8', '-proc:none',
        '-implicit:none', '-sourcepath', work / 'empty-sourcepath', '-cp', classes, '-d', work / 'classes', *sources], work, 60)
    sys.path.insert(0, str(ref / 'migration/tools'))
    from peer_interop import jvm, unused_port
    from handoff import decode
    cp = str(work / 'classes') + os.pathsep + str(classes)

    def java(name, root, main, *arguments, ports=(), timeout=180):
        return run(name, [*jvm(root, cp, ports), main, *arguments], root, timeout)

    def state(path):
        raw = path.read_bytes(); need(len(raw) <= 4 * 1024 * 1024, 'Bounded generated state required')
        if raw.startswith(b'\x1f\x8b'): raw = gzip.decompress(raw)
        need(len(raw) <= 4 * 1024 * 1024, 'Bounded decoded state required')
        return decode(raw)

    def engine_projection(native, original):
        count = len(original['indices']); engine = native['engine_files']
        need(len(native['original_files']) == count, 'Projection changed original file-slot count')
        logical = original['metadata']['logicalBytes']; piece = original['metadata']['piece']
        need(type(native['engine_trailing_pad']) is bool and int(native['original_total_bytes']) == logical,
             'Missing actual original/pad projection proof')
        if native['engine_trailing_pad']:
            need(original['metadata']['v1'] == '-' and original['metadata']['v2'] != '-'
                 and logical % piece != 0 and len(engine) == count + 1, 'Only a pure-v2 final pad is admissible')
            extra = engine[-1]; padding = piece - logical % piece
            need(extra['index'] == count and extra['pad'] is True and int(extra['offset']) == logical
                 and int(extra['bytes']) == padding and int(native['engine_total_bytes']) == logical + padding,
                 'Actual synthetic final pad has a different range')
        else:
            need(len(engine) == count and int(native['engine_total_bytes']) == logical, 'Unproven engine file/range difference')
        return count

    generation = work / 'generation'; generation.mkdir(mode=0o700)

    def ordering_probes():
        observations = {}
        for kind in (2, 3):
            name = 'order-' + str(kind); case = work / name; case.mkdir(mode=0o700); (case / 'profile').mkdir(mode=0o700)
            metadata = generation / ('order/order-' + str(kind) + '.torrent')
            original = rows(java(name + '-facts', generation, 'V2MetadataOracle', 'facts', metadata))
            raw, spans = state(metadata)
            need(b'info' in raw and (b'info',) in spans, 'Generated order probe lost raw info')
            subject = spans[(b'info',)]
            need(hashlib.sha256(subject).hexdigest().upper() == original['metadata']['v2'], 'Original full v2 hash differs from original serialized info')
            if original['metadata']['v1'] != '-':
                need(hashlib.sha1(subject).hexdigest().upper() == original['metadata']['v1'], 'Original full v1 hash differs from original serialized info')
            before = files(case / 'profile'); raw_before = sha(metadata)
            output = case / 'layout'
            run(name + '-native-layout', [driver, work, case / 'profile', metadata, generation / 'order/expected/order-fixture', output, 'layout', 0], case, 30)
            native = json.loads((output / 'result.json').read_text())
            need(sha(metadata) == raw_before and files(case / 'profile') == before, 'Ordering probe mutated metadata/profile')
            need(native['info_order'] == 'java-utf16-file-tree' and native['full_v1'] == original['metadata']['v1']
                 and native['full_v2'] == original['metadata']['v2'] and native['selected_hash'] == original['metadata']['selected'],
                 'Actual original/provider full raw identities or recognized encoding differ')
            engine_projection(native, original)
            for i, f in original['indices'].items():
                a, b = native['original_files'][i], native['engine_files'][i]
                need(a['index'] == b['index'] == i and int(a['offset']) == int(b['offset']) == f['offset']
                     and int(a['bytes']) == int(b['bytes']) == f['bytes'] and a['pad'] == b['pad'] == f['pad']
                     and a['path'] == f['path'], 'Actual Java and LT ordering/index/range/pad mismatch')
                if not f['pad']:
                    parts = Path(f['path']).parts
                    need(Path(b['path']).parts[-len(parts):] == parts, 'Actual provider real path differs from original index')
            observations[name] = {'original': original, 'native': native, 'metadata_sha256': raw_before,
                'raw_info_sha256': hashlib.sha256(subject).hexdigest(), 'transfer_credit': False}
        return observations

    if args.ordering_only:
        java('order-generate', generation, 'V2MetadataOracle', 'order', generation / 'order')
        result = {'status': 'PASS_ACTUAL_ORIGINAL_UTF16_PROVIDER_LAYOUT_ONLY', 'original_commit': ORIGINAL,
            'manifest_sha256': sha(HERE.parent / 'manifest.json'), 'driver_sha256': sha(driver),
            'layout_only': ordering_probes(), 'commands': commands, 'helper_class_sha256': files(work / 'classes'),
            'logs_sha256': {p.name: sha(p) for p in sorted(work.glob('*.std*'))}, 'transfer_credit': False}
        need(files(classes) == retention['file_sha256'], 'Original core cohort changed')
        (work / 'result.json').write_text(json.dumps(result, indent=2) + '\n'); print(result['status']); return
    java('single-generate', generation, 'InteropOracle', 'generate', generation / 'single')
    java('multi-generate', generation, 'MultiFileOracle', generation / 'multi')
    java('single-tail-generate', generation, 'V2MetadataOracle', 'tail', generation / 'tail')
    java('selected-hybrid', generation, 'V2MetadataOracle', 'select', generation / 'single/profile/generated-2.torrent', generation / 'selected-v2.torrent')
    java('order-generate', generation, 'V2MetadataOracle', 'order', generation / 'order')
    # Reproduce the original-only limitation before any native participation.
    legacy = work / 'legacy-original-full'; legacy.mkdir(mode=0o700)
    shutil.copyfile(generation / 'multi/multi-3.torrent', legacy / 'input.torrent')
    port = unused_port()
    java('legacy-original-full', legacy, 'MultiEngineOracle', port, 0, legacy / 'input.torrent',
         generation / 'multi/expected/multi-fixture', 'check-full', ports=(port,))
    port = unused_port()
    original_full = checked(rows(java('legacy-original-bitmap', legacy, 'V2ManagedOracle', port,
        generation / 'multi/expected/multi-fixture', 'bytes', -1, ports=(port,))))
    need(original_full['ready']['done'] == 8 and original_full['ready']['total'] == 9
         and original_full['ready']['bits'] == '111111110', 'Original-only8/9 characterization changed; investigate without dropping empty file')
    cases = []
    for kind in (2, 3):
        cases += [('single-' + str(kind), generation / ('single/profile/generated-' + str(kind) + '.torrent'), generation / 'single/generated.bin', False),
                  ('multi-' + str(kind), generation / ('multi/multi-' + str(kind) + '.torrent'), generation / 'multi/expected/multi-fixture', False)]
    cases += [('selected-hybrid-v2', generation / 'selected-v2.torrent', generation / 'single/generated.bin', False),
              ('multi-v2-reordered', generation / 'multi/multi-3.torrent', generation / 'multi/expected/multi-fixture', True),
              ('single-v2-tail', generation / 'tail/single-v2-tail.torrent', generation / 'tail/payload-tail.bin', False)]
    result = {'status': 'RUNNING', 'original_commit': ORIGINAL, 'manifest_sha256': sha(HERE.parent / 'manifest.json'),
        'driver_sha256': sha(driver), 'original_only_full': original_full, 'cases': {}, 'layout_only': {}}
    (work / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    for name, metadata, expected, reordered in cases:
        case = work / name; case.mkdir(mode=0o700); shutil.copyfile(metadata, case / 'input.torrent')
        port = unused_port()
        if name == 'single-v2-tail':
            baseline = checked(rows(java(name + '-prepare-tail', case, 'V2ManagedOracle', port, expected, 'prepare-tail', -1, ports=(port,))))
        elif reordered:
            baseline = checked(rows(java(name + '-prepare-reordered', case, 'V2ManagedOracle', port, expected, 'prepare-reordered', -1, ports=(port,))))
        else:
            if expected.is_dir():
                java(name + '-prepare', case, 'MultiEngineOracle', port, 0, case / 'input.torrent', expected, 'prepare', ports=(port,))
            else:
                java(name + '-prepare', case, 'EngineOracle', port, 0, case / 'input.torrent', expected, 'prepare-partial', ports=(port,))
            port = unused_port(); baseline = checked(rows(java(name + '-baseline', case, 'V2ManagedOracle', port, expected, 'inspect', -1, ports=(port,))))
        total, piece = baseline['ready']['total'], baseline['metadata']['piece']
        need(0 < baseline['ready']['done'] < total and piece == 16384, 'Authentic original fixture is not partial')
        candidates = [i for i in range(total - 1) if baseline['ready']['bits'][i] == '0' and any(not f['pad']
            and f['offset'] < (i + 1) * piece and f['offset'] + f['bytes'] > i * piece for f in baseline['indices'].values())]
        need(candidates, 'No actual missing non-tail real piece available'); omitted = candidates[-1]
        if name == 'selected-hybrid-v2':
            need(baseline['metadata']['type'] == 2 and baseline['metadata']['effective'] == 3
                 and baseline['metadata']['selected'] == baseline['metadata']['v2'][:40], 'Actual hybrid selector did not survive original profile creation')
        profile = case / 'profile'; active = profile / 'active' / (baseline['metadata']['selected'] + '.dat')
        _, original_spans = state(active)
        observations, gaps = [], []
        for mode in ('partial', 'complete'):
            config = (profile / 'biglybt.config').read_bytes()
            before, _ = state(profile / 'downloads.config'); old_row = before[b'downloads'][0]
            output = case / ('native-' + mode)
            run(name + '-native-' + mode, [driver, work, profile, case / 'input.torrent', expected, output, mode, omitted], case, 180)
            native = json.loads((output / 'result.json').read_text())
            need(native['hash'] == baseline['metadata']['selected'] and native['total_pieces'] == total
                 and native['pieces'] == total - (mode == 'partial') and native['session_joined'] and native['storage_released']
                 and int(native['received']) > 0, 'Actual native verification/retirement/identity proof incomplete')
            need(native['full_v1'] == baseline['metadata']['v1'] and native['full_v2'] == baseline['metadata']['v2'], 'Full native/original identities differ')
            engine_projection(native, baseline)
            if name == 'single-v2-tail':
                need(native['engine_trailing_pad'] is True, 'Common nonaligned pure-v2 tail did not exercise the actual projection')
            for i, original in baseline['indices'].items():
                a, b = native['original_files'][i], native['engine_files'][i]
                need(a['index'] == b['index'] == i and int(a['offset']) == int(b['offset']) == original['offset']
                     and int(a['bytes']) == int(b['bytes']) == original['bytes'] and a['pad'] == b['pad'] == original['pad']
                     and a['path'] == original['path'], 'Actual Java/original-projection/LT index geometry differs')
                parts = Path(original['path']).parts
                if not original['pad']:
                    need(Path(b['path']).parts[-len(parts):] == parts, 'Actual LT real file names differ from original source indices')
            need(mode == 'partial' or int(native['retained_seed_received']) > 0, 'No actual retained native seeding proof')
            inventory, _ = state(profile / 'downloads.config'); row = inventory[b'downloads'][0]
            need(row[b'downloaded'] == old_row.get(b'downloaded', 0) + int(native['received'])
                 and row[b'uploaded'] == old_row.get(b'uploaded', 0) + int(native['sent']), 'Native admission delta charged incorrectly')
            native_state, spans = state(active)
            for key in (b'info', b'piece layers', b'unknown.future.plugin'):
                if (key,) in original_spans: need(spans.get((key,)) == original_spans[(key,)], 'Hashed layers or unknown raw metadata changed')
            counts = native_state[b'attributes'][b'filedownloaded'][b'downloaded']
            need(len(counts) == len(baseline['indices']), 'Native lost original file slots')
            need(all(type(n) is int and 0 <= n <= baseline['indices'][i]['bytes'] for i, n in enumerate(counts)),
                 'Native original-index progress is out of bounds')
            logical_completed = sum(counts)
            payload_completed = sum(counts[i] for i, f in baseline['indices'].items() if not f['pad'])
            padding_completed = sum(counts[i] for i, f in baseline['indices'].items() if f['pad'])
            need(row[b'completedbytes'] == logical_completed == payload_completed + padding_completed,
                 'Original completedbytes must retain the checked logical span including virtual padding')
            need(int(native['bytes']) == baseline['metadata']['logicalBytes']
                 and int(native['completed']) == logical_completed,
                 'Actual managed status differs from original logical size/verified intersections')
            need((profile / 'biglybt.config').read_bytes() == config, 'Native changed original global config')
            port = unused_port(); observed = checked(rows(java(name + '-java-' + mode, case, 'V2ManagedOracle', port, expected,
                'bytes' if mode == 'complete' else 'inspect', -1, ports=(port,))))
            need(observed['metadata'] == baseline['metadata'] and observed['indices'] == baseline['indices']
                 and observed['intent'] == baseline['intent'] and observed['counters'] == (row[b'downloaded'], row[b'uploaded']),
                 'Original restored different identity, original indices, intent or actual counters')
            expected_bits = ['1'] * total
            if mode == 'partial': expected_bits[omitted] = '0'
            expected_bits = ''.join(expected_bits)
            if observed['ready']['bits'] != expected_bits:
                allowed = ''.join('1' if a == b == '1' else '0' for a, b in zip(expected_bits, original_full['ready']['bits']))
                need(name in ('multi-3', 'multi-v2-reordered') and total == 9 and observed['ready']['bits'] == allowed,
                     'Unexpected original/native checked-piece divergence')
                gaps.append({'mode': mode, 'native_bits': expected_bits, 'original_bits': observed['ready']['bits'],
                    'reason': 'Independently reproduced original-only real-tail+pad+empty recheck limitation'})
            for index, f in observed['files'].items():
                removed = sum(max(0, min(f['offset'] + f['bytes'], (i + 1) * piece) - max(f['offset'], i * piece))
                    for i, (a, b) in enumerate(zip(expected_bits, observed['ready']['bits'])) if a == '1' and b == '0')
                need(f['downloaded'] == counts[index] - removed,
                     'Original per-file progress differs beyond actually characterized checked-piece gap')
                if not f['pad']:
                    need(f['priority'] == baseline['files'][index]['priority'] and f['skipped'] == baseline['files'][index]['skipped'],
                         'Original selected real file policy changed')
            logical_gap = sum(min(piece, baseline['metadata']['logicalBytes'] - i * piece)
                for i, (a, b) in enumerate(zip(expected_bits, observed['ready']['bits'])) if a == '1' and b == '0')
            payload_gap = sum(max(0, min(f['offset'] + f['bytes'], (i + 1) * piece) - max(f['offset'], i * piece))
                for i, (a, b) in enumerate(zip(expected_bits, observed['ready']['bits'])) if a == '1' and b == '0'
                for f in baseline['indices'].values() if not f['pad'])
            need(observed['progress']['completedLogical'] == logical_completed - logical_gap
                 and observed['progress']['completedPayload'] == payload_completed - payload_gap
                 and observed['progress']['completedPadding'] == padding_completed - (logical_gap - payload_gap),
                 'Actual Java logical/payload/padding counters differ beyond the characterized checked-piece gap')
            observations.append({'mode': mode, 'native': native, 'original': observed,
                'native_progress': {'completedLogical': logical_completed, 'completedPayload': payload_completed,
                                    'completedPadding': padding_completed}})
        result['cases'][name] = {'status': 'PASS_WITH_CHARACTERIZED_ORIGINAL_RECHECK_GAP' if gaps else 'PASS_ACTUAL_MANAGED_HANDOFF',
            'baseline': baseline, 'omitted_real_piece': omitted, 'observations': observations, 'original_recheck_gaps': gaps}
    # Read-only probes retain exact raw identity and every real/pad/empty index.
    result['layout_only'] = ordering_probes()
    need(files(classes) == retention['file_sha256'], 'Original core cohort changed')
    result.update(status='PASS_ACTUAL_V2_HANDOFF_WITH_EXPLICIT_SOURCE_LIMITATIONS', commands=commands,
        helper_class_sha256=files(work / 'classes'), logs_sha256={p.name: sha(p) for p in sorted(work.glob('*.std*'))},
        original_core_recompiled=False, original_profile_or_process_access=False,
        selected_hybrid_swarm_restriction_credit=False,
        limitations=['Legacy original8/9 tail recheck is retained and independently reproduced; not complete Java progress parity for affected cases',
                     'Selected hybrid validates actual saved identity and owned loopback data, not public selected-swarm exclusivity',
                     'UTF16/UTF8 order pair is layout-only; no mutation or transfer credit; exact raw info/hash/index checks required', 'No real profile, public network, power-loss or whole-client claim'])
    (work / 'result.json').write_text(json.dumps(result, indent=2) + '\n'); print(result['status'])


if __name__ == '__main__':
    main()
