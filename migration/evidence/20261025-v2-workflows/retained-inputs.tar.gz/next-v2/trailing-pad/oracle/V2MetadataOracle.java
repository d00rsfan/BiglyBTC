import com.biglybt.core.torrent.TOTorrent;
import com.biglybt.core.torrent.TOTorrentFactory;
import com.biglybt.core.torrent.TOTorrentFile;
import com.biglybt.core.util.ByteFormatter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Actual original format selection and file-index observations. No native hash mirror. */
public final class V2MetadataOracle {
    static String hex(byte[] value) { return value == null ? "-" : ByteFormatter.encodeString(value); }
    static void facts(TOTorrent torrent) throws Exception {
        System.out.println("V2_META\t" + torrent.getTorrentType() + "\t" + torrent.getEffectiveTorrentType()
            + "\t" + hex(torrent.getHash()) + "\t" + hex(torrent.getFullHash(TOTorrent.TT_V1))
            + "\t" + hex(torrent.getFullHash(TOTorrent.TT_V2)) + "\t" + torrent.getPieceLength()
            + "\t" + torrent.getNumberOfPieces() + "\t" + torrent.getSize());
        int index = 0;
        for (TOTorrentFile file : torrent.getFiles()) {
            System.out.println("V2_INDEX\t" + index++ + "\t" + file.getOffsetInTorrent() + "\t" + file.getLength()
                + "\t" + file.isPadFile() + "\t" + hex(file.getRelativePath().getBytes("UTF-8")));
        }
    }
    private static void run(String[] args) throws Exception {
        if (!(System.getSecurityManager() instanceof ReferenceFence) || args.length < 2) {
            throw new IllegalArgumentException("ReferenceFence: facts INPUT | select INPUT OUTPUT | order OUTPUT");
        }
        Class.forName("com.biglybt.core.util.Debug");
        Path root = Paths.get(System.getProperty("biglybtc.test.root")).toRealPath();
        Path input = Paths.get(args[1]).toAbsolutePath().normalize();
        if (!input.startsWith(root) || Files.isSymbolicLink(input)) { throw new IllegalArgumentException("Generated owned fixture required"); }
        if (args[0].equals("tail") && args.length == 2) {
            if (Files.exists(input)) { throw new IllegalArgumentException("Fresh tail fixture required"); }
            Files.createDirectories(input); Path payload = input.resolve("payload-tail.bin");
            byte[] bytes = new byte[77003];
            for (int i = 0; i < bytes.length; ++i) { bytes[i] = (byte)((i * 31 + i / 257) & 255); }
            Files.write(payload, bytes);
            TOTorrent torrent = TOTorrentFactory.createFromFileOrDirWithFixedPieceLength(TOTorrent.TT_V2, payload.toFile(),
                new URL("http://127.0.0.1:1/announce"), false, 16384).create();
            torrent.setCreationDate(0); torrent.serialiseToBEncodedFile(input.resolve("single-v2-tail.torrent").toFile());
            facts(torrent);
        } else if (args[0].equals("order") && args.length == 2) {
            // Java UTF16 orders U+10000 before U+E000; UTF8 byte order reverses
            // them. Keep the nonaligned tail and actual empty file observable.
            if (Files.exists(input)) { throw new IllegalArgumentException("Fresh order fixture required"); }
            Path expected = input.resolve("expected/order-fixture"); Files.createDirectories(expected);
            String[] names = {"\uD800\uDC00-first.bin", "\uE000-tail.bin", "\uFFFF-empty.bin"};
            int[] lengths = {20000, 111079, 0};
            int offset = 0;
            for (int i = 0; i < names.length; ++i) {
                byte[] bytes = new byte[lengths[i]];
                for (int j = 0; j < bytes.length; ++j) { int p = offset + j; bytes[j] = (byte)((p * 31 + p / 257) & 255); }
                Files.write(expected.resolve(names[i]), bytes); offset += bytes.length;
            }
            for (int type : new int[]{TOTorrent.TT_V1_V2, TOTorrent.TT_V2}) {
                TOTorrent torrent = TOTorrentFactory.createFromFileOrDirWithFixedPieceLength(type, expected.toFile(),
                    new URL("http://127.0.0.1:1/announce"), false, 16384).create();
                torrent.setCreationDate(0); torrent.serialiseToBEncodedFile(input.resolve("order-" + type + ".torrent").toFile());
                facts(torrent);
            }
        } else {
            TOTorrent torrent = TOTorrentFactory.deserialiseFromBEncodedFile(input.toFile());
            if (args[0].equals("select") && args.length == 3) {
                Path output = Paths.get(args[2]).toAbsolutePath().normalize();
                if (!output.startsWith(root) || Files.exists(output) || Files.isSymbolicLink(output)) {
                    throw new IllegalArgumentException("Fresh owned selected metadata required");
                }
                torrent = torrent.selectHybridHashType(TOTorrent.TT_V2);
                torrent.serialiseToBEncodedFile(output.toFile());
                // Observe the actual serialized/reloaded selected identity too.
                torrent = TOTorrentFactory.deserialiseFromBEncodedFile(output.toFile());
            } else if (!args[0].equals("facts") || args.length != 2) { throw new IllegalArgumentException("Invalid role"); }
            facts(torrent);
        }
    }
    public static void main(String[] args) {
        try { run(args); System.exit(0); }
        catch (Throwable failure) { failure.printStackTrace(); System.exit(2); }
    }
}
