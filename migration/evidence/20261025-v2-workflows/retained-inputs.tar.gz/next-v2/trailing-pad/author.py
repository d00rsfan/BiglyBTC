from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent
base=W/'callers/staging/preview/native';counter=W/'provider-counter/app/staging/engine'
for rel,source in {
'preview/native/engine/managed_storage.cpp':base/'engine/managed_storage.cpp',
'preview/native/engine/managed_storage.hpp':base/'engine/managed_storage.hpp',
'preview/native/engine/persistent_session.cpp':counter/'persistent_session.cpp',
'preview/native/tests/original_identity_callers_tests.cpp':W/'ordering-accounting/amendments/canonical-test-order/staging/preview/native/tests/original_identity_callers_tests.cpp'
}.items():
    before=P/'before'/rel;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(source.read_bytes())
    out=P/'staging'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(source.read_bytes())
p=P/'staging/preview/native/engine/managed_storage.cpp';s=p.read_text().replace('#include "managed_storage.hpp"','#include "managed_storage.hpp"\n#include "original_layout_projection.hpp"')
start=s.index('  require(layout.files.size()==static_cast<std::size_t>(info->num_files())&&layout.bytes==info->total_size()')
end=s.index('  return {std::move(info),std::move(identity)};',start)
s=s[:start]+'  (void)take(projectOriginalLayout(layout,*info)); // Only one authenticated synthetic pure-v2 tail is optional.\n'+s[end:]
s=s.replace('  bool attempted=false;','  bool attempted=false;\n  bool progressFromPieces=false;')
anchor='profileDevice(device),profileInode(inode) {}';assert s.count(anchor)==1
s=s.replace(anchor,'''profileDevice(device),profileInode(inode) {
      progressFromPieces=layout.files.size()!=static_cast<std::size_t>(params.ti->num_files())
          ||std::ranges::any_of(layout.files,[](const auto& file){return file.padding;});
    }''')
anchor='std::shared_ptr<OriginalDiskFiles> ManagedStorage::mappedFiles() const'
pos=s.index(anchor)
s=s[:pos]+'''std::int64_t ManagedStorage::originalBytes() const noexcept { return impl_?impl_->layout.bytes:0; }
bool ManagedStorage::originalProgressRequiresPieces() const noexcept { return impl_&&impl_->progressFromPieces; }
std::expected<std::int64_t,Error> ManagedStorage::verifiedOriginalBytes(std::span<const std::uint8_t> pieces) const {
  if(!impl_) return std::unexpected(Error{ErrorCode::Conflict,"Managed storage was moved or released"});
  return detail::verifiedOriginalBytes(impl_->layout.bytes,impl_->layout.pieceLength,pieces);
}
'''+s[pos:]
s=s.replace('const bool mapped=std::ranges::any_of(slots,','const bool mapped=static_cast<std::size_t>(info->num_files())!=slots.size()||std::ranges::any_of(slots,')
anchor='params.file_priorities=priorities(*parsedPolicy,layout);';assert s.count(anchor)==1
s=s.replace(anchor,anchor+'\n    params.file_priorities.resize(static_cast<std::size_t>(info->num_files()),lt::download_priority_t{0});')
s=s.replace('std::vector<std::optional<OriginalDiskFile>> mappedFiles(slots.size());','std::vector<std::optional<OriginalDiskFile>> mappedFiles(static_cast<std::size_t>(info->num_files()));')
s=s.replace('std::vector<std::uint8_t> completeFiles(owner.slots.size());','std::vector<std::uint8_t> completeFiles(static_cast<std::size_t>(owner.params.ti->num_files()));')
p.write_text(s)
p=P/'staging/preview/native/engine/managed_storage.hpp';s=p.read_text();anchor='  std::shared_ptr<OriginalDiskFiles> mappedFiles() const;';assert anchor in s
s=s.replace(anchor,anchor+'''
  std::int64_t originalBytes() const noexcept;
  bool originalProgressRequiresPieces() const noexcept;
  std::expected<std::int64_t,storage::Error> verifiedOriginalBytes(std::span<const std::uint8_t>) const;''');p.write_text(s)
p=P/'staging/preview/native/engine/persistent_session.cpp';s=p.read_text();anchor='    lt::torrent_status sample;\n    detail::ManagedPayloadCounters::Sample actual;';assert anchor in s
s=s.replace(anchor,'''    const bool originalProgress=value.storage.originalProgressRequiresPieces();
    const bool needPieces=pieces||originalProgress;
'''+anchor)
s=s.replace('sample = value.handle.status(pieces ? lt::torrent_handle::query_pieces : lt::status_flags_t{});','sample = value.handle.status(needPieces ? lt::torrent_handle::query_pieces : lt::status_flags_t{});')
s=s.replace('    value.status.bytes = sample.total;','    value.status.bytes = value.storage.originalBytes();')
anchor='    if (pieces) {\n      value.verified.assign';assert s.count(anchor)==1;s=s.replace(anchor,'    if (needPieces) {\n      value.verified.assign')
anchor='    if (value.status.failure) { value.status.phase = ManagedPhase::Failed; }';assert s.count(anchor)==1
s=s.replace(anchor,'''    if(originalProgress) {
      const auto projected=value.storage.verifiedOriginalBytes(value.verified);
      if(sample.pieces.size()!=value.status.totalPieces||!projected) {
        value.status.failure=storage::Error{storage::ErrorCode::Io,"Actual original verified progress is unavailable; state requires recheck"};
        requestStop(value);value.status.phase=ManagedPhase::Failed;return;
      }
      value.status.completed=*projected;
    }
'''+anchor)
p.write_text(s)
p=P/'staging/preview/native/tests/original_identity_callers_tests.cpp';s=p.read_text().replace('#include "../engine/managed_storage.hpp"','#include "../engine/managed_storage.hpp"\n#include "../engine/original_layout_projection.hpp"\n#include "../engine/original_disk_io.hpp"')
extra=r'''
void syntheticTailUsesOnlyEnginePadSlot() {
  Area a;const auto bytes=metainfo(false);const auto source=doc(bytes);const auto key=a.importMetadata(bytes);
  const auto raw=take(storage::originalTorrentInfoSubject(source));
  auto owner=take(Owner::prepare(*a.lease,key,{}));const auto params=owner.parameters();
  check(params.ti->num_files()==2&&params.file_priorities.size()==2
      &&params.file_priorities[1]==lt::download_priority_t{0},"actual engine-only pad has explicit zero priority");
  check(owner.originalBytes()==1&&owner.originalProgressRequiresPieces(),"original logical size remains independent of engine tail");
  check(take(owner.verifiedOriginalBytes(std::array<std::uint8_t,1>{0}))==0
      &&take(owner.verifiedOriginalBytes(std::array<std::uint8_t,1>{1}))==1,"checked tail projection never counts synthetic bytes");
  check(owner.mappedFiles()!=nullptr,"extra virtual pad forces authenticated descriptor IO");
  write(a.destination/"identity.bin","x");std::string observed(16384,'?');
  done(owner.mappedFiles()->read(0,std::span<char>(observed)));
  check(observed[0]=='x'&&std::all_of(observed.begin()+1,observed.end(),[](char c){return c==0;}),"actual descriptor data plus engine pad reads zero without a file");
  done(owner.mappedFiles()->write(1,std::span<const char>(observed).subspan(1)));
  check(read(a.destination/"identity.bin")=="x"&&!fs::exists(a.destination/".pad"),"pad writes never touch payload or create padding paths");
  done(owner.checkpoint(*a.lease,std::array<std::uint8_t,1>{1},true,1,0));
  auto saved=doc(read(a.state(key)));const auto* attrs=saved.find("attributes");
  check(attrs->find("storetypes")->children.size()==1&&attrs->find("filedownloaded")->find("downloaded")->children.size()==1
      &&attrs->find("filedownloaded")->find("downloaded")->children[0].integer==1,"original controls/types/progress retain exactly one real slot");
  check(saved.find("resume")->find("data")->find("resume data")->bytes==std::string(1,'\1')
      &&saved.find("resume")->find("data")->find("valid")->integer==1,"actual complete original piece count stays authoritative");
  auto inventory=doc(read(a.profile/"downloads.config"));
  check(inventory.find("downloads")->children[0].find("completedbytes")->integer==1,"synthetic LT padding is never original completedbytes");
  check(take(storage::originalTorrentInfoSubject(saved))==raw&&!fs::exists(a.destination/".pad"),"raw hash subject and physical namespace unchanged");
}
void projectionRejectsNonTailDifferences() {
  const auto bytes=metainfo(false);const lt::torrent_info info(lt::span<const char>(bytes.data(),bytes.size()),lt::from_span);
  auto layout=compat::originalLayout(doc(bytes));check(layout.has_value(),"actual original single-v2 layout");
  const auto actual=take(engine::detail::projectOriginalLayout(*layout,info));
  check(actual.trailingPad==std::optional<std::size_t>{1}&&actual.originalFiles==1&&actual.engineFiles==2
      &&actual.originalBytes==1&&actual.engineBytes==16384,"one exact source-derived tail range admitted");
  auto changed=*layout;changed.files[0].path="different.bin";check(!engine::detail::projectOriginalLayout(changed,info),"changed source path remains refused");
  changed=*layout;changed.files[0].offset=1;check(!engine::detail::projectOriginalLayout(changed,info),"changed original offset remains refused");
  changed=*layout;changed.files[0].padding=true;check(!engine::detail::projectOriginalLayout(changed,info),"real/pad relabel remains refused");
  changed=*layout;changed.bytes=2;check(!engine::detail::projectOriginalLayout(changed,info),"changed original total remains refused");
  check(!engine::detail::verifiedOriginalBytes(1,16384,std::array<std::uint8_t,2>{1,0})
      &&!engine::detail::verifiedOriginalBytes(1,16384,std::array<std::uint8_t,1>{2}),"verified bitmap arity/value cannot be fabricated");
  const auto ordered=orderingMetadata(true);const lt::torrent_info multi(lt::span<const char>(ordered.data(),ordered.size()),lt::from_span);
  auto withEmpty=compat::originalLayout(doc(ordered));check(withEmpty&&withEmpty->files.back().bytes==0,"real trailing empty fixture");
  withEmpty->files.pop_back();check(!engine::detail::projectOriginalLayout(*withEmpty,multi),"a real empty entry cannot be dropped as an engine-only pad");
}
'''
assert '\n}\nint main()' in s;s=s.replace('\n}\nint main()',extra+'\n}\nint main()')
s=s.replace('int main(){try{originalJavaOrderAndPaddedProgress();','int main(){try{syntheticTailUsesOnlyEnginePadSlot();++families;projectionRejectsNonTailDifferences();++families;originalJavaOrderAndPaddedProgress();')
p.write_text(s)
