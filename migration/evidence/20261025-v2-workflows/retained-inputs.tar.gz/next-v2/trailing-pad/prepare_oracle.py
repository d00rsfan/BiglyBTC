from pathlib import Path
P=Path(__file__).resolve().parent;W=P.parent;O=W/'ordering-accounting/oracle'
for name in ['run.py','V2ManagedOracle.java','tests/v2_managed_handoff_driver.cpp']:
    out=P/'oracle'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((O/name).read_bytes())
    old=P/'before/oracle'/name;old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes((O/name).read_bytes())
name='V2MetadataOracle.java';(P/'oracle'/name).write_bytes((W/'oracle'/name).read_bytes());old=P/'before/oracle'/name;old.write_bytes((W/'oracle'/name).read_bytes())
p=P/'oracle/tests/v2_managed_handoff_driver.cpp';s=p.read_text().replace('#include "original_torrent_identity_lt.hpp"','#include "original_torrent_identity_lt.hpp"\n#include "original_layout_projection.hpp"')
anchor='    const int totalPieces=metadata->num_pieces();';s=s.replace(anchor,'''    const auto projection=engine::detail::projectOriginalLayout(*layout,*metadata);
    require(projection.has_value(),"Original/engine geometry differs beyond a proven synthetic final pad");
'''+anchor)
s=s.replace('    require(layout->files.size()==static_cast<std::size_t>(metadata->num_files()),"Original/LT file count differs before fixture writes");\n','')
anchor='    if(mode=="layout"){';assert anchor in s
s=s.replace(anchor,'''    if(projection->trailingPad){const auto i=lt::file_index_t{static_cast<int>(*projection->trailingPad)};
      engineFacts.append(QJsonObject{{"index",static_cast<int>(*projection->trailingPad)},{"offset",QString::number(metadata->files().file_offset(i))},
        {"bytes",QString::number(metadata->files().file_size(i))},{"pad",metadata->files().pad_file_at(i)},{"path",QString::fromStdString(metadata->files().file_path(i))}});}
'''+anchor)
s=s.replace('{"selected_hash",QString::fromStdString(exactIdentity->originalKey.hex())},','''{"selected_hash",QString::fromStdString(exactIdentity->originalKey.hex())},
        {"engine_trailing_pad",projection->trailingPad.has_value()},{"original_total_bytes",QString::number(layout->bytes)},
        {"engine_total_bytes",QString::number(metadata->total_size())},''')
# Final receipt builds fresh complete arrays, including the optional engine tail.
anchor='    QJsonObject receipt{{QStringLiteral("schema"), 1},';assert anchor in s
s=s.replace(anchor,'''    if(projection->trailingPad){const auto i=lt::file_index_t{static_cast<int>(*projection->trailingPad)};
      engineFiles.append(QJsonObject{{"index",static_cast<int>(*projection->trailingPad)},{"offset",QString::number(metadata->files().file_offset(i))},
        {"bytes",QString::number(metadata->files().file_size(i))},{"pad",metadata->files().pad_file_at(i)},{"path",QString::fromStdString(metadata->files().file_path(i))}});}
'''+anchor+'''
        {"engine_trailing_pad",projection->trailingPad.has_value()},{"original_total_bytes",QString::number(layout->bytes)},
        {"engine_total_bytes",QString::number(metadata->total_size())},{"bytes",QString::number(stopped.bytes)},''')
p.write_text(s)
p=P/'oracle/V2MetadataOracle.java';s=p.read_text();anchor='        if (args[0].equals("order") && args.length == 2) {';assert anchor in s
s=s.replace(anchor,'''        if (args[0].equals("tail") && args.length == 2) {
            if (Files.exists(input)) { throw new IllegalArgumentException("Fresh tail fixture required"); }
            Files.createDirectories(input); Path payload = input.resolve("payload-tail.bin");
            byte[] bytes = new byte[77003];
            for (int i = 0; i < bytes.length; ++i) { bytes[i] = (byte)((i * 31 + i / 257) & 255); }
            Files.write(payload, bytes);
            TOTorrent torrent = TOTorrentFactory.createFromFileOrDirWithFixedPieceLength(TOTorrent.TT_V2, payload.toFile(),
                new URL("http://127.0.0.1:1/announce"), false, 16384).create();
            torrent.setCreationDate(0); torrent.serialiseToBEncodedFile(input.resolve("single-v2-tail.torrent").toFile());
            facts(torrent);
        } else if (args[0].equals("order") && args.length == 2) {''')
p.write_text(s)
p=P/'oracle/V2ManagedOracle.java';s=p.read_text();s=s.replace('boolean prepare = args[2].equals("prepare-reordered"), bytesRequired = args[2].equals("bytes");', 'boolean prepare = args[2].equals("prepare-reordered"), prepareTail = args[2].equals("prepare-tail"), bytesRequired = args[2].equals("bytes");')
s=s.replace('if ((!prepare && !bytesRequired && !args[2].equals("inspect"))', 'if ((!prepare && !prepareTail && !bytesRequired && !args[2].equals("inspect"))')
s=s.replace('            if (prepare) {\n                Files.createDirectories(root.resolve("payload"));','            if (prepare || prepareTail) {\n                Files.createDirectories(root.resolve("payload"));')
s=s.replace('                prepareReordered(manager, expected);','''                if (prepare) { prepareReordered(manager, expected); }
                else {
                    DiskManagerFileInfo[] files = manager.getDiskManagerFileInfoSet().getFiles();
                    byte[] bytes = Files.readAllBytes(expected);
                    if (files.length != 1 || files[0].getTorrentFile().isPadFile() || bytes.length != 77003) {
                        throw new IllegalStateException("Bounded authentic single-tail fixture required");
                    }
                    files[0].setPriority(0); files[0].setSkipped(false);
                    Path actual = files[0].getFile(true).toPath().toAbsolutePath().normalize();
                    if (!actual.startsWith(root.resolve("payload")) || Files.isSymbolicLink(actual)) {
                        throw new IllegalStateException("Tail payload escaped owned fixture");
                    }
                    Files.createDirectories(actual.getParent()); Files.write(actual, Arrays.copyOf(bytes, 16384));
                }''')
s=s.replace('(prepare && (done == 0 || done == pieces.length))','((prepare || prepareTail) && (done == 0 || done == pieces.length))')
p.write_text(s)
p=P/'oracle/run.py';s=p.read_text().replace("[baseline / 'V2MetadataOracle.java', HERE / 'V2ManagedOracle.java']", "[HERE / 'V2MetadataOracle.java', HERE / 'V2ManagedOracle.java']")
anchor="    generation = work / 'generation'; generation.mkdir(mode=0o700)";assert anchor in s
s=s.replace(anchor,'''    def engine_projection(native, original):
        count = len(original['indices']); engine = native['engine_files']
        need(len(native['original_files']) == count, 'Projection changed original file-slot count')
        logical = original['metadata']['logicalBytes']; piece = original['metadata']['piece']
        need(type(native['engine_trailing_pad']) is bool and int(native['original_total_bytes']) == logical,
             'Missing actual original/pad projection proof')
        if native['engine_trailing_pad']:
            need(original['metadata']['v1'] == '-' and original['metadata']['v2'] != '-'
                 and logical % piece != 0 and len(engine) == count + 1, 'Only a pure-v2 final pad is admissible')
            extra = engine[-1]; padding = piece - logical % piece
            need(extra['index'] == count and extra['pad'] is True and int(extra['offset']) == logical
                 and int(extra['bytes']) == padding and int(native['engine_total_bytes']) == logical + padding,
                 'Actual synthetic final pad has a different range')
        else:
            need(len(engine) == count and int(native['engine_total_bytes']) == logical, 'Unproven engine file/range difference')
        return count

'''+anchor)
s=s.replace("need(len(native['original_files']) == len(native['engine_files']) == len(original['indices']), 'Ordering probe lost real/pad/empty slots')", "engine_projection(native, original)")
s=s.replace("    java('multi-generate', generation, 'MultiFileOracle', generation / 'multi')", "    java('multi-generate', generation, 'MultiFileOracle', generation / 'multi')\n    java('single-tail-generate', generation, 'V2MetadataOracle', 'tail', generation / 'tail')")
anchor="              ('multi-v2-reordered', generation / 'multi/multi-3.torrent', generation / 'multi/expected/multi-fixture', True)]";assert anchor in s
s=s.replace(anchor,"              ('multi-v2-reordered', generation / 'multi/multi-3.torrent', generation / 'multi/expected/multi-fixture', True),\n              ('single-v2-tail', generation / 'tail/single-v2-tail.torrent', generation / 'tail/payload-tail.bin', False)]")
s=s.replace("        if reordered:\n            baseline", "        if name == 'single-v2-tail':\n            baseline = checked(rows(java(name + '-prepare-tail', case, 'V2ManagedOracle', port, expected, 'prepare-tail', -1, ports=(port,))))\n        elif reordered:\n            baseline")
s=s.replace("            need(len(native['original_files']) == len(native['engine_files']) == len(baseline['indices']), 'Native lost original or actual LT indices')", "            engine_projection(native, baseline)\n            if name == 'single-v2-tail':\n                need(native['engine_trailing_pad'] is True, 'Common nonaligned pure-v2 tail did not exercise the actual projection')")
anchor="            need(row[b'completedbytes'] == logical_completed == payload_completed + padding_completed,\n                 'Original completedbytes must retain the checked logical span including virtual padding')";assert anchor in s
s=s.replace(anchor,anchor+'''
            need(int(native['bytes']) == baseline['metadata']['logicalBytes']
                 and int(native['completed']) == logical_completed,
                 'Actual managed status differs from original logical size/verified intersections')''')
p.write_text(s)
