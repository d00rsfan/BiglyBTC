Selected hybrid swarm — staged provider extension

Status: source-only candidate. No dependency/native file was modified. No compiler, session, wire test or payload test was run by the author. This candidate is not a new approved runtime and must not be attributed to the existing c35f provider.

API
- New libtorrent/biglybtc_swarm.hpp defines admission flags biglybtc_v1_only (bit25) and biglybtc_v2_only (bit26). Neither flag preserves upstream behavior. Both flags, or a selection unavailable in the supplied hashes, fail with invalid_info_hash before discovery/construction/IO. Bits are free in this exact pinned 2.0.12 source; they are not portable upstream API.
- The same DSO exports C symbol biglybtc_swarm_mask_abi_v1(), value1. Callers must check the actual source/artifact runtime binding and resolve this marker from that SAME verified loaded object before using the extension. A marker alone is not proof: stock libraries silently ignore unknown flags. No shipping default or runtime catalog is changed here.
- Selection is immutable for an admission. set_flags/unset_flags cannot change it; status flags expose it. A switch requires retirement and fresh admission. Adding a conflicting selected/default request cannot return an already active differently scoped handle.
- Full torrent_info, raw info, piece layers, file geometry, public handle/status hashes and removal-alert metadata hashes remain full. Internal session/peer wire identity is separate. Existing counters, alert consumer, disk ownership and weak-retirement logic are unchanged.
- Native application code must still prevent simultaneous admissions that would share payload storage. Distinct wire identities are intentionally not aliased into one handle. Original selected-state interpretation and payload ownership are outside this provider patch.

Boundaries changed
1. Session insertion/removal and encrypted indices receive only selected hashes. Metadata arrival retains the selected mask for collision checks/reindexing.
2. Tracker announce/scrape states and hashes, DHT announce and LSD use selected hashes. Response classification also uses wire identity, including the degenerate equal20-prefix case.
3. Existing BT handshake/MSE/v2-upgrade paths use the internal selected accessor. Explicit wrong-protocol hints cannot override V1-only; V2-only ordinary peers acquire the v2 hint. Actual selected hash is also used for SSL peer SNI and HTTP seed associated identity.
4. Seed-mode disk hash requests/results and Merkle initialization use full metadata hashes independently of the wire mask.
5. LT resume documents append biglybtc.swarm only for selected admissions. Duplicate keys, unknown mode/type, combined flags and unavailable selections reject rather than silently restoring dual-swarm mode. Absent key retains upstream defaults.

Applying and qualification
Apply provider.patch only to a fresh owned tree matching all444 source-inputs.json pins (upstream740a0b9aeabe00e762cc0efe4a0f27593db2550b). Never patch the retained/default tree in place. Rebuild all consumers of the internal torrent.hpp: its private layout changes. The ordinary public add_torrent_params layout is unchanged. The added upstream test file is discovered by existing test/CMakeLists.txt test_*.cpp glob; no build-system edit is needed.

Four new LT test definitions exercise pure masks, actual isolated-session public hash lookup, immutable flags, full raw metadata retention, actual metadata arrival, resume roundtrip and fail-before-admission cases. Sessions disable all listeners/discovery and use the stock disabled disk backend. These definitions are not packet captures or successful data-transfer evidence.

Before any application adoption, central qualification must separately establish:
- actual owned incoming/outgoing plain and encrypted handshakes for both selected modes; unselected hash rejected; wrong hints and hybrid upgrade do not bypass the mask;
- owned HTTP/UDP tracker started/completed/stopped announces and scrape hashes, plus bounded DHT/LSD send/result paths with no public discovery;
- actual payload download/upload and checking in both modes, including full v1/v2/Merkle verification, magnet metadata arrival/restart and no raw metadata/geometry/piece-layer loss;
- default dual-swarm behavior and identity-collision/admission tests;
- exact built/installed/loaded artifact identity plus required weak-retirement/counter-fence source qualification on the new provider (and separately bound causal overlay if used).
Only then may a new runtime catalog entry authorize selected-swarm admissions. No source path, ABI version or capability marker alone grants accounting/storage authority.
