// BiglyBTC source-provider extension. Not part of upstream libtorrent API.
// Requires exact artifact binding AND biglybtc_swarm_mask_abi_v1()==1.
#ifndef BIGLYBTC_LIBTORRENT_SWARM_HPP
#define BIGLYBTC_LIBTORRENT_SWARM_HPP
#include "libtorrent/info_hash.hpp"
#include "libtorrent/torrent_flags.hpp"
namespace libtorrent {
// Admission only. Both clear preserves upstream dual-swarm behavior.
// Both set, or an unavailable selected hash, rejects admission.
constexpr torrent_flags_t biglybtc_v1_only{std::uint64_t{1} << 25};
constexpr torrent_flags_t biglybtc_v2_only{std::uint64_t{1} << 26};
constexpr torrent_flags_t biglybtc_swarm_mask = biglybtc_v1_only | biglybtc_v2_only;
inline info_hash_t biglybtc_wire_hashes(info_hash_t full,torrent_flags_t flags) noexcept
{
 auto const selected=flags & biglybtc_swarm_mask;
 if(selected==biglybtc_swarm_mask) return {};
 if(selected==biglybtc_v1_only) return full.has_v1()?info_hash_t(full.v1):info_hash_t{};
 if(selected==biglybtc_v2_only) return full.has_v2()?info_hash_t(full.v2):info_hash_t{};
 return full;
}
extern "C" TORRENT_EXPORT unsigned biglybtc_swarm_mask_abi_v1() noexcept;
}
#endif
