// Source-only tests for the source-qualified BiglyBTC provider extension.
// These do not certify actual selected/unselected wire traffic or hash IO.
#include "test.hpp"
#include "libtorrent/biglybtc_swarm.hpp"
#include "libtorrent/add_torrent_params.hpp"
#include "libtorrent/bencode.hpp"
#include "libtorrent/create_torrent.hpp"
#include "libtorrent/disabled_disk_io.hpp"
#include "libtorrent/error_code.hpp"
#include "libtorrent/entry.hpp"
#include "libtorrent/file_storage.hpp"
#include "libtorrent/read_resume_data.hpp"
#include "libtorrent/session.hpp"
#include "libtorrent/session_params.hpp"
#include "libtorrent/settings_pack.hpp"
#include "libtorrent/torrent_handle.hpp"
#include "libtorrent/torrent_info.hpp"
#include "libtorrent/torrent_status.hpp"
#include "libtorrent/write_resume_data.hpp"
#include <iterator>
#include <memory>
#include <string>
#include <vector>
using namespace lt;
namespace {
info_hash_t hashes()
{
 sha1_hash v1;v1[0]=1;sha256_hash v2;v2[0]=2;
 return {v1,v2};
}
std::shared_ptr<torrent_info> hybrid()
{
 file_storage files;files.add_file("owned.bin",16384);
 create_torrent creator(files,16384);
 creator.set_hash(piece_index_t{0},hashes().v1);
 creator.set_hash2(file_index_t{0},piece_index_t::diff_type{0},hashes().v2);
 std::vector<char> bytes;bencode(std::back_inserter(bytes),creator.generate());
 error_code ec;auto out=std::make_shared<torrent_info>(bytes.data(),int(bytes.size()),ec);
 TEST_CHECK(!ec);return out;
}
session_params isolated()
{
 settings_pack settings;
 settings.set_str(settings_pack::listen_interfaces,"");
 settings.set_str(settings_pack::outgoing_interfaces,"127.0.0.1");
 settings.set_bool(settings_pack::enable_dht,false);
 settings.set_bool(settings_pack::enable_lsd,false);
 settings.set_bool(settings_pack::enable_upnp,false);
 settings.set_bool(settings_pack::enable_natpmp,false);
 settings.set_bool(settings_pack::enable_incoming_tcp,false);
 settings.set_bool(settings_pack::enable_outgoing_tcp,false);
 settings.set_bool(settings_pack::enable_incoming_utp,false);
 settings.set_bool(settings_pack::enable_outgoing_utp,false);
 session_params p(settings);p.disk_io_constructor=disabled_disk_io_constructor;return p;
}
add_torrent_params parameters(std::shared_ptr<torrent_info> info,torrent_flags_t selected)
{
 add_torrent_params p;p.ti=std::move(info);p.save_path=".";
 p.flags &= ~torrent_flags::auto_managed;p.flags |= torrent_flags::paused | selected;
 return p;
}
}
TORRENT_TEST(biglybtc_swarm_hash_selection)
{
 auto const full=hashes();
 for(auto const selected:{torrent_flags_t{},biglybtc_v1_only,biglybtc_v2_only})
 {
  auto const wire=biglybtc_wire_hashes(full,selected);
  TEST_CHECK(wire.has_v1()==(selected!=biglybtc_v2_only));
  TEST_CHECK(wire.has_v2()==(selected!=biglybtc_v1_only));
  TEST_CHECK(full.has_v1()&&full.has_v2());
 }
 TEST_CHECK(!biglybtc_wire_hashes(full,biglybtc_swarm_mask).has_v1());
 TEST_CHECK(!biglybtc_wire_hashes(full,biglybtc_swarm_mask).has_v2());
 TEST_CHECK(!biglybtc_wire_hashes(info_hash_t(full.v1),biglybtc_v2_only).has_v2());
 TEST_CHECK(!biglybtc_wire_hashes(info_hash_t(full.v2),biglybtc_v1_only).has_v1());
 TEST_EQUAL(biglybtc_swarm_mask_abi_v1(),1u);
}
TORRENT_TEST(biglybtc_swarm_session_indices_and_immutable_admission)
{
 auto const info=hybrid();auto const full=info->info_hashes();
 auto const section=info->info_section();std::string const raw(section.data(),section.size());
 for(auto const selected:{torrent_flags_t{},biglybtc_v1_only,biglybtc_v2_only})
 {
  session owner(isolated());error_code ec;
  auto handle=owner.add_torrent(parameters(info,selected),ec);TEST_CHECK(!ec);TEST_CHECK(handle.is_valid());
  if(!handle.is_valid())continue;
  TEST_CHECK(owner.find_torrent(full.v1).is_valid()==(selected!=biglybtc_v2_only));
  TEST_CHECK(owner.find_torrent(full.v2).is_valid()==(selected!=biglybtc_v1_only));
  TEST_CHECK(handle.info_hashes()==full);TEST_CHECK(handle.status().info_hashes==full);
  handle.set_flags(torrent_flags_t{},biglybtc_swarm_mask);
  TEST_CHECK((handle.status().flags & biglybtc_swarm_mask)==selected);
  auto duplicate=parameters(info,selected==torrent_flags_t{}?biglybtc_v1_only:torrent_flags_t{});
  auto rejected=owner.add_torrent(std::move(duplicate),ec);
  TEST_CHECK(ec==errors::duplicate_torrent);TEST_CHECK(!rejected.is_valid());
  auto const retained=handle.torrent_file()->info_section();
  TEST_CHECK(std::string(retained.data(),retained.size())==raw);
  TEST_CHECK(handle.torrent_file()->info_hashes()==full);
 }
}
TORRENT_TEST(biglybtc_swarm_metadata_arrival_preserves_selection)
{
 auto const info=hybrid();auto const full=info->info_hashes();
 for(auto const selected:{biglybtc_v1_only,biglybtc_v2_only})
 {
  session owner(isolated());add_torrent_params p;p.save_path=".";
  p.info_hashes=biglybtc_wire_hashes(full,selected);
  p.flags &= ~torrent_flags::auto_managed;p.flags |= torrent_flags::paused | selected;
  error_code ec;auto handle=owner.add_torrent(std::move(p),ec);TEST_CHECK(!ec);
  if(!handle.is_valid())continue;
  TEST_CHECK(handle.set_metadata(info->info_section()));
  TEST_CHECK(handle.info_hashes()==full);
  TEST_CHECK(owner.find_torrent(full.v1).is_valid()==(selected==biglybtc_v1_only));
  TEST_CHECK(owner.find_torrent(full.v2).is_valid()==(selected==biglybtc_v2_only));
  TEST_CHECK((handle.status().flags & biglybtc_swarm_mask)==selected);
 }
}
TORRENT_TEST(biglybtc_swarm_resume_and_invalid_admission)
{
 auto const info=hybrid();auto const full=info->info_hashes();
 for(auto const selected:{torrent_flags_t{},biglybtc_v1_only,biglybtc_v2_only})
 {
  auto p=parameters(info,selected);p.info_hashes=full;
  auto bytes=write_resume_data_buf(p);error_code ec;
  auto restored=read_resume_data(bytes,ec);TEST_CHECK(!ec);
  TEST_CHECK((restored.flags & biglybtc_swarm_mask)==selected);
  TEST_CHECK(restored.info_hashes==full);
 }
 for(auto const selected:{biglybtc_swarm_mask,biglybtc_v2_only})
 {
  session owner(isolated());auto p=parameters({},selected);p.info_hashes=info_hash_t(full.v1);
  error_code ec;auto rejected=owner.add_torrent(std::move(p),ec);
  TEST_CHECK(ec==errors::invalid_info_hash);TEST_CHECK(!rejected.is_valid());TEST_CHECK(owner.get_torrents().empty());
 }
 auto invalid=parameters(info,biglybtc_v1_only);invalid.info_hashes=full;
 auto malformed=write_resume_data(invalid);
 malformed["biglybtc.swarm"]="bad";std::vector<char> bytes;
 bencode(std::back_inserter(bytes),malformed);error_code ec;
 (void)read_resume_data(bytes,ec);TEST_CHECK(ec==errors::invalid_info_hash);
 auto duplicate=write_resume_data_buf(invalid);TEST_CHECK(!duplicate.empty());
 if(!duplicate.empty())
 {
  duplicate.pop_back();std::string const field="14:biglybtc.swarmi0ee";
  duplicate.insert(duplicate.end(),field.begin(),field.end());ec.clear();
  (void)read_resume_data(duplicate,ec);TEST_CHECK(ec==errors::invalid_info_hash);
 }
}
