from pathlib import Path
import shutil
r=Path(__file__).parent
base=Path('/tmp/biglybtc-deps/libtorrent-2.0.12-release/libtorrent-2.0.12')
def before(rel):
 p=r/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/rel,p);return p.read_text()
def write(rel,s):
 p=r/'staging'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def sub(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n)
 return s.replace(a,b)
header='''// BiglyBTC source-provider extension. Not part of upstream libtorrent API.
// Requires exact artifact binding AND biglybtc_swarm_mask_abi_v1()==1.
#ifndef BIGLYBTC_LIBTORRENT_SWARM_HPP
#define BIGLYBTC_LIBTORRENT_SWARM_HPP
#include "libtorrent/info_hash.hpp"
#include "libtorrent/torrent_flags.hpp"
namespace libtorrent {
// Admission only. Both clear preserves upstream dual-swarm behavior.
// Both set, or an unavailable selected hash, rejects admission.
constexpr torrent_flags_t biglybtc_v1_only{std::uint64_t{1} << 25};
constexpr torrent_flags_t biglybtc_v2_only{std::uint64_t{1} << 26};
constexpr torrent_flags_t biglybtc_swarm_mask = biglybtc_v1_only | biglybtc_v2_only;
inline info_hash_t biglybtc_wire_hashes(info_hash_t full,torrent_flags_t flags) noexcept
{
 auto const selected=flags & biglybtc_swarm_mask;
 if(selected==biglybtc_swarm_mask) return {};
 if(selected==biglybtc_v1_only) return full.has_v1()?info_hash_t(full.v1):info_hash_t{};
 if(selected==biglybtc_v2_only) return full.has_v2()?info_hash_t(full.v2):info_hash_t{};
 return full;
}
extern "C" TORRENT_EXPORT unsigned biglybtc_swarm_mask_abi_v1() noexcept;
}
#endif
'''
write('include/libtorrent/biglybtc_swarm.hpp',header)
s=before('include/libtorrent/torrent.hpp')
s=sub(s,'info_hash_t const& info_hash() const { return m_info_hash; }','''// Internal wire identity: session indices and peer/discovery protocols.
		info_hash_t const& info_hash() const { return m_wire_info_hash; }
		// Full immutable metainfo identity remains available for disk/Merkle
		// verification and public metadata/status access.
		info_hash_t const& metadata_info_hash() const { return m_info_hash; }
		torrent_flags_t swarm_selection_flags() const { return m_swarm_flags; }''')
s=sub(s,'\t\tinfo_hash_t m_info_hash;','''		info_hash_t m_info_hash;
		info_hash_t m_wire_info_hash;
		torrent_flags_t const m_swarm_flags;''')
write('include/libtorrent/torrent.hpp',s)
s=before('src/torrent.cpp')
s=sub(s,'#include "libtorrent/torrent.hpp"','#include "libtorrent/torrent.hpp"\n#include "libtorrent/biglybtc_swarm.hpp"')
s=sub(s,', m_info_hash(p.info_hashes)',', m_info_hash(p.info_hashes)\n\t\t, m_wire_info_hash(biglybtc_wire_hashes(p.info_hashes,p.flags))\n\t\t, m_swarm_flags(p.flags & biglybtc_swarm_mask)')
s=sub(s,'torrent_flags_t ret = torrent_flags_t{};','torrent_flags_t ret = m_swarm_flags;')
# No set_flags branch can modify either const admission mask or wire hash.
# Every network path that bypassed the internal info_hash() accessor.
s=sub(s,'m_torrent_file->info_hashes().for_each([&](sha1_hash const& ih, protocol_version)', 'm_wire_info_hash.for_each([&](sha1_hash const& ih, protocol_version)',2)
s=sub(s,'m_torrent_file->info_hashes().for_each([&](sha1_hash const& ih, protocol_version v)', 'm_wire_info_hash.for_each([&](sha1_hash const& ih, protocol_version v)')
s=sub(s,'req.info_hash = m_torrent_file->info_hashes().get(ih);','req.info_hash = m_wire_info_hash.get(ih);')
# All four supports_protocol arrays are tracker announce/scrape timer paths.
s=sub(s,'m_info_hash.has_v1(),\n\t\t\tm_info_hash.has_v2()','m_wire_info_hash.has_v1(),\n\t\t\tm_wire_info_hash.has_v2()',3)
s=sub(s,'m_info_hash.has_v1(),\n\t\t\t\tm_info_hash.has_v2()','m_wire_info_hash.has_v1(),\n\t\t\t\tm_wire_info_hash.has_v2()')
s=sub(s,'m_torrent_file->info_hashes().get(peerinfo->protocol())','m_wire_info_hash.get(peerinfo->protocol())')
s=sub(s,'TORRENT_ASSERT(info_hash().has_v2() || !(flags & pex_lt_v2));','''// A hint cannot opt a V1-only admission into the other swarm.
		if ((flags & pex_lt_v2) && !m_wire_info_hash.has_v2()) return nullptr;
		TORRENT_ASSERT(info_hash().has_v2() || !(flags & pex_lt_v2));''')
s=sub(s,'if (!torrent_file().info_hashes().has_v1())\n\t\t\tflags |= pex_lt_v2;','if (!m_wire_info_hash.has_v1())\n\t\t\tflags |= pex_lt_v2;')
s=sub(s,'\t\tif (m_abort) return false;\n\n\t\tpeerinfo->last_connected', '''		if (m_abort) return false;
		if (!m_wire_info_hash.has(peerinfo->protocol())) return false;

		peerinfo->last_connected''')
s=sub(s,'if (!info_hash().has_v2()) return {};','if (!metadata_info_hash().has_v2()) return {};')
s=sub(s,'info_hash_t const old_ih = m_torrent_file->info_hashes();','info_hash_t const old_ih = m_wire_info_hash;')
s=sub(s,'\t\t// we might already have this torrent in the session.\n\t\tbool failed = false;\n\t\tinfo->info_hashes().for_each', '''		auto const selected_ih = biglybtc_wire_hashes(info->info_hashes(),m_swarm_flags);
		if (!selected_ih.has_v1() && !selected_ih.has_v2())
		{
			set_error(errors::invalid_info_hash,torrent_status::error_file_metadata);
			pause();
			return false;
		}
		// Only selected wire identities participate in collision checks.
		bool failed = false;
		selected_ih.for_each''')
s=sub(s,'m_info_hash = m_torrent_file->info_hashes();','m_info_hash = m_torrent_file->info_hashes();\n\t\tm_wire_info_hash = selected_ih;')
s=sub(s,'TORRENT_ASSERT(m_info_hash.v2 == m_torrent_file->info_hashes().v2);','TORRENT_ASSERT(m_info_hash.v2 == m_torrent_file->info_hashes().v2);\n\t\t\tTORRENT_ASSERT(m_wire_info_hash == biglybtc_wire_hashes(m_info_hash,m_swarm_flags));')
s=sub(s,'st->info_hashes = info_hash();','st->info_hashes = metadata_info_hash();')
s=sub(s,'st->info_hash = info_hash().get_best();','st->info_hash = metadata_info_hash().get_best();')
s=sub(s,', info_hash(), get_userdata());',', metadata_info_hash(), get_userdata());',2)
write('src/torrent.cpp',s)
s=before('src/session_impl.cpp')
s=sub(s,'#include "libtorrent/torrent_info.hpp"','#include "libtorrent/torrent_info.hpp"\n#include "libtorrent/biglybtc_swarm.hpp"')
s=sub(s,'TORRENT_ASSERT(info_hash == torrent_ptr->torrent_file().info_hashes());','TORRENT_ASSERT(info_hash == torrent_ptr->info_hash());')
a='''#ifndef TORRENT_DISABLE_DHT
		// add params.dht_nodes to the DHT, if enabled'''
b='''\t\t// Validate immutable selection before discovery, torrent construction or IO.
		auto const wire_hashes=biglybtc_wire_hashes(
			params.ti?params.ti->info_hashes():params.info_hashes,params.flags);
		if ((params.flags & biglybtc_swarm_mask)
			&& !wire_hashes.has_v1() && !wire_hashes.has_v2())
		{
			ec=errors::invalid_info_hash;
			return ret_t{ptr_t(),params.info_hashes,false};
		}

#ifndef TORRENT_DISABLE_DHT
		// add params.dht_nodes to the DHT, if enabled'''
s=sub(s,a,b)
s=sub(s,'find_torrent(params.info_hashes).lock();','find_torrent(wire_hashes).lock();')
s=sub(s,'\t\tif (torrent_ptr)\n\t\t{\n\t\t\tif (!(params.flags & torrent_flags::duplicate_is_error))','''		if (torrent_ptr)
		{
			// Never return an existing dual-swarm handle for a selected request.
			if (torrent_ptr->swarm_selection_flags() != (params.flags & biglybtc_swarm_mask))
			{
				ec=errors::duplicate_torrent;
				return ret_t{ptr_t(),wire_hashes,false};
			}
			if (!(params.flags & torrent_flags::duplicate_is_error))''')
s=sub(s,'return ret_t{std::move(torrent_ptr), params.info_hashes, false};','return ret_t{std::move(torrent_ptr), wire_hashes, false};')
s=sub(s,'return ret_t{std::move(torrent_ptr), params.info_hashes, true};','return ret_t{std::move(torrent_ptr), wire_hashes, true};')
write('src/session_impl.cpp',s)
s=before('src/peer_connection.cpp')
# Exactly the seed-mode disk request/results use full metadata, not wire mask.
a=s.index('// this means we\'re in seed mode and we haven\'t yet');z=s.index('span<sha256_hash> v2_hashes(hashes);',a)
s=s[:a]+s[a:z].replace('t->info_hash()','t->metadata_info_hash()')+s[z:]
a=s.index('void peer_connection::on_seed_mode_hashed');z=s.index('void peer_connection::',a+5)
s=s[:a]+s[a:z].replace('t->info_hash()','t->metadata_info_hash()')+s[z:]
s=sub(s,'return ih.get((ih.has_v2() && peer_info_struct()->protocol_v2)','return ih.get((!ih.has_v1() || (ih.has_v2() && peer_info_struct()->protocol_v2))')
write('src/peer_connection.cpp',s)
s=before('src/torrent_handle.cpp')
s=sub(s,'return t ? t->info_hash().get_best() : sha1_hash{};','return t ? t->metadata_info_hash().get_best() : sha1_hash{};')
s=sub(s,'return t ? t->info_hash() : info_hash_t();','return t ? t->metadata_info_hash() : info_hash_t();')
write('src/torrent_handle.cpp',s)
s=before('src/version.cpp')
s=sub(s,'#include "libtorrent/version.hpp"','#include "libtorrent/version.hpp"\n#include "libtorrent/biglybtc_swarm.hpp"')
s=sub(s,'namespace libtorrent {','namespace libtorrent {\n\nextern "C" unsigned biglybtc_swarm_mask_abi_v1() noexcept { return 1; }')
write('src/version.cpp',s)
s=before('src/read_resume_data.cpp')
s=sub(s,'#include "libtorrent/read_resume_data.hpp"','#include "libtorrent/read_resume_data.hpp"\n#include "libtorrent/biglybtc_swarm.hpp"')
a='\t\tapply_flag(ret.flags, rd, "disable_pex", torrent_flags::disable_pex);'
b=a+'''
		int selection_keys=0;
		for (int i=0;i<rd.dict_size();++i)
			if (rd.dict_at(i).first=="biglybtc.swarm") ++selection_keys;
		if (selection_keys>1)
		{
			ec=errors::invalid_info_hash;
			return ret;
		}
		if (auto const selected=rd.dict_find("biglybtc.swarm"))
		{
			if (selected.type()!=bdecode_node::int_t || selected.int_value()<0 || selected.int_value()>2)
			{
				ec=errors::invalid_info_hash;
				return ret;
			}
			if (selected.int_value()==1) ret.flags |= biglybtc_v1_only;
			if (selected.int_value()==2) ret.flags |= biglybtc_v2_only;
			auto const wire=biglybtc_wire_hashes(ret.info_hashes,ret.flags);
			if (!wire.has_v1() && !wire.has_v2())
			{
				ec=errors::invalid_info_hash;
				return ret;
			}
		}
'''
s=sub(s,a,b);write('src/read_resume_data.cpp',s)
s=before('src/write_resume_data.cpp')
s=sub(s,'#include "libtorrent/write_resume_data.hpp"','#include "libtorrent/write_resume_data.hpp"\n#include "libtorrent/biglybtc_swarm.hpp"')
a='\t\tret["disable_pex"] = bool(atp.flags & torrent_flags::disable_pex);'
b=a+'''
		auto const selected=atp.flags & biglybtc_swarm_mask;
		if (selected) ret["biglybtc.swarm"] = selected==biglybtc_v1_only?1:
			selected==biglybtc_v2_only?2:3; // invalid combined bits fail on read
'''
s=sub(s,a,b);write('src/write_resume_data.cpp',s)
# Network-response classification also follows the selected wire hash even if
# a hybrid's two 20-byte swarm keys happen to collide.
rel='src/torrent.cpp';s=(r/'staging'/rel).read_text()
s=sub(s,'req.info_hash == m_info_hash.v1','req.info_hash == m_wire_info_hash.v1',2)
s=sub(s,'r.info_hash == m_info_hash.v1','r.info_hash == m_wire_info_hash.v1',2)
s=sub(s,'r.info_hash == torrent_file().info_hashes().v1','r.info_hash == m_wire_info_hash.v1')
write(rel,s)
s=(r/'staging/src/session_impl.cpp').read_text()
s=sub(s,'ih == t->torrent_file().info_hashes().v1','ih == t->info_hash().v1');write('src/session_impl.cpp',s)
