Owned selected-swarm qualification — SOURCE ONLY

Linux ELF qualification fixture. No compilation, target execution, network request, provider/native edit or new
qualification occurred during authoring. All results below are required future
assertions, not passing evidence. The existing c35f provider remains unchanged.

Inputs and order
1. Use a fresh owned LT740a source/build/install tree. Apply the immutable
   ../provider/provider.patch (manifest72865b63...) followed by the separate
   handshake-amendment/amendment.patch (manifest410be6d1...). Never patch the
   retained default provider in place. The amendment adds one include and gates
   the old incoming upgrade block off only for explicit V1Only. Its body stays
   exact for default/upstream admissions; a wrong v2 key still fails lookup.
2. Root builds/records the actual new provider, including source/build/install
   maps, then reviews an explicit qualification-only catalog entry in the
   retained source-bound approver. Old c35f approval cannot approve this tree.
   No candidate artifact digest, source-count increase or passing receipt is
   guessed here. An unchanged approver is expected to reject this candidate.
3. Build this standalone fixture against that exact new installed provider.
   No native CMake/shared file changes are needed. Example commands (root only):

   cmake -S STAGING -B OWNED_BUILD -G Ninja \
     -DCMAKE_PREFIX_PATH=QUALIFIED_INSTALL \
     -DCMAKE_BUILD_RPATH=QUALIFIED_INSTALL/lib
   cmake --build OWNED_BUILD --target biglybtc-selected-swarm-driver \
     biglybtc-wrong-swarm-marker biglybtc-foreign-swarm-marker --parallel 3

   STAGING is this capsule's staging directory. Compiler budget remains root's.
   The provider's earlier four LT tests remain a separate target,
   test_biglybtc_swarm, using upstream test/CMakeLists.txt's existing glob.
4. Invoke staging/run.py with a fresh absolute output directory and actual pins:

   python3 STAGING/run.py \
     --driver OWNED_BUILD/biglybtc-selected-swarm-driver \
     --artifact ACTUAL_PROVIDER --artifact-sha256 ACTUAL_SHA256 \
     --runtime-manifest REVIEWED_NEW_RUNTIME_MANIFEST \
     --provider-source OWNED_PATCHED_LT_SOURCE \
     --approver REVIEWED_RETAINED_APPROVER --approver-sha256 REVIEWED_SHA256 \
     --stock-provider RETAINED_C35F --stock-provider-sha256 c35f1b0408508c019f002c438d70dd361a55be20286ded56711efd6bba2424e3 \
     --wrong-marker OWNED_BUILD/libbiglybtc-wrong-swarm-marker.so \
     --foreign-marker OWNED_BUILD/libbiglybtc-foreign-swarm-marker.so \
     --output NEW_OWNED_RESULT_DIRECTORY

   The runner executes the approver CLI before any service fixture. It validates
   actual source overlay, amendment, manifest/artifact/source-root agreement,
   approval receipt and loaded artifact/capability. The approver/catalog pin is
   an explicit root-reviewed input; this harness creates no trust entry itself.
   Provider loading in gate-only negative probes creates no LT session/admission.

Actual future observations
- Independent numeric-loopback peers read actual68-byte plain handshakes and
  perform real DH/RC4 MSE with bounded padding, decrypting the actual BT handshake
  and checking MSE SKEY agrees with it. Both directions, each permitted hybrid
  key, and wrong incoming key are exercised in each mode/encryption combination.
- The V1Only incoming reserved-bit upgrade offer is exercised before metadata,
  after metadata and after actual resume reload. Returned key stays v1 and the
  responder does not advertise an unselected v2 upgrade.
- Wrong-swarm denial requires socket closure AND an actual invalid_info_hash
  error alert or pre-association peer-log alert from the LT owner. LoggingON
  is required (matching the retained source build); pre-association failures
  have no torrent handle and upstream does not post peer_disconnected_alert
  for them. A timeout is failure, not evidence of rejection.
- HTTP raw request lines and actual UDP datagrams are retained. Every observed
  announce/scrape hash must be selected. Each selected key must appear in actual
  started/completed/stopped announces and scrapes for both HTTP and UDP. The
  receiver waits for actual initial tracker replies before connecting, so a
  genuine downloading-to-complete transition is available to announce.
- Actual LT-to-LT transfers run with the selected mode and forced/plain crypto
  policy. Received bytes match the generated payload, SHA1 pieces, v2 piece
  roots and the full v2 file root independently. Actual clean force-recheck
  succeeds, and actual force-recheck rejects a deliberately corrupted piece.
  This is data/checking evidence, not an instrumented assertion about each
  internal disk callback's flag bits.
- Fresh actual magnet admission, metadata acceptance and saved-resume reload
  keep index scope, full public metadata hashes and raw info. Real wire probes
  repeat across those boundaries. Flag mutations have no effect on selection.
- Real owned modules demonstrate absent/incorrect capability rejection with
  admissions0; a foreign marker1 cannot authorize the actual LT-linked object.

Evidence and limits
Each run gets a new directory. It retains child stdout/stderr, all actual alert
text, raw socket TX/RX, decoded handshake fields, tracker requests, actual
metadata/resume bytes, source/corrupt payloads and loaded maps. Only a fully
successful run writes statusPASS, dynamic observed counts and output hashes.
There is no original-Java equality, public discovery/DHT/LSD qualification,
shipping Host adoption, accounting-fence or crash-durability credit here.
DHT/LSD encoder/result and counter-fence cohorts remain separate qualification
requirements already listed in the provider's ADOPTION.md. A failed first run
is retained; do not repair or overwrite it in place.
