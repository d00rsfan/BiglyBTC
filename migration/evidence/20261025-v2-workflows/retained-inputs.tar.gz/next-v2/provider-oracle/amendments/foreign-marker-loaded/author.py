from pathlib import Path
import hashlib,json,difflib,ast
W=Path('/home/yurii/Java/BiglyBT/build/storage-20261025');BASE=W/'next-v2/provider-oracle';FINAL=BASE/'amendments/final449';O=BASE/'amendments/foreign-marker-loaded'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(BASE/'manifest.json')=='cbbbb31ee0f25ab00402114f87c6ce0b0471a67b40a2ddb2427966c96c82090a'
assert sha(FINAL/'manifest.json')=='348e0a59f06edc18626b2649af6e61b31d2025bb84156a5ac8898fe3e2570db5'
driver=(BASE/'staging/provider_driver.cpp').read_text();runner=(FINAL/'staging/run.py').read_text()
(O/'before/provider_driver.cpp').write_text(driver);(O/'before/run.py').write_text(runner)
needle='const bool probe=std::string(argv[3])=="--probe";gate(artifact,argv[2],probe);'
replacement='''const bool probe=std::string(argv[3])=="--probe";
 const bool foreignProbe=argc==10&&std::string_view(argv[9])=="--foreign-probe";
 const auto closeModule=[](void* module){if(module){::dlclose(module);}};
 std::unique_ptr<void,decltype(closeModule)> foreign(nullptr,closeModule);
 if(foreignProbe){
  // Target-private negative fixture only. Authenticate before loading code, then
  // retain the real marker DSO through gate's unchanged NOLOAD/same-object test.
  need(artifact.is_absolute()&&fs::canonical(artifact)==artifact,"noncanonical foreign fixture");
  need(sha256File(artifact)==argv[2],"foreign fixture digest differs");
  foreign.reset(::dlopen(artifact.c_str(),RTLD_NOW|RTLD_LOCAL));
  need(bool(foreign),"foreign fixture module load failed");
  std::cout<<"FOREIGN\\tLOADED\\tadmissions=0"<<std::endl;
 }
 gate(artifact,argv[2],probe);
 need(!foreignProbe,"foreign fixture unexpectedly passed the linked-provider gate");'''
assert driver.count(needle)==1;driver=driver.replace(needle,replacement,1)
old="""        'V1Only', 'Plain', 'http://127.0.0.1:1/announce', 'udp://127.0.0.1:1/announce', 'rejected-before-owner'], args.output / 'gate-foreign', environment)
    text = (args.output / 'gate-foreign.stdout').read_text()
    require(status == 2 and 'LT version resolves to another object' in text and text.rstrip().endswith('admissions=0') and not (args.output / 'must-not-exist').exists(), 'foreign marker accepted before source identity')
    gate_cases.append({'case': 'foreign-marker1', 'artifact_sha256': digest(args.foreign_marker), 'exit': status, 'actual_admissions': 0})
"""
new="""        'V1Only', 'Plain', 'http://127.0.0.1:1/announce', 'udp://127.0.0.1:1/announce', 'rejected-before-owner', '--foreign-probe'], args.output / 'gate-foreign', environment)
    text = (args.output / 'gate-foreign.stdout').read_text()
    require(status == 2 and text.splitlines() == ['FOREIGN\\tLOADED\\tadmissions=0',
        'FAIL\\tLT version resolves to another object\\tadmissions=0']
        and not (args.output / 'must-not-exist').exists(), 'loaded foreign marker did not reach the linked-provider identity rejection')
    gate_cases.append({'case': 'foreign-marker1', 'artifact_sha256': digest(args.foreign_marker), 'exit': status,
        'actual_foreign_module_loaded': True, 'causal_gate': 'linked-provider-object-mismatch', 'actual_admissions': 0})
"""
assert runner.count(old)==1;runner=runner.replace(old,new,1)
(O/'staging/provider_driver.cpp').write_text(driver);(O/'staging/run.py').write_text(runner)
# Reversibility/source inspection only: never import or run the driver/runner.
assert driver.replace(replacement,needle,1)==(O/'before/provider_driver.cpp').read_text()
assert runner.replace(new,old,1)==(O/'before/run.py').read_text()
a=ast.parse((O/'before/run.py').read_text());b=ast.parse(runner);byname={n.name:n for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};kept=[]
for n in a.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name!='main':assert ast.dump(n,include_attributes=False)==ast.dump(byname[n.name],include_attributes=False);kept.append(n.name)
for name in ['provider_driver.cpp','run.py']:
 (O/(name+'.patch')).write_text(''.join(difflib.unified_diff((O/'before'/name).read_text().splitlines(True),(O/'staging'/name).read_text().splitlines(True),fromfile='a/staging/'+name,tofile='b/staging/'+name)))
proof={'source_only':True,'driver_gate_function_byte_exact':True,'driver_remaining_source_reverses_exactly':True,'runner_remaining_source_reverses_exactly':True,'runner_functions_ast_exact':kept,'native_provider_source_unchanged':True,'executed':False}
(O/'source-checks.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'driver_sha256':sha(O/'staging/provider_driver.cpp'),'runner_sha256':sha(O/'staging/run.py')},indent=2))
