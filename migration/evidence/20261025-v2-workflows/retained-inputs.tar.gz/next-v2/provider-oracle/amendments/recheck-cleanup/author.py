from pathlib import Path
import hashlib,json,difflib,ast
W=Path('/home/yurii/Java/BiglyBT/build/storage-20261025');BASE=W/'next-v2/provider-oracle';PREV=BASE/'amendments/foreign-marker-loaded';O=BASE/'amendments/recheck-cleanup'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(PREV/'manifest.json')=='a845ddbbfb78c3d965215c55fee2504b9e012542afa96e209384ee9114002235'
driver=(PREV/'staging/provider_driver.cpp').read_text();runner=(PREV/'staging/run.py').read_text()
for name,text in [('provider_driver.cpp',driver),('run.py',runner)]: (O/'before'/name).write_text(text)
assert driver.count('rh.force_recheck();')==2
updated=driver.replace('rh.force_recheck();','rh.force_recheck();rh.resume();')
assert updated.replace('rh.force_recheck();rh.resume();','rh.force_recheck();')==driver
(O/'staging/provider_driver.cpp').write_text(updated)
old='''    finally:
        if driver is not None:
            driver.close()
        trackers.close()
'''
new='''    finally:
        original_error = sys.exc_info()[1]
        cleanup_errors = []
        # Each owned resource must be closed even if a previously failed child
        # raises again during shutdown. Preserve the first fixture failure.
        for name, resource in (('driver', driver), ('trackers', trackers)):
            if resource is None:
                continue
            try:
                resource.close()
            except Exception as exc:
                cleanup_errors.append({'resource': name, 'error': str(exc)[:2048]})
        if cleanup_errors:
            try:
                save(root / 'cleanup-errors.json', cleanup_errors)
            except Exception as exc:
                cleanup_errors.append({'resource': 'cleanup-receipt', 'error': str(exc)[:2048]})
            message = 'Owned cleanup failed: ' + json.dumps(cleanup_errors, sort_keys=True)
            if original_error is not None:
                original_error.add_note(message)
            else:
                raise RuntimeError(message)
'''
assert runner.count(old)==1;amended=runner.replace(old,new,1);assert amended.replace(new,old,1)==runner
(O/'staging/run.py').write_text(amended)
(O/'staging/CMakeLists.txt').write_bytes((PREV/'staging/CMakeLists.txt').read_bytes())
for name in ['provider_driver.cpp','run.py']:
 (O/(name+'.patch')).write_text(''.join(difflib.unified_diff((O/'before'/name).read_text().splitlines(True),(O/'staging'/name).read_text().splitlines(True),fromfile='a/staging/'+name,tofile='b/staging/'+name)))
a=ast.parse(runner);b=ast.parse(amended);newnodes={n.name:n for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};exact=[]
for n in a.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name!='case':assert ast.dump(n,include_attributes=False)==ast.dump(newnodes[n.name],include_attributes=False),n.name;exact.append(n.name)
(O/'source-checks.json').write_text(json.dumps({'source_only':True,'driver_reversal_exact':True,'runner_reversal_exact':True,'runner_noncleanup_functions_ast_exact':exact,'recheck_resumes_added':2,'deadlines_and_hash_seed_corrupt_assertions_unchanged':True,'provider_or_native_changed':False,'executed':False},indent=2)+'\n')
print(sha(O/'staging/provider_driver.cpp'),sha(O/'staging/run.py'))
