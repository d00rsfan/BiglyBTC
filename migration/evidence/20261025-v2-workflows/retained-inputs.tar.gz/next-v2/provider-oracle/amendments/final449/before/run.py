#!/usr/bin/env python3
"""Run only after root builds and reviews a new source-bound provider/catalog.
No build/configure, Java, original profile or public-network activity here.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import queue
import socket
import subprocess
import sys
import threading
import time
sys.dont_write_bytecode = True

PROVIDER_MANIFEST = '72865b634db7f05e53f747daf14bf2bcc195487d3e9124fe80380427204561e9'
UPGRADE_MANIFEST = '410be6d14469f7ebdaeec51f72562fc337a1c0a8f41ffadde6c022642c5e5278'

def require(ok, why):
    if not ok:
        raise RuntimeError(why)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def source_pin(path, expected):
    path = Path(path).resolve(strict=True)
    require(path.is_file() and digest(path) == expected, f'Changed reviewed source: {path}')
    return path

def wait_for(predicate, seconds=10):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if predicate():
            return
        time.sleep(.02)
    raise RuntimeError('owned fixture deadline')

class Driver:
    def __init__(self, command, root, environment):
        self.root = root; self.lines = queue.Queue(); self.transcript = []
        self.stderr = (root / 'driver.stderr').open('wb')
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=self.stderr, text=True, bufsize=1, env=environment, start_new_session=True)
        self.reader = threading.Thread(target=self.read_loop)
        self.reader.start()

    def read_loop(self):
        for line in self.process.stdout:
            self.lines.put(line.rstrip('\n'))
        self.lines.put(None)

    def line(self, seconds=40):
        line = self.lines.get(timeout=seconds)
        require(line is not None, f'driver exited {self.process.poll()}')
        self.transcript.append(line)
        (self.root / 'driver.stdout').write_text('\n'.join(self.transcript) + '\n')
        require(not line.startswith('FAIL\t'), line)
        return line.split('\t')

    def command(self, command, expected=None):
        self.process.stdin.write(command + '\n'); self.process.stdin.flush()
        line = self.line()
        require(line[:2] == ['OK', expected or command.split()[0]], f'unexpected response{line}')
        return line

    def close(self):
        try:
            if self.process.poll() is None:
                try:
                    self.command('CLOSE')
                    self.process.stdin.close()
                    require(self.process.wait(timeout=15) == 0, 'driver failed at joined close')
                except Exception:
                    self.process.terminate()
                    try:
                        self.process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        self.process.kill(); self.process.wait(timeout=5)
                    raise
        finally:
            self.reader.join(timeout=3)
            self.stderr.close()
            require(not self.reader.is_alive(), 'driver pipe reader did not join')


def incoming(driver, port, key, mse, output, rejected=False, upgrade=False):
    wire = Wire(socket.create_connection(('127.0.0.1', port), timeout=5), output)
    try:
        received = initiate(wire, key, mse, upgrade)
        require(not rejected, 'unselected incoming handshake was accepted')
        require(received[28:48] == key, 'actual incoming response used another swarm')
        if upgrade:
            require(received[27] & 0x10 == 0, 'V1Only advertised v2 upgrade')
        wire.finish('accepted')
        return {'capture': output.name, 'direction': 'incoming', 'mse': mse,
            'hash': key.hex(), 'upgrade_offer': upgrade, 'accepted': True}
    except (EOFError, ConnectionResetError, BrokenPipeError) as exc:
        wire.finish('rejected', exc)
        require(rejected, f'qualified incoming handshake failed: {exc}')
        driver.command('REJECT')
        return {'capture': output.name, 'direction': 'incoming', 'mse': mse,
            'hash': key.hex(), 'upgrade_offer': upgrade, 'accepted': False,
            'actual_invalid_info_hash_evidence': True}
    except Exception as exc:
        wire.finish('failure', exc); raise


def outgoing(driver, key, protocol, mse, output):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('127.0.0.1', 0)); server.listen(1); server.settimeout(5)
    wire = None
    try:
        driver.command(f'CONNECT {server.getsockname()[1]} {protocol}', 'CONNECT')
        client, endpoint = server.accept()
        require(endpoint[0] == '127.0.0.1', 'nonowned peer')
        wire = Wire(client, output)
        received = respond(wire, [key], mse)
        require(received[28:48] == key, 'actual outgoing handshake used another swarm')
        wire.finish('accepted')
        return {'capture': output.name, 'direction': 'outgoing', 'mse': mse,
            'hash': key.hex(), 'accepted': True}
    except Exception as exc:
        if wire is not None:
            wire.finish('failure', exc)
        raise
    finally:
        server.close()


def tracker_complete(trackers, allowed, events):
    records = trackers.snapshot()
    require(not trackers.errors, f'owned tracker failure{trackers.errors}')
    actual = [key for row in records for key in row['hashes']]
    require(set(actual) <= set(allowed), 'unselected tracker hash observed')
    for transport in ('http', 'udp'):
        for event in events:
            for key in allowed:
                if not any(row['transport'] == transport and row['action'] == ('scrape' if event == 'scrape' else 'announce')
                    and (event == 'scrape' or row['event'] == event) and key in row['hashes'] for row in records):
                    return False
    return True


def check_outputs(root):
    expected = bytes((i * 17 + 3) % 251 for i in range(160 * 1024))
    # The driver deliberately corrupts one byte after successful transfer and
    # clean recheck, then requires actual checking to reject that exact piece.
    corrupted = bytearray(expected); corrupted[0] ^= 1
    require((root / 'seed/owned.bin').read_bytes() == expected, 'seed was changed')
    require((root / 'receive/owned.bin').read_bytes() == corrupted, 'actual corruption fixture differs')
    return {'source_payload_sha256': hashlib.sha256(expected).hexdigest(),
        'retained_corrupt_payload_sha256': hashlib.sha256(corrupted).hexdigest(),
        'bytes': len(expected)}


def case(args, output, mode, mse, environment):
    root = output / f'{mode}-{"Mse" if mse else "Plain"}'; root.mkdir()
    captures = root / 'captures'; captures.mkdir()
    tracker_root = root / 'trackers'; tracker_root.mkdir()
    trackers = Trackers(tracker_root); driver = None
    try:
        urls = trackers.urls
        driver = Driver([str(args.driver), str(args.artifact), args.artifact_sha256,
            str(root / 'owned'), mode, 'Mse' if mse else 'Plain', *urls, 'owned-hybrid-v1'], root, environment)
        ready = driver.line()
        require(len(ready) == 5 and ready[0] == 'READY', f'bad ready{ready}')
        port = int(ready[1]); v1 = bytes.fromhex(ready[2]); v2 = bytes.fromhex(ready[3])[:20]
        require(0 < port <= 65535 and len(v1) == len(v2) == 20 and v1 != v2, 'ambiguous hybrid fixture')
        allowed = [('v1', v1)] if mode == 'V1Only' else [('v2', v2)] if mode == 'V2Only' else [('v1', v1), ('v2', v2)]
        expected_hashes = [key.hex() for _, key in allowed]
        wait_for(lambda: tracker_complete(trackers, expected_hashes, ['started']))
        driver.command('MUTATE')
        observations = []
        for phase in ('initial', 'magnet', 'metadata', 'resume'):
            if phase != 'initial':
                driver.command(phase.upper())
            for protocol, key in allowed:
                observations.append(incoming(driver, port, key, mse, captures / f'{phase}-{protocol}-incoming'))
                observations.append(outgoing(driver, key, protocol, mse, captures / f'{phase}-{protocol}-outgoing'))
            wrong = v2 if mode == 'V1Only' else v1 if mode == 'V2Only' else bytes.fromhex('33' * 20)
            require(wrong not in [key for _, key in allowed], 'wrong key unexpectedly selected')
            observations.append(incoming(driver, port, wrong, mse, captures / f'{phase}-wrong-incoming', rejected=True))
            if mode == 'V1Only':
                observations.append(incoming(driver, port, v1, mse, captures / f'{phase}-v1-upgrade-offer', upgrade=True))
            if phase == 'initial':
                driver.command('TRANSFER')
                driver.command('SCRAPE')
                wait_for(lambda: tracker_complete(trackers, expected_hashes, ['started', 'completed', 'scrape', 'stopped']))
        driver.close(); driver = None
        require(tracker_complete(trackers, expected_hashes, ['started', 'completed', 'scrape', 'stopped']), 'missing actual tracker evidence')
        result = {'mode': mode, 'mse': mse, 'observations': observations, 'tracker_requests': len(trackers.snapshot()),
            'payload': check_outputs(root / 'owned'), 'status': 'PASS',
            'payload_scope': 'actual selected LT-to-LT transfer; received bytes independently SHA1/Merkle checked; actual clean and corrupt force-recheck'}
        save(root / 'result.json', result)
        return result
    finally:
        if driver is not None:
            driver.close()
        trackers.close()


def run_command(command, output, environment, timeout=60):
    with (output.with_suffix('.stdout')).open('wb') as stdout, (output.with_suffix('.stderr')).open('wb') as stderr:
        child = subprocess.Popen(command, stdout=stdout, stderr=stderr, env=environment, start_new_session=True)
        end = time.monotonic() + timeout
        try:
            while child.poll() is None:
                try:
                    child.wait(timeout=min(45, max(.1, end - time.monotonic())))
                except subprocess.TimeoutExpired:
                    require(time.monotonic() < end, 'bounded child deadline')
                    print('Owned provider qualification is running', flush=True)
            return child.returncode
        except Exception:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait(timeout=5)
            raise


def main():
    global Trackers, Wire, initiate, respond
    parser = argparse.ArgumentParser()
    for key in ('driver', 'artifact', 'runtime-manifest', 'approver', 'provider-source', 'output', 'stock-provider', 'wrong-marker', 'foreign-marker'):
        parser.add_argument('--' + key, type=Path, required=True)
    for key in ('artifact-sha256', 'approver-sha256', 'stock-provider-sha256'):
        parser.add_argument('--' + key, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    capsule = json.loads((here.parent / 'manifest.json').read_text())
    for rel, expected in capsule['artifacts'].items():
        source_pin(here.parent / rel, expected)
    from trackers import Trackers
    from wire_peers import Wire, initiate, respond
    for field in ('driver', 'artifact', 'runtime_manifest', 'approver', 'provider_source', 'stock_provider', 'wrong_marker', 'foreign_marker'):
        setattr(args, field, getattr(args, field).resolve(strict=True))
    require(args.output.is_absolute() and not args.output.exists() and args.output.parent.resolve(strict=True) == args.output.parent, 'output must be new beneath canonical owned parent')
    require(digest(args.artifact) == args.artifact_sha256, 'new provider bytes differ')
    require(digest(args.approver) == args.approver_sha256, 'unreviewed approver bytes')
    require(digest(args.stock_provider) == args.stock_provider_sha256, 'stock negative bytes differ')
    provider = here.parent.parent / 'provider'
    source_pin(provider / 'manifest.json', PROVIDER_MANIFEST)
    source_pin(here.parent / 'handshake-amendment/manifest.json', UPGRADE_MANIFEST)
    source_manifest = json.loads((provider / 'manifest.json').read_text())
    amendment = json.loads((here.parent / 'handshake-amendment/manifest.json').read_text())
    for rel, value in source_manifest['sources'].items():
        source_pin(args.provider_source / rel, value['sha256'])
    for rel, value in amendment['sources'].items():
        source_pin(args.provider_source / rel, value['sha256'])
    bound = json.loads(args.runtime_manifest.read_text())
    require(Path(bound['artifact']).resolve(strict=True) == args.artifact and bound['artifact_sha256'] == args.artifact_sha256
        and Path(bound['source_root']).resolve(strict=True) == args.provider_source, 'actual new source/artifact manifest mismatch')
    args.output.mkdir(mode=0o700)
    environment = {key: value for key, value in os.environ.items() if key not in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH', 'PYTHONPATH', 'PYTHONHOME')}
    environment['LD_LIBRARY_PATH'] = str(args.artifact.parent)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    command = [sys.executable, str(args.approver), '--manifest', str(args.runtime_manifest), '--library', str(args.artifact),
        '--include', str(Path(bound['install_root']) / 'include'), '--header', str(args.output / 'bound.hpp'), '--receipt', str(args.output / 'approval.json')]
    require(run_command(command, args.output / 'approval', environment) == 0, 'retained source-bound approver rejected candidate; a reviewed new catalog entry is required')
    approval = json.loads((args.output / 'approval.json').read_text())
    require(approval['artifact_sha256'] == args.artifact_sha256 and approval['manifest_sha256'] == digest(args.runtime_manifest), 'approver receipt did not bind actual input')
    gate_cases = []
    for name, artifact in [('absent', args.stock_provider), ('incorrect', args.wrong_marker)]:
        status = run_command([str(args.driver), str(artifact), digest(artifact), '--probe'], args.output / f'gate-{name}', environment)
        text = (args.output / f'gate-{name}.stdout').read_text()
        require(status == 2 and text.startswith('FAIL\t') and text.rstrip().endswith('admissions=0'), f'{name} capability did not reject before admission')
        require(('capability absent' if name == 'absent' else 'capability incorrect') in text, 'negative did not reach intended causal gate')
        gate_cases.append({'case': name, 'artifact_sha256': digest(artifact), 'exit': status, 'actual_admissions': 0})
    # A foreign object with marker1 must not authorize the LT-linked process.
    status = run_command([str(args.driver), str(args.foreign_marker), digest(args.foreign_marker), str(args.output / 'must-not-exist'),
        'V1Only', 'Plain', 'http://127.0.0.1:1/announce', 'udp://127.0.0.1:1/announce', 'rejected-before-owner'], args.output / 'gate-foreign', environment)
    text = (args.output / 'gate-foreign.stdout').read_text()
    require(status == 2 and 'LT version resolves to another object' in text and text.rstrip().endswith('admissions=0') and not (args.output / 'must-not-exist').exists(), 'foreign marker accepted before source identity')
    gate_cases.append({'case': 'foreign-marker1', 'artifact_sha256': digest(args.foreign_marker), 'exit': status, 'actual_admissions': 0})
    cases = []
    for mode in ('V1Only', 'V2Only', 'Both'):
        for mse in (False, True):
            print(f'Qualifying owned {mode} {"MSE" if mse else "plain"}', flush=True)
            cases.append(case(args, args.output, mode, mse, environment))
    result = {'status': 'PASS', 'source_provider_manifest_sha256': PROVIDER_MANIFEST,
        'upgrade_amendment_sha256': UPGRADE_MANIFEST, 'runtime_manifest_sha256': digest(args.runtime_manifest),
        'artifact_sha256': args.artifact_sha256, 'driver_sha256': digest(args.driver), 'approver_sha256': args.approver_sha256,
        'gate_cases': gate_cases, 'cases': cases, 'actual_handshake_observations': sum(len(row['observations']) for row in cases),
        'counter_fence_or_public_network_credit': False, 'original_java_equality_credit': False}
    result['outputs_sha256'] = {str(path.relative_to(args.output)): digest(path) for path in sorted(args.output.rglob('*')) if path.is_file()}
    save(args.output / 'result.json', result)
    print(json.dumps({'status': result['status'], 'cases': len(cases), 'actual_handshake_observations': result['actual_handshake_observations'],
        'artifact_sha256': args.artifact_sha256}, sort_keys=True), flush=True)

if __name__ == '__main__':
    main()
