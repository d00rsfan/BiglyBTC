from pathlib import Path
import hashlib,json
W=Path('/home/yurii/Java/BiglyBT/build/storage-20261025');B=W/'next-v2/provider-oracle';O=B/'amendments/final449'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'manifest.json')=='cbbbb31ee0f25ab00402114f87c6ce0b0471a67b40a2ddb2427966c96c82090a'
source=(B/'staging/run.py').read_text();(O/'before').mkdir(exist_ok=True);(O/'before/run.py').write_text(source)
s=source.replace('import hashlib\n','import hashlib\nimport importlib.util\n',1)
needle="UPGRADE_MANIFEST = '410be6d14469f7ebdaeec51f72562fc337a1c0a8f41ffadde6c022642c5e5278'\n"
assert s.count(needle)==1
root_review=sha(W/'provider-candidate/approval-r3/root-review.json')
s=s.replace(needle,needle+f'''
BASELINE_CAPSULE = 'cbbbb31ee0f25ab00402114f87c6ce0b0471a67b40a2ddb2427966c96c82090a'
PARENT_RECORD = '436931d4c6b87274c60b89877afedc19e06485bc4f04d120a3ab3e1889abfc66'
FINAL_MANIFEST = 'e74def09b2257a266786b8ddb116382d300716687bf26bbe57072f5ff90e8737'
FINAL_RECORD = '34bbba203833a31e59f0e9101f232fc2aaebe2bf080bdb8b640a29d68bd4016f'
FINAL_ARTIFACT = 'd367afd6499859c5a57d66bddd352a977ff76c7fb76b5925302c2c9008c7ddbd'
FINAL_APPROVER = '36146305c9df31bba21a8daff00151a0bd1570d48e366af080b06c61ab55b50c'
ROOT_REVIEW = '{root_review}'
OVERLAYS = {{
    'provider/manifest.json': PROVIDER_MANIFEST,
    'provider-oracle/handshake-amendment/manifest.json': UPGRADE_MANIFEST,
    'provider-counter/manifest.json': 'f10386b92e233ee02038f295419f2600d8f1e212201b5711d7ac11e2eca27770',
    'ordering-accounting/manifest.json': '1885dd0c620aeb1141f56b98ed820dd0312534c8d6b882220bcf6fb66b6db16d',
    'ordering-accounting/amendments/canonical-test-order/manifest.json': '35e56d8c2d20ebf1e0f2f342f65bc7510886d9e908f7b9c7977433bd961cfe5a',
}}
''',1)
start=s.index('\ndef main():')
helper='''
def baseline_module(name, path):
    # The original capsule and all its source bytes are pinned before this load.
    specification = importlib.util.spec_from_file_location(name, path)
    require(specification is not None and specification.loader is not None, 'cannot load frozen helper')
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def composed_sources(chapters, approval_root, actual_source):
    parent_path = source_pin(approval_root / 'source-build-record.json', PARENT_RECORD)
    parent = json.loads(parent_path.read_text())
    expected = dict(parent['source_sha256'])
    require(len(expected) == 444, 'wrong retained original source map')
    steps = []
    manifests = {}
    for rel, pin in OVERLAYS.items():
        path = source_pin(chapters / rel, pin)
        manifests[rel] = json.loads(path.read_text())

    def apply(label, items, before_root, after_root):
        for rel, value in items.items():
            leaf = Path(rel)
            require(not leaf.is_absolute() and '..' not in leaf.parts and str(leaf) == rel,
                'unsafe source-map leaf')
            before, after = value['before_sha256'], value['sha256']
            require(expected.get(rel) == before, f'overlay before-map mismatch: {label}: {rel}')
            if before is not None:
                source_pin(before_root / rel, before)
            else:
                require(rel not in expected, f'new overlay leaf already exists: {rel}')
            source_pin(after_root / rel, after)
            expected[rel] = after
            steps.append({'overlay': label, 'path': rel, 'before_sha256': before, 'sha256': after})

    apply('72865-wire', manifests['provider/manifest.json']['sources'],
        chapters / 'provider/before', chapters / 'provider/staging')
    apply('410be-upgrade', manifests['provider-oracle/handshake-amendment/manifest.json']['sources'],
        chapters / 'provider-oracle/handshake-amendment/before', chapters / 'provider-oracle/handshake-amendment/staging')
    apply('f103-counter', manifests['provider-counter/manifest.json']['sources']['provider'],
        chapters / 'provider-counter/provider/before', chapters / 'provider-counter/provider/staging')
    apply('1885-order', manifests['ordering-accounting/manifest.json']['provider_sources'],
        chapters / 'ordering-accounting/provider/before', chapters / 'ordering-accounting/provider/staging')
    canonical = manifests['ordering-accounting/amendments/canonical-test-order/manifest.json']
    key = 'provider/staging/test/test_biglybtc_utf16_info.cpp'
    apply('35e56-canonical-fixture', {'test/test_biglybtc_utf16_info.cpp': canonical['subjects'][key]},
        chapters / 'ordering-accounting/amendments/canonical-test-order/before/provider/staging',
        chapters / 'ordering-accounting/amendments/canonical-test-order/provider/staging')
    require(len(expected) == 449, 'composed final selected-source count differs')
    record_path = source_pin(approval_root / 'provider-source-build-record.json', FINAL_RECORD)
    record = json.loads(record_path.read_text())
    require(record['parent_record_sha256'] == PARENT_RECORD and record['overlay_manifests_sha256'] == OVERLAYS
        and record['source_sha256'] == expected, 'final build record differs from composed overlays')
    for rel, pin in expected.items():
        source_pin(actual_source / rel, pin)
    return {'parent_record_sha256': PARENT_RECORD, 'overlay_manifests_sha256': OVERLAYS,
        'final_source_record_sha256': FINAL_RECORD, 'selected_source_files': len(expected),
        'source_map_sha256': hashlib.sha256(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'steps': steps}

'''
s=s[:start]+helper+s[start:]
old="""    capsule = json.loads((here.parent / 'manifest.json').read_text())
    for rel, expected in capsule['artifacts'].items():
        source_pin(here.parent / rel, expected)
    from trackers import Trackers
    from wire_peers import Wire, initiate, respond
"""
new="""    capsule = json.loads((here.parent / 'manifest.json').read_text())
    for rel, expected in capsule['artifacts'].items():
        source_pin(here.parent / rel, expected)
    baseline = here.parents[2]  # .../provider-oracle/amendments/final449/staging
    source_pin(baseline / 'manifest.json', BASELINE_CAPSULE)
    original = json.loads((baseline / 'manifest.json').read_text())
    for rel, expected in original['artifacts'].items():
        source_pin(baseline / rel, expected)
    trackers = baseline_module('biglybtc_final449_trackers', baseline / 'staging/trackers.py')
    peers = baseline_module('biglybtc_final449_wire_peers', baseline / 'staging/wire_peers.py')
    Trackers = trackers.Trackers
    Wire, initiate, respond = peers.Wire, peers.initiate, peers.respond
"""
assert s.count(old)==1;s=s.replace(old,new,1)
start=s.index("    provider = here.parent.parent / 'provider'");end=s.index('    bound = json.loads(args.runtime_manifest.read_text())',start)
s=s[:start]+'''    source_pin(args.runtime_manifest, FINAL_MANIFEST)
    require(args.artifact_sha256 == FINAL_ARTIFACT and args.artifact.stat().st_size == 9072560,
        'not the exact root-reviewed final449 artifact')
    require(args.approver_sha256 == FINAL_APPROVER, 'not the exact final449 standalone approver')
    approval_root = args.runtime_manifest.parent
    source_pin(approval_root / 'root-review.json', ROOT_REVIEW)
    source_composition = composed_sources(baseline.parent, approval_root, args.provider_source)
'''+s[end:]
s=s.replace("    args.output.mkdir(mode=0o700)\n","    args.output.mkdir(mode=0o700)\n    save(args.output / 'source-composition.json', source_composition)\n",1)
needle="    result['outputs_sha256'] = {str(path.relative_to(args.output)): digest(path) for path in sorted(args.output.rglob('*')) if path.is_file()}"
s=s.replace(needle,"    result['final449_source_composition'] = source_composition\n"+needle,1)
(O/'staging/run.py').write_text(s)
print('runner',sha(O/'staging/run.py'),'root-review',root_review)
