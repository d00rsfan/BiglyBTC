// Target-private real DSO fixtures, never part of a shipping dependency catalog.
#ifndef BIGLYBTC_MARKER_VALUE
#error Missing fixture value
#endif
extern "C" __attribute__((visibility("default"))) unsigned biglybtc_swarm_mask_abi_v1() noexcept
{
 return BIGLYBTC_MARKER_VALUE;
}
