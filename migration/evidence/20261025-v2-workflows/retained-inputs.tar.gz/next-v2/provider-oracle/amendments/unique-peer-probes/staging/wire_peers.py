"""Finite owned numeric-loopback BT/MSE fixture; no routing or discovery.
MSE DH modulus/key directions/1024 discard follow pinned LT pe_crypto.cpp.
Raw socket TX/RX and decrypted handshakes are retained, never inferred from flags.
"""
import hashlib
import itertools
import json
import secrets
import socket
import struct
from pathlib import Path

PRIME = int('FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A63A36210000000000090563', 16)
PEER_IDS = itertools.count(1)

def sha(value):
    return hashlib.sha1(value).digest()

class RC4:
    def __init__(self, key):
        self.state = list(range(256)); j = 0
        for i in range(256):
            j = (j + self.state[i] + key[i % len(key)]) & 255
            self.state[i], self.state[j] = self.state[j], self.state[i]
        self.i = self.j = 0
        self.crypt(bytes(1024))

    def crypt(self, data):
        out = bytearray()
        for value in data:
            self.i = (self.i + 1) & 255
            self.j = (self.j + self.state[self.i]) & 255
            self.state[self.i], self.state[self.j] = self.state[self.j], self.state[self.i]
            out.append(value ^ self.state[(self.state[self.i] + self.state[self.j]) & 255])
        return bytes(out)

class Wire:
    def __init__(self, sock, capture):
        self.sock = sock; self.capture = Path(capture)
        # A previous owned probe may still be completing asynchronous EOF.
        # Identity belongs to this real connection, not the whole test process.
        self.peer_id = b'-BTCQF1-' + f'{next(PEER_IDS):012d}'.encode('ascii')
        if len(self.peer_id) != 20:
            raise ValueError('owned probe peer identity exhausted')
        self.tx = bytearray(); self.rx = bytearray()
        self.record = {'scope': 'actual loopback socket bytes and decoded handshake'}
        self.sock.settimeout(5)

    def send(self, data):
        view = memoryview(data)
        while view:
            n = self.sock.send(view)
            if n <= 0:
                raise EOFError('socket send closed')
            self.tx.extend(view[:n]); view = view[n:]

    def take(self, count):
        out = bytearray()
        while len(out) < count:
            chunk = self.sock.recv(count - len(out))
            if not chunk:
                raise EOFError('socket closed before handshake')
            self.rx.extend(chunk); out.extend(chunk)
        return bytes(out)

    def scan(self, marker, maximum_padding=512):
        seen = bytearray()
        while len(seen) < maximum_padding + len(marker):
            seen.extend(self.take(1))
            if seen.endswith(marker):
                return len(seen) - len(marker)
        raise ValueError('MSE sync exceeds source bound')

    def finish(self, outcome, error=None):
        self.record.update(outcome=outcome, tx_bytes=len(self.tx), rx_bytes=len(self.rx))
        if error is not None:
            self.record['exception'] = str(error)
        self.capture.with_suffix('.tx.bin').write_bytes(self.tx)
        self.capture.with_suffix('.rx.bin').write_bytes(self.rx)
        self.capture.with_suffix('.json').write_text(json.dumps(self.record, indent=2) + '\n')
        self.sock.close()


def handshake(key, peer_id, upgrade=False):
    if len(key) != 20 or len(peer_id) != 20:
        raise ValueError('BT key and peer identity must be exactly20 bytes')
    reserved = bytearray(8)
    # No extension/FAST/DHT claims; optional v2 upgrade hint only for that probe.
    if upgrade:
        reserved[7] = 0x10
    return b'\x13BitTorrent protocol' + reserved + key + peer_id


def parsed(raw):
    if len(raw) != 68 or raw[:20] != b'\x13BitTorrent protocol':
        raise ValueError('not an actual68-byte BT handshake')
    return {'hex': raw.hex(), 'info_hash': raw[28:48].hex(),
            'reserved': raw[20:28].hex(), 'peer_id': raw[48:].hex()}


def secret(remote, private):
    value = int.from_bytes(remote, 'big')
    if not 1 < value < PRIME - 1:
        raise ValueError('invalid fixture DH public value')
    return pow(value, private, PRIME).to_bytes(96, 'big')


def initiate(wire, key, mse, upgrade=False):
    sent = handshake(key, wire.peer_id, upgrade)
    wire.record.update(role='initiator', mse=mse, sent_handshake=parsed(sent))
    if not mse:
        wire.send(sent); received = wire.take(68)
    else:
        private = secrets.randbits(160) + 2
        wire.send(pow(2, private, PRIME).to_bytes(96, 'big'))
        shared = secret(wire.take(96), private)
        enc = RC4(sha(b'keyA' + shared + key)); dec = RC4(sha(b'keyB' + shared + key))
        obscured = bytes(a ^ b for a, b in zip(sha(b'req2' + key), sha(b'req3' + shared)))
        wire.send(sha(b'req1' + shared) + obscured + enc.crypt(bytes(8) + struct.pack('>IHH', 2, 0, 68) + sent))
        # Advance the cipher exactly across the source's8-byte VC. Padding
        # preceding encrypted VC is unencrypted and must not consume RC4.
        padding = wire.scan(dec.crypt(bytes(8)))
        chosen, n = struct.unpack('>IH', dec.crypt(wire.take(6)))
        if chosen != 2 or n > 512:
            raise ValueError('fixture requires actual RC4 MSE')
        dec.crypt(wire.take(n)); received = dec.crypt(wire.take(68))
        wire.record.update(dh_bytes=96, pad_b=padding, pad_d=n, crypto_select=chosen)
    wire.record['received_handshake'] = parsed(received)
    return received


def respond(wire, keys, mse):
    wire.record.update(role='responder', mse=mse)
    if not mse:
        received = wire.take(68); key = bytes.fromhex(parsed(received)['info_hash'])
        if key not in keys:
            raise ValueError('outgoing plain handshake uses unexpected swarm')
        sent = handshake(key, wire.peer_id); wire.send(sent)
    else:
        private = secrets.randbits(160) + 2
        shared = secret(wire.take(96), private)
        wire.send(pow(2, private, PRIME).to_bytes(96, 'big'))
        padding = wire.scan(sha(b'req1' + shared))
        obscured = wire.take(20)
        candidates = [key for key in keys if obscured == bytes(a ^ b for a, b in zip(sha(b'req2' + key), sha(b'req3' + shared)))]
        if len(candidates) != 1:
            raise ValueError('outgoing MSE key does not identify exactly one allowed swarm')
        key = candidates[0]
        dec = RC4(sha(b'keyA' + shared + key)); enc = RC4(sha(b'keyB' + shared + key))
        constant, offered, n = struct.unpack('>8sIH', dec.crypt(wire.take(14)))
        if constant != bytes(8) or not offered & 2 or n > 512:
            raise ValueError('invalid source MSE provide/VC/padding')
        tail = dec.crypt(wire.take(n + 2)); ia = struct.unpack('>H', tail[-2:])[0]
        if ia != 68:
            raise ValueError('expected actual source68-byte initial handshake')
        received = dec.crypt(wire.take(ia)); actual_key = bytes.fromhex(parsed(received)['info_hash'])
        if actual_key != key:
            raise ValueError('MSE SKEY and decoded BT hash disagree')
        sent = handshake(key, wire.peer_id)
        wire.send(enc.crypt(bytes(8) + struct.pack('>IH', 2, 0) + sent))
        wire.record.update(dh_bytes=96, pad_a=padding, pad_c=n, crypto_select=2, actual_skey=key.hex())
    wire.record.update(sent_handshake=parsed(sent), received_handshake=parsed(received))
    return received
