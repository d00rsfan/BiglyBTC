"""Owned127.0.0.1 HTTP/BEP15 trackers. Preserve actual request bytes."""
import http.server
import json
import socket
import struct
import threading
import urllib.parse
from pathlib import Path

EVENTS = {0: 'none', 1: 'completed', 2: 'started', 3: 'stopped'}

def bencode(value):
    if isinstance(value, int):
        return b'i' + str(value).encode('ascii') + b'e'
    if isinstance(value, bytes):
        return str(len(value)).encode('ascii') + b':' + value
    if isinstance(value, dict):
        return b'd' + b''.join(bencode(k) + bencode(value[k]) for k in sorted(value)) + b'e'
    raise TypeError(type(value))

class Trackers:
    def __init__(self, root):
        self.root = Path(root); self.lock = threading.Lock()
        self.records = []; self.errors = []; self.stopping = threading.Event()
        outer = self
        class Handler(http.server.BaseHTTPRequestHandler):
            def setup(self):
                super().setup(); self.connection.settimeout(5)
            def log_message(self, *args):
                pass
            def do_GET(self):
                try:
                    parsed = urllib.parse.urlsplit(self.path)
                    pairs = [entry.split('=', 1) for entry in parsed.query.split('&') if entry]
                    fields = {}
                    for key, value in pairs:
                        fields.setdefault(urllib.parse.unquote_to_bytes(key), []).append(urllib.parse.unquote_to_bytes(value))
                    hashes = fields.get(b'info_hash', [])
                    if not hashes or any(len(key) != 20 for key in hashes):
                        raise ValueError('HTTP tracker did not receive20-byte info_hash')
                    scrape = parsed.path == '/scrape'
                    event = fields.get(b'event', [b'none'])[0].decode('ascii')
                    if not scrape and parsed.path != '/announce':
                        raise ValueError('unexpected owned tracker path')
                    outer.record({'transport': 'http', 'action': 'scrape' if scrape else 'announce',
                        'event': event, 'hashes': [key.hex() for key in hashes]}, self.raw_requestline)
                    if scrape:
                        response = bencode({b'files': {key: {b'complete': 1, b'downloaded': 0, b'incomplete': 0} for key in hashes}})
                    else:
                        response = bencode({b'interval': 3600, b'min interval': 1, b'complete': 1, b'incomplete': 0, b'peers': b''})
                    self.send_response(200); self.send_header('Content-Length', str(len(response))); self.end_headers(); self.wfile.write(response)
                except Exception as exc:
                    outer.errors.append(str(exc)); self.send_error(400)
        self.http = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.http.daemon_threads = False
        self.udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.udp.bind(('127.0.0.1', 0)); self.udp.settimeout(.2)
        self.threads = [threading.Thread(target=self.http.serve_forever), threading.Thread(target=self.udp_loop)]
        for thread in self.threads:
            thread.start()

    @property
    def urls(self):
        return (f'http://127.0.0.1:{self.http.server_port}/announce', f'udp://127.0.0.1:{self.udp.getsockname()[1]}/announce')

    def record(self, value, raw):
        with self.lock:
            value = dict(value); value['sequence'] = len(self.records) + 1
            name = f"{value['sequence']:04}-{value['transport']}-{value['action']}.bin"
            (self.root / name).write_bytes(raw); value['raw'] = name
            self.records.append(value)
            (self.root / 'requests.json').write_text(json.dumps(self.records, indent=2) + '\n')

    def udp_loop(self):
        connection = 0x4254435146495854
        while not self.stopping.is_set():
            try:
                data, peer = self.udp.recvfrom(2048)
                if peer[0] != '127.0.0.1' or len(data) < 16:
                    raise ValueError('nonowned/short UDP request')
                identifier, action, transaction = struct.unpack('>QII', data[:16])
                if action == 0:
                    if identifier != 0x41727101980 or len(data) != 16:
                        raise ValueError('invalid actual UDP connect')
                    self.record({'transport': 'udp', 'action': 'connect', 'event': 'none', 'hashes': []}, data)
                    reply = struct.pack('>IIQ', 0, transaction, connection)
                elif action == 1:
                    if identifier != connection or len(data) < 98:
                        raise ValueError('invalid actual UDP announce')
                    event = struct.unpack('>I', data[80:84])[0]
                    if event not in EVENTS:
                        raise ValueError('invalid UDP event')
                    self.record({'transport': 'udp', 'action': 'announce', 'event': EVENTS[event], 'hashes': [data[16:36].hex()]}, data)
                    reply = struct.pack('>IIIII', 1, transaction, 3600, 0, 1)
                elif action == 2:
                    if identifier != connection or (len(data) - 16) % 20 or len(data) == 16:
                        raise ValueError('invalid actual UDP scrape')
                    hashes = [data[i:i + 20] for i in range(16, len(data), 20)]
                    self.record({'transport': 'udp', 'action': 'scrape', 'event': 'none', 'hashes': [key.hex() for key in hashes]}, data)
                    reply = struct.pack('>II', 2, transaction) + b''.join(struct.pack('>III', 1, 0, 0) for _ in hashes)
                else:
                    raise ValueError('unexpected UDP tracker action')
                self.udp.sendto(reply, peer)
            except socket.timeout:
                continue
            except OSError as exc:
                if not self.stopping.is_set():
                    self.errors.append(str(exc))
            except Exception as exc:
                self.errors.append(str(exc))

    def snapshot(self):
        with self.lock:
            return [dict(row) for row in self.records]

    def close(self):
        self.stopping.set(); self.http.shutdown(); self.http.server_close()
        for thread in self.threads:
            thread.join(timeout=3)
            if thread.is_alive():
                raise RuntimeError('owned tracker thread did not join')
        self.udp.close()
