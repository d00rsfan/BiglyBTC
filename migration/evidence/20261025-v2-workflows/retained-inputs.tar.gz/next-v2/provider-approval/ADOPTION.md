Additional provider approval lane — source only

This capsule does not approve a provider. No DSO hash, build result, record hash or real manifest hash was known when it was authored. It does not load a library, run a target, change native files, or change old approval records. The current c35f artifact/catalog and both existing instrumented lanes remain intact.

Two gates remain separate:

1. prepare_record.py records the ACTUAL completed owned build and emits an unadopted verifier amendment with ONE literal manifest SHA and ONE literal record SHA. It cannot compile, repair, run or approve the candidate. Its only child commands are /usr/bin/readelf static byte inspections.
2. Root independently reviews the actual record, maps, ELF evidence and literal amendment, then adopts the source catalog change for qualification only. Existing loaded-object identity/hash/export checks and actual wire/counter/storage/causal testing remain required. The manifest and configure receipt always say causal_qualified=false. No ordinary build, capability marker or record generator can mint a settled receipt.

Expected exact inputs

- Original LT740a0b9aeabe00e762cc0efe4a0f27593db2550b and unchanged parent record436931d4c6b87274c60b89877afedc19e06485bc4f04d120a3ab3e1889abfc66.
- Frozen swarm72865b63…, incoming-upgrade410be6d1…, counterf10386b9… source capsules. The source maps in expected-inputs.json were computed from the pristine full source plus ONLY these overlays. No candidate tree supplied its own expected hashes.
- Selected source map447: old444 plus the two public extension headers and test/test_biglybtc_swarm.cpp. Complete source-tree inventory1070: pristine1067 plus those same three new leaves. Thirteen unchanged build-rule leaves; sixteen unchanged bundled-dependency leaves. Whole-tree equality rejects extra, missing, symlinked or changed source leaves.
- Installed inventory284: the old282 keys plus include/libtorrent/biglybtc_swarm.hpp and biglybtc_payload_counters.hpp. Installed headers must equal source bytes. Only the two original .so SONAME aliases are allowed as internal symlinks. The future DSO, package-config and CMake export file digests are measured after build, never inherited from c35f.
- Four legacy build-evidence leaves retained: CMakeCache.txt, build.ninja, .ninja_log, install_manifest.txt. Entire cache is recorded and checked; original source ABI/options stay equal, with build_tests=ON intentionally changed for the real provider unit target. Source/build/install roots are exact canonical isolated sibling directories. No relocation exception is added for a new artifact.
- Actual build-source-map.json must equal the expected447 map. Actual build-r1-receipt.json must contain successful configure/build/install stages with exact durable log hashes, and bind the whole torrent-rasterbar + test_biglybtc_swarm targets. No source-only test definition is counted as an executed test.
- Static ELF evidence must contain the old six original guard functions, the swarm capability and both counter exports as unique defined default-visible functions, with SONAME libtorrent-rasterbar.so.2.0. Capability RETURN VALUES and correct behavior are not proven by static symbol inspection.

Any changed count, source repair, extra build rule, compiler/config ABI or install inventory must fail this producer and receive a narrow new source amendment. Do not change expected maps to match arbitrary output. In particular, this lane is not an approval path for an instrumented overlay: that requires its own explicit source/catalog qualification.

Root-only post-build command (after all provider compilation/install has stopped)

    python3 /home/yurii/Java/BiglyBT/build/storage-20261025/next-v2/provider-approval/prepare_record.py \
      --candidate /home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate \
      --output /home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/approval-r1 \
      --parent-record /home/yurii/Java/BiglyBTC/preview/native/engine/runtime-binding/source-build-record.json

The new output directory must not exist. Every input check, source/install/build reread and static ELF scan finishes before this directory is created. Failure changes neither source/build/install nor existing catalog. All output is limited to the NEW explicit approval-N child. A failed partial output directory is not reused; keep it and choose a new name.

Post-build output fields and review

- provider-source-build-record.json: exact roots, complete1070/selected447/rules13/bundled16 maps, actual284 install map and4 build map, full cache, actual artifact path/size/SHA, immutable parent+three overlay identities, actual receipt/source-map/log pins, static ELF exports/SONAME evidence pins and recorder source pin. Status SOURCE_BUILT_PROVIDER_CANDIDATE_NOT_RUNTIME_QUALIFIED.
- provider-runtime.json: the existing strict11-key manifest schema; source_build_record is provider-source-build-record.json, source_build_record_sha256 is the actual record hash, all roots/artifact values are exact actual inputs, purpose remains source-bound-qualification-only, causal_qualified=false.
- source-build-record.json: exact unchanged original parent copy for independent standalone verification. Static provider-dynamic-symbols.txt/provider-dynamic-section.txt are raw readelf output.
- staging/engine/runtime-binding/verify_runtime_manifest.py and verify_provider_runtime.py plus approval.patch: literal future manifest/record SHA only. No environment variable, CMake argument, runtime string, candidate-supplied map or wildcard can choose an approved SHA. recording-receipt.json pins all generated leaves and explicitly records no adoption/runtime qualification.

Before adopting any catalog source, root reviews these outputs against actual build receipts/artifact/source. The staged outer verifier only adds a new equality branch and new-candidate receipt branch; removing the added nodes recovers the OLD verifier byte-for-byte. Its old APPROVED table, old/instrumented branches, helper bodies and legacy receipts are untouched. Existing approval/test bytes are pinned in source-pins.json. The unfilled templates in this capsule cannot accept a candidate: UNAPPROVED_PROVIDER_MANIFEST/RECORD are not SHA digests.

After root approves the exact staged constants, first invoke the STAGED verifier (no target execution):

    python3 APPROVAL/staging/engine/runtime-binding/verify_runtime_manifest.py \
      --manifest APPROVAL/provider-runtime.json \
      --library CANDIDATE/install/lib/libtorrent-rasterbar.so.2.0.12 \
      --include CANDIDATE/install/include \
      --header APPROVAL/qualification-config.hpp \
      --receipt APPROVAL/configure-verification.json

Then adopt only the reviewed two verifier source paths and exact data records/evidence as root's source checkpoint requires. The old verifier is expected to reject this new manifest before that amendment. Missing record/parent/log/source, incomplete stages, additional source/install files, wrong installed header, changed build evidence, wrong imported SDK/DSO, wrong ELF scans or any edited record must reject without generating a successful configure header.

The wire harness approver CLI remains the existing --manifest/--library/--include/--header/--receipt API. The additional configure receipt reports447 selected source,1070 complete source,13 rules,16 bundled,284 install and4 build leaves. Old receipts retain444/13/282/4 or their existing instrumented446/14/283/5 values exactly.

This is Linux qualification tooling, not a portable dependency release or transitive compiler/OpenSSL/Boost reproducibility claim. Post-build writes/reconfiguration that change .ninja_log or any other bound leaf require a new reviewed record and new exact SHA amendment. The application runtime guard still checks actual loaded mappings, all required exports, named path/device/inode/hash before and after. New source approval does not extend c35f's relocation exception or weaken any storage/counter fence.
