Exact ordering overlay / r2 evidence amendment — source only

Use this COMPLETE standalone recorder in place of the frozen447 baseline. The baseline b73ff812359e2154e10c77c977cb72127d62085c0187d72d4fcea3193a2f8912 remains byte-exact. All safety/adoption requirements in its ADOPTION.md remain; this amendment changes only the explicitly pinned source overlay/counts and actual r2 evidence names. No actual artifact, record or manifest SHA is guessed or approved here.

Additional immutable source input is Codec ordering-accounting/manifest.json1885dd0c620aeb1141f56b98ed820dd0312534c8d6b882220bcf6fb66b6db16d. Its provider slice replaces src/torrent_info.cpp, adds src/biglybtc_utf16_info.hpp and test/test_biglybtc_utf16_info.cpp. These three exact before/after hashes are checked against the prior expected source map. The private helper and new test increase selected447→449 and complete1070→1072; build rules13, bundled16, installed284 and build-evidence4 stay fixed. No provider CMake/public-header/ABI or global decoder change is authorized by this amendment.

The final449 map is original444 plus two public extension headers, two provider test sources and the private ordering helper. It is NOT derived from whatever the candidate happens to contain. The full1072 map is the previously frozen complete source tree plus only the same exact three-path overlay. Every extra/missing/changed source leaf rejects; installed SDK must still equal actual pinned source headers. The verifier's two map digests and fourth overlay-manifest pin are literal source constants. Manifest/record approval literals remain non-digest UNAPPROVED placeholders until the post-build recorder runs.

Root records a real same-options configure, affected cached build and install as:

    CANDIDATE/build-r2-receipt.json
    CANDIDATE/build-source-map-r2.json
    CANDIDATE/configure-r2.log
    CANDIDATE/build-r2.log
    CANDIDATE/install-r2.log

The receipt is the same three-element stage/command/exit/seconds/log_sha256 schema as r1. All stages must have actual exit0 and matching raw log hashes; the configured source/build roots must match. The actual build command must include torrent-rasterbar, test_biglybtc_swarm and test_biglybtc_utf16_info. The explicit reconfigure is required because upstream discovers test_*.cpp using a configure-time GLOB. Preserve all r1 logs/map/receipt and the pre-r2 artifact independently. Nothing here rewrites them or invents configure/test credit.

After all provider compilation/install is finished, root runs ONLY this recorder:

    python3 /home/yurii/Java/BiglyBT/build/storage-20261025/next-v2/provider-approval/amendments/ordering-r2/prepare_record.py \
      --candidate /home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate \
      --output /home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/approval-r2 \
      --parent-record /home/yurii/Java/BiglyBTC/preview/native/engine/runtime-binding/source-build-record.json

No compiler, loader, target binary or network action is invoked. Static readelf inspection and stable byte rereads precede creation of the NEW output directory. The result is still an unadopted record/manifest and a staged verifier amendment containing only the actual future manifest/record SHA. The old outer verifier must continue rejecting the candidate until root independently reviews and adopts those exact source constants. The new configure receipt reports449/full1072/13/16/284/4; old approval tables, branches, test scripts and old receipt counts stay unchanged.

The generated source/runtime record keys and standalone verifier CLI are unchanged from the baseline. Review the output recording-receipt.json, actual source/build/install maps, full artifact hash/size, ELF exports, both capability runtime probes and source-bound wire/counter/storage qualification independently. A source record or successful static ELF scan is never wire behavior, Java equality, counter-fence or causally qualified execution evidence. Current c35f, its relocation exception and all old catalogs remain untouched.
