#!/usr/bin/env python3
"""Root-only post-build recorder. Reads artifacts; stages ONE unadopted approval.

No compiler, target binary, loader, network, native tree or existing catalog is
invoked/written. readelf only inspects bytes. Review the actual outputs before
adopting their literal SHA-pinned verifier amendment.
"""
import argparse
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
TEMPLATES = HERE / "staging/engine/runtime-binding"
SPEC_SHA = "1faf9a6b24f8c13985ef21acdaf1f921aed56a69220ee1e6e65eb693da3b1a97"
TEMPLATE_PINS = {
    "verify_runtime_manifest.py": "5129f040462d123a1732a89e356b4b21174633717d700730655cf6b5cce735f8",
    "verify_provider_runtime.py": "5e6486fda9bce79dd074fbd3b4cfa9cd14d3da53a27a583ed5dfb675157d83cb",
}
BASE_TEMPLATE_SHA = "8dd7d9c6894d6fe5f8139657e700e94c4854638e67a72169821ef60dc40c42d9"
PARENT_SHA = "436931d4c6b87274c60b89877afedc19e06485bc4f04d120a3ab3e1889abfc66"


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(65536):
            result.update(block)
    return result.hexdigest()


def regular(path):
    if path.is_symlink() or not path.is_file() or path != path.resolve(strict=True):
        raise ValueError("Expected exact canonical regular file: " + str(path))
    return path


def directory(path):
    if path.is_symlink() or not path.is_dir() or path != path.resolve(strict=True):
        raise ValueError("Expected exact canonical directory: " + str(path))
    return path


def encoded(value):
    return (json.dumps(value, indent=2) + "\n").encode()


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("Template anchor changed")
    return text.replace(old, new)


def file_map(root, names):
    return {name: digest(root / name) for name in sorted(names)}


def inspect_elf(artifact, option):
    # Static ELF inspection, not ld.so/ldd or a target invocation.
    result = subprocess.run(["/usr/bin/readelf", option, "--wide", str(artifact)],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    if result.returncode or result.stderr or len(result.stdout) > 16 * 1024 * 1024:
        raise ValueError("Static ELF inspection failed")
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--parent-record", required=True, type=Path)
    args = parser.parse_args()
    candidate = directory(args.candidate)
    source, build, install = [directory(candidate / name) for name in ("source", "build", "install")]
    output = args.output
    if output.parent != candidate or not re.fullmatch(r"approval-[A-Za-z0-9_-]+", output.name) \
            or output.exists() or output.is_symlink():
        raise ValueError("Output must be a NEW approval-N directory immediately under candidate")
    parent_path = regular(args.parent_record)
    parent_bytes = parent_path.read_bytes()
    if hashlib.sha256(parent_bytes).hexdigest() != PARENT_SHA:
        raise ValueError("Wrong immutable original parent record")
    specification = regular(HERE / "expected-inputs.json")
    if digest(specification) != SPEC_SHA:
        raise ValueError("Changed independently pinned expected source inputs")
    expected = json.loads(specification.read_bytes())
    for name, sha in TEMPLATE_PINS.items():
        if digest(regular(TEMPLATES / name)) != sha:
            raise ValueError("Changed reviewed verifier template")
    if digest(regular(HERE / "before/engine/runtime-binding/verify_runtime_manifest.py")) != BASE_TEMPLATE_SHA:
        raise ValueError("Changed immutable old verifier beforeimage")
    spec = importlib.util.spec_from_file_location("provider_record_helpers", TEMPLATES / "verify_provider_runtime.py")
    tools = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tools)
    # No template inspect()/approval function runs. These utilities only parse
    # cache/ELF text and enumerate the exact source/install trees.
    if tools.tree_keys(source) != set(expected["source_inputs_sha256"]):
        raise ValueError("Missing/additional source-tree leaf")
    full_source = file_map(source, expected["source_inputs_sha256"])
    if full_source != expected["source_inputs_sha256"]:
        raise ValueError("Source differs from immutable original+three exact overlays")
    for key in ("source_sha256", "source_build_rules_sha256", "bundled_dependency_sha256"):
        if file_map(source, expected[key]) != expected[key]:
            raise ValueError("Changed expected compiled source/build/dependency input")
    if tools.tree_keys(install, True) != set(expected["installed_keys"]):
        raise ValueError("Install inventory must be exactly old282 plus two public headers")
    installed = file_map(install, expected["installed_keys"])
    for name, sha in installed.items():
        if name.startswith("include/") and full_source.get(name) != sha:
            raise ValueError("Installed SDK is not the exact candidate source")
    build_files = file_map(build, expected["build_keys"])
    cache = tools.cache_values(build / "CMakeCache.txt")
    required_cache = dict(expected["required_cache"])
    required_cache.update(CMAKE_HOME_DIRECTORY=str(source), libtorrent_SOURCE_DIR=str(source),
                          libtorrent_BINARY_DIR=str(build), CMAKE_CACHEFILE_DIR=str(build), CMAKE_INSTALL_PREFIX=str(install))
    if any(cache.get(key) != value for key, value in required_cache.items()):
        raise ValueError("Wrong source ABI/build options")
    receipt_path = regular(candidate / "build-r2-receipt.json")
    source_map_path = regular(candidate / "build-source-map-r2.json")
    if json.loads(source_map_path.read_bytes()) != expected["source_sha256"]:
        raise ValueError("Actual pre-build449 source map differs")
    receipt = json.loads(receipt_path.read_bytes())
    if not isinstance(receipt, list) or len(receipt) != 3:
        raise ValueError("Actual successful configure/build/install receipt required")
    logs = {}
    for row, stage in zip(receipt, ("configure", "build", "install")):
        if row.get("stage") != stage or type(row.get("exit")) is not int or row["exit"] != 0 \
                or not isinstance(row.get("command"), list) or not all(isinstance(x, str) for x in row["command"]):
            raise ValueError("Actual provider stage failed/incomplete")
        log = regular(candidate / (stage + "-r2.log"))
        logs[str(log)] = digest(log)
        if row.get("log_sha256") != logs[str(log)]:
            raise ValueError("Actual build log changed")
    configure, compile_command, install_command = [row["command"] for row in receipt]
    if configure[:5] != ["cmake", "-S", str(source), "-B", str(build)] \
            or ["cmake", "--install", str(build)] != install_command \
            or not all(value in compile_command for value in ("cmake", "--build", str(build), "torrent-rasterbar", "test_biglybtc_swarm", "test_biglybtc_utf16_info")):
        raise ValueError("Build receipt does not bind the actual source/build and complete required targets")
    artifact = regular(install / "lib/libtorrent-rasterbar.so.2.0.12")
    artifact_sha = digest(artifact)
    dynamic_symbols = inspect_elf(artifact, "--dyn-syms")
    dynamic_section = inspect_elf(artifact, "--dynamic")
    tools.exported_functions(dynamic_symbols.decode("utf-8", errors="strict"))
    if re.findall(r"\(SONAME\).*\[([^\]]+)\]", dynamic_section.decode("utf-8", errors="strict")) != ["libtorrent-rasterbar.so.2.0"]:
        raise ValueError("Wrong provider ELF SONAME")
    record = {
        "schema": 1, "status": "SOURCE_BUILT_PROVIDER_CANDIDATE_NOT_RUNTIME_QUALIFIED", "causal_qualified": False,
        "upstream_commit": expected["upstream_commit"], "parent_record_sha256": PARENT_SHA,
        "overlay_manifests_sha256": expected["overlay_manifests_sha256"],
        "source_root": str(source), "build_root": str(build), "install_root": str(install),
        "source_inputs_sha256": full_source, "source_sha256": expected["source_sha256"],
        "source_build_rules_sha256": expected["source_build_rules_sha256"],
        "bundled_dependency_sha256": expected["bundled_dependency_sha256"],
        "installed_sha256": installed, "build_files_sha256": build_files, "cache": cache,
        "artifact": str(artifact), "artifact_sha256": artifact_sha, "artifact_bytes": artifact.stat().st_size,
        "build_receipt": str(receipt_path), "build_receipt_sha256": digest(receipt_path),
        "build_source_map": str(source_map_path), "build_source_map_sha256": digest(source_map_path),
        "logs_sha256": logs, "required_exports": tools.EXPORTS, "elf_soname": "libtorrent-rasterbar.so.2.0",
        "export_scan_sha256": hashlib.sha256(dynamic_symbols).hexdigest(),
        "dynamic_section_sha256": hashlib.sha256(dynamic_section).hexdigest(), "recipe_sha256": digest(Path(__file__).resolve()),
    }
    if set(record) != tools.RECORD_KEYS:
        raise ValueError("Producer/verifier schema mismatch")
    raw_record = encoded(record); record_sha = hashlib.sha256(raw_record).hexdigest()
    manifest = {
        "schema": 1, "purpose": "source-bound-qualification-only", "causal_qualified": False,
        "source_build_record": "provider-source-build-record.json", "source_build_record_sha256": record_sha,
        "source_root": str(source), "build_root": str(build), "install_root": str(install),
        "artifact": str(artifact), "artifact_sha256": artifact_sha, "artifact_bytes": artifact.stat().st_size,
    }
    raw_manifest = encoded(manifest); manifest_sha = hashlib.sha256(raw_manifest).hexdigest()
    main_template = (TEMPLATES / "verify_runtime_manifest.py").read_text()
    provider_template = (TEMPLATES / "verify_provider_runtime.py").read_text()
    frozen_main = replace_once(main_template, 'PROVIDER_MANIFEST_SHA = "UNAPPROVED_PROVIDER_MANIFEST"',
                               'PROVIDER_MANIFEST_SHA = "' + manifest_sha + '"')
    frozen_provider = replace_once(provider_template, 'MANIFEST_SHA = "UNAPPROVED_PROVIDER_MANIFEST"',
                                   'MANIFEST_SHA = "' + manifest_sha + '"')
    frozen_provider = replace_once(frozen_provider, 'RECORD_SHA = "UNAPPROVED_PROVIDER_RECORD"',
                                   'RECORD_SHA = "' + record_sha + '"')
    # Recheck all bound trees/build evidence AFTER readelf, before any output.
    # This is a stable byte snapshot check, not a cross-file transaction claim.
    if tools.tree_keys(source) != set(full_source) or file_map(source, full_source) != full_source \
            or tools.tree_keys(install, True) != set(installed) or file_map(install, installed) != installed \
            or file_map(build, build_files) != build_files or digest(receipt_path) != record["build_receipt_sha256"] \
            or digest(source_map_path) != record["build_source_map_sha256"] \
            or any(digest(Path(path)) != sha for path, sha in logs.items()):
        raise ValueError("Provider/build inputs changed during recording")
    # Only new output leaves below the explicit owned candidate directory.
    output.mkdir()
    staged = output / "staging/engine/runtime-binding"; staged.mkdir(parents=True)
    (output / "provider-source-build-record.json").write_bytes(raw_record)
    (output / "provider-runtime.json").write_bytes(raw_manifest)
    (output / "source-build-record.json").write_bytes(parent_bytes)
    (output / "provider-dynamic-symbols.txt").write_bytes(dynamic_symbols)
    (output / "provider-dynamic-section.txt").write_bytes(dynamic_section)
    (staged / "verify_runtime_manifest.py").write_text(frozen_main)
    (staged / "verify_provider_runtime.py").write_text(frozen_provider)
    baseline = (HERE / "before/engine/runtime-binding/verify_runtime_manifest.py").read_text()
    patch = list(difflib.unified_diff(baseline.splitlines(True), frozen_main.splitlines(True),
                                    fromfile="a/engine/runtime-binding/verify_runtime_manifest.py",
                                    tofile="b/engine/runtime-binding/verify_runtime_manifest.py"))
    patch += list(difflib.unified_diff([], frozen_provider.splitlines(True), fromfile="/dev/null",
                                     tofile="b/engine/runtime-binding/verify_provider_runtime.py"))
    (output / "approval.patch").write_text("".join(patch))
    summary = {"status": "STAGED_EXACT_PINS_NOT_ADOPTED_NOT_RUNTIME_QUALIFIED", "manifest_sha256": manifest_sha,
               "record_sha256": record_sha, "artifact_sha256": artifact_sha, "artifact_bytes": record["artifact_bytes"],
               "source_files": 449, "full_source_files": 1072, "build_rules": 13, "bundled_inputs": 16,
               "installed_files": 284, "build_files": 4,
               "staged_sha256": {str(path.relative_to(output)): digest(path) for path in sorted(output.rglob("*")) if path.is_file()},
               "native_catalog_changed": False, "target_or_loader_executed": False, "causal_qualified": False}
    (output / "recording-receipt.json").write_bytes(encoded(summary))
    print(json.dumps({key: summary[key] for key in ("status", "manifest_sha256", "record_sha256", "artifact_sha256", "artifact_bytes")}, indent=2))


if __name__ == "__main__":
    main()
