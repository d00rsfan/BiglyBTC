Closed canonical fixture / r3 approval amendment — source only

This complete standalone recorder replaces ordering-r2 for the final build. All earlier capsules, logs and artifacts remain immutable. Only the one exact provider test leaf changes; production provider, ABI and source449/full1072/rules13/deps16/install284/build4 counts remain unchanged. The canonical-test-order source amendment is explicitly pinned in expected-inputs.json and both closed-map digests are recomputed from the previous frozen maps with only that leaf changed.

Only actual build-r3-receipt.json, build-source-map-r3.json and configure-r3.log/build-r3.log/install-r3.log are accepted. The required configure/build/install stages and target checks are preserved, including torrent-rasterbar, test_biglybtc_swarm and test_biglybtc_utf16_info. Retain r1/r2 evidence; do not rerecord it. Future record/manifest approvals remain UNAPPROVED until root runs the recorder and independently reviews its measured outputs. All earlier ADOPTION safety/qualification requirements continue to apply. No wildcard, dynamic catalog trust or current c35 approval change is introduced.

Root command after final build:

    python3 /home/yurii/Java/BiglyBT/build/storage-20261025/next-v2/provider-approval/amendments/canonical-r3/prepare_record.py \
      --candidate /home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate \
      --output /home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/approval-r3 \
      --parent-record /home/yurii/Java/BiglyBTC/preview/native/engine/runtime-binding/source-build-record.json

Author checks only: prior capsule hash map exact; closed maps differ at exactly the corrected test leaf; three Python files AST-parsed without imports/execution. No build, loader, test, network, native/dependency or approval mutation performed.
