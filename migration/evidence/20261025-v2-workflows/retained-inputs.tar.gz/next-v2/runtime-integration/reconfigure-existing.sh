#!/usr/bin/env bash
set -eu
# SOURCE ONLY. Root runs ONLY after adopting and qualifying the exact provider overlay.
NATIVE_SOURCE=/home/yurii/Java/BiglyBTC/preview/native
PROVIDER_INSTALL=/home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/install
SELECTED_MANIFEST="$NATIVE_SOURCE/engine/runtime-binding/provider-runtime.json"

cmake -S "$NATIVE_SOURCE" -B "/home/yurii/Java/BiglyBTC/build/persistent-peer-accounting-20261021/bound-gcc" \
  -DLibtorrentRasterbar_DIR:PATH="$PROVIDER_INSTALL/lib/cmake/LibtorrentRasterbar" \
  -DCMAKE_PREFIX_PATH:STRING="/home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/install;/home/yurii/Java/BiglyBTC/build/dependencies/sysroot/usr;/home/yurii/Java/BiglyBTC/build/dependencies/country/sysroot/usr;/opt/Qt/6.12.0/gcc_64" \
  -DBIGLYBTC_PERSISTENT_RUNTIME_MANIFEST:FILEPATH="$SELECTED_MANIFEST" \
  -DBIGLYBTC_PAYLOAD_COUNTER_TEST_LANE:STRING=Qualified

cmake -S "$NATIVE_SOURCE" -B "/home/yurii/Java/BiglyBTC/build/saved-services-20261018/clang" \
  -DLibtorrentRasterbar_DIR:PATH="$PROVIDER_INSTALL/lib/cmake/LibtorrentRasterbar" \
  -DCMAKE_PREFIX_PATH:STRING="/home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/install;/home/yurii/Java/BiglyBTC/build/dependencies/sysroot/usr;/home/yurii/Java/BiglyBTC/build/dependencies/country/sysroot/usr;/opt/Qt/6.12.0/gcc_64" \
  -DBIGLYBTC_PERSISTENT_RUNTIME_MANIFEST:FILEPATH="$SELECTED_MANIFEST" \
  -DBIGLYBTC_PAYLOAD_COUNTER_TEST_LANE:STRING=Qualified

cmake -S "$NATIVE_SOURCE" -B "/home/yurii/Java/BiglyBTC/build/saved-services-20261018/sanitized-desktop" \
  -DLibtorrentRasterbar_DIR:PATH="$PROVIDER_INSTALL/lib/cmake/LibtorrentRasterbar" \
  -DCMAKE_PREFIX_PATH:STRING="/home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/install;/home/yurii/Java/BiglyBTC/build/dependencies/sysroot/usr;/home/yurii/Java/BiglyBTC/build/dependencies/country/sysroot/usr;/opt/Qt/6.12.0/gcc_64" \
  -DBIGLYBTC_PERSISTENT_RUNTIME_MANIFEST:FILEPATH="$SELECTED_MANIFEST" \
  -DBIGLYBTC_PAYLOAD_COUNTER_TEST_LANE:STRING=Qualified
