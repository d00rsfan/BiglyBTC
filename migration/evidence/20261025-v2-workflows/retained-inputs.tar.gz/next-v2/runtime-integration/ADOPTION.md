Exact selected provider app/portable integration — SOURCE ONLY

Base is immutable future55 final-manifest c9d45a3b6e5eea71d42ab2246735a34b0f6fc5369c22f0c4bd318d6a0ee0ee0d, falling back to current native files where future55 has no leaf. All before-images and deltas are included. This capsule has NOT been adopted, configured, built, loaded or tested by its author. Root adopts only after the current milestone is published and the new provider's separate actual wire/counter/storage qualifications pass. The root-reviewed source record is qualification binding, not runtime success.

Exact additional lane

* Manifest e74def09b2257a266786b8ddb116382d300716687bf26bbe57072f5ff90e8737.
* Source record 34bbba203833a31e59f0e9101f232fc2aaebe2bf080bdb8b640a29d68bd4016f.
* Complete9072560-byte uninstrumented provider d367afd6499859c5a57d66bddd352a977ff76c7fb76b5925302c2c9008c7ddbd.
* Closed449/full1072/rules13/bundled16/installed284/build4 proof; actual r3 configure/build/install receipts and raw static ELF scans. No wildcard, version match, capability match or environment override can substitute for these inputs.

The staged main/module are byte-exact copies of the independently root-reviewed approval-r3 outputs. New record/manifest and both ELF scans sit beside existing source-build-record.json, whose436931 bytes are REQUIRED and untouched. Every old c35/instrumented branch, catalog entry and receipt path remains; removing the added catalog constant and two provider branches recovers the old verifier exactly. Existing PersistentRuntimeBinding.cmake already invokes this verifier against the actual imported SDK/library, so no alternate CMake acceptance shortcut is added.

Runtime/portable changes

A separate exact manifest/hash/size relocation predicate permits the bundled d367 image to move, just as the two previous exact manifests permit c35. It does not change the old c35 predicate. Actual loaded-object/default-export agreement, executable mappings, named file/dev/inode, full-byte hash and before/after identity checks remain mandatory. Instrumented providers retain their previous exact-path restriction. Codec's separate selected-admission change expands the shared proof/pin; compose this predicate+hunk with that patch rather than overwriting the whole guard.

The portable tool's old source_libtorrent/install_source_libtorrent functions and no-extra-option c35 behavior remain byte-exact. The new lane requires BOTH:

    --source-libtorrent /home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/install/lib/libtorrent-rasterbar.so.2.0.12
    --source-provider-manifest /home/yurii/Java/BiglyBTC/preview/native/engine/runtime-binding/provider-runtime.json

Before destination creation/install/loader invocation, it checks the exact manifest and record, both exact trusted verifier source files, complete source/build/install/SDK proof through the SAME inspector, full artifact bytes, and the app cache's exact generated binding header/configure receipt. Changed/corrupt/arbitrary/instrumented inputs reject. The new installer writes only the same private LT location/aliases, verifies every alias digest and retains the original loader checks/notices. BUILD_MANIFEST identifies the additional record/hash scope honestly; source/capability binding is not full provider/client parity. A fresh configure header alone is not proof a stale binary was rebuilt: root must freshly build and run the real packaged bound-owner tests before promotion, retaining rollback as usual.

Compose/apply

Copy only manifest source_sha256 leaves after checking their before_sha256 (null means NEW). Guard and tests/CMakeLists patches are against future55, not current shipping source. Preserve all other future55/Codec changes. The guard has only a new predicate plus one conjunction; tests/CMakeLists only appends one Qualified-only Python CTest. The root-owned selected-admission patch may touch those same files and must merge hunks. Never copy provider SDK/DSO into native source, overwrite436931/c35, or replace existing causal records/catalogs.

Reconfigure existing caches (root only, AFTER source composition)

reconfigure-existing.sh contains the exact three commands for bound-gcc, clang and sanitized-desktop. It overrides ONLY:

    LibtorrentRasterbar_DIR = candidate/install/lib/cmake/LibtorrentRasterbar
    CMAKE_PREFIX_PATH = candidate/install + existing sysroot/country/Qt prefixes
    BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST = native/engine/runtime-binding/provider-runtime.json
    BIGLYBTC_PAYLOAD_COUNTER_TEST_LANE = Qualified

No fresh build directory, compiler, build type, Qt setting, sanitizer/vptr flag or linker option is changed. cache-context.json pins the read-only before snapshots: GCC16 Release, Clang24 Release, GCC16 RelWithDebInfo with address+undefined/no-recover and existing -O1. The last two caches currently select causal-v2; this recipe deliberately selects the uninstrumented new provider for ordinary/ABI integration. Their old causal evidence/artifacts remain immutable and are NOT recounted as new-provider causal execution. Run separate old causal lanes only with their original provider/configuration.

Root checks each actual configure-receipt.json reports e74/d367 and449/1072/13/16/284/4, and that imported headers come from candidate/install. Existing positive target biglybtc-provider-payload-counter-tests / CTest provider-payload-counter is already in future55. The additive Python CTest provider-runtime-inputs exercises exact source binding plus changed/missing record, changed manifest, altered imported SDK/target, real byte-map header corruption and stale generated app binding refusal; it creates no owner, loader, network or profile. Actual marker/export rejection remains the existing compiled provider wire/unsupported/ABI cohort; these Python tests do not fabricate marker execution coverage. Actual method/CTest results remain root-observed, not predicted here.

After root's compile/tests, source-bound runtime and actual portable loader/owner checks, use the normal fresh staging/promote/rollback recipe with the two explicit new portable arguments above. Clear old LD_LIBRARY_PATH choices or put candidate/install/lib first for local test runs; the strict proof must fail if another mapped image wins. Do not silently reuse old83/other fixed cohort assertions; root records actual current names/counts. Nothing in this capsule changes default-off runtime binding or authorizes an unreviewed/instrumented artifact.
