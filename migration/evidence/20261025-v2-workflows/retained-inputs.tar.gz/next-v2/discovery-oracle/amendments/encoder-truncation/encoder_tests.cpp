// Two exact extracted LT function bodies, explicit inert invocation boundaries.
// No session, socket, resolver or public discovery runs in this executable.
#include <libtorrent/entry.hpp>
#include <libtorrent/address.hpp>
#include <libtorrent/bencode.hpp>
#include <libtorrent/biglybtc_swarm.hpp>
#include <libtorrent/performance_counters.hpp>
#include <libtorrent/aux_/numeric_cast.hpp>
#include <libtorrent/debug.hpp>
#include <libtorrent/socket.hpp>
#include <openssl/evp.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <memory>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>
namespace lt = libtorrent;
namespace fs = std::filesystem;
namespace {
#include "provider_gate.inc"
unsigned checks = 0;
void check(bool valid, const std::string& why) { ++checks; need(valid, why); }
namespace fixture {
using entry = lt::entry;
using counters = lt::counters;
namespace aux = lt::aux;
#include "source-bodies/render_lsd_packet.inc"
struct Observer {
    lt::udp::endpoint target_ep() const { return {lt::make_address("127.0.0.1"), 49123}; }
};
using observer_ptr = std::shared_ptr<Observer>;
struct Rpc {
    std::vector<entry> messages;
    bool result = true;
    bool invoke(const entry& value, const lt::udp::endpoint& endpoint, const observer_ptr&) {
        check(endpoint.address().to_string() == "127.0.0.1" && endpoint.port() == 49123, "source RPC destination");
        messages.push_back(value); return result;
    }
};
struct Logger {
    unsigned calls = 0;
    void outgoing_get_peers(const lt::sha1_hash& target, const lt::sha1_hash& query, const lt::udp::endpoint&) {
        check(target == query, "source logger hashes"); ++calls;
    }
};
struct Stats {
    unsigned calls = 0;
    void inc_stats_counter(int key) { check(key == counters::dht_get_peers_out, "source request counter"); ++calls; }
};
struct Node {
    Rpc m_rpc; Logger logger; Stats stats; bool logging = true;
    Logger* observer() { return logging ? &logger : nullptr; }
    Stats& stats_counters() { return stats; }
};
struct get_peers {
    bool m_done = false;
    bool m_noseeds = false;
    Node m_node;
    lt::sha1_hash key;
    lt::sha1_hash target() const { return key; }
    bool invoke(observer_ptr);
};
#include "source-bodies/get_peers_invoke.inc"
} // namespace fixture
std::string encoded(const lt::entry& entry) {
    std::string value; lt::bencode(std::back_inserter(value), entry); return value;
}
} // namespace
int main(int argc, char** argv) {
    try {
        need(argc == 4, "ARTIFACT SHA256 NEWOUTPUT");
        gate(argv[1], argv[2], false);
        const fs::path output(argv[3]);
        need(output.is_absolute() && !fs::exists(output) && fs::canonical(output.parent_path()) == output.parent_path(), "new owned output");
        fs::create_directory(output);
        write(output / "loaded-maps.txt", read("/proc/self/maps"));
        lt::sha1_hash v1; lt::sha256_hash v2;
        for (int i = 0; i < 20; ++i) v1[i] = static_cast<char>(i + 1);
        for (int i = 0; i < 32; ++i) v2[i] = static_cast<char>(i + 41);
        const lt::info_hash_t full(v1, v2);
        const std::array masks{lt::torrent_flags_t{}, lt::biglybtc_v1_only, lt::biglybtc_v2_only};
        unsigned actualQueries = 0;
        for (std::size_t index = 0; index < masks.size(); ++index) {
            const auto selected = lt::biglybtc_wire_hashes(full, masks[index]);
            check(selected.has_v1() == (index != 2) && selected.has_v2() == (index != 1), "selected encoder identity");
            selected.for_each([&](const lt::sha1_hash& key, lt::protocol_version) {
                const auto hash = hex(key.data(), 20);
                for (bool noseeds : {false, true}) {
                    fixture::get_peers request; request.key = key; request.m_noseeds = noseeds;
                    check(request.invoke(std::make_shared<fixture::Observer>()), "actual invoke result");
                    check(request.m_node.m_rpc.messages.size() == 1 && request.m_node.stats.calls == 1
                        && request.m_node.logger.calls == 1, "actual source invocation count");
                    const auto query = encoded(request.m_node.m_rpc.messages.front());
                    const auto expected = std::string("d1:ad9:info_hash20:") + std::string(key.data(), 20)
                        + (noseeds ? "6:noseedi1e" : "") + "e1:q9:get_peers1:y1:qe";
                    check(query == expected, "literal pre-RPC BEP5 entry");
                    write(output / (std::to_string(actualQueries) + ".bencode"), query); ++actualQueries;
                }
                std::array<char, 512> packet{};
                const auto size = fixture::render_lsd_packet(packet.data(), static_cast<int>(packet.size()), 49001, hash.c_str(), 0x1234abcd, "239.192.152.143");
                const auto expected = "BT-SEARCH * HTTP/1.1\r\nHost: 239.192.152.143:6771\r\nPort: 49001\r\nInfohash: "
                    + hash + "\r\ncookie: 1234abcd\r\n\r\n\r\n";
                check(size == static_cast<int>(expected.size()) && std::string(packet.data(), static_cast<std::size_t>(size)) == expected,
                    "exact actual LSD formatter");
                std::array<char, 8> truncated{};
                using RenderLsd = int (*)(char*, int, int, const char*, std::uint32_t, const char*);
                RenderLsd volatile renderShort = &fixture::render_lsd_packet;
                check(renderShort(truncated.data(), static_cast<int>(truncated.size()), 49001, hash.c_str(), 0x1234abcd, "239.192.152.143") == size
                    && truncated.back() == '\0', "actual LSD bounded snprintf semantics");
            });
        }
        fixture::get_peers done; done.m_done = true;
        check(!done.invoke(std::make_shared<fixture::Observer>()) && done.m_node.m_rpc.messages.empty() && done.m_node.stats.calls == 0,
            "completed traversal has no source query");
        fixture::get_peers noLogger; noLogger.key = v1; noLogger.m_node.logging = false; noLogger.m_node.m_rpc.result = false;
        check(!noLogger.invoke(std::make_shared<fixture::Observer>()) && noLogger.m_node.logger.calls == 0
            && noLogger.m_node.m_rpc.messages.size() == 1, "source RPC result and absent logger");
        const auto invalid = lt::biglybtc_wire_hashes(full, lt::biglybtc_swarm_mask);
        check(!invalid.has_v1() && !invalid.has_v2(), "invalid mask produces no encoder identity");
        std::cout << "PASS " << actualQueries << " exact source get_peers entries; " << checks
            << " assertions; exact LSD formatter; NO socket/session/discovery runtime credit\n";
        return 0;
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 2; }
}
