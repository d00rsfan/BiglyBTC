The runtime bundle and reviewed hosted control files are separate. The ZIP
contains the frozen encoder-truncation runtime (f5c55c2d), not this control
directory. Its historical hosted placeholders are unused. This avoids a
bundle/catalog hash cycle. Original discovery d7bc and both failed build
attempts remain unchanged. Only the new workflow fragments use ubuntu-26.04,
matching the already qualified native hosted image.

Root-run sequence (no command below has been executed by this author):

1. Root already built both standalone targets in provider-discovery-working and
   reviewed root-build-review.json (a39c6e3b49d3589ee7e72207c8f26cd4aed84ad12e862381817e1a346cb9461a).
   This finite actual receipt is the only admitted build input. The producer
   checks its two successful stages, actual binary hashes and exact six-source
   map against final runtime f5c55c2d and provider e74def09. It does not relabel
   the earlier failed builds or grant runtime credit for compilation.

2. After reviewing this producer, run it against that exact receipt SHA:

       W=/home/yurii/Java/BiglyBT/build/storage-20261025
       CONTROL="$W/next-v2/discovery-oracle/amendments/hosted-bundle"
       python3 "$CONTROL/prepare_bundle.py" \
         --fixture-build "$W/provider-discovery-working/root-build-review.json" \
         --fixture-build-sha256 a39c6e3b49d3589ee7e72207c8f26cd4aed84ad12e862381817e1a346cb9461a \
         --output "$W/discovery-hosted-bundle-r1"

   The producer only reads exact inputs and writes this new directory. It imports
   the hash-pinned filesystem-only source approver; it never loads a DSO, builds,
   probes a namespace, runs a target, downloads, publishes or grants approval.
   It packages full1072 source leaves,284 SDK/install leaves,4 build-proof leaves,
   actual r3 evidence, both exact verifier modules, the closed runtime sources,
   and actual fixture binaries/build evidence. The two LT SONAME aliases become
   regular identical-byte files; the existing approver accepts that form.
   Unrelated objects, payloads, profiles and original Java are excluded.

3. Independently review bundle.zip and proposed-catalog.json. Root may publish
   only that reviewed ZIP as bundle.zip in a development Release in the existing
   repository. No release/repository/CI has been created by this capsule. Fill
   stage-inputs.json with the actual repository/release tag/ZIP SHA/bytes, change
   its status to ROOT_REVIEWED_EXACT_BUNDLE_TRANSPORT, then source-freeze its
   SHA in stage_release.py. Commit this reviewed external control directory at
   preview/migration/fixtures/selected-discovery-control and stage-workflow.yml
   at a distinct .github/workflows/selected-discovery-stage.yml. The staging job
   only downloads and hashes the ZIP, then uploads selected-discovery-inputs.
   It executes no archive member. Neither workflow accepts arbitrary inputs.

4. After that actual job succeeds, retain the GitHub run and artifact API JSON:

       gh api repos/OWNER/REPO/actions/runs/ACTUAL_RUN_ID
       gh api repos/OWNER/REPO/actions/runs/ACTUAL_RUN_ID/artifacts

   Copy proposed-catalog.json to the external hosted-inputs.json. Preserve all
   source/member/ZIP/runner fields exactly; set repository, run_id,
   artifact_name=selected-discovery-inputs, artifact_id, artifact_digest
   (GitHub's sha256:... value), staging_head_sha from those actual responses.
   Set status=ROOT_REVIEWED_EXACT_PROVIDER_INPUTS. Root separately reviews and
   source-freezes this catalog SHA in external hosted.py. No producer changes
   either approval constant. Adopt discovery-workflow.yml at a second distinct
   workflow path and dispatch only after this review/commit.

5. Strict hosted qualification rechecks the actual successful staging run,
   source commit, artifact ID/name/digest, ZIP bytes and every member. It restores
   only exact chapter paths, never overwriting existing files or accepting
   symlinks/special members; then the original source-bound verifier and both
   compiled gates run again. The fixture MUST create fresh user+network
   namespaces, with only private loopback and private multicast. A denied
   namespace is a runtime gap/failing workflow, never a host multicast fallback.
   Missing ABI/system runtime compatibility also fails; do not substitute a
   different LT or silently rebuild/approve on the runner. Actual DHT/LSD raw
   evidence is uploaded even after a runtime rejection when output exists.

Local namespace denial is retained in namespace-probe.json,
namespace-probe-unsandboxed.json and namespace-probe-sudo.json. Encoder-only
success, source inspection and a staging upload grant no discovery-runtime
credit. No public bootstrap, payload/storage or causal-provider claim is added.

Separate native cache scope: root explicitly disabled
BIGLYBTC_CAUSAL_QUALIFICATION_TESTS for the new uninstrumented provider in its
next configure. Old causal-v2 approvals, tests and execution evidence remain
unchanged; this provider is not a replacement execution of those causal gates.
