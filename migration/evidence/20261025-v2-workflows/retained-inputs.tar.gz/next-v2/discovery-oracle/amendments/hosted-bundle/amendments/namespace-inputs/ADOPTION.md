Closed r2 inputs only. Parent actual root-build-review-r2.json1b71 pins successful configure/build9.94s, changed driver47658370 and unchanged encoderdcaaf169. Producer differs from frozen91c by exactly4 input literals: runtime path/hash and actual receipt path/hash. Every source/SDK/build/provider/ZIP check remains unchanged.

Root command:

    W=/home/yurii/Java/BiglyBT/build/storage-20261025
    python3 "$W/next-v2/discovery-oracle/amendments/hosted-bundle/amendments/namespace-inputs/prepare_bundle.py" \
      --fixture-build "$W/provider-discovery-working/root-build-review-r2.json" \
      --fixture-build-sha256 1b71b80f9fb1a06f125817f7dde47a24eba024a3b81a801dd49d0a5eecfd78ed \
      --output "$W/discovery-hosted-bundle-r2"

External hosted.py preserves the exact two SONAME alias repair and all API/byte/namespace checks; only source capsule888f replacesf5 and catalog becomes UNAPPROVED until root separately measures/uploads/reviews the new immutable bundle and actual staging run. Old ZIP/release/catalog/producer and both failed hosted runs stay untouched. Update the exact stage-release spec/pin through root review, then freeze the final new catalog SHA in this external consumer. No author execution or runtime claim.
