#!/usr/bin/env python3
"""Root-run filesystem-only producer. Produces proposed inputs, never approval.

No loader, compiler, target, network, namespace or Git invocation. The external
reviewed hosted control plane is deliberately NOT a member of the runtime ZIP.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
W = Path('/home/yurii/Java/BiglyBT/build/storage-20261025')
CANDIDATE = W / 'provider-candidate'
APPROVAL = CANDIDATE / 'approval-r3'
RUNTIME = W / 'next-v2/discovery-oracle/amendments/namespace-descriptors/runtime'
CAPSULE_SHA = '888fdd76a4fd585cfbacce50d5236318580e0e46983148249fd09e8807891856'
MANIFEST_SHA = 'e74def09b2257a266786b8ddb116382d300716687bf26bbe57072f5ff90e8737'
RECORD_SHA = '34bbba203833a31e59f0e9101f232fc2aaebe2bf080bdb8b640a29d68bd4016f'
ARTIFACT_SHA = 'd367afd6499859c5a57d66bddd352a977ff76c7fb76b5925302c2c9008c7ddbd'
APPROVER = APPROVAL / 'staging/engine/runtime-binding/verify_runtime_manifest.py'
APPROVER_SHA = '36146305c9df31bba21a8daff00151a0bd1570d48e366af080b06c61ab55b50c'
MODULE_SHA = 'fc9ae8203bb6f32f94d57a05c5ea174944bdf1dbbe41ae51d9caf987ac01d89a'
FIXTURE_RECEIPT = W / 'provider-discovery-working/root-build-review-r2.json'
FIXTURE_RECEIPT_SHA = '1b71b80f9fb1a06f125817f7dde47a24eba024a3b81a801dd49d0a5eecfd78ed'
SHA = re.compile('[0-9a-f]{64}')
TARGETS = ('biglybtc-selected-discovery-driver', 'biglybtc-selected-discovery-encoder')


def need(ok, why):
    if not ok:
        raise ValueError(why)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path, pin=None, installed_alias=False):
    need(path.is_absolute(), 'absolute input required')
    original = path
    if installed_alias and path.is_symlink():
        need(path.name in ('libtorrent-rasterbar.so', 'libtorrent-rasterbar.so.2.0')
             and path.parent == CANDIDATE / 'install/lib', 'unapproved installed alias')
        path = path.resolve(strict=True)
        need(path == CANDIDATE / 'install/lib/libtorrent-rasterbar.so.2.0.12', 'alias escapes artifact')
    need(not path.is_symlink() and path.resolve(strict=True) == path, 'aliased input: ' + str(original))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= 256 * 1024 * 1024, 'nonregular/oversized input')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read(256 * 1024 * 1024 + 1)
        after, named = os.fstat(fd), path.stat()
        identity = lambda x: (x.st_dev, x.st_ino, x.st_size, x.st_mtime_ns, x.st_ctime_ns)
        need(identity(before) == identity(after) == identity(named) and len(data) == before.st_size,
             'input changed during read: ' + str(original))
        need(pin is None or SHA.fullmatch(pin) and digest(data) == pin, 'changed pinned input: ' + str(original))
        return data
    finally:
        os.close(fd)


def leaf(root, name):
    relative = PurePosixPath(name)
    need(isinstance(name, str) and str(relative) == name and relative.parts
         and not relative.is_absolute() and not any(x in ('.', '..') for x in relative.parts), 'unsafe map key')
    return root / name


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixture-build', type=Path, required=True)
    parser.add_argument('--fixture-build-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    need(args.fixture_build == FIXTURE_RECEIPT and args.fixture_build_sha256 == FIXTURE_RECEIPT_SHA,
         'only the actual root-reviewed final fixture build receipt is admitted')
    receipt = json.loads(read(args.fixture_build, args.fixture_build_sha256))
    need(receipt['status'] == 'ROOT_REVIEWED_DISCOVERY_FIXTURE_BUILD'
         and receipt['source_capsule_sha256'] == CAPSULE_SHA
         and receipt['provider_manifest_sha256'] == MANIFEST_SHA
         and receipt['runtime_qualification'] is False, 'unreviewed fixture build identity')
    runtime_manifest = json.loads(read(RUNTIME / 'manifest.json', CAPSULE_SHA))
    need(len(runtime_manifest['artifacts']) == 13, 'changed runtime cohort')
    manifest_path = APPROVAL / 'provider-runtime.json'
    provider = json.loads(read(manifest_path, MANIFEST_SHA))
    record = json.loads(read(APPROVAL / 'provider-source-build-record.json', RECORD_SHA))
    artifact = Path(provider['artifact'])
    need(provider['artifact_sha256'] == ARTIFACT_SHA and provider['artifact_bytes'] == 9072560, 'wrong provider')
    read(APPROVER, APPROVER_SHA)
    read(APPROVER.with_name('verify_provider_runtime.py'), MODULE_SHA)
    # Exact source-reviewed approver only; inspect does filesystem validation,
    # including the closed full-source/SDK/build inventories, with no outputs.
    spec = importlib.util.spec_from_file_location('reviewed_discovery_approver', APPROVER)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    checked, pin = verifier.inspect(manifest_path, artifact, CANDIDATE / 'install/include')
    need(checked == provider and pin == MANIFEST_SHA, 'closed source-bound provider validation failed')
    driver, encoder = [Path(receipt[key]) for key in ('driver', 'encoder')]
    build = driver.parent
    need(encoder.parent == build and driver.name == TARGETS[0] and encoder.name == TARGETS[1]
         and build.is_relative_to(W) and build.resolve(strict=True) == build, 'unexpected fixture binary paths')
    for key in ('driver', 'encoder'):
        need(SHA.fullmatch(receipt[key + '_sha256']), 'exact actual fixture hash required')
        data = read(Path(receipt[key]), receipt[key + '_sha256'])
        need(data[:4] == b'\x7fELF' and Path(receipt[key]).stat().st_mode & 0o111, 'fixture not executable ELF')
    stages = receipt['stages']
    need(isinstance(stages, list) and len(stages) == 2, 'actual configure/build pair required')
    for row, stage in zip(stages, ('configure', 'build')):
        need(row['stage'] == stage and type(row['exit']) is int and row['exit'] == 0
             and isinstance(row['command'], list) and all(isinstance(x, str) for x in row['command']), 'failed/missing actual fixture stage')
        read(Path(row['log']), row['log_sha256'])
    configure, compile_command = [x['command'] for x in stages]
    def option(command, name):
        need(command.count(name) == 1 and command.index(name) + 1 < len(command), 'missing build option ' + name)
        return command[command.index(name) + 1]
    source_directory = Path(receipt['source_directory'])
    need(source_directory.is_absolute() and source_directory.is_relative_to(W)
         and source_directory.resolve(strict=True) == source_directory, 'canonical owned fixture source required')
    compile_inputs = ('CMakeLists.txt', 'discovery_driver.cpp', 'encoder_tests.cpp', 'provider_gate.inc',
                      'source-bodies/get_peers_invoke.inc', 'source-bodies/render_lsd_packet.inc')
    need(receipt['source_inputs_sha256'] == {name: runtime_manifest['artifacts']['staging/' + name]
                                           for name in compile_inputs}, 'actual six-source map differs')
    for name in compile_inputs:
        read(source_directory / name, runtime_manifest['artifacts']['staging/' + name])
    need('cmake' in configure and option(configure, '-S') == str(source_directory)
         and option(configure, '-B') == str(build)
         and any(x.startswith('-DCMAKE_PREFIX_PATH=' + str(CANDIDATE / 'install')) for x in configure), 'wrong actual fixture configure')
    need('cmake' in compile_command and option(compile_command, '--build') == str(build)
         and all(x in compile_command for x in TARGETS), 'both exact fixture targets must be built')
    members, aliases = {}, []
    def add(path, pin=None, alias=False):
        need(path.is_relative_to(W), 'bundle input outside chapter root')
        data = read(path, pin, installed_alias=alias)
        name = str(path).lstrip('/')
        need(name not in members or members[name][0] == data, 'conflicting bundle path')
        members[name] = (data, bool(path.stat().st_mode & 0o111))
        if alias and path.is_symlink():
            aliases.append(name)
    for key, root in (('source_inputs_sha256', CANDIDATE / 'source'),
                      ('installed_sha256', CANDIDATE / 'install'),
                      ('build_files_sha256', CANDIDATE / 'build')):
        for name, expected in record[key].items():
            add(leaf(root, name), expected, alias=key == 'installed_sha256')
    for name, expected in runtime_manifest['artifacts'].items():
        add(leaf(RUNTIME, name), expected)
    add(RUNTIME / 'manifest.json', CAPSULE_SHA)
    for name in ('provider-runtime.json', 'provider-source-build-record.json', 'source-build-record.json',
                 'provider-dynamic-symbols.txt', 'provider-dynamic-section.txt'):
        add(APPROVAL / name)
    add(APPROVER, APPROVER_SHA)
    add(APPROVER.with_name('verify_provider_runtime.py'), MODULE_SHA)
    for key in ('build_receipt', 'build_source_map'):
        add(Path(record[key]), record[key + '_sha256'])
    for name, expected in record['logs_sha256'].items():
        add(Path(name), expected)
    add(args.fixture_build, args.fixture_build_sha256)
    for row in stages:
        add(Path(row['log']), row['log_sha256'])
    for key in ('driver', 'encoder'):
        add(Path(receipt[key]), receipt[key + '_sha256'])
    for name in compile_inputs:
        add(source_directory / name, runtime_manifest['artifacts']['staging/' + name])
    need(len(members) <= 10000 and sum(len(x[0]) for x in members.values()) <= 2 * 1024 ** 3, 'bounded bundle exceeded')
    # Reread every source before creating any output, not a transactional claim.
    for name, (data, _) in members.items():
        read(Path('/') / name, digest(data), installed_alias=name in aliases)
    output = args.output
    need(output.is_absolute() and output.parent.resolve(strict=True) == W
         and output.parent == W and not output.exists() and not output.is_symlink(), 'new chapter-level owned output required')
    need(not any((Path('/') / name).is_relative_to(output) for name in members), 'output overlaps inputs')
    output.mkdir()
    bundle = output / 'bundle.zip'
    with zipfile.ZipFile(bundle, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (data, executable) in sorted(members.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 25, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | (0o755 if executable else 0o644)) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    pins = {name: digest(data) for name, (data, _) in sorted(members.items())}
    value = {'schema': 1, 'status': 'UNAPPROVED_PROPOSED_HOSTED_DISCOVERY_INPUTS',
             'repository': None, 'run_id': None, 'artifact_name': None,
             'artifact_id': None, 'artifact_digest': None, 'staging_head_sha': None,
             'bundle_sha256': digest(bundle.read_bytes()), 'bundle_bytes': bundle.stat().st_size,
             'members_sha256': pins, 'restore_roots': [str(W)],
             'runner': str(RUNTIME / 'staging/run.py'),
             'runner_options': {'driver': str(driver), 'driver-sha256': receipt['driver_sha256'],
                 'encoder': str(encoder), 'encoder-sha256': receipt['encoder_sha256'],
                 'artifact': str(artifact), 'artifact-sha256': ARTIFACT_SHA,
                 'runtime-manifest': str(manifest_path), 'approver': str(APPROVER),
                 'approver-sha256': APPROVER_SHA, 'approver-module-sha256': MODULE_SHA,
                 'output': str(W / 'discovery-hosted-results')},
             'source_capsule_sha256': CAPSULE_SHA, 'provider_manifest_sha256': MANIFEST_SHA,
             'fixture_build_receipt_sha256': args.fixture_build_sha256,
             'producer_sha256': digest(Path(__file__).read_bytes()),
             'aliases_dereferenced_as_identical_regular_files': sorted(aliases),
             'approval_created': False, 'discovery_executed': False,
             'shared_host_multicast_allowed': False}
    (output / 'proposed-catalog.json').write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps({'status': value['status'], 'members': len(members),
                      'bundle_sha256': value['bundle_sha256'], 'bytes': value['bundle_bytes']}))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('FAIL: ' + str(error), file=sys.stderr)
        raise SystemExit(2)
