#!/usr/bin/env python3
"""Root-run exact-provider discovery fixture; NEVER fall back to host multicast.

No builds, dynamic approval, public nodes, original application or profile.
Encoder-only coverage is separate from the mandatory isolated runtime cohort.
"""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import queue
import signal
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def exact_file(path, expected=None):
    require(path.is_absolute() and path.is_file() and not path.is_symlink()
            and path.resolve(strict=True) == path, 'canonical regular input required: ' + str(path))
    if expected:
        require(len(expected) == 64 and digest(path) == expected, 'changed reviewed input: ' + str(path))
    return path


def bounded_run(command, stem, environment, timeout=120, pass_fds=()):
    """Raw output retained; heartbeats and cleanup even for rejected namespaces."""
    with stem.with_suffix('.stdout').open('wb') as stdout, stem.with_suffix('.stderr').open('wb') as stderr:
        started = time.monotonic()
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr, env=environment,
                                   start_new_session=True, pass_fds=pass_fds)
        failure = None
        try:
            while True:
                try:
                    result = process.wait(timeout=min(30, max(.01, timeout - (time.monotonic() - started))))
                    break
                except subprocess.TimeoutExpired:
                    require(time.monotonic() - started < timeout, 'owned child deadline')
                    print('Discovery qualification: child still running', flush=True)
        except Exception as error:
            failure = error
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
        save(stem.with_suffix('.command.json'), {'command': command, 'exit': process.returncode,
             'seconds': time.monotonic() - started,
             'failure': None if failure is None else str(failure),
             'stdout_sha256': digest(stem.with_suffix('.stdout')),
             'stderr_sha256': digest(stem.with_suffix('.stderr'))})
        if failure:
            raise failure
        return result


class Driver:
    def __init__(self, args, root, mode, router, environment):
        self.lines = queue.Queue()
        self.output = (root / 'driver.stdout').open('w')
        self.errors = (root / 'driver.stderr').open('wb')
        command = [str(args.driver), str(args.artifact), args.artifact_sha256, str(root / 'owner'), mode,
                   str(router.port), 'PRIVATE', str(args.outer_net_fd), str(args.outer_user_fd)]
        save(root / 'driver-command.json', command)
        self.process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=self.errors, text=True, bufsize=1, env=environment,
            pass_fds=(args.outer_net_fd, args.outer_user_fd))
        self.reader = threading.Thread(target=self.read_loop, name='driver-stdout')
        self.reader.start()

    def read_loop(self):
        for line in self.process.stdout:
            self.output.write(line)
            self.output.flush()
            self.lines.put(line.rstrip('\n'))
        self.lines.put(None)

    def line(self):
        row = self.lines.get(timeout=40)
        require(row is not None, 'discovery driver exited: ' + str(self.process.poll()))
        require(not row.startswith('FAIL\t'), row)
        return row.split('\t')

    def command(self, command):
        self.process.stdin.write(command + '\n')
        self.process.stdin.flush()
        row = self.line()
        require(row[:2] == ['OK', command.split()[0]], 'unexpected driver response: ' + repr(row))
        return row

    def close(self):
        failed = None
        try:
            if self.process.poll() is None:
                try:
                    self.command('CLOSE')
                    self.process.stdin.close()
                    require(self.process.wait(timeout=15) == 0, 'joined driver close failed')
                except Exception as error:
                    failed = error
                    self.process.terminate()
                    try:
                        self.process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        self.process.kill()
                        self.process.wait(timeout=5)
            else:
                require(self.process.returncode == 0, 'driver failed before cleanup')
        finally:
            self.reader.join(timeout=3)
            self.output.close()
            self.errors.close()
            require(not self.reader.is_alive(), 'driver stdout thread failed to join')
        if failed:
            raise failed


def private_identity(args):
    # Descriptor identities are inherited from the actual outer runner. Command
    # line strings cannot merely assert a fabricated namespace boundary.
    identity = {}
    for kind, fd in (('net', args.outer_net_fd), ('user', args.outer_user_fd)):
        outer = os.fstat(fd)
        here = os.stat('/proc/self/ns/' + kind)
        initial = os.stat('/proc/1/ns/' + kind)
        require((here.st_dev, here.st_ino) not in ((outer.st_dev, outer.st_ino),
                (initial.st_dev, initial.st_ino)), 'fresh private ' + kind + ' namespace required')
        identity[kind] = {'outer_inode': outer.st_ino, 'current_inode': here.st_ino, 'init_inode': initial.st_ino}
    # sysfs may retain its mounting namespace. proc/self/net is current-netns.
    interfaces = [line.split(':', 1)[0].strip()
                  for line in Path('/proc/self/net/dev').read_text().splitlines() if ':' in line]
    require(sorted(interfaces) == ['lo'], 'namespace must contain only loopback')
    identity['interfaces'] = interfaces
    identity['uid_map'] = Path('/proc/self/uid_map').read_text()
    return identity


def pump_until(driver, predicate, seconds=25):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        driver.command('DHT')
        driver.command('PUMP 300')
        if predicate():
            return
    raise RuntimeError('actual selected discovery deadline')


def one_mode(args, mode, environment):
    from owned_peers import Peer, Router, Lsd, require as peer_require
    root = args.output / mode
    root.mkdir()
    result = {'mode': mode}
    with ExitStack() as cleanup:
        router = Router(root)
        cleanup.callback(router.close)
        lsd = Lsd(root)
        cleanup.callback(lsd.close)
        driver = Driver(args, root, mode, router, environment)
        cleanup.callback(driver.close)
        ready = driver.line()
        require(len(ready) == 4 and ready[0] == 'READY', 'actual driver readiness')
        owner_port = int(ready[1])
        full = [bytes.fromhex(ready[2]), bytes.fromhex(ready[3])[:20]]
        require(len(full[0]) == len(full[1]) == 20 and full[0] != full[1], 'distinct actual hybrid wire keys')
        selected = full if mode == 'Both' else [full[0 if mode == 'V1Only' else 1]]
        forbidden = set(full) - set(selected)
        positive = []
        for index, key in enumerate(selected):
            peer = Peer('127.0.0.' + str(10 + index), key, root)
            cleanup.callback(peer.close)
            positive.append(peer)
        router.phase('normal', {key: peer.endpoint for key, peer in zip(selected, positive)})
        pump_until(driver, lambda: all(peer.accepted for peer in positive)
                   and set(selected) <= router.gets and set(selected) <= router.announces)
        require(not (forbidden & router.gets) and router.announces <= set(selected), 'unselected actual DHT request escaped')

        # The hash is absent from a BEP5 response. Test actual source/transaction
        # rejection plus an actual candidate handshake with a wrong swarm.
        foreign_peers = []
        for index, key in enumerate(selected):
            peer = Peer('127.0.0.' + str(20 + index), key, root)
            cleanup.callback(peer.close)
            foreign_peers.append(peer)
        router.phase('empty', {})
        driver.command('PUMP 1000')
        driver.command('RESET_DHT')
        router.phase('wrong-source', {key: peer.endpoint for key, peer in zip(selected, foreign_peers)})
        pump_until(driver, lambda: router.foreign_replies > 0)
        unknown = driver.command('UNKNOWN')
        driver.command('PUMP 2000')
        driver.command('NO_DHT_PEERS')
        require(not any(peer.accepted for peer in foreign_peers), 'wrong-source DHT result consumed as a candidate')
        bad_hash = bytes.fromhex('a5' * 20)
        require(bad_hash not in full, 'fixture wrong key collision')
        bad = Peer('127.0.0.30', selected[0], root, response_key=bad_hash)
        cleanup.callback(bad.close)
        router.phase('normal', {selected[0]: bad.endpoint})
        pump_until(driver, lambda: bad.accepted > 0)
        driver.command('REJECT ' + bad.endpoint[0] + ':' + str(bad.endpoint[1]))
        router.phase('empty', {})

        for index, key in enumerate(selected):
            peer = Peer('127.0.0.' + str(40 + index), key, root)
            cleanup.callback(peer.close)
            lsd.inject(peer, key)
            driver.command('LSD ' + peer.endpoint[0] + ':' + str(peer.endpoint[1]) + ' ' + key.hex() + ' 1')
            pump_until(driver, lambda: peer.accepted > 0)
        unselected = next(iter(forbidden), bad_hash)
        ghost = Peer('127.0.0.50', unselected, root)
        cleanup.callback(ghost.close)
        lsd.inject(ghost, unselected)
        driver.command('LSD ' + ghost.endpoint[0] + ':' + str(ghost.endpoint[1]) + ' ' + unselected.hex() + ' 0')
        require(ghost.accepted == 0, 'unselected LSD announcement produced an actual handshake')
        pump_until(driver, lambda: set(selected) <= lsd.announced(owner_port))
        require(lsd.announced(owner_port) == set(selected), 'actual LSD announce used another identity')
        require(not (forbidden & router.gets) and router.announces <= set(selected), 'late unselected DHT query')
        peer_require(router.error is None and lsd.error is None, 'protocol peer failed')
        result.update(selected_hashes=[key.hex() for key in selected],
                      dht_get_peers=[key.hex() for key in router.gets],
                      dht_announces=[key.hex() for key in router.announces],
                      actual_selected_dht_handshakes=sum(peer.accepted for peer in positive),
                      injected_wrong_source_replies=router.foreign_replies,
                      actual_unknown_transaction_log_count=int(unknown[3]),
                      foreign_candidate_handshakes=sum(peer.accepted for peer in foreign_peers),
                      actual_wrong_swarm_handshake_rejected=True,
                      lsd_announcements=[key.hex() for key in lsd.announced(owner_port)],
                      rejected_lsd_hash=unselected.hex(), rejected_lsd_handshakes=ghost.accepted,
                      maintenance_get_peers_hashes=[key.hex() for key in router.gets - set(full)])
    save(root / 'result.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('driver', 'encoder', 'artifact', 'runtime-manifest', 'approver', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    for name in ('driver-sha256', 'encoder-sha256', 'artifact-sha256', 'approver-sha256', 'approver-module-sha256'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--inside', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--outer-net-fd', type=int, default=-1, help=argparse.SUPPRESS)
    parser.add_argument('--outer-user-fd', type=int, default=-1, help=argparse.SUPPRESS)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    capsule = json.loads((here.parent / 'manifest.json').read_bytes())
    for name, pin in capsule['artifacts'].items():
        exact_file(here.parent / name, pin)
    for field in ('driver', 'encoder', 'artifact', 'approver'):
        exact_file(getattr(args, field), getattr(args, field + '_sha256'))
    approver_module = args.approver.with_name('verify_provider_runtime.py')
    exact_file(approver_module, args.approver_module_sha256)
    exact_file(args.runtime_manifest)
    environment = dict(os.environ)
    environment.pop('LD_PRELOAD', None)
    environment.pop('LD_AUDIT', None)
    environment['LD_LIBRARY_PATH'] = str(args.artifact.parent)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    if args.inside:
        require(args.output.is_dir(), 'owned output missing')
        identity = private_identity(args)  # BEFORE any socket/service creation
        save(args.output / 'namespace-identity.json', identity)
        ip = next((str(path) for path in (Path('/usr/sbin/ip'), Path('/usr/bin/ip')) if path.is_file()), None)
        require(ip is not None, 'iproute2 required inside the isolated namespace')
        for index, command in enumerate(([ip, 'link', 'set', 'lo', 'up', 'multicast', 'on'],
                                         [ip, 'route', 'add', '239.192.152.143/32', 'dev', 'lo'])):
            require(bounded_run(command, args.output / ('namespace-setup-' + str(index)), environment, 10) == 0,
                    'private loopback multicast setup failed')
        save(args.output / 'runtime-results.json', {'status': 'PASS', 'namespace': identity,
             'modes': [one_mode(args, name, environment) for name in ('Both', 'V1Only', 'V2Only')],
             'public_network': False, 'payload_or_storage_qualification': False})
        print('PASS actual isolated DHT/LSD selected-swarm discovery in three modes', flush=True)
        return 0
    require(args.output.is_absolute() and not args.output.exists() and not args.output.is_symlink()
            and args.output.parent.resolve(strict=True) == args.output.parent, 'new canonical owned output required')
    manifest = json.loads(args.runtime_manifest.read_bytes())
    require(manifest['artifact'] == str(args.artifact) and manifest['artifact_sha256'] == args.artifact_sha256,
            'runtime manifest does not bind this artifact')
    args.output.mkdir()
    approver = [sys.executable, str(args.approver), '--manifest', str(args.runtime_manifest), '--library', str(args.artifact),
                '--include', str(Path(manifest['install_root']) / 'include'), '--header', str(args.output / 'bound.hpp'),
                '--receipt', str(args.output / 'approval.json')]
    require(bounded_run(approver, args.output / 'approver', environment, 120) == 0,
            'retained exact source-bound approver rejected provider; no automatic approval allowed')
    approval = json.loads((args.output / 'approval.json').read_bytes())
    require(approval['artifact_sha256'] == args.artifact_sha256
            and approval['manifest_sha256'] == digest(args.runtime_manifest), 'approval receipt mismatch')
    encoder = [str(args.encoder), str(args.artifact), args.artifact_sha256, str(args.output / 'encoder-output')]
    require(bounded_run(encoder, args.output / 'encoder', environment, 30) == 0, 'actual source encoder check failed')
    net_fd = os.open('/proc/self/ns/net', os.O_RDONLY | os.O_CLOEXEC)
    user_fd = os.open('/proc/self/ns/user', os.O_RDONLY | os.O_CLOEXEC)
    try:
        command = ['/usr/bin/unshare', '--user', '--map-root-user', '--net', sys.executable, str(Path(__file__).resolve()),
                   *sys.argv[1:], '--inside', '--outer-net-fd', str(net_fd), '--outer-user-fd', str(user_fd)]
        result = bounded_run(command, args.output / 'isolated-runtime', environment, 600, (net_fd, user_fd))
    finally:
        os.close(net_fd)
        os.close(user_fd)
    if result != 0:
        gap = not (args.output / 'namespace-identity.json').exists()
        save(args.output / 'result.json', {'status': 'RUNTIME_GAP' if gap else 'FAIL', 'exit': result,
             'encoder_only_passed': True, 'isolated_discovery_passed': False,
             'shared_host_multicast_fallback': False,
             'reason': 'Fresh private user/network namespace unavailable; no discovery sockets opened' if gap else 'Isolated fixture failed; see retained logs'})
        return 77 if gap else 2
    for field in ('driver', 'encoder', 'artifact', 'approver'):
        exact_file(getattr(args, field), getattr(args, field + '_sha256'))
    exact_file(approver_module, args.approver_module_sha256)
    require(digest(args.runtime_manifest) == approval['manifest_sha256'], 'runtime manifest changed during qualification')
    actual = json.loads((args.output / 'runtime-results.json').read_bytes())
    require(actual['status'] == 'PASS', 'missing actual runtime receipt')
    save(args.output / 'result.json', {'status': 'PASS', 'runtime_manifest_sha256': digest(args.runtime_manifest),
         'artifact_sha256': args.artifact_sha256, 'approver_sha256': args.approver_sha256,
         'approver_module_sha256': args.approver_module_sha256,
         'driver_sha256': args.driver_sha256, 'encoder_sha256': args.encoder_sha256,
         'capsule_sha256': digest(here.parent / 'manifest.json'), 'actual_modes': actual['modes'],
         'shared_host_multicast_fallback': False, 'public_network': False,
         'files_sha256': {str(path.relative_to(args.output)): digest(path)
                         for path in sorted(args.output.rglob('*')) if path.is_file()}})
    print('PASS isolated discovery; source/artifact/raw evidence pinned in result.json', flush=True)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print('FAIL: ' + str(error), file=sys.stderr)
        raise SystemExit(2)
