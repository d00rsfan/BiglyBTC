"""Finite protocol peers. Construct ONLY after run.py proves private namespaces."""
import ipaddress
import json
from pathlib import Path
import socket
import struct
import threading
import time


def require(ok, text):
    if not ok:
        raise RuntimeError(text)


def encode(value):
    if isinstance(value, bytes):
        return str(len(value)).encode() + b':' + value
    if isinstance(value, int):
        return b'i' + str(value).encode() + b'e'
    if isinstance(value, list):
        return b'l' + b''.join(encode(x) for x in value) + b'e'
    require(isinstance(value, dict), 'unsupported owned protocol value')
    return b'd' + b''.join(encode(k) + encode(value[k]) for k in sorted(value)) + b'e'


def decode(raw):
    require(len(raw) <= 65536, 'bounded owned datagram')
    position = 0
    tokens = 0

    def take(depth=0):
        nonlocal position, tokens
        tokens += 1
        require(depth <= 20 and tokens <= 4096 and position < len(raw), 'malformed owned bencode')
        tag = raw[position:position + 1]
        if tag == b'i':
            end = raw.index(b'e', position)
            value = int(raw[position + 1:end])
            position = end + 1
            return value
        if tag in (b'd', b'l'):
            position += 1
            result = {} if tag == b'd' else []
            while position < len(raw) and raw[position:position + 1] != b'e':
                if tag == b'd':
                    key = take(depth + 1)
                    require(isinstance(key, bytes) and key not in result, 'duplicate/non-byte dictionary key')
                    result[key] = take(depth + 1)
                else:
                    result.append(take(depth + 1))
            require(position < len(raw), 'unterminated bencode')
            position += 1
            return result
        colon = raw.index(b':', position)
        count = int(raw[position:colon])
        require(0 <= count <= 65536 and colon + 1 + count <= len(raw), 'invalid byte string')
        position = colon + 1 + count
        return raw[colon + 1:position]

    result = take()
    require(position == len(raw), 'trailing owned bencode')
    return result


def loopback(address):
    return ipaddress.ip_address(address).version == 4 and ipaddress.ip_address(address).is_loopback


class Capture:
    def __init__(self, path):
        self.path = Path(path)
        self.rows = []
        self.lock = threading.RLock()

    def append(self, row):
        with self.lock:
            require(len(self.rows) < 20000, 'bounded fixture evidence exhausted')
            self.rows.append(row)
            with self.path.open('a') as stream:
                stream.write(json.dumps(row, sort_keys=True) + '\n')


class Peer:
    """A genuine plain BitTorrent handshake endpoint, no claimed payload oracle."""
    def __init__(self, address, key, root, response_key=None):
        require(loopback(address) and len(key) == 20, 'owned numeric peer only')
        self.key = key
        self.response_key = response_key or key
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.bind((address, 0))
        self.socket.listen(8)
        self.socket.settimeout(.1)
        self.endpoint = self.socket.getsockname()
        self.capture = Capture(Path(root) / ('peer-' + address + '-' + str(self.endpoint[1]) + '.jsonl'))
        self.stop = threading.Event()
        self.error = None
        self.accepted = 0
        self.clients = set()
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self.run, name='owned-handshake')
        self.thread.start()

    def run(self):
        try:
            while not self.stop.is_set():
                try:
                    client, sender = self.socket.accept()
                except socket.timeout:
                    continue
                except OSError:
                    if self.stop.is_set():
                        break
                    raise
                with self.lock:
                    self.clients.add(client)
                try:
                    require(loopback(sender[0]), 'nonowned handshake source')
                    client.settimeout(3)
                    received = b''
                    while len(received) < 68:
                        part = client.recv(68 - len(received))
                        require(part, 'owned peer EOF before handshake')
                        received += part
                    require(received[:20] == b'\x13BitTorrent protocol', 'not an actual BitTorrent handshake')
                    require(received[28:48] == self.key, 'discovery connected using wrong selected key')
                    reply = b'\x13BitTorrent protocol' + b'\0' * 8 + self.response_key + b'-OWNED00-0123456789x'
                    require(len(reply) == 68, 'fixture peer-id length')
                    client.sendall(reply)
                    self.accepted += 1
                    self.capture.append({'source': sender, 'received': received.hex(), 'sent': reply.hex(),
                                         'selected_key': self.key.hex(), 'reply_key': self.response_key.hex()})
                    # An actual empty bitfield is sufficient for a completed
                    # handshake. No payload/capacity result is claimed here.
                    client.sendall(b'\0\0\0\2\5\0')
                    time.sleep(.05)
                finally:
                    with self.lock:
                        self.clients.discard(client)
                    client.close()
        except Exception as error:
            if not self.stop.is_set():
                self.error = str(error)

    def close(self):
        self.stop.set()
        self.socket.close()
        with self.lock:
            for client in self.clients:
                try:
                    client.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
        self.thread.join(timeout=5)
        require(not self.thread.is_alive(), 'owned handshake thread failed to join')
        require(self.error is None, self.error)


class Router:
    """BEP5 router with no public nodes. Replies are transaction/source bound."""
    def __init__(self, root):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(('127.0.0.1', 0))
        self.socket.settimeout(.1)
        self.foreign = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.foreign.bind(('127.0.0.2', 0))
        self.port = self.socket.getsockname()[1]
        self.capture = Capture(Path(root) / 'dht-router.jsonl')
        self.lock = threading.RLock()
        self.mode = 'empty'
        self.peers = {}
        self.keys = set()
        self._gets = set()
        self._announces = set()
        self.foreign_replies = 0
        self.stop = threading.Event()
        self.error = None
        self.thread = threading.Thread(target=self.run, name='owned-bep5')
        self.thread.start()

    def phase(self, mode, peers):
        require(mode in ('normal', 'wrong-source', 'empty'), 'owned DHT phase')
        with self.lock:
            self.mode = mode
            self.peers = dict(peers)
            self.keys = set(peers)

    @property
    def gets(self):
        with self.lock:
            return set(self._gets)

    @property
    def announces(self):
        with self.lock:
            return set(self._announces)

    def send(self, message, destination, foreign=False):
        raw = encode(message)
        self.capture.append({'direction': 'TX-wrong-source' if foreign else 'TX', 'endpoint': destination, 'hex': raw.hex()})
        (self.foreign if foreign else self.socket).sendto(raw, destination)

    def run(self):
        try:
            while not self.stop.is_set():
                try:
                    raw, source = self.socket.recvfrom(65536)
                except socket.timeout:
                    continue
                except OSError:
                    if self.stop.is_set():
                        break
                    raise
                require(loopback(source[0]), 'nonowned DHT source')
                self.capture.append({'direction': 'RX', 'endpoint': source, 'hex': raw.hex()})
                message = decode(raw)
                if message.get(b'y') != b'q':
                    continue
                transaction = message[b't']
                query = message[b'q']
                arguments = message[b'a']
                response = {b'id': b'OWNED-ROUTER-NODE-ID'}
                require(len(response[b'id']) == 20, 'owned node-id length')
                with self.lock:
                    selected_mode, peers = self.mode, dict(self.peers)
                if query == b'get_peers':
                    key = arguments[b'info_hash']
                    require(len(key) == 20, 'BEP5 hash width')
                    with self.lock:
                        self._gets.add(key)
                    response[b'token'] = b'owned-token'
                    response[b'nodes'] = b''
                    if key in peers:
                        endpoint = peers[key]
                        values = [socket.inet_aton(endpoint[0]) + struct.pack('!H', endpoint[1])]
                        if selected_mode == 'normal':
                            response[b'values'] = values
                        elif selected_mode == 'wrong-source':
                            # Same real transaction, wrong actual source IP.
                            # BEP5 has no response hash field. The real source
                            # then completes the RPC with an empty result.
                            injected = {b'id': b'OTHER-ROUTER-NODE-ID', b'token': b'foreign', b'values': values}
                            self.send({b't': transaction, b'y': b'r', b'r': injected}, source, foreign=True)
                            self.foreign_replies += 1
                            time.sleep(.05)
                elif query == b'announce_peer':
                    require(arguments.get(b'token') == b'owned-token', 'actual announce token')
                    key = arguments[b'info_hash']
                    with self.lock:
                        self._announces.add(key)
                elif query == b'find_node':
                    response[b'nodes'] = b''
                elif query != b'ping':
                    self.send({b't': transaction, b'y': b'e', b'e': [204, b'unsupported owned query']}, source)
                    continue
                self.send({b't': transaction, b'y': b'r', b'r': response}, source)
        except Exception as error:
            if not self.stop.is_set():
                self.error = str(error)

    def close(self):
        self.stop.set()
        self.socket.close()
        self.foreign.close()
        self.thread.join(timeout=3)
        require(not self.thread.is_alive(), 'owned DHT thread failed to join')
        require(self.error is None, self.error)


class Lsd:
    group = '239.192.152.143'

    def __init__(self, root):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket.bind(('', 6771))
        self.socket.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP,
                               socket.inet_aton(self.group) + socket.inet_aton('127.0.0.1'))
        self.socket.settimeout(.1)
        self.capture = Capture(Path(root) / 'lsd.jsonl')
        self.stop = threading.Event()
        self.error = None
        self.thread = threading.Thread(target=self.run, name='private-lsd')
        self.thread.start()

    def run(self):
        try:
            while not self.stop.is_set():
                try:
                    raw, source = self.socket.recvfrom(65536)
                except socket.timeout:
                    continue
                except OSError:
                    if self.stop.is_set():
                        break
                    raise
                require(loopback(source[0]), 'nonowned LSD source')
                self.capture.append({'direction': 'RX', 'endpoint': source, 'hex': raw.hex()})
        except Exception as error:
            if not self.stop.is_set():
                self.error = str(error)

    def inject(self, peer, key):
        address, port = peer.endpoint
        require(loopback(address) and len(key) == 20, 'owned LSD injection')
        raw = ('BT-SEARCH * HTTP/1.1\r\nHost: ' + self.group + ':6771\r\nPort: ' + str(port)
               + '\r\nInfohash: ' + key.hex() + '\r\ncookie: fdf0abcd\r\n\r\n\r\n').encode()
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP) as sender:
            sender.bind((address, 0))
            sender.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(address))
            sender.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)
            sender.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
            self.capture.append({'direction': 'INJECT', 'endpoint': sender.getsockname(), 'hex': raw.hex()})
            sender.sendto(raw, (self.group, 6771))

    def announced(self, owner_port):
        keys = set()
        with self.capture.lock:
            rows = list(self.capture.rows)
        for row in rows:
            if row['direction'] != 'RX' or row['endpoint'][0] != '127.0.0.1':
                continue
            raw = bytes.fromhex(row['hex'])
            lines = raw.decode('ascii', errors='strict').split('\r\n')
            fields = {}
            for line in lines[1:]:
                key, separator, value = line.partition(':')
                if separator:
                    fields.setdefault(key.lower(), []).append(value.strip())
            if fields.get('port') == [str(owner_port)]:
                keys.update(bytes.fromhex(value) for value in fields.get('infohash', []))
        return keys

    def close(self):
        self.stop.set()
        self.socket.close()
        self.thread.join(timeout=3)
        require(not self.thread.is_alive(), 'private LSD thread failed to join')
        require(self.error is None, self.error)
