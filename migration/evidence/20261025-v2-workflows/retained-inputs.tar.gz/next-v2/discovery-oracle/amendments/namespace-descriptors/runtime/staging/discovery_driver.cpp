// Qualification only. The mandatory namespace gate precedes every LT owner.
#include <libtorrent/session.hpp>
#include <libtorrent/session_params.hpp>
#include <libtorrent/settings_pack.hpp>
#include <libtorrent/add_torrent_params.hpp>
#include <libtorrent/torrent_handle.hpp>
#include <libtorrent/torrent_status.hpp>
#include <libtorrent/torrent_info.hpp>
#include <libtorrent/create_torrent.hpp>
#include <libtorrent/bencode.hpp>
#include <libtorrent/alert_types.hpp>
#include <libtorrent/error_code.hpp>
#include <libtorrent/hasher.hpp>
#include <libtorrent/biglybtc_swarm.hpp>
#include <openssl/evp.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <vector>
#ifdef TORRENT_DISABLE_LOGGING
#error Discovery rejection qualification requires actual LT logging
#endif
namespace lt = libtorrent;
namespace fs = std::filesystem;
using Clock = std::chrono::steady_clock;
namespace {
#include "provider_gate.inc"

void isolated(int outerNetFd, int outerUserFd, int pid1NetFd, int pid1UserFd) {
    struct stat beforeNet{}, beforeUser{}, hereNet{}, hereUser{}, initNet{}, initUser{};
    need(::fstat(outerNetFd, &beforeNet) == 0 && ::fstat(outerUserFd, &beforeUser) == 0,
        "missing inherited outer namespace descriptors");
    need(::stat("/proc/self/ns/net", &hereNet) == 0 && ::stat("/proc/self/ns/user", &hereUser) == 0
        && ::fstat(pid1NetFd, &initNet) == 0 && ::fstat(pid1UserFd, &initUser) == 0,
        "current or inherited PID1 namespace identity unavailable");
    const auto different = [](const struct stat& a, const struct stat& b) {
        return a.st_dev != b.st_dev || a.st_ino != b.st_ino;
    };
    need(different(hereNet, beforeNet) && different(hereUser, beforeUser)
        && different(hereNet, initNet) && different(hereUser, initUser),
        "fresh PRIVATE user and network namespaces required");
    // /sys may have been mounted in the outer namespace; use current-netns
    // proc data, without opening even a query socket before the boundary.
    std::vector<std::string> interfaces;
    std::istringstream devices(read("/proc/self/net/dev"));
    std::string line;
    while (std::getline(devices, line)) {
        const auto colon = line.find(':');
        if (colon == std::string::npos) continue;
        auto name = line.substr(0, colon);
        name.erase(0, name.find_first_not_of(" \t"));
        name.erase(name.find_last_not_of(" \t") + 1);
        interfaces.push_back(std::move(name));
    }
    need(interfaces == std::vector<std::string>{"lo"}, "only loopback may exist in the namespace");
}

lt::torrent_flags_t mode(const std::string& name) {
    if (name == "Both") return {};
    if (name == "V1Only") return lt::biglybtc_v1_only;
    if (name == "V2Only") return lt::biglybtc_v2_only;
    throw std::runtime_error("unknown selected mode");
}

lt::settings_pack settings(unsigned short routerPort) {
    lt::settings_pack s;
    s.set_str(lt::settings_pack::listen_interfaces, "127.0.0.1:0");
    s.set_str(lt::settings_pack::outgoing_interfaces, "127.0.0.1");
    s.set_str(lt::settings_pack::dht_bootstrap_nodes, "127.0.0.1:" + std::to_string(routerPort));
    for (const auto key : {lt::settings_pack::enable_upnp, lt::settings_pack::enable_natpmp,
        lt::settings_pack::enable_incoming_utp, lt::settings_pack::enable_outgoing_utp})
        s.set_bool(key, false);
    s.set_bool(lt::settings_pack::enable_dht, true);
    s.set_bool(lt::settings_pack::enable_lsd, true);
    s.set_bool(lt::settings_pack::allow_multiple_connections_per_ip, true);
    s.set_bool(lt::settings_pack::dht_ignore_dark_internet, false);
    s.set_bool(lt::settings_pack::dht_enforce_node_id, false);
    s.set_bool(lt::settings_pack::dht_privacy_lookups, false);
    s.set_bool(lt::settings_pack::dht_restrict_routing_ips, false);
    s.set_bool(lt::settings_pack::dht_restrict_search_ips, false);
    s.set_int(lt::settings_pack::in_enc_policy, lt::settings_pack::pe_disabled);
    s.set_int(lt::settings_pack::out_enc_policy, lt::settings_pack::pe_disabled);
    s.set_int(lt::settings_pack::alert_mask, static_cast<int>(static_cast<std::uint32_t>(lt::alert_category::all)));
    s.set_int(lt::settings_pack::alert_queue_size, 20000);
    s.set_int(lt::settings_pack::local_service_announce_interval, 1);
    s.set_int(lt::settings_pack::max_retry_port_bind, 0);
    return s;
}

struct Observe {
    std::ofstream alerts;
    std::ofstream packets;
    bool bootstrapped = false;
    bool removed = false;
    unsigned dhtReplies = 0;
    unsigned dhtPeerValues = 0;
    unsigned unknownTransactions = 0;
    unsigned foreignPackets = 0;
    std::set<std::string> lsdLogs;
    std::set<std::string> lsdPeers;
    std::set<std::string> rejected;
    std::size_t count = 0;
    explicit Observe(const fs::path& root) : alerts(root / "alerts.tsv"), packets(root / "dht-packets.tsv") {}
    static std::string endpoint(const lt::tcp::endpoint& value) {
        return value.address().to_string() + ":" + std::to_string(value.port());
    }
    void pop(lt::session& owner) {
        std::vector<lt::alert*> batch;
        owner.pop_alerts(&batch); // sole consumer; every borrowed value is copied here
        for (auto* alert : batch) {
            need(++count <= 200000, "bounded alert evidence exhausted");
            alerts << alert->what() << '\t' << std::quoted(alert->message()) << '\n';
            if (lt::alert_cast<lt::alerts_dropped_alert>(alert)) throw std::runtime_error("actual alerts dropped");
            if (lt::alert_cast<lt::dht_bootstrap_alert>(alert)) bootstrapped = true;
            if (lt::alert_cast<lt::torrent_removed_alert>(alert)) removed = true;
            if (const auto* item = lt::alert_cast<lt::dht_reply_alert>(alert)) {
                ++dhtReplies;
                need(item->num_peers >= 0 && item->num_peers <= 4096, "bounded actual DHT peer count");
                dhtPeerValues += static_cast<unsigned>(item->num_peers);
            }
            if (const auto* item = lt::alert_cast<lt::dht_log_alert>(alert)) {
                const std::string_view text(item->log_message());
                if (text.find("reply with unknown transaction id") != std::string_view::npos
                    && text.find("127.0.0.2:") != std::string_view::npos)
                    ++unknownTransactions;
            }
            if (const auto* item = lt::alert_cast<lt::dht_pkt_alert>(alert)) {
                const auto bytes = item->pkt_buf();
                if (item->direction == lt::dht_pkt_alert::incoming && item->node.address().to_string() == "127.0.0.2")
                    ++foreignPackets;
                packets << (item->direction == lt::dht_pkt_alert::outgoing ? "TX" : "RX") << '\t'
                    << item->node.address().to_string() << ':' << item->node.port() << '\t'
                    << hex(bytes.data(), static_cast<std::size_t>(bytes.size())) << '\n';
            }
            if (const auto* item = lt::alert_cast<lt::lsd_peer_alert>(alert)) lsdPeers.insert(endpoint(item->endpoint));
            if (const auto* item = lt::alert_cast<lt::log_alert>(alert)) {
                const std::string text(item->log_message());
                if (text.find("<== LSD:") != std::string::npos) lsdLogs.insert(text);
            }
            if (const auto* item = lt::alert_cast<lt::peer_error_alert>(alert))
                if (item->error == lt::errors::invalid_info_hash) rejected.insert(endpoint(item->endpoint));
            if (const auto* item = lt::alert_cast<lt::peer_disconnected_alert>(alert))
                if (item->error == lt::errors::invalid_info_hash) rejected.insert(endpoint(item->endpoint));
            if (const auto* item = lt::alert_cast<lt::peer_log_alert>(alert)) {
                const lt::error_code invalid = lt::errors::invalid_info_hash;
                if (std::string_view(item->log_message()).find(invalid.message()) != std::string_view::npos)
                    rejected.insert(endpoint(item->endpoint));
            }
        }
        alerts.flush(); packets.flush();
    }
};
template<class Predicate>
void until(lt::session& owner, Observe& observed, Predicate predicate) {
    const auto end = Clock::now() + std::chrono::seconds(30);
    do {
        observed.pop(owner);
        if (predicate()) return;
        need(Clock::now() < end, "actual discovery fixture deadline");
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    } while (true);
}
void pump(lt::session& owner, Observe& observed, unsigned millis) {
    need(millis <= 10000, "bounded pump duration");
    const auto end = Clock::now() + std::chrono::milliseconds(millis);
    do { observed.pop(owner); std::this_thread::sleep_for(std::chrono::milliseconds(20)); } while (Clock::now() < end);
}

std::shared_ptr<lt::torrent_info> metadata(const fs::path& root) {
    std::string payload;
    for (int i = 0; i < 160 * 1024; ++i) payload += static_cast<char>((i * 17 + 3) % 251);
    write(root / "owned.bin", payload);
    lt::file_storage files; files.add_file("owned.bin", static_cast<std::int64_t>(payload.size()));
    lt::create_torrent creator(files, 32768);
    lt::error_code error; lt::set_piece_hashes(creator, root.string(), error);
    need(!error, "hash generated hybrid metadata");
    std::vector<char> encoded; lt::bencode(std::back_inserter(encoded), creator.generate());
    return std::make_shared<lt::torrent_info>(encoded.data(), static_cast<int>(encoded.size()));
}
} // namespace

int main(int argc, char** argv) {
    try {
        need(argc == 11, "ARTIFACT SHA256 NEWROOT MODE ROUTERPORT PRIVATE OUTER_NET_FD OUTER_USER_FD PID1_NET_FD PID1_USER_FD");
        isolated(std::stoi(argv[7]), std::stoi(argv[8]), std::stoi(argv[9]), std::stoi(argv[10]));
        gate(argv[1], argv[2], false);
        const fs::path root(argv[3]);
        need(root.is_absolute() && !fs::exists(root) && fs::canonical(root.parent_path()) == root.parent_path(), "new owned root required");
        const auto port = std::stoul(argv[5]);
        need(port > 0 && port <= 65535 && std::string_view(argv[6]) == "PRIVATE", "explicit private fixture arguments required");
        fs::create_directory(root);
        write(root / "loaded-maps.txt", read("/proc/self/maps"));
        auto info = metadata(root);
        const auto full = info->info_hashes();
        need(full.has_v1() && full.has_v2(), "actual hybrid metadata required");
        const auto selected = mode(argv[4]);
        lt::session owner{lt::session_params(settings(static_cast<unsigned short>(port)))};
        Observe observed(root);
        until(owner, observed, [&] { return observed.bootstrapped && owner.listen_port() != 0; });
        lt::add_torrent_params parameters;
        parameters.ti = info; parameters.save_path = root.string(); parameters.flags |= selected;
        parameters.flags &= ~(lt::torrent_flags::paused | lt::torrent_flags::auto_managed);
        lt::error_code error;
        auto handle = owner.add_torrent(std::move(parameters), error);
        need(!error && handle.is_valid(), "actual selected admission: " + error.message());
        until(owner, observed, [&] { return handle.status().is_seeding; });
        std::cout << "READY\t" << owner.listen_port() << '\t' << hex(full.v1.data(), 20)
            << '\t' << hex(full.v2.data(), 32) << std::endl;
        std::string command;
        while (std::getline(std::cin, command)) {
            std::istringstream input(command); std::string op; input >> op;
            if (op == "DHT") { handle.force_dht_announce(); pump(owner, observed, 100); }
            else if (op == "PUMP") { unsigned millis = 0; input >> millis; pump(owner, observed, millis); }
            else if (op == "RESET_DHT") { observed.dhtPeerValues = 0; }
            else if (op == "NO_DHT_PEERS") {
                pump(owner, observed, 500);
                need(observed.dhtPeerValues == 0, "wrong-source reply delivered peer values to the torrent");
            }
            else if (op == "UNKNOWN") {
                until(owner, observed, [&] { return observed.unknownTransactions != 0 && observed.foreignPackets != 0; });
            }
            else if (op == "REJECT") {
                std::string peer; input >> peer;
                until(owner, observed, [&] { return observed.rejected.contains(peer); });
            }
            else if (op == "LSD") {
                std::string peer, hash; unsigned accepted = 2; input >> peer >> hash >> accepted;
                need(hash.size() == 40 && accepted <= 1, "LSD expectation arguments");
                until(owner, observed, [&] {
                    return std::ranges::any_of(observed.lsdLogs, [&](const auto& text) {
                        return text.find(peer + " ih: " + hash) != std::string::npos;
                    });
                });
                if (accepted) until(owner, observed, [&] { return observed.lsdPeers.contains(peer); });
                else { pump(owner, observed, 1500); need(!observed.lsdPeers.contains(peer), "unselected LSD hash admitted a peer"); }
            }
            else if (op == "CLOSE") {
                owner.remove_torrent(handle);
                until(owner, observed, [&] { return observed.removed; });
                std::cout << "OK\tCLOSE" << std::endl;
                return 0; // owner destruction joins its actual threads
            }
            else throw std::runtime_error("unknown fixture command");
            std::cout << "OK\t" << op << '\t' << observed.dhtReplies << '\t' << observed.unknownTransactions << std::endl;
        }
        throw std::runtime_error("driver input closed before explicit joined close");
    } catch (const std::exception& error) {
        std::cout << "FAIL\t" << error.what() << std::endl;
        return 2;
    }
}
