Selected-swarm DHT/LSD qualification — source only

This is a separate fixture, not an amendment to the frozen plain/MSE/tracker/payload wire harness. It adds no application, provider, original-profile or production-network activation. The fixture has not been compiled or executed by its author. Planned assertions and protocols below are not passing runtime evidence.

Scope

* Three real hybrid modes: Both (default), V1Only and V2Only. Each uses the actual selected provider's per-torrent DHT and LSD paths. Public session.dht_get_peers()/dht_announce() are deliberately not used to manufacture selection coverage.
* Actual IPv4 numeric-loopback BEP5 bootstrap/get_peers/announce_peer packets, compact peer results and real plain BitTorrent result handshakes are retained. Every announce key must be selected. Actual per-torrent get_peers keys must include each selected identity and exclude the unselected full hybrid identity. Unrelated random maintenance get_peers hashes are retained separately; they are not misreported as torrent identity leaks.
* BEP5 responses have NO info_hash field. Rejection coverage therefore uses a response for an actual transaction sent from a different numeric source IP, actual LT packet/log evidence of rejection, no delivered peer values, and no ghost handshake. A separate genuinely returned peer completes an actual wrong-info-hash handshake and must produce invalid_info_hash. This is not a claim that a nonexistent response hash field was validated.
* Actual LSD multicast announcements and injected receive packets are captured. Selected hash announcements must yield actual LSD peer alerts and handshakes. An unselected hash must be actually received/logged, without an LSD peer alert or handshake. The fixture does not infer reception merely from sendto success.
* No payload integrity, storage, MSE, IPv6, public routing, bootstrap or whole-provider parity credit belongs to this cohort. Existing independent wire/payload/counter/storage qualification remains required.

Mandatory isolation

Every DHT and multicast socket is created only inside fresh user AND network namespaces. The runner inherits open descriptors for the actual outer namespaces; both Python and C++ compare kernel inode identities, also against PID1's namespaces. Only lo may exist, checked through /proc/self/net/dev (sysfs can retain an outer mount's namespace). The runner brings up only private lo and adds only a private multicast route. No veth, physical interface, public address, public router or shared-host multicast fallback exists.

Root's retained namespace-probe*.json reports local sandbox and unsandboxed namespace denial. This is an explicit local runtime gap. Do not request host multicast permissions or weaken the gate. The source encoder executable can run without sockets/namespaces, but its result can NEVER substitute for the isolated runtime cohort. run.py exits77 and writes RUNTIME_GAP when namespace creation fails before the identity gate; an actual in-namespace fixture failure is FAIL/exit2. A hosted job must treat both as unqualified, not success/skip.

The encoder compiles exact extracted function bodies from pinned LT2.0.12: get_peers::invoke builds the actual pre-RPC entry against an explicitly inert RPC/log/counter boundary; render_lsd_packet is the actual formatter. Literal binary expectations, selection, no-seeds, done, absent-log, RPC-failure and truncation cases exercise those bodies. It creates NO LT session/socket/resolver and makes no actual UDP/discovery claim. The source-body hashes and original containing files are pinned separately.

Root build (never run by author)

Use the same actual source-qualified provider SDK/artifact, compiler and ABI options as its approved record. No existing native target or CMake is modified. Example paths:

    CAP=/home/yurii/Java/BiglyBT/build/storage-20261025/next-v2/discovery-oracle
    CANDIDATE=/home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate
    BUILD=/home/yurii/Java/BiglyBT/build/storage-20261025/provider-discovery/build
    cmake -S "$CAP/staging" -B "$BUILD" -G Ninja \
      -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_STANDARD=23 \
      -DCMAKE_CXX_COMPILER=/usr/bin/g++-16 \
      -DCMAKE_PREFIX_PATH="$CANDIDATE/install" \
      -DCMAKE_BUILD_RPATH="$CANDIDATE/install/lib"
    cmake --build "$BUILD" --parallel 1 --target \
      biglybtc-selected-discovery-driver biglybtc-selected-discovery-encoder

Retain actual configure/build commands, logs, source capsule SHA and produced executable hashes. The targets use strict warnings. Compilation is not runtime evidence. The fixture must not consume stock c35 or an unapproved candidate: run.py first executes the retained closed source-bound approver; both C++ executables additionally check the complete loaded artifact hash and same-object capability/version exports. The r3 canonical-test approval amendment is source context only until root measures and independently reviews the actual record/manifest/catalog pair. This capsule adds no approval.

Root runtime command, using actual reviewed output hashes (no defaults/wildcards):

    python3 "$CAP/staging/run.py" \
      --driver "$BUILD/biglybtc-selected-discovery-driver" --driver-sha256 ACTUAL_REVIEWED_SHA \
      --encoder "$BUILD/biglybtc-selected-discovery-encoder" --encoder-sha256 ACTUAL_REVIEWED_SHA \
      --artifact "$CANDIDATE/install/lib/libtorrent-rasterbar.so.2.0.12" --artifact-sha256 ACTUAL_APPROVED_SHA \
      --runtime-manifest "$CANDIDATE/approval-r3/provider-runtime.json" \
      --approver "$CANDIDATE/approval-r3/staging/engine/runtime-binding/verify_runtime_manifest.py" \
      --approver-sha256 ACTUAL_REVIEWED_SHA --approver-module-sha256 ACTUAL_REVIEWED_MODULE_SHA \
      --output /home/yurii/Java/BiglyBT/build/storage-20261025/discovery-run-NEW

The standalone approver's sibling module is independently hash-pinned too. No authored helper imports or runs the approval recorder. New output only; failed attempts/raw captures remain. Alert data is copied by the sole pop consumer before the next pop; no borrowed alert escapes. All peer/pipe threads and child owners join on success/failure, with finite deadlines. Actual raw UDP, handshakes, LT alerts, namespace identities, commands and input digests are retained; no fixed passing test/capture counts are guessed.

Hosted recipe

staging/selected-discovery-workflow.yml is an UNADOPTED workflow fragment for standard GitHub-hosted ubuntu-24.04 with ordinary runner sudo. It is workflow_dispatch only and grants read-only repository/actions permissions. Root may adopt this capsule under preview/migration/fixtures/selected-discovery. The hosted runner deliberately rejects the placeholder catalog before downloading or restoring anything.

Two-stage prerequisites: first build the exact provider and fixtures on a compatible host image, retain actual build/source/install/record inputs and run source-bound qualifications. Root independently reviews that artifact and freezes a complete ZIP member/hash map, repository/run/artifact identity, ZIP size/SHA, exact restore roots and runner options in hosted-inputs.json. Then a separately reviewed source amendment pins ONE actual catalog SHA in hosted.py and refreshes the capsule manifest. This is not a producer that autoapproves whatever CI just built. No workflow_dispatch hash/path input can grant trust.

Bundle includes the exact approved source/build/install trees, actual receipts/logs and full helper cohort needed by the retained approver, the source-pinned fixture capsule and compiled driver/encoder. Restore original recorded absolute paths; do not loosen relocation checks. Include only reviewed owned build/artifact roots; ordinary LT install aliases may be dereferenced with identical file bytes, no unreviewed symlinks/special files. The hosted tool preflights the entire pinned archive and every destination before mutation, refuses existing files/aliases, and verifies all restored members again before running. The bundle/runner image must actually satisfy the built ELF's glibc/libstdc++ ABI; no dependency substitution or success is assumed here.

GitHub's authenticated gh artifact downloader fetches the exact reviewed run/name; sudo performs only byte-checked restoration and the runner. Tokens are not forwarded to the fixture. The fixture still runs unshare --user --map-root-user --net and must pass both namespace gates. There is no host-multicast fallback even on hosted namespace denial. Raw result upload is independent of success. Root can dispatch this reviewed hosted lane later; no local or hosted execution is claimed by this source capsule.
