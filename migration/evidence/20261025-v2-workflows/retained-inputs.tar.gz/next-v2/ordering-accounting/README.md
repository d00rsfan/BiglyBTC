# CF02 original UTF16 ordering and checked-byte accounting

Source-only, uncompiled and unexecuted. Apply after the frozen CF02 identity/callers; keep the original capsules unchanged. Use per-file patches when composing with current CF01 storage fixes. No ManagedStorage/PersistentSession production changes are included.

- `originalTorrentInfoOrder(Document)` classifies unmodified raw info as byte-sorted or the pinned Java UTF16 file-tree order. Intake still rejects duplicates and unsafe original layouts. The exception applies only below the actual version2 `file tree`; unknown non-tree info dictionaries remain byte-sorted. It neither sorts nor encodes any node.
- The provider changes exactly `src/torrent_info.cpp`, adds private `src/biglybtc_utf16_info.hpp` and adds `test/test_biglybtc_utf16_info.cpp`. The existing soft-error path is retained; its exception independently walks every info token, rejects leading-zero lengths/integers, negative zero, duplicates, other unsorted dictionaries, invalid UTF8 and mixed tree ordering. It is bounded by32MiB,2million nodes,depth100. Global bdecode is unchanged. No public header/ABI/format/hash/layout changes.
- Provider tests assert original raw info/SHA256 and file/pad/empty indices, byte-canonical compatibility, and rejection of other malformed encodings. The existing caller tests gain an actual LT/intake/held-profile padded checkpoint and a canonical-external-tree geometry refusal. Actual execution against the amended provider is mandatory.
- Original `completedbytes` includes the checked logical span, including padding. Existing production checkpoint accounting matches this source. The old handoff assertion excluding pads was incorrect. The amended Java helper emits actual `getDownloadCompletedBytes`, disk total/remaining, and separate per-file payload/pad sums. The runner independently compares all of them, retaining every original slot and the narrow independently reproduced8/9 tail limitation. No transfer/full-byte/retained-seeding/close assertions are removed.

## Adoption and root execution

Apply `patches/app-*.patch` after callers; the old pure/caller targets stay unchanged and gain source families. Adopt the3 provider inputs only after the current immutable candidate build finishes; rebuild/approve its exact new source/artifact map before using it for owner handoffs. Upstream test/CMakeLists already globs `test_*.cpp`, so a refreshed test configuration exposes `test_biglybtc_utf16_info`. No shared CMake changes are authored here.

Adopt `oracle/tests/v2_managed_handoff_driver.cpp` at the existing driver path and rebuild that target centrally. Keep the amended runner/helper here; it verifies this manifest and all frozen baseline sources. It reuses the baseline V2MetadataOracle byte-exactly. Same CLI as the frozen runner, with optional `--ordering-only`: fresh owned `/tmp/biglybtc-managed-handoff-v2-*`, original5432 classes, ReferenceFence, no original rebuild. Ordering-only requires actual Java full hashes and every Java/LT index/path/offset/pad/empty fact to agree and records zero transfer credit. Run the full recipe separately for actual partial/complete transfers and original READY accounting; failure remains a failure, never a guessed remap.

`author.py` is retained initial authoring history, not a final installer/generator; do not rerun it over this frozen capsule. All final adopted leaves, patches and exact beforeimages are listed in manifest.json.

## Remaining boundaries

Canonical external UTF8 trees may enumerate files differently from the original UTF16 layout. The unchanged ManagedStorage exact geometry gate must reject that case before state/payload writes. No reindex, raw-info rewrite, hash alias, public-swarm, whole-client or complete original recheck parity is claimed. Source compatibility of the parser exception is not runtime qualification. The original-only8/9 case and its real empty file remain intact.
