from pathlib import Path
import difflib, hashlib, json, subprocess, ast
P=Path(__file__).resolve().parent
W=P.parent
F=W/'callers/staging'
N=Path('/home/yurii/Java/BiglyBTC')
LT=N/'build/dependencies/source-qualified-2.0.12/source'

def staged(path,source):
    dest=P/'staging'/path; dest.parent.mkdir(parents=True,exist_ok=True)
    if source is not None:
        before=P/'before'/path; before.parent.mkdir(parents=True,exist_ok=True)
        before.write_bytes(source.read_bytes()); dest.write_bytes(source.read_bytes())
    return dest

paths=['preview/native/adapters/original_torrent_identity.hpp','preview/native/adapters/original_torrent_identity.cpp','preview/native/adapters/torrent_intake.cpp','preview/native/tests/original_torrent_identity_tests.cpp','preview/native/tests/original_identity_callers_tests.cpp']
for path in paths: staged(path,F/path)
for name in ['run.py','V2ManagedOracle.java','tests/v2_managed_handoff_driver.cpp']:
    dst=P/'oracle'/name; dst.parent.mkdir(parents=True,exist_ok=True)
    before=P/'before/oracle'/name;before.parent.mkdir(parents=True,exist_ok=True)
    before.write_bytes((W/'oracle'/name).read_bytes());dst.write_bytes(before.read_bytes())
for path in ['src/torrent_info.cpp','test/test_biglybtc_utf16_info.cpp','src/biglybtc_utf16_info.hpp']:
    dst=P/'provider/staging'/path;dst.parent.mkdir(parents=True,exist_ok=True)
    if (LT/path).exists():
        before=P/'provider/before'/path;before.parent.mkdir(parents=True,exist_ok=True)
        before.write_bytes((LT/path).read_bytes());dst.write_bytes(before.read_bytes())

h=P/'staging/preview/native/adapters/original_torrent_identity.hpp'
s=h.read_text(); marker='// Explicit full32 is an opt-in reader compatibility policy'
s=s.replace(marker,'''// Read-only classification of the exact original info subject. The Java mode
// permits UTF16/String.compareTo order only inside the version2 file tree;
// all other dictionaries remain byte sorted. This never grants geometry or
// selected-swarm authority and never re-encodes/reorders any hashed byte.
enum class OriginalInfoOrder { ByteSorted, JavaUtf16FileTree };
std::expected<OriginalInfoOrder,Error> originalTorrentInfoOrder(const core::Document&);
'''+marker);h.write_text(s)

utf='''bool utf16Key(std::string_view bytes, std::u16string& out) {
  out.clear();
  for (std::size_t at=0;at<bytes.size();) {
    const auto first=static_cast<unsigned char>(bytes[at++]);
    std::uint32_t scalar=0, minimum=0; unsigned continuation=0;
    if (first<0x80) { scalar=first; }
    else if ((first&0xe0)==0xc0) { scalar=first&0x1f; continuation=1; minimum=0x80; }
    else if ((first&0xf0)==0xe0) { scalar=first&0x0f; continuation=2; minimum=0x800; }
    else if ((first&0xf8)==0xf0) { scalar=first&0x07; continuation=3; minimum=0x10000; }
    else { return false; }
    if (continuation>bytes.size()-at) { return false; }
    for (unsigned i=0;i<continuation;++i) {
      const auto next=static_cast<unsigned char>(bytes[at++]);
      if ((next&0xc0)!=0x80) { return false; }
      scalar=(scalar<<6)|(next&0x3f);
    }
    if (scalar<minimum||scalar>0x10ffff||(scalar>=0xd800&&scalar<=0xdfff)) { return false; }
    if (scalar<0x10000) { out.push_back(static_cast<char16_t>(scalar)); }
    else { scalar-=0x10000; out.push_back(static_cast<char16_t>(0xd800+(scalar>>10))); out.push_back(static_cast<char16_t>(0xdc00+(scalar&0x3ff))); }
  }
  return true;
}
'''
cpp=P/'staging/preview/native/adapters/original_torrent_identity.cpp'
s=cpp.read_text().replace('#include <algorithm>','#include <algorithm>\n#include <cstdint>')
assert s.endswith('}\n')
s=s[:-2]+'''namespace {
'''+utf+'''struct InfoOrderState { bool byteSorted=true,javaSorted=true; std::size_t nodes=0; };
void infoOrderNode(const Node& node,const Node* tree,bool inTree,std::size_t depth,InfoOrderState& state) {
  require(depth<=128&&++state.nodes<=2000000&&!node.changed&&!node.origin,
      ErrorCode::InvalidFormat,"Original info order requires bounded pristine nodes");
  if (node.type==Node::Type::Dictionary) {
    require(node.children.size()%2==0,ErrorCode::InvalidFormat,"Incomplete original info dictionary");
    std::string_view previous; std::u16string priorUnits; bool priorValid=true;
    for (std::size_t i=0;i<node.children.size();i+=2) {
      const auto& key=node.children[i];
      require(++state.nodes<=2000000&&key.type==Node::Type::Bytes&&!key.changed&&!key.origin,
          ErrorCode::InvalidFormat,"Invalid original info dictionary key");
      if (inTree) {
        state.byteSorted=state.byteSorted&&(i==0||previous<key.bytes);
        std::u16string units; const bool valid=utf16Key(key.bytes,units);
        state.javaSorted=state.javaSorted&&valid&&(i==0||(priorValid&&priorUnits<units));
        priorValid=valid; priorUnits=std::move(units);
      } else {
        require(i==0||previous<key.bytes,ErrorCode::InvalidFormat,"Noncanonical original info keys outside v2 file tree");
      }
      previous=key.bytes; const auto& value=node.children[i+1];
      infoOrderNode(value,tree,inTree||&value==tree,depth+1,state);
    }
  } else if (node.type==Node::Type::List) {
    for (const auto& value:node.children) { infoOrderNode(value,tree,inTree,depth+1,state); }
  }
}
}
std::expected<OriginalInfoOrder,Error> originalTorrentInfoOrder(const core::Document& document) {
  return guarded([&]()->std::expected<OriginalInfoOrder,Error> {
    auto subject=originalTorrentInfoSubject(document); if (!subject) { return std::unexpected(subject.error()); }
    require(subject->size()<=32*1024*1024,ErrorCode::InvalidFormat,"Original info exceeds metadata bound");
    const auto* info=one(document.root(),"info"); const auto* tree=one(*info,"file tree");
    const auto* version=one(*info,"meta version");
    if (!tree||tree->type!=Node::Type::Dictionary||!version||version->type!=Node::Type::Integer||version->integer!=2) { tree=nullptr; }
    InfoOrderState state; infoOrderNode(*info,tree,false,0,state);
    if (state.byteSorted) { return OriginalInfoOrder::ByteSorted; }
    require(tree&&state.javaSorted,ErrorCode::InvalidFormat,"Original v2 tree is neither byte-sorted nor consistently Java UTF16-sorted");
    return OriginalInfoOrder::JavaUtf16FileTree;
  });
}
}
''';cpp.write_text(s)
intake=P/'staging/preview/native/adapters/torrent_intake.cpp'
s=intake.read_text(); assert s.count('  uniqueKeys(*info, 0, true);')==1
s=s.replace('  uniqueKeys(*info, 0, true);','  (void)take(originalTorrentInfoOrder(torrent)); // Exact raw bytes; qualified provider accepts only the narrow Java tree exception.')
intake.write_text(s)

# Provider is private to torrent_info.cpp; global bdecode policy stays unchanged.
p=P/'provider/staging/src/biglybtc_utf16_info.hpp'
provider_utf=utf.replace('std::string_view','string_view')
p.write_text('''// Private compatibility exception for the pinned original BEncoder file tree.
// No exported ABI; included only by torrent_info.cpp. No raw bytes are edited.
#pragma once
#include "libtorrent/bdecode.hpp"
#include <algorithm>
#include <cstdint>
#include <string>

namespace libtorrent { namespace aux { namespace biglybtc_info_detail {
'''+provider_utf+'''inline bool byteLess(string_view a,string_view b) {
  return std::lexicographical_compare(a.begin(),a.end(),b.begin(),b.end(),
      [](char x,char y){return static_cast<unsigned char>(x)<static_cast<unsigned char>(y);});
}
inline bool canonicalScalar(bdecode_node const& node) {
  auto const raw=node.data_section();
  if (node.type()==bdecode_node::string_t) {
    return raw.size()>=2&&(raw[0]!='0'||raw[1]==':');
  }
  if (node.type()==bdecode_node::int_t) {
    if (raw.size()<3||raw[0]!='i'||raw[raw.size()-1]!='e') return false;
    int const start=raw[1]=='-'?2:1;
    if (start>=raw.size()-1||raw[start]<'0'||raw[start]>'9') return false;
    if (raw[start]=='0'&&(start==2||raw.size()!=3)) return false;
    for (int i=start;i<raw.size()-1;++i) if (raw[i]<'0'||raw[i]>'9') return false;
  }
  return true;
}
struct State { int tokens=0; bool changedOrder=false; };
inline bool canonicalNode(bdecode_node const& node,std::ptrdiff_t treeOffset,bool inTree,int depth,State& state) {
  if (depth>100||++state.tokens>2000000||!canonicalScalar(node)) return false;
  if (node.type()==bdecode_node::dict_t) {
    string_view previous; std::u16string priorUnits;
    for (int i=0;i<node.dict_size();++i) {
      auto const entry=node.dict_at_node(i);
      if (++state.tokens>2000000||entry.first.type()!=bdecode_node::string_t||!canonicalScalar(entry.first)) return false;
      auto const key=entry.first.string_value();
      if (inTree) {
        std::u16string units;
        if (!utf16Key(key,units)||(i>0&&!(priorUnits<units))) return false;
        if (i>0&&!byteLess(previous,key)) state.changedOrder=true;
        priorUnits=std::move(units);
      } else if (i>0&&!byteLess(previous,key)) return false;
      previous=key;
      if (!canonicalNode(entry.second,treeOffset,inTree||entry.second.data_offset()==treeOffset,depth+1,state)) return false;
    }
  } else if (node.type()==bdecode_node::list_t) {
    for (int i=0;i<node.list_size();++i) if (!canonicalNode(node.list_at(i),treeOffset,inTree,depth+1,state)) return false;
  } else if (node.type()!=bdecode_node::string_t&&node.type()!=bdecode_node::int_t) return false;
  return true;
}
} // biglybtc_info_detail
inline bool biglybtcOriginalUtf16Info(bdecode_node const& info) {
  if (info.type()!=bdecode_node::dict_t||info.data_section().size()>32*1024*1024
      ||info.dict_find_int_value("meta version",-1)!=2) return false;
  auto const tree=info.dict_find_dict("file tree");
  if (!tree) return false;
  biglybtc_info_detail::State state;
  return biglybtc_info_detail::canonicalNode(info,tree.data_offset(),false,0,state)&&state.changedOrder;
}
} } // libtorrent::aux
''')
p=P/'provider/staging/src/torrent_info.cpp';s=p.read_text();s=s.replace('#include "libtorrent/config.hpp"','#include "libtorrent/config.hpp"\n#include "biglybtc_utf16_info.hpp"');assert s.count('if (info.has_soft_error(error_string))')==1
s=s.replace('if (info.has_soft_error(error_string))','if (info.has_soft_error(error_string)\n\t\t\t\t&& !aux::biglybtcOriginalUtf16Info(info))')
p.write_text(s)
# Header hygiene: provider itself still targets the upstream C++ language level.
p=P/'provider/staging/src/biglybtc_utf16_info.hpp';s=p.read_text().replace('#include <string>','#include <string>\n#include <utility>').replace('bool utf16Key(','inline bool utf16Key(').replace('int const start=raw[1]', 'std::ptrdiff_t const start=raw[1]').replace('for (int i=start;i<raw.size()-1;++i)', 'for (std::ptrdiff_t i=start;i<raw.size()-1;++i)');p.write_text(s)

# Pure ordering classification regressions extend the existing executable.
p=P/'staging/preview/native/tests/original_torrent_identity_tests.cpp';s=p.read_text();before='int main(){try{sourceSelectorIntegers();'
assert before in s
extra=r'''
void exactFileTreeOrdering() {
  const std::string astral="\xf0\x90\x80\x80",bmp="\xee\x80\x80";
  const auto leaf=[](){return std::string("d0:d6:lengthi0eee");};
  const auto subject=[&](std::string tree,std::string extra={}) {
    return parse("d4:infod9:file tree"+tree+"12:meta versioni2e4:name1:f12:piece lengthi16384e"+extra+"ee");
  };
  auto java=subject("d"+b(astral)+leaf()+b(bmp)+leaf()+"e");
  const auto raw=java.serialize(); const auto info=std::string(take(st::originalTorrentInfoSubject(java)));
  check(take(st::originalTorrentInfoOrder(java))==st::OriginalInfoOrder::JavaUtf16FileTree,"actual Java String order has narrow explicit classification");
  check(java.serialize()==raw&&take(st::originalTorrentInfoSubject(java))==info,"classification preserves every original hashed byte");
  auto bytes=subject("d"+b(bmp)+leaf()+b(astral)+leaf()+"e");
  check(take(st::originalTorrentInfoOrder(bytes))==st::OriginalInfoOrder::ByteSorted,"external byte-canonical v2 remains valid input");
  auto duplicate=subject("d"+b(astral)+leaf()+b(astral)+leaf()+"e");
  check(!st::originalTorrentInfoOrder(duplicate),"duplicate tree components never gain an exception");
  const auto javaTree="d"+b(astral)+leaf()+b(bmp)+leaf()+"e";
  const auto byteTree="d"+b(bmp)+leaf()+b(astral)+leaf()+"e";
  auto mixed=subject("d1:a"+javaTree+"1:b"+byteTree+"e");
  check(!st::originalTorrentInfoOrder(mixed),"mixed dictionary ordering cannot be passed as original Java encoding");
  auto outside=parse("d4:infod4:name1:f9:file tree"+javaTree+"12:meta versioni2e12:piece lengthi16384eee");
  check(!st::originalTorrentInfoOrder(outside),"unsorted non-tree info remains rejected");
  auto notV2=parse("d4:infod9:file tree"+javaTree+"4:name1:fee");
  check(!st::originalTorrentInfoOrder(notV2),"unknown v1 file tree cannot mint v2 exception");
  auto badUtf8=subject("d"+b(astral)+leaf()+b(bmp)+leaf()+b(std::string("\xed\xa0\x80",3))+leaf()+"e");
  check(!st::originalTorrentInfoOrder(badUtf8),"encoded surrogate is not a Java UTF8 tree component");
  check(java.replaceValue("info",info).has_value()&&!st::originalTorrentInfoOrder(java),"edited info still requires a fresh parse/hash chain");
}
'''
# C++ string literal escapes above are intentional actual UTF8 byte literals.
s=s.replace('\n}\nint main()',extra+'\n}\nint main()')
s=s.replace(before,'int main(){try{exactFileTreeOrdering();sourceSelectorIntegers();').replace('five original selected-identity families passed','six original selected-identity/order families passed');p.write_text(s)

# Actual LT + existing intake/ManagedStorage fixtures keep geometry and full hashes.
p=P/'staging/preview/native/tests/original_identity_callers_tests.cpp';s=p.read_text();extra=r'''
std::string orderingMetadata(bool javaOrder) {
  const std::string astral="\xf0\x90\x80\x80-a",bmp="\xee\x80\x80-b",empty="\xef\xbf\xbf-empty";
  const auto leaf=[&](char value){const auto root=lt::hasher256(&value,1).final().to_string();return "d0:d6:lengthi1e11:pieces root"+b(root)+"ee";};
  const auto a=b(astral)+leaf('a'),z=b(bmp)+leaf('z');
  return "d4:infod9:file treed"+(javaOrder?a+z:z+a)+b(empty)+"d0:d6:lengthi0eeee12:meta versioni2e4:name6:bundle12:piece lengthi16384eee";
}
void originalJavaOrderAndPaddedProgress() {
  Area a;const auto bytes=orderingMetadata(true);const auto source=doc(bytes);
  check(take(storage::originalTorrentInfoOrder(source))==storage::OriginalInfoOrder::JavaUtf16FileTree,"source-compatible UTF16 file tree recognized");
  const auto key=a.importMetadata(bytes);const auto selected=identity(bytes);
  check(key==selected.originalKey,"UTF16 import keeps actual full-hash selected prefix");
  const auto subject=take(storage::originalTorrentInfoSubject(source));
  const lt::torrent_info engine(lt::span<const char>(bytes.data(),bytes.size()),lt::from_span);
  check(std::string_view(engine.info_section().data(),engine.info_section().size())==subject
      &&engine.info_hashes().v2==lt::hasher256(subject.data(),static_cast<int>(subject.size())).final(),"provider retains exact raw info and SHA256, never sorted replacement");
  auto owner=take(Owner::prepare(*a.lease,key,{}));const auto& files=owner.parameters().ti->files();
  check(files.num_files()==5&&files.pad_file_at(lt::file_index_t{1})&&files.pad_file_at(lt::file_index_t{3})
      &&files.file_size(lt::file_index_t{4})==0,"two pads and real empty index retained");
  for(int i:{0,2}){write(a.destination/files.file_path(lt::file_index_t{i}),i==0?"a":"z");}
  done(owner.checkpoint(*a.lease,std::array<std::uint8_t,2>{1,1},true,2,0));
  const auto saved=doc(read(a.state(key)));const auto* progress=saved.find("attributes")->find("filedownloaded")->find("downloaded");
  check(progress&&progress->children.size()==5,"original per-file progress slot count unchanged");
  check(progress->children[0].integer==1&&progress->children[1].integer==16383&&progress->children[2].integer==1
      &&progress->children[3].integer==16383&&progress->children[4].integer==0,"original logical intersections include virtual pads and real empty slot");
  auto inventory=doc(read(a.profile/"downloads.config"));
  check(inventory.find("downloads")->children[0].find("completedbytes")->integer==32768,"original completedbytes is logical checked span, not two payload bytes");
  check(take(storage::originalTorrentInfoSubject(saved))==subject,"checkpoint does not rewrite differently sorted raw info");
}
void canonicalExternalTreeCannotReindexOriginalGeometry() {
  Area a;const auto bytes=orderingMetadata(false);const auto key=a.importMetadata(bytes);
  const auto saved=read(a.state(key)),inventory=read(a.profile/"downloads.config");
  auto owner=Owner::prepare(*a.lease,key,{});
  check(!owner&&owner.error().code==Code::Unsupported,"external UTF8 order versus Java UTF16 index mismatch remains fail closed");
  check(read(a.state(key))==saved&&read(a.profile/"downloads.config")==inventory&&!fs::exists(a.destination),"no guessed reindex or payload mutation on geometry mismatch");
}
'''
assert '\n}\nint main()' in s;s=s.replace('\n}\nint main()',extra+'\n}\nint main()')
s=s.replace('int main(){try{selectedImportAndOfflineOperations();','int main(){try{originalJavaOrderAndPaddedProgress();++families;canonicalExternalTreeCannotReindexOriginalGeometry();++families;selectedImportAndOfflineOperations();');p.write_text(s)
