import com.biglybt.core.Core;
import com.biglybt.core.disk.DiskManagerFileInfo;
import com.biglybt.core.disk.DiskManagerPiece;
import com.biglybt.core.diskmanager.file.FMFile;
import com.biglybt.core.diskmanager.file.FMFileManagerFactory;
import com.biglybt.core.diskmanager.file.FMFileOwner;
import com.biglybt.core.download.DownloadManager;
import com.biglybt.core.download.DownloadManagerInitialisationAdapter;
import com.biglybt.core.torrent.TOTorrentFile;
import com.biglybt.core.util.DirectByteBuffer;
import com.biglybt.core.util.StringInterner;
import java.io.File;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

/** Dynamic version of the maintained actual GlobalManager READY handoff. */
public final class V2ManagedOracle {
    private static void prepareReordered(final DownloadManager manager, Path expected) throws Exception {
        DiskManagerFileInfo[] files = manager.getDiskManagerFileInfoSet().getFiles();
        int chosen = -1;
        for (DiskManagerFileInfo file : files) {
            if (!file.getTorrentFile().isPadFile() && file.getLength() >= 4 * 16384) { chosen = file.getIndex(); break; }
        }
        if (chosen < 0 || !files[chosen].setStorageType(DiskManagerFileInfo.ST_REORDER)) {
            throw new IllegalStateException("Original could not create a selected reorder fixture");
        }
        for (final DiskManagerFileInfo file : files) {
            TOTorrentFile source = file.getTorrentFile();
            if (source.isPadFile()) { continue; }
            file.setPriority(0); file.setSkipped(false);
            byte[] bytes = Files.readAllBytes(expected.resolve(source.getRelativePath()));
            if (bytes.length != source.getLength()) { throw new IllegalStateException("Fixture length differs"); }
            Path actual = file.getFile(true).toPath(); Files.createDirectories(actual.getParent());
            if (file.getIndex() != chosen) { Files.write(actual, bytes); continue; }
            FMFileOwner owner = new FMFileOwner() {
                public String getName() { return "owned v2 reorder handoff"; }
                public TOTorrentFile getTorrentFile() { return file.getTorrentFile(); }
                public File getControlFileDir() { return manager.getDownloadState().getStateDir(); }
                public StringInterner.FileKey getFileLink(StringInterner.FileKey path) { return path; }
                public long getFileAllocationStrategy() { return 0; }
            };
            FMFile target = FMFileManagerFactory.getSingleton().createFile(owner,
                new StringInterner.FileKey(actual.toFile()), FMFile.FT_PIECE_REORDER, false);
            target.setAccessMode(FMFile.FM_WRITE);
            try {
                int first = 16384 - (int)(source.getOffsetInTorrent() % 16384);
                int second = first + 16384;
                target.write(new DirectByteBuffer(ByteBuffer.wrap(Arrays.copyOfRange(bytes, 0, first))), 0);
                target.write(new DirectByteBuffer(ByteBuffer.wrap(Arrays.copyOfRange(bytes, second, second + 16384))), second);
                target.flush();
            } finally { target.close(); }
        }
    }
    private static void run(String[] args) throws Exception {
        if (!(System.getSecurityManager() instanceof ReferenceFence) || args.length != 4) {
            throw new IllegalArgumentException("ReferenceFence: LISTEN EXPECTED_DIRECTORY_OR_FILE inspect|bytes|prepare-reordered EXPECTED_DONE_OR_-1");
        }
        Class.forName("com.biglybt.core.util.Debug");
        Path root = Paths.get(System.getProperty("biglybtc.test.root")).toRealPath();
        Path expected = Paths.get(args[1]).toRealPath(); int wanted = Integer.parseInt(args[3]);
        boolean prepare = args[2].equals("prepare-reordered"), bytesRequired = args[2].equals("bytes");
        if ((!prepare && !bytesRequired && !args[2].equals("inspect")) || wanted < -1) { throw new IllegalArgumentException("Invalid bounded role"); }
        Core core = EngineOracle.configuredCore(Integer.parseInt(args[0])); boolean started = false;
        try {
            core.start(); started = true; DownloadManager manager;
            if (prepare) {
                Files.createDirectories(root.resolve("payload"));
                manager = core.getGlobalManager().addDownloadManager(root.resolve("input.torrent").toString(), null,
                    root.resolve("payload").toString(), DownloadManager.STATE_STOPPED, true, false,
                    new DownloadManagerInitialisationAdapter() {
                        public int getActions() { return ACT_NONE; }
                        public void initialised(DownloadManager download, boolean seeding) {
                            download.getDownloadState().setNetworks(new String[]{"Public"});
                            download.getDownloadState().setPeerSources(new String[]{"Plugin", "Incoming"});
                        }
                    });
                if (manager == null) { throw new IllegalStateException("Original rejected generated reorder metadata"); }
                prepareReordered(manager, expected);
            } else {
                List<DownloadManager> saved = core.getGlobalManager().getDownloadManagers();
                if (saved.size() != 1) { throw new IllegalStateException("Exactly one actual saved download required"); }
                manager = saved.get(0);
            }
            V2MetadataOracle.facts(manager.getTorrent());
            manager.initialize(); long deadline = System.nanoTime() + 90000000000L;
            while (manager.getState() != DownloadManager.STATE_READY) {
                if (manager.getState() == DownloadManager.STATE_ERROR || System.nanoTime() >= deadline) {
                    throw new IllegalStateException("Actual original READY failed: " + manager.getErrorDetails());
                }
                Thread.sleep(25);
            }
            DiskManagerPiece[] pieces = manager.getDiskManager().getPieces(); int done = 0; StringBuilder bitmap = new StringBuilder();
            if (pieces.length == 0 || pieces.length > 1024) { throw new IllegalStateException("Unbounded generated geometry"); }
            for (DiskManagerPiece piece : pieces) { if (piece.isDone()) { ++done; } bitmap.append(piece.isDone() ? '1' : '0'); }
            if ((wanted >= 0 && done != wanted) || (prepare && (done == 0 || done == pieces.length))) {
                throw new IllegalStateException("Actual original checked count differs " + done + "/" + pieces.length);
            }
            System.out.println("V2_READY\t" + done + "\t" + pieces.length + "\t" + bitmap);
            long payloadCompleted = 0, paddingCompleted = 0, payloadBytes = 0, paddingBytes = 0;
            for (DiskManagerFileInfo file : manager.getDiskManagerFileInfoSet().getFiles()) {
                if (file.getTorrentFile().isPadFile()) {
                    paddingCompleted = Math.addExact(paddingCompleted, file.getDownloaded());
                    paddingBytes = Math.addExact(paddingBytes, file.getLength());
                } else {
                    payloadCompleted = Math.addExact(payloadCompleted, file.getDownloaded());
                    payloadBytes = Math.addExact(payloadBytes, file.getLength());
                }
            }
            // Actual original getters, not an expected completedbytes expression.
            System.out.println("V2_PROGRESS\t" + manager.getStats().getDownloadCompletedBytes()
                + "\t" + manager.getDiskManager().getTotalLength() + "\t" + manager.getDiskManager().getRemaining()
                + "\t" + payloadCompleted + "\t" + paddingCompleted + "\t" + payloadBytes + "\t" + paddingBytes);
            System.out.println("V2_INTENT\t" + manager.isForceStart() + "\t" + manager.isPaused() + "\t" + manager.getPosition()
                + "\t" + manager.getStats().getDownloadRateLimitBytesPerSecond() + "\t" + manager.getStats().getUploadRateLimitBytesPerSecond());
            System.out.println("V2_COUNTERS\t" + manager.getStats().getTotalDataBytesReceived() + "\t" + manager.getStats().getTotalDataBytesSent());
            for (DiskManagerFileInfo file : manager.getDiskManagerFileInfoSet().getFiles()) {
                TOTorrentFile source = file.getTorrentFile(); Path actual = file.getFile(true).toPath().toAbsolutePath().normalize();
                System.out.println("V2_FILE\t" + file.getIndex() + "\t" + source.getOffsetInTorrent() + "\t" + file.getLength()
                    + "\t" + source.isPadFile() + "\t" + file.getPriority() + "\t" + file.isSkipped()
                    + "\t" + file.getStorageType() + "\t" + file.getDownloaded() + "\t" + V2MetadataOracle.hex(actual.toString().getBytes("UTF-8")));
                if (source.isPadFile()) { continue; }
                if (Files.isSymbolicLink(actual) || !actual.toRealPath().startsWith(root.resolve("payload").toRealPath())) {
                    throw new IllegalStateException("Actual real file escaped the generated payload");
                }
                if (bytesRequired) {
                    Path wantedPath = manager.getTorrent().isSimpleTorrent() ? expected : expected.resolve(source.getRelativePath());
                    byte[] original = Files.readAllBytes(wantedPath), observed = new byte[original.length];
                    if (original.length > 0) {
                        DirectByteBuffer buffer = file.read(0, original.length);
                        try {
                            if (buffer.getFlag(DirectByteBuffer.FL_CONTAINS_TRANSIENT_DATA)) { throw new IllegalStateException("Complete bytes remain transient"); }
                            buffer.position(DirectByteBuffer.SS_FILE, 0); buffer.get(DirectByteBuffer.SS_FILE, observed);
                        } finally { buffer.returnToPool(); }
                    }
                    if (!Arrays.equals(original, observed) || Files.size(actual) == 0 && original.length != 0) {
                        throw new IllegalStateException("Actual original logical data differs including real empty entry");
                    }
                }
            }
            manager.stopIt(DownloadManager.STATE_STOPPED, false, false);
        } finally { if (started) { core.stop(); } }
        System.out.println("V2_ORIGINAL_STOPPED");
    }
    public static void main(String[] args) {
        try { run(args); System.exit(0); }
        catch (Throwable failure) { failure.printStackTrace(); System.exit(2); }
    }
}
