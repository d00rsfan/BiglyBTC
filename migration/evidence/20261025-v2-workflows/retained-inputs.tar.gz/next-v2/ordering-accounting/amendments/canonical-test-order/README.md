# Correct byte-order fixture

The byte-canonical test accidentally kept the U+FFFF empty entry last after U+10000. Correct UTF8 order is E000,FFFF,10000; original Java UTF16 order remains10000,E000,FFFF. Only the two fixture builders change. All assertions, payloads/roots and production helper/TU remain byte exact. Root observed provider line68 failed on this malformed positive; no author execution.
