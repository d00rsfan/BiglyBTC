// Source-derived parser compatibility tests; root executes against the exact
// rebuilt provider. These are not original-Java or active swarm equality credit.
#include "test.hpp"
#include "libtorrent/bdecode.hpp"
#include "libtorrent/error_code.hpp"
#include "libtorrent/hasher.hpp"
#include "libtorrent/torrent_info.hpp"
#include "../src/biglybtc_utf16_info.hpp"
#include <array>
#include <string>
#include <vector>
using namespace lt;
namespace {
std::string b(std::string const& text) { return std::to_string(text.size())+':'+text; }
std::string const astral="\xf0\x90\x80\x80-a",bmp="\xee\x80\x80-b",empty="\xef\xbf\xbf-empty";
std::string leaf(char byte) {
 return "d0:d6:lengthi1e11:pieces root"+b(hasher256(&byte,1).final().to_string())+"ee";
}
std::string info(std::string tree) {
 return "d9:file tree"+tree+"12:meta versioni2e4:name6:bundle12:piece lengthi16384ee";
}
std::string tree(bool javaOrder) {
 auto const a=b(astral)+leaf('a'),z=b(bmp)+leaf('z');
 return "d"+(javaOrder?a+z:z+a)+b(empty)+"d0:d6:lengthi0eeee";
}
std::string replaceOne(std::string value,std::string const& from,std::string const& to) {
 auto const at=value.find(from);TEST_CHECK(at!=std::string::npos);
 if (at!=std::string::npos) value.replace(at,from.size(),to);
 return value;
}
bool exception(std::string const& subject) {
 error_code ec;auto const parsed=bdecode(span<char const>(subject.data(),subject.size()),ec,nullptr,128,2000000);
 if(ec) return false;
 return aux::biglybtcOriginalUtf16Info(parsed);
}
void refused(std::string const& subject) {
 TEST_CHECK(!exception(subject));
 auto const full="d4:info"+subject+'e';error_code ec;
 torrent_info ti(full.data(),static_cast<int>(full.size()),ec);
 TEST_EQUAL(ec,errors::invalid_bencoding);
}
}
TORRENT_TEST(biglybtc_original_utf16_info_hash_and_indices)
{
 auto const subject=info(tree(true)),full="d4:info"+subject+'e';error_code ec;
 auto const decoded=bdecode(span<char const>(subject.data(),subject.size()),ec);
 TEST_CHECK(!ec);std::array<char,200> message{};
 TEST_CHECK(decoded.has_soft_error(message)); // Global bdecode remains strict.
 TEST_CHECK(exception(subject));
 torrent_info ti(full.data(),static_cast<int>(full.size()),ec);
 TEST_CHECK(!ec);if(ec)return;
 TEST_EQUAL(std::string(ti.info_section().data(),ti.info_section().size()),subject);
 TEST_EQUAL(ti.info_hashes().v2,hasher256(subject.data(),static_cast<int>(subject.size())).final());
 TEST_EQUAL(ti.num_files(),5);TEST_EQUAL(ti.total_size(),32768);
 auto const& files=ti.files();
 TEST_EQUAL(files.file_path(file_index_t{0}),"bundle/"+astral);
 TEST_EQUAL(files.file_path(file_index_t{2}),"bundle/"+bmp);
 TEST_EQUAL(files.file_path(file_index_t{4}),"bundle/"+empty);
 TEST_CHECK(files.pad_file_at(file_index_t{1})&&files.pad_file_at(file_index_t{3}));
 TEST_EQUAL(files.file_offset(file_index_t{2}),16384);
 TEST_EQUAL(files.file_size(file_index_t{4}),0);
}
TORRENT_TEST(biglybtc_original_utf16_info_preserves_byte_canonical_input)
{
 auto const subject=info(tree(false)),full="d4:info"+subject+'e';error_code ec;
 TEST_CHECK(!exception(subject)); // Existing fast path, not the exception.
 torrent_info ti(full.data(),static_cast<int>(full.size()),ec);
 TEST_CHECK(!ec);if(ec)return;
 TEST_EQUAL(ti.files().file_path(file_index_t{0}),"bundle/"+bmp);
 TEST_EQUAL(ti.info_hashes().v2,hasher256(subject.data(),static_cast<int>(subject.size())).final());
 TEST_EQUAL(std::string(ti.info_section().data(),ti.info_section().size()),subject);
}
TORRENT_TEST(biglybtc_original_utf16_info_rejects_other_soft_errors)
{
 auto const subject=info(tree(true));
 refused(replaceOne(subject,"i1e","i01e"));
 refused(replaceOne(subject,"i1e","i-0e"));
 refused(replaceOne(subject,"9:file tree","09:file tree"));
 refused(replaceOne(subject,"4:name6:bundle12:piece lengthi16384e","12:piece lengthi16384e4:name6:bundle"));
 refused(replaceOne(subject,b(bmp)+leaf('z'),b(astral)+leaf('z')));
 // Outside-tree arbitrary maps are not part of the BEncoder compatibility exception.
 refused(replaceOne(subject,"4:name6:bundle","4:name6:bundle6:opaqued1:zi1e1:ai2ee"));
 // A canonical-order descendant cannot disguise a mixed order Java tree.
 refused(info("d1:ad"+b(astral)+leaf('a')+b(bmp)+leaf('z')+"e1:bd"+b(bmp)+leaf('z')+b(astral)+leaf('a')+"ee"));
}
TORRENT_TEST(biglybtc_original_utf16_info_rejects_invalid_unicode_and_bounds)
{
 auto const subject=info(tree(true));
 for(auto const& invalid:std::vector<std::string>{std::string("\xc0\x80",2),std::string("\xed\xa0\x80",3),std::string("\xf4\x90\x80\x80",4),std::string("\xe2\x82",2)}) {
  refused(replaceOne(subject,b(bmp),b(invalid)));
 }
 std::string nested="d0:d6:lengthi0eee";
 for(int i=0;i<102;++i) nested="d1:x"+nested+'e';
 TEST_CHECK(!exception(info("d"+b(astral)+leaf('a')+b(bmp)+nested+'e')));
}
