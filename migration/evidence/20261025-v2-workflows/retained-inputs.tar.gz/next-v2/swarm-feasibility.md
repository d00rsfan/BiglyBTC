# Selected-hybrid swarm feasibility

Source-only; no provider/session execution, patch, source adoption or ABI experiment. Exact inputs are in `swarm-source-pins.json`. Original cb8c6cb9bb97916cbc7e80338a017200ffc3e71f; LT2.0.12 bound source.

**Recommendation:** a reviewed source-provider extension is required for a complete selected-swarm contract. No documented public API found enforces it while retaining the original full metainfo and geometry. Preserve offline identity support separately; do not call ordinary LT hybrid dual-swarm admission equivalent to the original selected swarm.

## Original behavior supported by source

`TOTorrentImpl.setHashFromInfo` computes both full hybrid hashes and selects20-byte v1 by default or truncated v2 when private `hybrid_hash_v2==1`. `getEffectiveTorrentType` follows that choice. For ordinary, non-overridden downloads:

- DownloadManagerController.getTargetHash returns that selected original hash.
- PEPeerTransportProtocol sends it in BTHandshake and rejects a different incoming handshake hash.
- TRTrackerBTAnnouncerImpl builds its request info_hash from the selected getHashWrapper; DHTTrackerPlugin targets the selected getHash.
- PEPeerControlImpl selects its v2 hash handler only for effective typeV2.

These are exact source facts, not a new packet capture. Existing older ordinary hybrid transfers do not prove selected-v2 wire exclusion. Original target-hash override remains a distinct unsupported native policy, not a reason to accept arbitrary hashes.

## Public options and limits

| Option | Why it does not provide the full restriction |
|---|---|
| `add_torrent_params.info_hashes` / magnet exact topics | `session_impl::add_torrent_impl` replaces it from valid `ti` at5070. Hash-only admission initially has one hash but `torrent::set_metadata` expands to full metadata hashes at7857. |
| `torrent_info` copy/constructor, handle metadata APIs | Metadata hash getters are const; there is no supported per-swarm mask setter. Hash-only torrent_info is not full metadata. `remap_files` is explicitly incompatible with v2 and cannot solve identity policy. Removing fields or mutating private hash caches would break hash/verification invariants. |
| Tracker endpoint state or replace_trackers | Public endpoint enabled is per tracker/socket, not a stable per-hash policy. Retry counters/times are observations, not an exclusion capability. DHT/LSD, inbound lookup and handshake remain. |
| Public session/torrent/peer plugins | Peer handshake callbacks can reject some peers but cannot veto all tracker/DHT/LSD publication or change the session's registered hash identities. Plugins run after torrent start; there is no documented pre-admission protocol-selector hook. |
| Global discovery disable + explicit peer hints | Useful owned-loopback test policy, not complete selected-swarm behavior. It removes functionality and does not itself make the alternate hash unavailable to incoming connections. |

## Smallest defensible provider extension

Retain `torrent_info`'s two full hashes, raw info bytes, piece layers and exact file geometry. Add an immutable admission-time **wire protocol mask** with explicit DefaultBoth/V1Only/V2Only and validated availability. DefaultBoth preserves unmodified upstream callers; normal original-compatible hybrid admissions request their actual original selected mode. Reject conflicting/unsupported masks before starting a torrent or preparing payload state. A live mode switch requires retirement and fresh admission.

Prefer a separate wire-hash accessor derived from full metadata and the mask. **Do not merely clear `torrent::m_info_hash`:** peer_connection.cpp5339–5354 uses it to request v1/v2 disk verification, while torrent.cpp2804/2892/3421 uses `torrent_info` hashes directly for LSD/DHT/scrape. A field-only edit either misses publication paths or changes verification policy.

The bounded patch must consistently cover:

1. Session insertion/removal, duplicate detection, normal/encrypted incoming lookup and metadata-arrival reindex/collision handling. No unselected hash entry or accidental alias coalescing.
2. Tracker announces and scrapes, including manual/completed/stopped events; DHT and LSD sends and result admission.
3. Outgoing peer protocol choice, explicit peer hints, incoming handshake matching, encrypted matching, PEX/imported peers and hybrid upgrade negotiation. Unselected protocol hints cannot override policy.
4. Metadata refresh and all restore paths retain the mask. Full metadata hashes and disk/Merkle verification inputs stay available independently.

A small provider-only admission flag representation could avoid changing add_torrent_params layout, but it is a new private contract, not supported upstream API. It needs an explicit capability/version check and exact source/artifact runtime binding; stock providers silently ignoring unknown flags must fail closed. New patched DSO bytes require a separate approved runtime catalog entry; existing c35f source qualification cannot be relabelled. No new alert consumer, strong torrent reference, counter policy or storage authority is needed.

## Finite qualification before enabling

Use owned loopback peers and HTTP/UDP tracker fixtures to observe selected and unselected handshake/announce hashes, both modes, incoming/outgoing, plus actual transfer and v1/v2 verification. Cover metadata arrival/restart, wrong-protocol hints, mixed peers and duplicate selected identities. Exercise DHT/LSD hash selection with bounded owned transport/encoder fixtures, never public discovery. Verify raw info/piece layers/file geometry and both full metadata hashes before/after; original Java reload must retain the selected getHash/effective type.

These are proposed gates, not tests executed here. Full public-network equivalence or an ABI-compatible provider patch is not yet certified.
