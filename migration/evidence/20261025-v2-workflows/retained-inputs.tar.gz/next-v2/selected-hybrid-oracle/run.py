#!/usr/bin/env python3
"""Two actual original selected-hybrid profiles -> native transfer -> Java READY.

Root executes this recipe; source preparation never implies observed success.
"""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
JAVA = Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-root', type=Path, required=True)
    parser.add_argument('--driver', type=Path, required=True)
    parser.add_argument('--classes', type=Path, default=Path('/tmp/biglybtc-oracle/classes'))
    parser.add_argument('--retention', type=Path, default=Path('/home/yurii/Java/BiglyBTC/build/dependencies/java-oracle-17-20261021/retention.json'))
    parser.add_argument('--work', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE / 'manifest.json').read_text())
    for name, digest in manifest['artifacts'].items():
        need(sha(HERE / name) == digest, 'Changed selected-hybrid source: ' + name)
    for name, digest in manifest['dependency_files'].items():
        need(sha(Path(name)) == digest, 'Changed frozen dependency: ' + name)
    legacy = Path(manifest['reused_tail_oracle'])
    # Reuse its unchanged actual-output parser/READY consistency checks, not an
    # expected reimplementation or a rerun of its seven unrelated cases.
    spec = importlib.util.spec_from_file_location('frozen_tail_observations', legacy / 'oracle/run.py')
    observation = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(observation)
    baseline = json.loads((Path(manifest['reused_initial_oracle']) / 'manifest.json').read_text())
    ref = args.reference_root.resolve(strict=True)
    for group in ('reference_sha256', 'original_source_sha256'):
        for name, digest in baseline[group].items():
            need(sha(ref / name) == digest, 'Changed actual original source/helper: ' + name)
    need(sha(args.retention) == baseline['retention_sha256'], 'Changed original cohort identity')
    retention = json.loads(args.retention.read_text())
    need(retention['source_commit'] == manifest['original_commit'] and retention['recompiled'] is False,
         'Wrong original cohort')
    classes = args.classes.resolve(strict=True)
    need(classes == args.classes and classes.is_relative_to('/tmp')
         and observation.files(classes) == retention['file_sha256'], 'Changed retained5432 original classes')
    driver = args.driver.resolve(strict=True)
    need(driver.is_file() and not args.driver.is_symlink(), 'Actual bound native driver required')
    work = args.work.absolute()
    need(work.parent == Path('/tmp') and work.name.startswith('biglybtc-managed-handoff-selected-')
         and not work.exists() and not work.is_symlink() and work.resolve() == work, 'Fresh private owned work required')
    work.mkdir(mode=0o700)
    for name in ('classes', 'empty-sourcepath', 'generation'):
        (work / name).mkdir(mode=0o700)
    env = {k: v for k, v in os.environ.items()
           if k not in ('CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'LD_PRELOAD', 'LD_AUDIT')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    commands = []

    def run(name, argv, cwd, timeout=180):
        command = {'name': name, 'argv': list(map(str, argv)), 'cwd': str(cwd), 'timeout': timeout}
        commands.append(command)
        (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        with (work / (name + '.stdout')).open('wb') as out, (work / (name + '.stderr')).open('wb') as err:
            completed = subprocess.run(command['argv'], cwd=cwd, env=env, stdout=out, stderr=err, timeout=timeout)
        need(completed.returncode == 0, 'Actual command failed; raw logs retained: ' + name)
        return (work / (name + '.stdout')).read_text()

    sources = [ref / 'migration/fixtures/java' / name for name in
               ('ReferenceFence.java', 'EngineOracle.java', 'InteropOracle.java')]
    sources += [legacy / 'oracle/V2MetadataOracle.java', legacy / 'oracle/V2ManagedOracle.java', HERE / 'SelectedHybridOracle.java']
    run('javac-thin-helpers', [JAVA / 'javac', '-J-XX:ActiveProcessorCount=2', '--release', '8', '-encoding', 'UTF-8',
        '-proc:none', '-implicit:none', '-sourcepath', work / 'empty-sourcepath', '-cp', classes, '-d', work / 'classes', *sources], work, 60)
    sys.path.insert(0, str(ref / 'migration/tools'))
    from peer_interop import jvm, unused_port
    from handoff import decode
    cp = str(work / 'classes') + os.pathsep + str(classes)

    def java(name, root, helper, *arguments, ports=()):
        return run(name, [*jvm(root, cp, ports), helper, *arguments], root)

    def state(path):
        raw = path.read_bytes()
        need(len(raw) <= 4 * 1024 * 1024, 'Bounded actual state required')
        if raw.startswith(b'\x1f\x8b'):
            raw = gzip.decompress(raw)
        need(len(raw) <= 4 * 1024 * 1024, 'Bounded decoded state required')
        return decode(raw)

    generation = work / 'generation'
    java('original-generate', generation, 'InteropOracle', 'generate', generation / 'single')
    original_metadata = generation / 'single/profile/generated-2.torrent'
    expected = generation / 'single/generated.bin'
    payload_digest = sha(expected)
    source_metadata_digest = sha(original_metadata)
    _, source_spans = state(original_metadata)
    source_subject = source_spans[(b'info',)]
    result = {'status': 'RUNNING', 'original_commit': manifest['original_commit'],
              'manifest_sha256': sha(HERE / 'manifest.json'), 'driver_sha256': sha(driver), 'cases': {}}
    (work / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    for version, effective in (('v1', 1), ('v2', 3)):
        name = 'selected-hybrid-' + version
        metadata = generation / (name + '.torrent')
        selected_text = java(name + '-original-select', generation, 'SelectedHybridOracle', original_metadata, metadata, version)
        need('SELECTED_HYBRID\t' + version in selected_text.splitlines(), 'Actual original selection receipt absent')
        selected = observation.rows(selected_text)
        facts = selected['metadata']
        _, selected_spans = state(metadata)
        need(selected_spans[(b'info',)] == source_subject, 'Original selection changed hashed info bytes')
        need(facts['type'] == 2 and facts['effective'] == effective and facts['v1'] != '-' and facts['v2'] != '-'
             and facts['selected'] == (facts['v1'] if version == 'v1' else facts['v2'][:40]),
             'Actual selected identity/full hashes/type disagree')
        need(hashlib.sha1(source_subject).hexdigest().upper() == facts['v1']
             and hashlib.sha256(source_subject).hexdigest().upper() == facts['v2'], 'Actual original full hashes differ from raw info')
        case = work / name
        case.mkdir(mode=0o700)
        shutil.copyfile(metadata, case / 'input.torrent')
        metadata_digest = sha(case / 'input.torrent')
        port = unused_port()
        java(name + '-original-prepare', case, 'EngineOracle', port, 0, case / 'input.torrent', expected, 'prepare-partial', ports=(port,))
        port = unused_port()
        initial = observation.checked(observation.rows(java(name + '-original-baseline', case,
            'V2ManagedOracle', port, expected, 'inspect', -1, ports=(port,))))
        need(initial['metadata'] == facts and initial['indices'] == selected['indices'], 'Original profile lost explicit selected metadata')
        total, piece = initial['ready']['total'], facts['piece']
        need(0 < initial['ready']['done'] < total and piece == 16384 and len(initial['files']) == 1
             and not initial['files'][0]['skipped'] and initial['files'][0]['priority'] == 0,
             'Actual selected real-file fixture must be normally selected and partially verified')
        omitted = next((i for i in range(total - 2, -1, -1) if initial['ready']['bits'][i] == '0'), None)
        need(omitted is not None, 'A missing real non-tail piece is required')
        profile = case / 'profile'
        active = profile / 'active' / (facts['selected'] + '.dat')
        _, original_spans = state(active)
        preserve = [(b'info',), (b'azureus_private_properties', b'unknown.selected.fixture'), (b'unknown.future.plugin',)]
        need(all(key in original_spans for key in preserve), 'Actual original profile lost opaque fixture/provenance')
        observations = []
        for mode in ('partial', 'complete'):
            config_before = (profile / 'biglybt.config').read_bytes()
            inventory, _ = state(profile / 'downloads.config')
            previous = inventory[b'downloads'][0]
            output = case / ('native-' + mode)
            run(name + '-native-' + mode, [driver, work, profile, case / 'input.torrent', expected, output, mode, omitted], case)
            native = json.loads((output / 'result.json').read_text())
            need(native['selected_version'] == version and native['swarm_marker'] == 1
                 and native['seed_swarm_v1'] is (version == 'v1') and native['seed_swarm_v2'] is (version == 'v2'),
                 'Actual native source-bound seed did not use exclusively selected indices')
            if mode == 'complete':
                need(native['receiver_swarm_v1'] is (version == 'v1') and native['receiver_swarm_v2'] is (version == 'v2')
                     and int(native['retained_seed_received']) > 0, 'Actual selected retained receiver/seeding proof missing')
            else:
                need(native['receiver_swarm_v1'] is None and native['receiver_swarm_v2'] is None,
                     'Partial mode must not fabricate a receiver observation')
            need(native['hash'] == facts['selected'] and native['full_v1'] == facts['v1'] and native['full_v2'] == facts['v2']
                 and native['total_pieces'] == total and native['pieces'] == total - (mode == 'partial')
                 and native['session_joined'] and native['storage_released'] and int(native['received']) > 0,
                 'Actual selected managed transfer/full identity/retirement proof incomplete')
            need(native['engine_trailing_pad'] is False and len(native['original_files']) == len(native['engine_files']) == 1,
                 'Aligned selected-hybrid fixture must preserve exact one-file geometry')
            for original, engine in zip(native['original_files'], native['engine_files']):
                observed = initial['indices'][original['index']]
                need(original['index'] == engine['index'] == 0 and int(original['offset']) == int(engine['offset']) == observed['offset']
                     and int(original['bytes']) == int(engine['bytes']) == observed['bytes']
                     and original['pad'] == engine['pad'] == observed['pad'] and original['path'] == observed['path'],
                     'Actual selected geometry differs from original indices')
            inventory, _ = state(profile / 'downloads.config')
            current = inventory[b'downloads'][0]
            need(current[b'downloaded'] == previous.get(b'downloaded', 0) + int(native['received'])
                 and current[b'uploaded'] == previous.get(b'uploaded', 0) + int(native['sent']), 'Actual selected deltas charged incorrectly')
            saved, spans = state(active)
            need(all(spans.get(key) == original_spans[key] for key in preserve), 'Native changed exact raw info or opaque properties')
            counts = saved[b'attributes'][b'filedownloaded'][b'downloaded']
            need(len(counts) == 1 and type(counts[0]) is int and 0 <= counts[0] <= facts['logicalBytes']
                 and counts[0] == current[b'completedbytes'] == int(native['completed'])
                 and int(native['bytes']) == facts['logicalBytes'], 'Original/native actual progress differs')
            need((profile / 'biglybt.config').read_bytes() == config_before, 'Native modified original global config')
            port = unused_port()
            observed = observation.checked(observation.rows(java(name + '-java-' + mode, case, 'V2ManagedOracle',
                port, expected, 'bytes' if mode == 'complete' else 'inspect', -1, ports=(port,))))
            bits = ''.join('0' if mode == 'partial' and i == omitted else '1' for i in range(total))
            need(observed['metadata'] == facts and observed['indices'] == initial['indices'] and observed['intent'] == initial['intent']
                 and observed['counters'] == (current[b'downloaded'], current[b'uploaded']) and observed['ready']['bits'] == bits,
                 'Actual original reload lost selection/identity/intents/counters or verified pieces')
            need(observed['progress']['completedLogical'] == observed['progress']['completedPayload'] == counts[0]
                 and observed['progress']['completedPadding'] == 0 and observed['files'][0]['downloaded'] == counts[0]
                 and observed['files'][0]['priority'] == initial['files'][0]['priority']
                 and observed['files'][0]['skipped'] == initial['files'][0]['skipped'], 'Actual original file policy/progress differs')
            need(sha(expected) == payload_digest and sha(case / 'input.torrent') == metadata_digest,
                 'Actual input/expected payload was modified')
            observations.append({'mode': mode, 'native': native, 'original': observed})
        result['cases'][name] = {'status': 'PASS_ACTUAL_ORIGINAL_SELECTED_PROFILE_HANDOFF', 'baseline': initial,
                                 'omitted_real_piece': omitted, 'observations': observations}
        (work / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    need(sha(original_metadata) == source_metadata_digest and observation.files(classes) == retention['file_sha256'],
         'Original generator subject or retained core cohort changed')
    result.update(status='PASS_ACTUAL_ORIGINAL_SELECTED_HYBRID_PROFILE_HANDOFF', commands=commands,
        helper_classes_sha256=observation.files(work / 'classes'),
        logs_sha256={p.name: sha(p) for p in sorted(work.glob('*.std*'))},
        original_core_recompiled=False, original_profile_or_process_access=False,
        scope='Two generated regular selected hybrid profiles, actual owned selected-swarm peers, actual Java READY/data reload',
        limitations=['No pending-magnet or public-network exclusivity credit',
                     'Known original multifile8/9 and UTF16 ordering characterization remain separate unchanged gates'])
    (work / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(result['status'])


if __name__ == '__main__':
    main()
