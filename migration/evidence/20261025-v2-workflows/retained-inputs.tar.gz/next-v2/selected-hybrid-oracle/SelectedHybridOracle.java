import com.biglybt.core.torrent.TOTorrent;
import com.biglybt.core.torrent.TOTorrentFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/** Only actual original selection/serialization; no native hash/piece mirror. */
public final class SelectedHybridOracle {
    private static void run(String[] args) throws Exception {
        if (!(System.getSecurityManager() instanceof ReferenceFence) || args.length != 3) {
            throw new IllegalArgumentException("ReferenceFence: INPUT OUTPUT v1|v2");
        }
        Class.forName("com.biglybt.core.util.Debug");
        Path root = Paths.get(System.getProperty("biglybtc.test.root")).toRealPath();
        Path input = Paths.get(args[0]).toRealPath();
        Path output = Paths.get(args[1]).toAbsolutePath().normalize();
        if (!input.startsWith(root) || !output.startsWith(root) || Files.isSymbolicLink(input)
                || Files.exists(output) || Files.isSymbolicLink(output)
                || !(args[2].equals("v1") || args[2].equals("v2"))) {
            throw new IllegalArgumentException("Fresh owned selection fixture required");
        }
        TOTorrent source = TOTorrentFactory.deserialiseFromBEncodedFile(input.toFile());
        if (source.getTorrentType() != TOTorrent.TT_V1_V2
                || source.getFullHash(TOTorrent.TT_V1) == null || source.getFullHash(TOTorrent.TT_V2) == null) {
            throw new IllegalArgumentException("Actual full hybrid input required");
        }
        Map<String, Object> old = source.getAdditionalMapProperty("azureus_private_properties");
        Map<String, Object> properties = old == null ? new HashMap<String, Object>() : new HashMap<String, Object>(old);
        properties.put("unknown.selected.fixture", Arrays.asList(Long.valueOf(7), "opaque–π".getBytes(StandardCharsets.UTF_8)));
        source.setAdditionalMapProperty("azureus_private_properties", properties);
        int type = args[2].equals("v1") ? TOTorrent.TT_V1 : TOTorrent.TT_V2;
        TOTorrent selected = source.selectHybridHashType(type);
        selected.serialiseToBEncodedFile(output.toFile());
        TOTorrent reloaded = TOTorrentFactory.deserialiseFromBEncodedFile(output.toFile());
        if (reloaded.getTorrentType() != TOTorrent.TT_V1_V2 || reloaded.getEffectiveTorrentType() != type) {
            throw new IllegalStateException("Actual serialized selected type changed");
        }
        V2MetadataOracle.facts(reloaded);
        System.out.println("SELECTED_HYBRID\t" + args[2]);
    }
    public static void main(String[] args) {
        try { run(args); System.exit(0); }
        catch (Throwable failure) { failure.printStackTrace(); System.exit(2); }
    }
}
