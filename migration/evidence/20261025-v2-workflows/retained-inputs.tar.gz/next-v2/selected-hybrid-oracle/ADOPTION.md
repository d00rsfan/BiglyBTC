# Actual original selected-hybrid handoff extension

Source only, no author compilation/execution/native mutation. Keep all ordering/tail/original limitation capsules unchanged. Depends on selected-admission4d9d6ccb and the exact approved final runtime integration0eb59123. Copy only the new `staging/preview/native/tests/selected_hybrid_handoff_driver.cpp`; add the guarded `Targets.cmake` registration. The driver is a narrow clone of the frozen trailing-pad driver, with its original verification/retirement/byte assertions retained.

Root command after its coherent driver build:

```sh
python3 -B build/storage-20261025/next-v2/selected-hybrid-oracle/run.py \
  --reference-root /home/yurii/Java/BiglyBT \
  --driver /ABSOLUTE/QUALIFIED_BUILD/tests/biglybtc-selected-hybrid-handoff-driver \
  --work /tmp/biglybtc-managed-handoff-selected-FRESH
```

The runner reuses the retained5432 original classes, the unchanged ReferenceFence/EngineOracle/InteropOracle bootstrap, and frozen V2MetadataOracle/V2ManagedOracle observations. It compiles only thin fixture helpers; no original core build. One new small helper calls actual `selectHybridHashType(TT_V1/TT_V2)`, adds an opaque private field through the actual original API, serializes/reloads, and reports actual effective/full identities. The runner requires exact unchanged raw info and full SHA1/SHA256 for both selected files.

Only two actual generated regular selected hybrid profiles run. Each starts with authentic normally-selected original partial data, continues native partial progress, reopens actual original READY, finishes natively, seeds a real independent receiver, then reopens original READY and reads every payload byte through its real disk API. Exact original identity/index/policy/intents/raw opaque fields, original cumulative deltas, native joined/storage receipt and original observed logical/payload progress remain mandatory. Global config is captured anew immediately before each native invocation so legitimate prior Java port setup is not mislabeled as native mutation.

The new driver requires the same opaque full runtime proof before fixture payload effects and sets selected-only immutable masks on its actual seed and independent retained receiver. It records their real session indices; missing/old/unqualified providers fail, never skip. Actual native owner admission uses the production selected bridge and is independently exercised by the selected admission Qt tests. A successful handoff proves generated selected-profile interoperability and actual owned selected-peer data flow; it does not claim that this fixture probes every possible unselected public handshake.

The original multifile8/9 tail+empty limitation, UTF16-order probes and pure-v2 trailing-pad gate are separate unchanged evidence. They are neither rerun nor generalized away here. Pending magnets, public trackers/network and real user profiles/processes are excluded. commands.json, raw stdout/stderr, exact helper class hashes and incremental result.json are retained in the fresh work directory even when a gate fails.
