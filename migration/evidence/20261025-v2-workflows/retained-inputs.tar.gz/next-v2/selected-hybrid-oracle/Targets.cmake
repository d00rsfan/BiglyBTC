# Additive root-owned registration. Driver is run only by the fenced Python
# recipe, never as an argument-free CTest. It requires the final approved SDK.
if(BIGLYBTC_LOCAL_ENGINE AND BIGLYBTC_DESKTOP AND BIGLYBTC_PAYLOAD_COUNTER_TEST_LANE STREQUAL "Qualified")
  add_executable(biglybtc-selected-hybrid-handoff-driver selected_hybrid_handoff_driver.cpp)
  target_link_libraries(biglybtc-selected-hybrid-handoff-driver PRIVATE
    biglybtc_local_engine biglybtc_profile LibtorrentRasterbar::torrent-rasterbar Qt6::Core)
  target_compile_options(biglybtc-selected-hybrid-handoff-driver PRIVATE -Wall -Wextra -Wpedantic -Werror)
endif()
