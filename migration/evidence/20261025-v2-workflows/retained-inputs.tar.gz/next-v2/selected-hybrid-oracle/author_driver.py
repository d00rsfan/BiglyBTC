#!/usr/bin/env python3
"""Source authoring only; no compiler, native mutation or subject execution."""
from pathlib import Path
HERE = Path(__file__).resolve().parent
BASE = HERE.parent / 'trailing-pad/oracle/tests/v2_managed_handoff_driver.cpp'
raw = BASE.read_bytes()
(HERE / 'before').mkdir(exist_ok=True)
(HERE / 'before/v2_managed_handoff_driver.cpp').write_bytes(raw)
text = raw.decode()
def change(old, new):
    global text
    assert text.count(old) == 1, (old[:100], text.count(old))
    text = text.replace(old, new)
change('#include "persistent_session.hpp"', '#include "persistent_session.hpp"\n#include "managed_payload_counters.hpp"\n#include <libtorrent/biglybtc_swarm.hpp>')
change('#include <iostream>', '#include <iostream>\n#include <optional>')
change('Usage: v2_managed_handoff_driver ', 'Usage: selected_hybrid_handoff_driver ')
change('''    require(exactIdentity.has_value(),"Actual LT hashes do not bind to exact original raw info");''', '''    require(exactIdentity.has_value(),"Actual LT hashes do not bind to exact original raw info");
    require(exactIdentity->full.v1&&exactIdentity->full.v2,"This focused extension requires an actual full hybrid");
    auto swarmBridge=engine::detail::managedPayloadCounterBridge();
    require(swarmBridge&&lt::biglybtc_swarm_mask_abi_v1()==1,
        "Selected handoff requires the exact approved counter/swarm module before fixture payload effects");
    const bool useV2=exactIdentity->selected==storage::OriginalSelectedHash::V2;
    const auto selectedMask=useV2?lt::biglybtc_v2_only:lt::biglybtc_v1_only;''')
change('''    const auto seedHandle = seed->add_torrent(seedOptions, error);''', '''    require(engine::detail::selectManagedSwarm(seedOptions,*exactIdentity,swarmBridge),
        "Cannot bind the actual owned seed to the selected full identity");
    const auto seedHandle = seed->add_torrent(seedOptions, error);''')
change('''    require(!error && seedHandle.is_valid(), "Cannot admit owned seed");''', '''    require(!error && seedHandle.is_valid(), "Cannot admit owned seed");
    const auto full=metadata->info_hashes();
    const bool seedV1=seed->find_torrent(full.v1).is_valid(),seedV2=seed->find_torrent(full.v2).is_valid();
    require(seedV1==!useV2&&seedV2==useV2&&(seedHandle.status().flags & lt::biglybtc_swarm_mask)==selectedMask,
        "Actual owned seed indices are not exclusively selected");
    require(seedHandle.info_hashes()==full,"Selected seed lost the full hybrid metadata identity");''')
change('''    std::int64_t uploadedToActualLeecher=0;''', '''    std::int64_t uploadedToActualLeecher=0;
    std::optional<bool> receiverV1,receiverV2;''')
change('''      auto receiver=leecher.add_torrent(receive,error);require(!error&&receiver.is_valid(),"Cannot admit actual owned leecher");''', '''      require(engine::detail::selectManagedSwarm(receive,*exactIdentity,swarmBridge),
          "Cannot bind retained receiver to the selected full identity");
      auto receiver=leecher.add_torrent(receive,error);require(!error&&receiver.is_valid(),"Cannot admit actual owned leecher");
      receiverV1=leecher.find_torrent(full.v1).is_valid();receiverV2=leecher.find_torrent(full.v2).is_valid();
      require(*receiverV1==!useV2&&*receiverV2==useV2&&(receiver.status().flags & lt::biglybtc_swarm_mask)==selectedMask,
          "Actual retained receiver indices are not exclusively selected");
      require(receiver.info_hashes()==full,"Selected receiver lost the full hybrid metadata identity");''')
change('''    QJsonObject receipt{{QStringLiteral("schema"), 1},''', '''    QJsonObject receipt{{QStringLiteral("schema"), 1},
        {"selected_version",useV2?"v2":"v1"},{"swarm_marker",1},
        {"seed_swarm_v1",seedV1},{"seed_swarm_v2",seedV2},
        {"receiver_swarm_v1",receiverV1?QJsonValue(*receiverV1):QJsonValue(QJsonValue::Null)},
        {"receiver_swarm_v2",receiverV2?QJsonValue(*receiverV2):QJsonValue(QJsonValue::Null)},''')
target=HERE/'staging/preview/native/tests/selected_hybrid_handoff_driver.cpp'
target.parent.mkdir(parents=True,exist_ok=True)
target.write_text(text)
