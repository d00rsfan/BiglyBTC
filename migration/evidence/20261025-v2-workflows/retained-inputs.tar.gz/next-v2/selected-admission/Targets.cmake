# Append within the EXISTING Qualified payload-counter lane in tests/CMakeLists.
# Unsupported lane reuses its existing target, amended with two selected-hybrid
# rows. Never run the positive suite on a stock/old/unqualified provider.
if(BIGLYBTC_PAYLOAD_COUNTER_TEST_LANE STREQUAL "Qualified")
  add_executable(biglybtc-selected-swarm-admission-tests selected_swarm_admission_tests.cpp)
  set_target_properties(biglybtc-selected-swarm-admission-tests PROPERTIES AUTOMOC ON)
  target_link_libraries(biglybtc-selected-swarm-admission-tests PRIVATE
    biglybtc_local_engine LibtorrentRasterbar::torrent-rasterbar Qt6::Test ${CMAKE_DL_LIBS})
  target_link_options(biglybtc-selected-swarm-admission-tests PRIVATE "LINKER:--wrap=dlsym")
  target_compile_options(biglybtc-selected-swarm-admission-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  add_test(NAME selected-swarm-admission COMMAND biglybtc-selected-swarm-admission-tests)
  set_tests_properties(selected-swarm-admission PROPERTIES TIMEOUT 120 LABELS "unit;qualified-provider;original-identity")
endif()
