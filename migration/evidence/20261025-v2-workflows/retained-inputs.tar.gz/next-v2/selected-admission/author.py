#!/usr/bin/env python3
"""Authoring history only. Writes this capsule, never native or parent staging."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1] / 'integration/amendments/trailing-pad/final-stage/preview/native'

def edit(path, replacements):
    raw = (BASE / path).read_bytes()
    before = HERE / 'before/preview/native' / path
    after = HERE / 'staging/preview/native' / path
    before.parent.mkdir(parents=True, exist_ok=True)
    after.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes(raw)
    text = raw.decode()
    for old, new in replacements:
        assert text.count(old) == 1, (path, old[:100], text.count(old))
        text = text.replace(old, new)
    after.write_text(text)

edit('engine/persistent_runtime_guard.hpp', [
    ('#pragma once\n', '#pragma once\n\n#include <memory>\n'),
    ('// Same full proof, plus the provider-owned raw payload-counter capability/read\n// exports.',
     '// Same full proof, plus the raw payload-counter and selected-swarm exports.'),
    ('bool managedPayloadCounterRuntimeQualified() noexcept;',
     '''bool managedPayloadCounterRuntimeQualified() noexcept;
// Returns the SAME handle held throughout the complete mapped-image proof.
// It cannot unload between that proof and the admission/plugin lifetime pin.
std::shared_ptr<void> managedPayloadCounterRuntimePin() noexcept;'''),
])
edit('engine/persistent_runtime_guard.cpp', [
    ('#include <unistd.h>\n', '#include <unistd.h>\n#include <utility>\n'),
    ('bool checkLoadedProvider(bool counterBridge = false) {',
     'bool checkLoadedProvider(bool counterBridge = false, std::shared_ptr<void>* retainedPin = nullptr) {'),
    ('"biglybtc_payload_counter_abi_v1", "biglybtc_read_payload_counters_v1"};\n  const std::size_t required = counterBridge ? 8 : 6;\n  std::array<std::uintptr_t, 8> addresses{};\n  std::array<Mapping, 8> beforeMappings{};',
     '''"biglybtc_payload_counter_abi_v1", "biglybtc_read_payload_counters_v1",
      "biglybtc_swarm_mask_abi_v1"};
  const std::size_t required = counterBridge ? 9 : 6;
  std::array<std::uintptr_t, 9> addresses{};
  std::array<Mapping, 9> beforeMappings{};'''),
    ('  return canonicalMatches(object->l_name, *actual);',
     '''  if (!canonicalMatches(object->l_name, *actual)) { return false; }
  if (retainedPin) {
    // Transfer, rather than reopen, the object which passed every mapping,
    // descriptor, source-bound digest and before/after identity check above.
    // exchange also prevents a double dlclose if shared_ptr allocation fails.
    *retainedPin = std::shared_ptr<void>(std::exchange(library.value, nullptr),
        [](void* value) { if (value) { ::dlclose(value); } });
  }
  return true;'''),
    ('bool managedPayloadCounterRuntimeQualified() noexcept {\n#if BIGLYBTC_PERSISTENT_RUNTIME_BOUND\n  try { return checkLoadedProvider(true); }\n  catch (...) { return false; }\n#else\n  return false;\n#endif\n}',
     '''std::shared_ptr<void> managedPayloadCounterRuntimePin() noexcept {
#if BIGLYBTC_PERSISTENT_RUNTIME_BOUND
  try {
    std::shared_ptr<void> pin;
    if (!checkLoadedProvider(true, &pin)) { return {}; }
    return pin;
  } catch (...) { return {}; }
#else
  return {}; // Default build does not open a provider to manufacture approval.
#endif
}
bool managedPayloadCounterRuntimeQualified() noexcept {
  return static_cast<bool>(managedPayloadCounterRuntimePin());
}'''),
])
edit('engine/managed_payload_counters.hpp', [
    ('namespace biglybtc::engine::detail {',
     'namespace biglybtc::storage { struct OriginalTorrentIdentity; }\n\nnamespace biglybtc::engine::detail {'),
    ('// Immutable pin to the approved provider\'s supported raw-counter bridge.',
     '// Immutable pin to the approved provider\'s raw-counter AND selected-swarm ABI.'),
    ('std::shared_ptr<const ManagedPayloadCounterBridge> managedPayloadCounterBridge() noexcept;',
     '''std::shared_ptr<const ManagedPayloadCounterBridge> managedPayloadCounterBridge() noexcept;
// Before any state/payload effects, use a raw-info-validated full identity to
// choose exactly one immutable swarm. Header presence or a marker is insufficient:
// only the opaque, same-image-qualified bridge can authorize these flags.
// Failure leaves every parameter unchanged. No metadata/hash rewriting occurs.
bool selectManagedSwarm(libtorrent::add_torrent_params&,
    const storage::OriginalTorrentIdentity&,
    const std::shared_ptr<const ManagedPayloadCounterBridge>&) noexcept;'''),
])
edit('engine/managed_payload_counters.cpp', [
    ('#include "persistent_runtime_guard.hpp"', '#include "persistent_runtime_guard.hpp"\n#include "original_torrent_identity.hpp"'),
    ('#include <libtorrent/torrent_handle.hpp>', '#include <libtorrent/torrent_handle.hpp>\n#include <libtorrent/torrent_info.hpp>'),
    ('#include <utility>', '#include <algorithm>\n#include <utility>'),
    ('#if defined(__linux__) && __has_include(<libtorrent/biglybtc_payload_counters.hpp>) \\\n    && !defined(TORRENT_DISABLE_EXTENSIONS)',
     '#if defined(__linux__) && __has_include(<libtorrent/biglybtc_payload_counters.hpp>) \\\n    && __has_include(<libtorrent/biglybtc_swarm.hpp>) && !defined(TORRENT_DISABLE_EXTENSIONS)'),
    ('#include <libtorrent/biglybtc_payload_counters.hpp>', '#include <libtorrent/biglybtc_payload_counters.hpp>\n#include <libtorrent/biglybtc_swarm.hpp>'),
    ('  decltype(&libtorrent::biglybtc_read_payload_counters_v1) read = nullptr;',
     '  decltype(&libtorrent::biglybtc_read_payload_counters_v1) read = nullptr;\n  decltype(&libtorrent::biglybtc_swarm_mask_abi_v1) swarm = nullptr;'),
    ('''    // The existing complete artifact/source/hash proof now checks BOTH new
    // original exports in the same loaded object, before trusting capability1.
    // BOUND0 returns before any loader call. No caller can supply a trust token.
    if (!managedPayloadCounterRuntimeQualified()) { return {}; }
    std::shared_ptr<void> library(::dlopen("libtorrent-rasterbar.so.2.0", RTLD_NOW | RTLD_NOLOAD),
        [](void* value) { if (value) { ::dlclose(value); } });''',
     '''    // The complete source/artifact/mapping proof covers all NINE exports.
    // Retain its exact module handle, with no proof-to-reopen lifetime gap.
    // BOUND0 returns before any loader call. No caller supplies a trust token.
    auto library = managedPayloadCounterRuntimePin();'''),
    ('''    if (!capability || !read || capability() != 1
        || reinterpret_cast<void*>(capability) != ::dlsym(RTLD_DEFAULT, "biglybtc_payload_counter_abi_v1")
        || reinterpret_cast<void*>(read) != ::dlsym(RTLD_DEFAULT, "biglybtc_read_payload_counters_v1")) { return {}; }
    return std::make_shared<const ManagedPayloadCounterBridge>(ManagedPayloadCounterBridge{std::move(library), read});''',
     '''    const auto swarm = reinterpret_cast<decltype(&libtorrent::biglybtc_swarm_mask_abi_v1)>(
        ::dlsym(library.get(), "biglybtc_swarm_mask_abi_v1"));
    if (!capability || !read || !swarm || capability() != 1 || swarm() != 1
        || reinterpret_cast<void*>(capability) != ::dlsym(RTLD_DEFAULT, "biglybtc_payload_counter_abi_v1")
        || reinterpret_cast<void*>(read) != ::dlsym(RTLD_DEFAULT, "biglybtc_read_payload_counters_v1")
        || reinterpret_cast<void*>(swarm) != ::dlsym(RTLD_DEFAULT, "biglybtc_swarm_mask_abi_v1")) { return {}; }
    return std::make_shared<const ManagedPayloadCounterBridge>(ManagedPayloadCounterBridge{std::move(library), read, swarm});'''),
    ('#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS\nclass ManagedPayloadPlugin',
     '''bool selectManagedSwarm(libtorrent::add_torrent_params& parameters,
    const storage::OriginalTorrentIdentity& identity,
    const std::shared_ptr<const ManagedPayloadCounterBridge>& bridge) noexcept {
#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
  if (!bridge || !bridge->library || !bridge->read || !bridge->swarm || !parameters.ti) { return false; }
  const auto full = parameters.ti->info_hashes();
  if (identity.full.v1.has_value() != full.has_v1() || identity.full.v2.has_value() != full.has_v2()) { return false; }
  if ((identity.full.v1 && !std::equal(identity.full.v1->begin(), identity.full.v1->end(),
           reinterpret_cast<const std::byte*>(full.v1.data())))
      || (identity.full.v2 && !std::equal(identity.full.v2->begin(), identity.full.v2->end(),
           reinterpret_cast<const std::byte*>(full.v2.data())))) { return false; }
  libtorrent::torrent_flags_t selected;
  switch (identity.selected) {
  case storage::OriginalSelectedHash::V1:
    if (!full.has_v1()) { return false; }
    selected = libtorrent::biglybtc_v1_only; break;
  case storage::OriginalSelectedHash::V2:
    if (!full.has_v2()) { return false; }
    selected = libtorrent::biglybtc_v2_only; break;
  default: return false;
  }
  parameters.flags = (parameters.flags & ~libtorrent::biglybtc_swarm_mask) | selected;
  return true;
#else
  static_cast<void>(parameters); static_cast<void>(identity); static_cast<void>(bridge);
  return false;
#endif
}

#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
class ManagedPayloadPlugin'''),
])
edit('engine/managed_storage.hpp', [
    ('class OriginalDiskFiles;', 'class OriginalDiskFiles;\nstruct ManagedPayloadCounterBridge;'),
    ('      std::span<const storage::OriginalTorrentIdentity> retainedIdentities={});',
     '''      std::span<const storage::OriginalTorrentIdentity> retainedIdentities={},
      std::shared_ptr<const ManagedPayloadCounterBridge> swarmBridge={});'''),
])
edit('engine/managed_storage.cpp', [
    ('#include "managed_storage.hpp"', '#include "managed_storage.hpp"\n#include "managed_payload_counters.hpp"'),
    ('ValidatedMetadata metadata(const Document& state, const core::TorrentHash& hash, const compat::OriginalLayout& layout) {',
     'ValidatedMetadata metadata(const Document& state, const core::TorrentHash& hash, const compat::OriginalLayout& layout,\n    const std::shared_ptr<const ManagedPayloadCounterBridge>& swarmBridge) {'),
    ('require(!(identity.selected==storage::OriginalSelectedHash::V2&&identity.full.v1),\n      "Selected-v2 hybrid live swarm policy is not qualified",ErrorCode::Unsupported);',
     '''require(!(identity.selected==storage::OriginalSelectedHash::V2&&identity.full.v1)||swarmBridge,
      "Selected-v2 hybrid requires the exact qualified swarm provider",ErrorCode::Unsupported);'''),
    ('  storage::OriginalTorrentIdentity selectedIdentity;',
     '  storage::OriginalTorrentIdentity selectedIdentity;\n  std::shared_ptr<const ManagedPayloadCounterBridge> swarmBridge;'),
    ('const NetworkPolicy& policy,std::span<const ManagedPayloadClaim> claimed,std::span<const storage::OriginalTorrentIdentity> retainedIdentities) {',
     'const NetworkPolicy& policy,std::span<const ManagedPayloadClaim> claimed,std::span<const storage::OriginalTorrentIdentity> retainedIdentities,std::shared_ptr<const ManagedPayloadCounterBridge> swarmBridge) {'),
    ('auto validated=metadata(source,hash,layout);auto info=std::move(validated.info);auto identity=std::move(validated.identity);',
     '''auto validated=metadata(source,hash,layout,swarmBridge);auto info=std::move(validated.info);auto identity=std::move(validated.identity);
    lt::add_torrent_params params; params.ti=info;
    if(swarmBridge) {
      require(selectManagedSwarm(params,identity,swarmBridge),
          "Selected swarm requires the same exact counter/provider module",ErrorCode::Unsupported);
    } // Immutable admission flags are fixed before state ownership/payload effects.'''),
    ('lt::add_torrent_params params; params.ti=info; params.save_path=save.string(); params.file_priorities=priorities(*parsedPolicy,layout);',
     'params.save_path=save.string(); params.file_priorities=priorities(*parsedPolicy,layout);'),
    ('    result->queue=queue;', '    result->queue=queue; result->swarmBridge=std::move(swarmBridge);'),
])
edit('engine/persistent_session.cpp', [
    ('"Managed payload counter provider ABI is unavailable"', '"Managed counter/selected-swarm provider ABI is unavailable"'),
    ('detail::ManagedStorage::prepare(lease, options.hash, *impl_->network,claimed,retainedIdentities)',
     'detail::ManagedStorage::prepare(lease, options.hash, *impl_->network,claimed,retainedIdentities,payloadBridge)'),
])
edit('tests/provider_payload_counter_unsupported_tests.cpp', [
    ('#include "owned_engine_fixture.hpp"', '#include "owned_engine_fixture.hpp"\n#include "selected_swarm_fixture.hpp"'),
    ('\n};\nQTEST_GUILESS_MAIN', '''
  void selectedHybridAlsoRejectsBeforeProfileAndPayload_data() {
    QTest::addColumn<bool>("v2");
    QTest::newRow("original-v1") << false; QTest::newRow("original-v2") << true;
  }
  void selectedHybridAlsoRejectsBeforeProfileAndPayload() {
    QFETCH(bool, v2);
    test::selected_swarm::Fixture fixture(v2);
    QVERIFY(!engine::detail::managedPayloadCounterBridge());
    auto created = engine::PersistentSession::create({801, 802, 803});
    if (created) {
      auto owner = std::move(*created);
      const auto admitted = owner->startManaged(*fixture.lease, {.hash = *fixture.key});
      QVERIFY(!admitted); QCOMPARE(admitted.error().code, storage::ErrorCode::Unsupported);
      QVERIFY(owner->managedDownloads().empty());
      const auto closed = owner->close(std::chrono::steady_clock::now() + 5s);
      QVERIFY(closed.sessionJoined);
    } else {
      QCOMPARE(created.error(), engine::AccountingError::DependencyUnqualified);
    }
    QVERIFY(fixture.untouched());
  }
};
QTEST_GUILESS_MAIN'''),
])
