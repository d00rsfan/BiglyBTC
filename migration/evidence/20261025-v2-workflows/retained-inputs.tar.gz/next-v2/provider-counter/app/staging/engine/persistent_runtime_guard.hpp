#pragma once

namespace biglybtc::engine::detail {
// Private build/runtime admission, never a caller-supplied trust token. This is
// source/artifact binding only; causal qualification remains a separate gate.
bool persistentRuntimeQualified() noexcept;
// Same full proof, plus the provider-owned raw payload-counter capability/read
// exports. This does not confer reset, storage-retirement or finality authority.
bool managedPayloadCounterRuntimeQualified() noexcept;
}
