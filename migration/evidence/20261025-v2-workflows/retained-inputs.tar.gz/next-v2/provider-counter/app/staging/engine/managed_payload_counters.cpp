#include "managed_payload_counters.hpp"
#include "persistent_runtime_guard.hpp"

#include <libtorrent/add_torrent_params.hpp>
#include <libtorrent/extensions.hpp>
#include <libtorrent/torrent_handle.hpp>
#include <libtorrent/version.hpp>

#include <utility>

#if defined(__linux__) && __has_include(<libtorrent/biglybtc_payload_counters.hpp>) \
    && !defined(TORRENT_DISABLE_EXTENSIONS)
#define BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS 1
#include <libtorrent/biglybtc_payload_counters.hpp>
#include <dlfcn.h>
#else
#define BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS 0
#endif

namespace biglybtc::engine::detail {
static_assert(LIBTORRENT_VERSION_NUM == 20012,
    "Managed raw reset boundaries require the reviewed LT2.0.12 source");

struct ManagedPayloadCounterBridge final {
#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
  std::shared_ptr<void> library;
  decltype(&libtorrent::biglybtc_read_payload_counters_v1) read = nullptr;
#endif
};

std::shared_ptr<const ManagedPayloadCounterBridge> managedPayloadCounterBridge() noexcept {
#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
  try {
    // The existing complete artifact/source/hash proof now checks BOTH new
    // original exports in the same loaded object, before trusting capability1.
    // BOUND0 returns before any loader call. No caller can supply a trust token.
    if (!managedPayloadCounterRuntimeQualified()) { return {}; }
    std::shared_ptr<void> library(::dlopen("libtorrent-rasterbar.so.2.0", RTLD_NOW | RTLD_NOLOAD),
        [](void* value) { if (value) { ::dlclose(value); } });
    if (!library) { return {}; }
    const auto capability = reinterpret_cast<decltype(&libtorrent::biglybtc_payload_counter_abi_v1)>(
        ::dlsym(library.get(), "biglybtc_payload_counter_abi_v1"));
    const auto read = reinterpret_cast<decltype(&libtorrent::biglybtc_read_payload_counters_v1)>(
        ::dlsym(library.get(), "biglybtc_read_payload_counters_v1"));
    if (!capability || !read || capability() != 1
        || reinterpret_cast<void*>(capability) != ::dlsym(RTLD_DEFAULT, "biglybtc_payload_counter_abi_v1")
        || reinterpret_cast<void*>(read) != ::dlsym(RTLD_DEFAULT, "biglybtc_read_payload_counters_v1")) { return {}; }
    return std::make_shared<const ManagedPayloadCounterBridge>(ManagedPayloadCounterBridge{std::move(library), read});
  } catch (...) { return {}; }
#else
  return {}; // Default/stock SDK: no private-class or guessed-zero fallback.
#endif
}

#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
class ManagedPayloadPlugin final : public libtorrent::torrent_plugin {
public:
  ManagedPayloadPlugin(libtorrent::torrent_handle handle,
      std::shared_ptr<ManagedPayloadCounters> counters,
      std::shared_ptr<const ManagedPayloadCounterBridge> bridge)
      : handle_(std::move(handle)), counters_(std::move(counters)), bridge_(std::move(bridge)) {
    counters_->installed();
  }
  bool on_pause() noexcept override { paused_ = true; return false; }
  bool on_resume() noexcept override {
    if (!paused_) { return false; } // Duplicate active resume does not reset m_stat.
    paused_ = false;
    const auto raw = read();
    if (!raw) { counters_->fail(); return false; }
    if (!raw->files_checked && (raw->received != 0 || raw->sent != 0)) {
      counters_->fail(); return false; // No supported recheck after payload.
    }
    counters_->seal(raw->received, raw->sent);
    return false; // Never override standard LT pause/resume behavior.
  }
  void on_files_checked() noexcept override {
    const auto raw = read();
    // Initial check precedes the first announcing epoch, exactly as before.
    if (!raw || raw->received != 0 || raw->sent != 0) { counters_->fail(); }
  }
private:
  std::optional<libtorrent::BiglybtcPayloadCountersV1> read() const noexcept {
    libtorrent::BiglybtcPayloadCountersV1 value{};
    if (!bridge_ || !bridge_->read
        || bridge_->read(&handle_, &value, sizeof(value))
            != static_cast<std::uint32_t>(libtorrent::BiglybtcPayloadCounterStatusV1::Accepted)
        || value.reserved != 0 || value.files_checked > 1 || value.received < 0 || value.sent < 0) { return {}; }
    return value;
  }
  libtorrent::torrent_handle handle_; // Public weak handle, never dereferenced here.
  std::shared_ptr<ManagedPayloadCounters> counters_;
  std::shared_ptr<const ManagedPayloadCounterBridge> bridge_;
  bool paused_ = true;
};
#endif

bool attachManagedPayloadCounters(libtorrent::add_torrent_params& parameters,
    const std::shared_ptr<ManagedPayloadCounters>& counters,
    std::shared_ptr<const ManagedPayloadCounterBridge> bridge) noexcept {
  if (!counters) { return false; }
#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
  if (!bridge || !bridge->read) { counters->fail(); return false; }
  try {
    parameters.extensions.push_back([counters, bridge = std::move(bridge)](
        const libtorrent::torrent_handle& handle, libtorrent::client_data_t)
        -> std::shared_ptr<libtorrent::torrent_plugin> {
      try { return std::make_shared<ManagedPayloadPlugin>(handle, counters, bridge); }
      catch (...) { counters->fail(); return {}; }
    });
    return true;
  } catch (...) { counters->fail(); return false; }
#else
  static_cast<void>(parameters); static_cast<void>(bridge);
  counters->fail(); return false;
#endif
}
} // namespace biglybtc::engine::detail
