#!/usr/bin/env python3
"""Generate a source-only counter bridge capsule. Never builds or adopts it."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
NATIVE = Path('/home/yurii/Java/BiglyBTC/preview/native')
LT = Path('/tmp/biglybtc-deps/libtorrent-2.0.12-release/libtorrent-2.0.12')
WIRE = HERE.parent / 'provider'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def changed(text, before, after):
    assert text.count(before) == 1, before[:160]
    return text.replace(before, after)

def stage(group, relative, before, after):
    path = HERE / group / 'staging' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(after)
    if before is not None:
        old = HERE / group / 'before' / relative
        old.parent.mkdir(parents=True, exist_ok=True)
        old.write_bytes(before)
    return {'before_sha256': None if before is None else digest(before),
            'sha256': digest(after), 'bytes': len(after)}

def patch(group, sources):
    lines = []
    for relative in sources:
        before = HERE / group / 'before' / relative
        after = HERE / group / 'staging' / relative
        lines.extend(difflib.unified_diff(
            before.read_text().splitlines(True) if before.exists() else [],
            after.read_text().splitlines(True),
            fromfile='a/' + relative if before.exists() else '/dev/null',
            tofile='b/' + relative))
    (HERE / group / 'changes.patch').write_text(''.join(lines))

provider = {}
public = '''// Supported only by the reviewed BiglyBTC LT2.0.12 provider.
// This is a source/artifact-bound C++-handle ABI, not an upstream portable API.
#ifndef TORRENT_BIGLYBTC_PAYLOAD_COUNTERS_HPP
#define TORRENT_BIGLYBTC_PAYLOAD_COUNTERS_HPP

#include "libtorrent/config.hpp"
#include "libtorrent/fwd.hpp"
#include <cstdint>
#include <type_traits>

namespace libtorrent {
// Raw m_stat values copied in the provider, before the caller's existing
// on_resume callback returns to LT's normal clear/reset path. No epoch, total,
// reset, ownership/finality claim or private-class pointer crosses this ABI.
struct BiglybtcPayloadCountersV1 {
    std::int64_t received;
    std::int64_t sent;
    std::uint32_t files_checked;
    std::uint32_t reserved;
};
static_assert(sizeof(BiglybtcPayloadCountersV1) == 24, "Counter ABI size");
static_assert(std::is_standard_layout<BiglybtcPayloadCountersV1>::value
    && std::is_trivially_copyable<BiglybtcPayloadCountersV1>::value, "Counter ABI layout");

enum class BiglybtcPayloadCounterStatusV1 : std::uint32_t {
    Accepted = 0, InvalidArgument = 1, InvalidHandle = 2,
    WrongThread = 3, InvalidCounters = 4, Failed = 5
};

extern "C" TORRENT_EXPORT unsigned biglybtc_payload_counter_abi_v1() noexcept;
// Only call from a callback on this handle's real io_context executor thread.
// Unlike status(), this never dispatches or waits. Failure leaves *output
// unchanged. A temporary weak-lock is released before the function returns.
extern "C" TORRENT_EXPORT std::uint32_t biglybtc_read_payload_counters_v1(
    torrent_handle const* handle, BiglybtcPayloadCountersV1* output,
    std::uint32_t output_bytes) noexcept;
}
#endif
'''
relative = 'include/libtorrent/biglybtc_payload_counters.hpp'
provider[relative] = stage('provider', relative, None, public.encode())
relative = 'include/libtorrent/torrent_handle.hpp'
before = (LT / relative).read_bytes()
text = changed(before.decode(), '#include "libtorrent/config.hpp"',
               '#include "libtorrent/config.hpp"\n#include "libtorrent/biglybtc_payload_counters.hpp"')
text = changed(text, '\t\tfriend struct torrent;\n', '''\t\tfriend struct torrent;
\t\tfriend std::uint32_t biglybtc_read_payload_counters_v1(torrent_handle const*,
\t\t\tBiglybtcPayloadCountersV1*, std::uint32_t) noexcept;
''')
provider[relative] = stage('provider', relative, before, text.encode())
relative = 'src/torrent_handle.cpp'
before = (WIRE / 'staging' / relative).read_bytes()
assert digest(before) == '986e757ea1a7f1eb6915aa45beffd54da222fbc72855e6b220e5e297ece80be7'
text = changed(before.decode(), '\tstd::shared_ptr<torrent> torrent_handle::native_handle() const\n', '''\textern "C" unsigned biglybtc_payload_counter_abi_v1() noexcept
\t{
\t\treturn 1;
\t}

\textern "C" std::uint32_t biglybtc_read_payload_counters_v1(
\t\ttorrent_handle const* handle, BiglybtcPayloadCountersV1* output,
\t\tstd::uint32_t const output_bytes) noexcept
\t{
\t\tusing result = BiglybtcPayloadCounterStatusV1;
\t\tif (handle == nullptr || output == nullptr
\t\t\t|| output_bytes != sizeof(BiglybtcPayloadCountersV1))
\t\t\treturn static_cast<std::uint32_t>(result::InvalidArgument);
\t\ttry
\t\t{
\t\t\t// The layout and inline stat read stay inside their defining DSO.
\t\t\t// Never dispatch: a delayed read would miss the pre-clear boundary.
\t\t\tauto const t = handle->m_torrent.lock();
\t\t\tif (!t) return static_cast<std::uint32_t>(result::InvalidHandle);
\t\t\tif (!t->session().get_context().get_executor().running_in_this_thread())
\t\t\t\treturn static_cast<std::uint32_t>(result::WrongThread);
\t\t\tauto const raw = t->statistics();
\t\t\tauto const received = raw.total_payload_download();
\t\t\tauto const sent = raw.total_payload_upload();
\t\t\tif (received < 0 || sent < 0)
\t\t\t\treturn static_cast<std::uint32_t>(result::InvalidCounters);
\t\t\tBiglybtcPayloadCountersV1 const value{received, sent,
\t\t\t\tt->are_files_checked() ? 1u : 0u, 0u};
\t\t\t*output = value;
\t\t\treturn static_cast<std::uint32_t>(result::Accepted);
\t\t}
\t\tcatch (...) { return static_cast<std::uint32_t>(result::Failed); }
\t}

\tstd::shared_ptr<torrent> torrent_handle::native_handle() const
''')
provider[relative] = stage('provider', relative, before, text.encode())
patch('provider', provider)

app = {}
def edit(relative, transform):
    before = (NATIVE / relative).read_bytes()
    app[relative] = stage('app', relative, before, transform(before.decode()).encode())

def counter_header(text):
    return changed(text, '''// Private source/ABI-bound implementation lives in the one LT shim TU.
bool attachManagedPayloadCounters(libtorrent::add_torrent_params&,
    const std::shared_ptr<ManagedPayloadCounters>&) noexcept;
''', '''// Immutable pin to the approved provider's supported raw-counter bridge.
// Resolve BEFORE preparing payload storage; absent/stock/unbound is unsupported.
// The pin is retained by the installed factory/plugin for its full lifetime.
struct ManagedPayloadCounterBridge;
std::shared_ptr<const ManagedPayloadCounterBridge> managedPayloadCounterBridge() noexcept;
bool attachManagedPayloadCounters(libtorrent::add_torrent_params&,
    const std::shared_ptr<ManagedPayloadCounters>&,
    std::shared_ptr<const ManagedPayloadCounterBridge>) noexcept;
''')
edit('engine/managed_payload_counters.hpp', counter_header)

counter_cpp = '''#include "managed_payload_counters.hpp"
#include "persistent_runtime_guard.hpp"

#include <libtorrent/add_torrent_params.hpp>
#include <libtorrent/extensions.hpp>
#include <libtorrent/torrent_handle.hpp>
#include <libtorrent/version.hpp>

#include <utility>

#if defined(__linux__) && __has_include(<libtorrent/biglybtc_payload_counters.hpp>) \\
    && !defined(TORRENT_DISABLE_EXTENSIONS)
#define BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS 1
#include <libtorrent/biglybtc_payload_counters.hpp>
#include <dlfcn.h>
#else
#define BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS 0
#endif

namespace biglybtc::engine::detail {
static_assert(LIBTORRENT_VERSION_NUM == 20012,
    "Managed raw reset boundaries require the reviewed LT2.0.12 source");

struct ManagedPayloadCounterBridge final {
#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
  std::shared_ptr<void> library;
  decltype(&libtorrent::biglybtc_read_payload_counters_v1) read = nullptr;
#endif
};

std::shared_ptr<const ManagedPayloadCounterBridge> managedPayloadCounterBridge() noexcept {
#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
  try {
    // The existing complete artifact/source/hash proof now checks BOTH new
    // original exports in the same loaded object, before trusting capability1.
    // BOUND0 returns before any loader call. No caller can supply a trust token.
    if (!managedPayloadCounterRuntimeQualified()) { return {}; }
    std::shared_ptr<void> library(::dlopen("libtorrent-rasterbar.so.2.0", RTLD_NOW | RTLD_NOLOAD),
        [](void* value) { if (value) { ::dlclose(value); } });
    if (!library) { return {}; }
    const auto capability = reinterpret_cast<decltype(&libtorrent::biglybtc_payload_counter_abi_v1)>(
        ::dlsym(library.get(), "biglybtc_payload_counter_abi_v1"));
    const auto read = reinterpret_cast<decltype(&libtorrent::biglybtc_read_payload_counters_v1)>(
        ::dlsym(library.get(), "biglybtc_read_payload_counters_v1"));
    if (!capability || !read || capability() != 1
        || reinterpret_cast<void*>(capability) != ::dlsym(RTLD_DEFAULT, "biglybtc_payload_counter_abi_v1")
        || reinterpret_cast<void*>(read) != ::dlsym(RTLD_DEFAULT, "biglybtc_read_payload_counters_v1")) { return {}; }
    return std::make_shared<const ManagedPayloadCounterBridge>(ManagedPayloadCounterBridge{std::move(library), read});
  } catch (...) { return {}; }
#else
  return {}; // Default/stock SDK: no private-class or guessed-zero fallback.
#endif
}

#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
class ManagedPayloadPlugin final : public libtorrent::torrent_plugin {
public:
  ManagedPayloadPlugin(libtorrent::torrent_handle handle,
      std::shared_ptr<ManagedPayloadCounters> counters,
      std::shared_ptr<const ManagedPayloadCounterBridge> bridge)
      : handle_(std::move(handle)), counters_(std::move(counters)), bridge_(std::move(bridge)) {
    counters_->installed();
  }
  bool on_pause() noexcept override { paused_ = true; return false; }
  bool on_resume() noexcept override {
    if (!paused_) { return false; } // Duplicate active resume does not reset m_stat.
    paused_ = false;
    const auto raw = read();
    if (!raw) { counters_->fail(); return false; }
    if (!raw->files_checked && (raw->received != 0 || raw->sent != 0)) {
      counters_->fail(); return false; // No supported recheck after payload.
    }
    counters_->seal(raw->received, raw->sent);
    return false; // Never override standard LT pause/resume behavior.
  }
  void on_files_checked() noexcept override {
    const auto raw = read();
    // Initial check precedes the first announcing epoch, exactly as before.
    if (!raw || raw->received != 0 || raw->sent != 0) { counters_->fail(); }
  }
private:
  std::optional<libtorrent::BiglybtcPayloadCountersV1> read() const noexcept {
    libtorrent::BiglybtcPayloadCountersV1 value{};
    if (!bridge_ || !bridge_->read
        || bridge_->read(&handle_, &value, sizeof(value))
            != static_cast<std::uint32_t>(libtorrent::BiglybtcPayloadCounterStatusV1::Accepted)
        || value.reserved != 0 || value.files_checked > 1 || value.received < 0 || value.sent < 0) { return {}; }
    return value;
  }
  libtorrent::torrent_handle handle_; // Public weak handle, never dereferenced here.
  std::shared_ptr<ManagedPayloadCounters> counters_;
  std::shared_ptr<const ManagedPayloadCounterBridge> bridge_;
  bool paused_ = true;
};
#endif

bool attachManagedPayloadCounters(libtorrent::add_torrent_params& parameters,
    const std::shared_ptr<ManagedPayloadCounters>& counters,
    std::shared_ptr<const ManagedPayloadCounterBridge> bridge) noexcept {
  if (!counters) { return false; }
#if BIGLYBTC_SUPPORTED_PAYLOAD_COUNTERS
  if (!bridge || !bridge->read) { counters->fail(); return false; }
  try {
    parameters.extensions.push_back([counters, bridge = std::move(bridge)](
        const libtorrent::torrent_handle& handle, libtorrent::client_data_t)
        -> std::shared_ptr<libtorrent::torrent_plugin> {
      try { return std::make_shared<ManagedPayloadPlugin>(handle, counters, bridge); }
      catch (...) { counters->fail(); return {}; }
    });
    return true;
  } catch (...) { counters->fail(); return false; }
#else
  static_cast<void>(parameters); static_cast<void>(bridge);
  counters->fail(); return false;
#endif
}
} // namespace biglybtc::engine::detail
'''
before = (NATIVE / 'engine/managed_payload_counters.cpp').read_bytes()
app['engine/managed_payload_counters.cpp'] = stage('app', 'engine/managed_payload_counters.cpp', before, counter_cpp.encode())

edit('engine/persistent_runtime_guard.hpp', lambda t: changed(t,
     'bool persistentRuntimeQualified() noexcept;\n',
     '''bool persistentRuntimeQualified() noexcept;
// Same full proof, plus the provider-owned raw payload-counter capability/read
// exports. This does not confer reset, storage-retirement or finality authority.
bool managedPayloadCounterRuntimeQualified() noexcept;
'''))

def runtime_guard(text):
    text = changed(text, 'bool checkLoadedProvider() {', 'bool checkLoadedProvider(bool counterBridge = false) {')
    text = changed(text, '"_ZN10libtorrent14session_handle14remove_torrentERKNS_14torrent_handleENS_5flags13bitfield_flagIhNS_16remove_flags_tagEvEE"};',
        '''"_ZN10libtorrent14session_handle14remove_torrentERKNS_14torrent_handleENS_5flags13bitfield_flagIhNS_16remove_flags_tagEvEE",
      "biglybtc_payload_counter_abi_v1", "biglybtc_read_payload_counters_v1"};''')
    text = changed(text, '''  std::array<std::uintptr_t, 6> addresses{};
  std::array<Mapping, 6> beforeMappings{};
  std::size_t at = 0;
  for (const auto* name : symbols) {
''', '''  const std::size_t required = counterBridge ? 8 : 6;
  std::array<std::uintptr_t, 8> addresses{};
  std::array<Mapping, 8> beforeMappings{};
  std::size_t at = 0;
  for (; at < required; ++at) {
    const auto* name = symbols[at];
''')
    text = changed(text, 'addresses[at] = address; beforeMappings[at] = *mapping; ++at;',
                         'addresses[at] = address; beforeMappings[at] = *mapping;')
    text = changed(text, 'if (at != addresses.size()) { return false; }', 'if (at != required) { return false; }')
    text = changed(text, 'for (const auto& mapping : beforeMappings) {',
                         'for (std::size_t i = 0; i < required; ++i) {\n    const auto& mapping = beforeMappings[i];')
    text = changed(text, 'i < addresses.size(); ++i', 'i < required; ++i')
    text = changed(text, '} // namespace biglybtc::engine::detail', '''bool managedPayloadCounterRuntimeQualified() noexcept {
#if BIGLYBTC_PERSISTENT_RUNTIME_BOUND
  try { return checkLoadedProvider(true); }
  catch (...) { return false; }
#else
  return false;
#endif
}
} // namespace biglybtc::engine::detail''')
    return text
edit('engine/persistent_runtime_guard.cpp', runtime_guard)

def persistent(text):
    anchor = '''  impl_->call = true;
  try {
    impl_->bind(lease);
    impl_->retirement.reset();
    detail::require(!options.ownedLoopbackPeerPort'''
    text = changed(text, anchor, '''  // Required raw counter support is admitted before any ManagedStorage
  // beginUpdate/create/truncate. Stock/old approved providers stay unsupported.
  const auto payloadBridge = detail::managedPayloadCounterBridge();
  if (!payloadBridge) {
    return std::unexpected(storage::Error{storage::ErrorCode::Unsupported,
        "Managed payload counter provider ABI is unavailable"});
  }
  impl_->call = true;
  try {
    impl_->bind(lease);
    impl_->retirement.reset();
    detail::require(!options.ownedLoopbackPeerPort''')
    return changed(text, 'detail::attachManagedPayloadCounters(parameters, value->payloadCounters)',
                   'detail::attachManagedPayloadCounters(parameters, value->payloadCounters, payloadBridge)')
edit('engine/persistent_session.cpp', persistent)

def cmake(text):
    return changed(text, '''# Keep private LT layout/RTTI access in one translation unit. The approved
# shared provider does not export libtorrent::torrent's private typeinfo, so
# UBSan vptr instrumentation cannot cross that ABI boundary. Address and all
# remaining undefined-behavior checks stay enabled here and in every caller.
target_sources(biglybtc_local_engine PRIVATE managed_payload_counters.cpp)
if(CMAKE_CXX_COMPILER_ID MATCHES "^(GNU|Clang|AppleClang)$")
  set_property(SOURCE "${CMAKE_CURRENT_SOURCE_DIR}/managed_payload_counters.cpp"
    APPEND PROPERTY COMPILE_OPTIONS "-fno-sanitize=vptr")
endif()
''', '''# The reviewed provider owns all private layout/stat reads. This TU uses only
# public handles and a fixed supported export: keep ALL sanitizer checks enabled.
target_sources(biglybtc_local_engine PRIVATE managed_payload_counters.cpp)
target_link_libraries(biglybtc_local_engine PRIVATE ${CMAKE_DL_LIBS})
''')
edit('engine/CMakeLists.txt', cmake)
patch('app', app)

(HERE / 'source-map.json').write_text(json.dumps({'provider': provider, 'app': app}, indent=2) + '\n')
print('Staged source only:', len(provider), 'provider files,', len(app), 'app files')
