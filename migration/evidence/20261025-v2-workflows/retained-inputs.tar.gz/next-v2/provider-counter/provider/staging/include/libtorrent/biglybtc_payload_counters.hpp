// Supported only by the reviewed BiglyBTC LT2.0.12 provider.
// This is a source/artifact-bound C++-handle ABI, not an upstream portable API.
#ifndef TORRENT_BIGLYBTC_PAYLOAD_COUNTERS_HPP
#define TORRENT_BIGLYBTC_PAYLOAD_COUNTERS_HPP

#include "libtorrent/config.hpp"
#include "libtorrent/fwd.hpp"
#include <cstdint>
#include <type_traits>

namespace libtorrent {
// Raw m_stat values copied in the provider, before the caller's existing
// on_resume callback returns to LT's normal clear/reset path. No epoch, total,
// reset, ownership/finality claim or private-class pointer crosses this ABI.
struct BiglybtcPayloadCountersV1 {
    std::int64_t received;
    std::int64_t sent;
    std::uint32_t files_checked;
    std::uint32_t reserved;
};
static_assert(sizeof(BiglybtcPayloadCountersV1) == 24, "Counter ABI size");
static_assert(std::is_standard_layout<BiglybtcPayloadCountersV1>::value
    && std::is_trivially_copyable<BiglybtcPayloadCountersV1>::value, "Counter ABI layout");

enum class BiglybtcPayloadCounterStatusV1 : std::uint32_t {
    Accepted = 0, InvalidArgument = 1, InvalidHandle = 2,
    WrongThread = 3, InvalidCounters = 4, Failed = 5
};

extern "C" TORRENT_EXPORT unsigned biglybtc_payload_counter_abi_v1() noexcept;
// Only call from a callback on this handle's real io_context executor thread.
// Unlike status(), this never dispatches or waits. Failure leaves *output
// unchanged. A temporary weak-lock is released before the function returns.
extern "C" TORRENT_EXPORT std::uint32_t biglybtc_read_payload_counters_v1(
    torrent_handle const* handle, BiglybtcPayloadCountersV1* output,
    std::uint32_t output_bytes) noexcept;
}
#endif
