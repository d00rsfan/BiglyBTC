Provider-owned payload counter bridge — source-only candidate

This capsule is uncompiled and unexecuted. It changes neither the retained c35f artifact/catalog nor any active native/dependency file. The current shipping private-RTTI implementation and its vptr exemption remain in place. Do not adopt the app half without qualifying and approving the new provider first.

ABI and accounting

`libtorrent/biglybtc_payload_counters.hpp` is an explicit extension of the exact LT2.0.12 source/SDK. The same DSO exports `biglybtc_payload_counter_abi_v1()` returning1 and `biglybtc_read_payload_counters_v1(const torrent_handle*, BiglybtcPayloadCountersV1*, uint32_t bytes)`. The POD is exactly24 bytes: received/sent int64, files_checked/reserved uint32. The read function returns Accepted/InvalidArgument/InvalidHandle/WrongThread/InvalidCounters/Failed as fixed uint32 values. It changes output only on Accepted; reserved is0 and files_checked is0/1. It never dispatches, waits, posts alerts, clears counters or stores a handle/strong torrent reference.

The provider weak-locks the supplied public handle and checks its actual io_context executor before reading. The private torrent layout and inline stat read are compiled ONLY inside their defining DSO. A friend function changes no public handle data layout. This is a reviewed source/SDK ABI, not an upstream portable API, opaque C handle ABI or process-wide thread-safety guarantee.

The app obtains one immutable opaque module pin before ManagedStorage preparation. Existing exact artifact/source configuration and runtime identity proof must succeed for all six old dynamic exports PLUS both new counter exports in the same loaded object. A capability1 from another object is insufficient. BOUND0 rejects before any loader call; a stock SDK without this header compiles an explicit unsupported path. Old source-bound c35f can still use the unchanged convenience path, but new managed admission returns Unsupported before payload/profile preparation. No private-class fallback exists in this candidate.

The installed public torrent_plugin calls this bridge at precisely the existing on_resume/on_files_checked points. ManagedPayloadCounters::installed/epoch/seal/combine, checked arithmetic, crossing-read Retry, published monotonicity, pause gating, initial zero check and sticky failure are unchanged. No timer/tick estimate substitutes for the final pre-clear raw sample. The library pin lasts through factory/plugin destruction; no new strong torrent owner is retained. Failed bridge reads poison essential per-admission accounting exactly as failed private reads did. Peer-session counters, pump/response order, epoch identity, retirement/storage fences and receipts are unchanged.

Ordered central adoption and qualification

1. Leave c35f, its existing source/build/install record and all approved/instrumented catalogs byte-exact. Use a NEW owned LT source/build/install tree matching the retained original444 map referenced by source-pins.json. Never patch the retained provider in place.
2. Apply these deltas, in order, only to that new tree:
   - `../provider/provider.patch` (frozen manifest72865b63…)
   - `../provider-oracle/handshake-amendment/amendment.patch` (410be6d1…)
   - `provider/changes.patch` from this capsule (three paths; torrent_handle.cpp beforeimage is the wire-provider version986e757e…, not upstream).
   Verify every exact before/after hash. The handshake amendment is a separate nonoverlapping file. This counter capsule does not alter any frozen wire-provider/harness file.
3. Build/install the WHOLE provider using the retained source-built configuration (ABI1, I2P/logging/etc), not just torrent_handle.cpp. The wire provider changes a private layout. Ensure the new public header is installed; rebuild all app/test consumers against this exact SDK. Record complete source/rules/dependency/build/install byte maps and artifact hash/size. No hash/path/count of that future artifact is guessed here.
4. Obtain an independently reviewed NEW source-bound approver/catalog entry for those exact maps and loaded artifact. The current verify_runtime_manifest catalog deliberately rejects an arbitrary new tree and has old fixed cohort counts. Do not merely add a capability marker or reuse c35f's manifest. New source/install maps must explicitly include both extension headers and all changed provider sources; the full strict binding rules stay enabled. New instrumented causal images require their own bound records.
5. Run the frozen selected-swarm qualification harness according to its ADOPTION.md against the new approved provider. Its original four LT tests, actual plain/MSE/upgrade/tracker/metadata/resume/payload/Merkle tests and wrong-capability probes retain their original scope. This counter extension grants none of those passes in advance.
6. Apply `app/changes.patch` against the six recorded app beforeimages; copy the two new test sources. Integrate Targets.cmake in the engine-enabled test block. Resolve overlap by narrow patches; do not overwrite subsequent root source work. This staged app CMake removes `-fno-sanitize=vptr` only because the staged TU no longer includes or dereferences the private torrent class. The current shipping exception is not removed by this capsule.
7. In an owned default/stock build select `-DBIGLYBTC_PAYLOAD_COUNTER_TEST_LANE=Unsupported`, build `biglybtc-provider-payload-counter-unsupported-tests`, run CTest `^provider-payload-counter-unsupported$`. Run both BOUND0 and the existing source-bound c35f lane: the default factory rejection and old-source-bound managed preflight rejection are distinct and logged. Existing c35f convenience-path tests must remain passing; managed transfer is intentionally unavailable for this new app half on c35f.
8. In a separate new-provider build select `-DBIGLYBTC_PAYLOAD_COUNTER_TEST_LANE=Qualified` with the actual new `BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST`, build `biglybtc-provider-payload-counter-tests`, and run CTest `^provider-payload-counter$`. These are positive, mandatory actual-owner tests; missing SDK/capability/approval fails instead of skipping. Keep full UBSan vptr checks for the app shim. Then run existing managed download/seeding/scheduler/host/storage tests on the same new provider, plus the unchanged source-qualified close/weak-retirement/response/fault cohorts under separately bound causal images as applicable. Counter-ABI tests alone cannot certify final peer counters or storage fences.
9. Only after actual central results may this new provider and app be promoted together. Restore the current code/artifact together on rollback. Do not claim the old shipping provider supports this ABI or that a source-only capsule removed a shipping sanitizer exception.

Commands are conventional central invocations (owned paths supplied by root):

    cmake --build OWNED_APP_BUILD --target biglybtc-provider-payload-counter-tests --parallel 3
    ctest --test-dir OWNED_APP_BUILD -R '^provider-payload-counter$' --output-on-failure

Focused test source scope

- Qualified lane: rejection leaves output unchanged, actual live wrong-thread rejection and weak expiry after real session join; actual public callback raw reads exactly equal status on the same executor; real pre-clear sample including possible pending pause tail survives resume and crossing epochs retry; actual managed partial transfer/pause/resume/retirement preserves saved cumulative totals and existing close receipt requirements.
- Unsupported lane: no module/zero fallback, failed attach does not add an extension, default factory or old-bound managed rejection precedes payload/profile mutation.
- Existing raw overflow/regression/epoch tests in managed_download_tests.cpp remain byte-exact and still required. No new test row/pass count is asserted here. No Java/runtime equality, public-network, wire-provider, counter-fence or causal execution credit has been earned by authoring these files.
