# Root-owned adoption after CF-01 qualification; not executed.
target_sources(biglybtc_profile PRIVATE original_torrent_identity.cpp)
add_executable(biglybtc-original-torrent-identity-tests original_torrent_identity_tests.cpp)
target_link_libraries(biglybtc-original-torrent-identity-tests PRIVATE biglybtc_profile)
target_compile_options(biglybtc-original-torrent-identity-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
add_test(NAME original-selected-torrent-identity COMMAND biglybtc-original-torrent-identity-tests)
set_tests_properties(original-selected-torrent-identity PROPERTIES TIMEOUT 30 LABELS "unit;fixtures;identity")
