from pathlib import Path
import hashlib,json,subprocess,time
out=Path(__file__).resolve().parent
build=Path('/home/yurii/Java/BiglyBTC/build/persistent-peer-accounting-20261021/bound-gcc')
commands=[('build',['nice','-n','5','cmake','--build',str(build),'--target','biglybtc-original-identity-callers-tests','--parallel','1']),('test',['ctest','--test-dir',str(build),'-R','^original-identity-callers$','-VV','--output-junit',str(out/'tests.xml')])]
receipt={'scope':'only authorized identity caller target/test','commands':[]}
for label,command in commands:
    started=time.time()
    with (out/(label+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False)
    item={'argv':command,'returncode':result.returncode,'seconds':time.time()-started,'log_sha256':hashlib.sha256((out/(label+'.log')).read_bytes()).hexdigest()}
    receipt['commands'].append(item)
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(label,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
receipt['status']='PASS'
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
