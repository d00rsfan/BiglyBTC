# Root merges only after current CF01 production milestone is committed.
# Engine directory (existing biglybtc_local_engine static target):
target_sources(biglybtc_local_engine PRIVATE network_binding.cpp)
# Tests directory, within existing BIGLYBTC_LOCAL_ENGINE gate:
add_executable(biglybtc-network-binding-tests network_binding_tests.cpp)
target_link_libraries(biglybtc-network-binding-tests PRIVATE biglybtc_local_engine LibtorrentRasterbar::torrent-rasterbar)
target_compile_options(biglybtc-network-binding-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
add_test(NAME network-binding COMMAND biglybtc-network-binding-tests)
set_tests_properties(network-binding PROPERTIES LABELS unit TIMEOUT 20)
# Actual owner fixture remains a required positive in source-bound builds.
if(NOT BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST STREQUAL "")
  add_executable(biglybtc-network-binding-owner-tests network_binding_owner_tests.cpp)
  set_target_properties(biglybtc-network-binding-owner-tests PROPERTIES AUTOMOC ON)
  target_link_libraries(biglybtc-network-binding-owner-tests PRIVATE biglybtc_local_engine biglybtc_profile
    LibtorrentRasterbar::torrent-rasterbar Qt6::Core Qt6::Network Qt6::Test)
  target_compile_options(biglybtc-network-binding-owner-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  target_link_options(biglybtc-network-binding-owner-tests PRIVATE "LINKER:--wrap=getifaddrs")
  add_test(NAME network-binding-owner COMMAND biglybtc-network-binding-owner-tests)
  set_tests_properties(network-binding-owner PROPERTIES LABELS unit TIMEOUT 300)
endif()
