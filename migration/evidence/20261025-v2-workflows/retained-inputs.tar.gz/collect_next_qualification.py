from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
w=Path(__file__).resolve().parent;h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=json.loads((w/'next-plan-r1.json').read_text());expected=set(plan['suites'])-{'provider-runtime-inputs'}
lanes={'gcc':['next-gcc-check-r1.xml','next-gcc-corrected-r2.xml','next-gcc-identity-r4.xml','identity-caller-qualification/tests.xml'],'clang':['next-clang-check-r1.xml','next-clang-caller-final.xml'],'sanitizers':['next-san-check-r1.xml']};proof={}
for lane,files in lanes.items():
 latest={}
 for file in files:
  for t in ET.parse(w/file).getroot().iter('testcase'):
   latest[t.attrib['name']]={'passed':t.find('failure')is None and t.find('error')is None and t.find('skipped')is None,'evidence':file}
 assert set(latest)==expected and all(x['passed']for x in latest.values()),(lane,sorted(set(latest)^expected),[k for k,v in latest.items()if not v['passed']])
 proof[lane]={'suites':len(latest),'latest_actual_results':latest,'inputs_sha256':{file:h(w/file)for file in files}}
runtime=ET.parse(w/'next-runtime-deploy-check-r2.xml').getroot();rows=list(runtime.iter('testcase'));assert len(rows)==9 and all(t.find('failure')is None and t.find('error')is None and t.find('skipped')is None for t in rows)
for file in ['provider-wire-working/run-r5-receipt.json','next-creator-oracle-r3/receipt.json','next-selected-oracle-r1/receipt.json','next-tail-oracle-r2/receipt.json','next-inputs-r1-receipt.json']:
 assert json.loads((w/file).read_text())['exit']==0,file
v={'status':'BOUNDED_CORE_SOURCE_BATCH_QUALIFIED_DISCOVERY_NAMESPACE_PROOF_PENDING','source_plan_sha256':h(w/'next-source-commit-plan.json'),'compiler_lanes':proof,'runtime_suites':9,'runtime_xml_sha256':h(w/'next-runtime-deploy-check-r2.xml'),'actual_oracles':{'wire_cases':6,'handshake_observations':96,'creator_cases':6,'selected_hybrid_profiles':2,'v2_hybrid_profiles':7},'remaining_gate':'Hosted discovery needs inherited PID1 namespace FDs opened outside the private user namespace. All checks remain; no host-network fallback.','dist_promoted':False,'clang_final_caller_build_log_note':'The subsequent same-case check overwrote its small build log. Actual successful tool return was11.7s; final source/binary, Ninja state and corrected execution are retained. Full Clang batch log remains.'}
(w/'next-core-qualification.json').write_text(json.dumps(v,indent=2)+'\n');print('Qualified31actual suites per compiler, runtime9, all four owned oracle cohorts; discovery remainsopen')
