#pragma once
#define BIGLYBTC_PERSISTENT_RUNTIME_BOUND 1
namespace biglybtc::engine::detail::runtime_binding {
inline constexpr char artifact[] = "/home/yurii/Java/BiglyBT/build/storage-20261025/provider-candidate/install/lib/libtorrent-rasterbar.so.2.0.12";
inline constexpr char sha256[] = "d367afd6499859c5a57d66bddd352a977ff76c7fb76b5925302c2c9008c7ddbd";
inline constexpr char manifest[] = "e74def09b2257a266786b8ddb116382d300716687bf26bbe57072f5ff90e8737";
inline constexpr unsigned long long bytes = 9072560ULL;
}
