from pathlib import Path
import shutil
W=Path(__file__).resolve().parent;R=Path('/home/yurii/Java/BiglyBTC/preview/native')
rels=['core/include/biglybtc/file_policy.hpp','core/src/file_policy.cpp','adapters/file_policy_commands.cpp','adapters/torrent_intake.hpp','adapters/torrent_intake.cpp','ui/library_window.hpp','ui/library_window.cpp','app/session_bridge.hpp','app/session_bridge.cpp','app/main_desktop.cpp']
for rel in rels:
    for name in ['before','staging']:
        p=W/name/'preview/native'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,p)
def change(rel,a,b):
    p=W/'staging/preview/native'/rel;s=p.read_text();assert s.count(a)==1,(rel,a[:80],s.count(a));p.write_text(s.replace(a,b))
change('core/include/biglybtc/file_policy.hpp','// Preserve every distinct non-skipped priority ordering.','// Original compressed policy encoding; validates signed round-trip and the seven\n// representable selected priority ranks. Padding is validated by the caller.\nstd::expected<std::string, PolicyError> encodeOriginalFilePolicy(std::span<const FilePolicy>);\n\n// Preserve every distinct non-skipped priority ordering.')
change('core/src/file_policy.cpp','#include <limits>','#include <limits>\n#include <map>\n#include <set>')
change('core/src/file_policy.cpp','std::expected<std::vector<std::uint8_t>, PolicyError> linearPriorityRanks(','''std::expected<std::string, PolicyError> encodeOriginalFilePolicy(std::span<const FilePolicy> values) {
  if (values.size() > 100000) { return std::unexpected(PolicyError{"File-priority count exceeds its bound"}); }
  std::set<std::int32_t> levels;
  std::map<std::int64_t, std::string> groups;
  for (std::size_t index = 0; index < values.size(); ++index) {
    const auto& value = values[index];
    if (value.priority == std::numeric_limits<std::int32_t>::min()) {
      return std::unexpected(PolicyError{"Priority cannot round trip through original encoding"});
    }
    if (!value.skipped) { levels.insert(value.priority); }
    const std::int64_t key = value.skipped ? 0
        : value.priority <= 0 ? static_cast<std::int64_t>(value.priority)-1 : value.priority;
    auto& indices = groups[key]; if (!indices.empty()) { indices += ','; } indices += std::to_string(index);
  }
  if (levels.size() > 7) { return std::unexpected(PolicyError{"At most seven distinct file priorities are supported"}); }
  std::string result = "d";
  for (const auto& [key, indices] : groups) {
    const auto name = std::to_string(key);
    result += std::to_string(name.size())+':'+name+std::to_string(indices.size())+':'+indices;
  }
  return result+'e';
}

std::expected<std::vector<std::uint8_t>, PolicyError> linearPriorityRanks(''')
a='''  std::set<std::int32_t> levels;
  std::map<std::int64_t,std::string> groups;
  for(std::size_t i=0;i<policies.size();++i) {
    const auto& policy=policies[i];
    if(layout->files[i].padding && !policy.skipped) { return bad(ErrorCode::Unsupported,"Padding files cannot be selected"); }
    if(policy.priority==std::numeric_limits<std::int32_t>::min()) { return bad(ErrorCode::Unsupported,"Priority cannot round trip through original encoding"); }
    if(!policy.skipped && !layout->files[i].padding) { levels.insert(policy.priority); }
    const std::int64_t encoded=policy.skipped?0:policy.priority<=0?static_cast<std::int64_t>(policy.priority)-1:policy.priority;
    auto& ranges=groups[encoded]; if(!ranges.empty()) { ranges+=','; } ranges+=std::to_string(i);
  }
  if(levels.size()>7) { return bad(ErrorCode::Unsupported,"At most seven distinct linear priorities are supported"); }
'''
b='''  for(std::size_t i=0;i<policies.size();++i) {
    if(layout->files[i].padding && !policies[i].skipped) { return bad(ErrorCode::Unsupported,"Padding files cannot be selected"); }
  }
  auto policyEncoding=compat::encodeOriginalFilePolicy(policies);
  if(!policyEncoding){return std::unexpected(Error{ErrorCode::Unsupported,policyEncoding.error().message});}
'''
change('adapters/file_policy_commands.cpp',a,b)
change('adapters/file_policy_commands.cpp','''  std::string encoded="d";
  for(const auto& [priority,ranges]:groups) { encoded+=bytes(std::to_string(priority))+bytes(ranges); } encoded+='e';
''','''  const auto& encoded=*policyEncoding;
''')
# Old local bytes helper becomes unused under -Werror.
change('adapters/file_policy_commands.cpp','std::string bytes(std::string_view value) { return std::to_string(value.size())+":"+std::string(value); }\n','')
change('adapters/torrent_intake.hpp','#include "biglybtc/library.hpp"','#include "biglybtc/library.hpp"\n#include "biglybtc/file_policy.hpp"\n#include "biglybtc/torrent_layout.hpp"')
change('adapters/torrent_intake.hpp','#include <optional>','#include <optional>\n#include <memory>\n#include <stop_token>')
change('adapters/torrent_intake.hpp','// Startup recovery before loading library/admitting operations.','''// Read-only worker preview of the same validated raw metadata. The sealed value
// retains exact source bytes/inode/stat; no payload/profile changes or engine.
class TorrentIntakeMetadata final {
public:
  const core::TorrentHash& hash() const noexcept;
  const compat::OriginalLayout& layout() const noexcept;
  const std::filesystem::path& source() const noexcept;
private:
  struct Data;
  std::shared_ptr<const Data> data_;
  explicit TorrentIntakeMetadata(std::shared_ptr<const Data>);
  friend std::expected<TorrentIntakeMetadata, Error> inspectTorrentIntake(const std::filesystem::path&, std::stop_token);
  friend std::expected<core::TorrentHash, Error> importTorrentWithFileOptions(ProfileLease&,
      const TorrentIntakeMetadata&, const std::filesystem::path&, bool, std::span<const compat::FilePolicy>,
      void (*)(TorrentIntakeStage), bool);
};
std::expected<TorrentIntakeMetadata, Error> inspectTorrentIntake(
    const std::filesystem::path&, std::stop_token = {});
// Full original-index vector, including immutable skipped padding entries.
// All skipped => Stopped/no force, with no payload allocation. New journal option
// records retain original priority/storage choices through every recovery stage.
// Existing skipped leaves stay L; absent skipped leaves use source C/X policy.
std::expected<core::TorrentHash, Error> importTorrentWithFileOptions(ProfileLease&,
    const TorrentIntakeMetadata&, const std::filesystem::path& destination, bool stopped,
    std::span<const compat::FilePolicy>, void (*observer)(TorrentIntakeStage) = nullptr,
    bool forceStart = false);

// Startup recovery before loading library/admitting operations.''')
change('adapters/torrent_intake.cpp','#include "file_io.hpp"','#include "file_io.hpp"\n#include "file_operation_io.hpp"\n#include "original_storage_defaults.hpp"')
a='''struct Plan {
'''
b='''struct MetadataSubject {
  core::Document torrent;
  compat::OriginalLayout layout;
  core::TorrentHash hash;
  int pieces;
};
// Shared by old direct import and the new preview. CF02 identity caller patches
// belong in this single subject validation function, not in file-option logic.
MetadataSubject metadataSubject(std::string_view metadata) {
'''
# Extract old validation unchanged except parse needs owned string.
p=W/'staging/preview/native/adapters/torrent_intake.cpp';s=p.read_text()
start=s.index('  auto torrent = parse(metadata, MaximumMetadata);',s.index('Plan plan('))
end=s.index('  auto inventory = parse(before.value_or(',start)
validation=s[start:end].replace('parse(metadata, MaximumMetadata)','parse(std::string(metadata), MaximumMetadata)')
new=b+validation+'''  return {std::move(torrent),std::move(*original),*hash,engine.num_pieces()};
}
struct IntakeFileOptions {
  std::string policy, stores;
  std::optional<std::int64_t> reorderMinimumMiB;
};
void validateFileOptions(const MetadataSubject& source,const IntakeFileOptions& options) {
  auto entry=parse("de");put(entry,"file_priorities_c",options.policy);
  const auto values=compat::originalFilePolicy(entry.root(),source.layout.files.size());
  require(values && values->size()==options.stores.size(),ErrorCode::InvalidFormat,"Intake options differ from original file indices");
  const auto encoded=compat::encodeOriginalFilePolicy(*values);
  require(encoded && *encoded==options.policy,ErrorCode::InvalidFormat,"Noncanonical intake file policy");
  for(std::size_t n=0;n<values->size();++n) {
    const auto& value=(*values)[n];const auto kind=options.stores[n];
    require(kind=='L'||kind=='C'||kind=='R'||kind=='X',ErrorCode::InvalidFormat,"Invalid intake storage kind");
    require(!source.layout.files[n].padding||(value.skipped&&value.priority==0),ErrorCode::Unsupported,"Padding cannot be selected");
    require(value.skipped||(kind=='L'||kind=='R'),ErrorCode::InvalidFormat,"Selected file cannot use compact storage");
    require(kind!='R'||!value.skipped,ErrorCode::InvalidFormat,"Skipped reordered file needs explicit X or existing linear data");
  }
  require(!options.reorderMinimumMiB||(*options.reorderMinimumMiB>=INT32_MIN&&*options.reorderMinimumMiB<=INT32_MAX),
      ErrorCode::InvalidFormat,"Invalid original reorder threshold");
}
void checkCompactAbsence(const compat::OriginalLayout& layout,const IntakeFileOptions& options,const fs::path& destination) {
  for(std::size_t n=0;n<options.stores.size();++n) {
    if(layout.files[n].padding||(options.stores[n]!='C'&&options.stores[n]!='X')) { continue; }
    const auto path=destination/(layout.multifile?fs::path(layout.name)/layout.files[n].path:fs::path(layout.name));
    require(!fileop::inspect(path),ErrorCode::Conflict,"A skipped payload appeared after choosing absent compact storage");
  }
}
IntakeFileOptions fileOptions(const ProfileLease& lease,const MetadataSubject& source,
    const fs::path& destination,std::span<const compat::FilePolicy> values) {
  require(values.size()==source.layout.files.size(),ErrorCode::InvalidFormat,"Intake selection does not match metadata");
  const auto encoded=compat::encodeOriginalFilePolicy(values);
  require(encoded.has_value(),ErrorCode::Unsupported,encoded ? "" : encoded.error().message.c_str());
  auto empty=parse("de");const auto defaults=take(resolveOriginalStorageTypes(lease,source.hash,source.layout,empty.root()));
  require(defaults.markers.empty()&&!defaults.unsupportedConversion,ErrorCode::Conflict,"Orphan original storage controls already own this import");
  IntakeFileOptions result{*encoded,"",defaults.reorderMinimumMiB};result.stores.reserve(values.size());
  for(std::size_t n=0;n<values.size();++n) {
    const bool reorder=defaults.requested[n]==OriginalStorageKind::Reordered;
    if(!values[n].skipped) { result.stores+=reorder?'R':'L';continue; }
    if(source.layout.files[n].padding){result.stores+=reorder?'X':'C';continue;}
    const auto path=destination/(source.layout.multifile?fs::path(source.layout.name)/source.layout.files[n].path:fs::path(source.layout.name));
    const auto present=fileop::inspect(path);
    result.stores+=present?'L':reorder?'X':'C'; // Never convert/reclaim existing data.
  }
  validateFileOptions(source,result);checkCompactAbsence(source.layout,result,destination);return result;
}
struct Plan {
'''
s=s.replace(a,new,1)
# Old inline validator is replaced by the shared function.
start=s.index('  auto torrent = parse(metadata, MaximumMetadata);',s.index('Plan plan('))
end=s.index('  auto inventory = parse(before.value_or(',start)
s=s[:start]+'''  auto subject=metadataSubject(metadata);auto& torrent=subject.torrent;auto* original=&subject.layout;
  const auto hash=std::optional{subject.hash};const auto key=hash->bytes();
  const auto* digest=reinterpret_cast<const char*>(key.data());
  if(options){validateFileOptions(subject,*options);checkCompactAbsence(*original,*options,destination);}
'''+s[end:]
s=s.replace('  mode_t inventoryMode;\n};','  mode_t inventoryMode;\n  std::optional<IntakeFileOptions> options;\n};',1)
s=s.replace('bool stopped, mode_t mode, bool forceStart) {','bool stopped, mode_t mode, bool forceStart, std::optional<IntakeFileOptions> options = {}) {',1)
s=s.replace('''  entry += "ee";
  std::string list''','''  entry += "ee";
  if(options) {
    auto selected=parse(std::move(entry));put(selected,"file_priorities_c",options->policy);
    const auto policies=compat::originalFilePolicy(selected.root(),original->files.size());
    require(policies.has_value(),ErrorCode::InvalidFormat,"Published intake policy invalid");
    const bool allSkipped=std::ranges::all_of(*policies,[](const auto& value){return value.skipped;});
    if(allSkipped){stopped=true;forceStart=false;put(selected,"state","i70e");put(selected,"forceStart","i0e");}
    entry=selected.serialize();
  }
  std::string list''',1)
s=s.replace('''  for (std::size_t n = 0; n < original->files.size(); ++n) { stores += "1:L"; }
''','''  for (std::size_t n = 0; n < original->files.size(); ++n) { stores += options ? "1:"+std::string(1,options->stores[n]) : "1:L"; }
  if(options&&options->reorderMinimumMiB){put(attributes,"reordermb",i(*options->reorderMinimumMiB));}
''',1)
s=s.replace("static_cast<std::size_t>(engine.num_pieces())", "static_cast<std::size_t>(subject.pieces)",1)
s=s.replace('stopped, forceStart, static_cast<mode_t>(mode & 0777)};','stopped, forceStart, static_cast<mode_t>(mode & 0777),std::move(options)};',1)
s=s.replace('''  return "d" + b("version") + "i1e"''','''  std::string optionalOptions;
  if(p.options) {
    std::string value="d"+b("policy")+b(p.options->policy)+b("stores")+b(p.options->stores);
    if(p.options->reorderMinimumMiB){value+=b("reordermb")+i(*p.options->reorderMinimumMiB);}
    optionalOptions=b("fileOptions")+value+'e';
  }
  return "d" + b("version") + "i1e"''',1)
s=s.replace("""+ b("forceStart") + i(p.forceStart ? 1 : 0) + 'e';""","""+ b("forceStart") + i(p.forceStart ? 1 : 0) + optionalOptions + 'e';""",1)
s=s.replace('''  require(((document.root().children.size() == 20 && !force) || (document.root().children.size() == 22 && force))
      && integer(document.find("version")) == 1,''','''  const auto* optionsNode=document.find("fileOptions");
  require(document.root().children.size()==20+(force?2U:0U)+(optionsNode?2U:0U)
      && integer(document.find("version")) == 1,''',1)
s=s.replace('''  return plan(text(document.find("metadata")), std::move(destination), profile,''','''  std::optional<IntakeFileOptions> options;
  if(optionsNode){
    require(optionsNode->type==Node::Type::Dictionary,ErrorCode::InvalidFormat,"Invalid intake options journal");
    const auto* reorder=optionsNode->find("reordermb");
    require(optionsNode->children.size()==4+(reorder?2U:0U),ErrorCode::InvalidFormat,"Unexpected intake options fields");
    options=IntakeFileOptions{text(optionsNode->find("policy")),text(optionsNode->find("stores")),
        reorder?std::optional{integer(reorder)}:std::nullopt};
  }
  return plan(text(document.find("metadata")), std::move(destination), profile,''',1)
s=s.replace('stopped == 1, static_cast<mode_t>(mode), forceStart == 1);','stopped == 1, static_cast<mode_t>(mode), forceStart == 1,std::move(options));',1)
s=s.replace('''  inventoryCurrent(root, p);
  auto active = childDirectory(root, "active", true);''','''  inventoryCurrent(root, p);
  if(p.options){const auto source=metadataSubject(p.metadata);checkCompactAbsence(source.layout,*p.options,p.destination);}
  auto active = childDirectory(root, "active", true);''',1)
s=s.replace('''  publishNew(active.get(), stateName, p.state);''','''  publishNew(active.get(), stateName, p.state);''',1)
# Recheck absence immediately before admission publication, not just initial replay.
s=s.replace('''  auto current = read(root, "downloads.config", MaximumInventory);
  if (contents(current)''','''  if(p.options){const auto source=metadataSubject(p.metadata);checkCompactAbsence(source.layout,*p.options,p.destination);}
  auto current = read(root, "downloads.config", MaximumInventory);
  if (contents(current)''',1)
s=s.replace('''std::expected<core::TorrentHash, Error> importTorrent(ProfileLease& lease,
    const fs::path& metadata, const fs::path& destination, bool stopped,
    void (*observer)(TorrentIntakeStage), bool forceStart) {''','''static std::expected<core::TorrentHash, Error> importImpl(ProfileLease& lease,
    const fs::path& metadata, const fs::path& destination, bool stopped,
    void (*observer)(TorrentIntakeStage), bool forceStart,
    std::optional<std::span<const compat::FilePolicy>> policies = {},const File* expected = nullptr) {''',1)
s=s.replace('''    require(source.has_value(), ErrorCode::Missing, "Torrent metadata file is missing");
    const auto before''','''    require(source.has_value(), ErrorCode::Missing, "Torrent metadata file is missing");
    require(!expected||(unchanged(expected->info,source->info)&&expected->bytes==source->bytes),
        ErrorCode::Conflict,"Torrent metadata changed after file preview; load it again");
    std::optional<IntakeFileOptions> options;
    if(policies){const auto subject=metadataSubject(source->bytes);options=fileOptions(lease,subject,destination,*policies);}
    const auto before''',1)
s=s.replace('stopped, before ? before->info.st_mode : 0600, forceStart);','stopped, before ? before->info.st_mode : 0600, forceStart,std::move(options));',1)
# Public wrappers and sealed metadata.
at=s.index('std::expected<std::optional<core::TorrentHash>, Error> recoverTorrentIntake(')
s=s[:at]+'''struct TorrentIntakeMetadata::Data {
  fs::path path;File input;compat::OriginalLayout layout;core::TorrentHash hash;
};
TorrentIntakeMetadata::TorrentIntakeMetadata(std::shared_ptr<const Data> data):data_(std::move(data)){}
const core::TorrentHash& TorrentIntakeMetadata::hash()const noexcept{return data_->hash;}
const compat::OriginalLayout& TorrentIntakeMetadata::layout()const noexcept{return data_->layout;}
const fs::path& TorrentIntakeMetadata::source()const noexcept{return data_->path;}
std::expected<TorrentIntakeMetadata,Error> inspectTorrentIntake(const fs::path& path,std::stop_token stop) {
  try {
    require(!stop.stop_requested(),ErrorCode::Cancelled,"Torrent preview cancelled");pathShape(path);
    auto parent=directory(path.parent_path());auto input=read(parent.get(),path.filename().native(),MaximumMetadata);
    require(input.has_value(),ErrorCode::Missing,"Torrent metadata file is missing");
    auto subject=metadataSubject(input->bytes);
    require(!stop.stop_requested(),ErrorCode::Cancelled,"Torrent preview cancelled");
    return TorrentIntakeMetadata(std::make_shared<const TorrentIntakeMetadata::Data>(
        TorrentIntakeMetadata::Data{path,std::move(*input),std::move(subject.layout),subject.hash}));
  } catch(const Failure& failure){return std::unexpected(failure.error);}
  catch(...){return std::unexpected(Error{ErrorCode::Io,"Cannot inspect torrent metadata"});}
}
std::expected<core::TorrentHash,Error> importTorrent(ProfileLease& lease,const fs::path& source,
    const fs::path& destination,bool stopped,void(*observer)(TorrentIntakeStage),bool forceStart) {
  return importImpl(lease,source,destination,stopped,observer,forceStart);
}
std::expected<core::TorrentHash,Error> importTorrentWithFileOptions(ProfileLease& lease,
    const TorrentIntakeMetadata& metadata,const fs::path& destination,bool stopped,
    std::span<const compat::FilePolicy> policies,void(*observer)(TorrentIntakeStage),bool forceStart) {
  return importImpl(lease,metadata.data_->path,destination,stopped,observer,forceStart,policies,&metadata.data_->input);
}

'''+s[at:]
p.write_text(s)
