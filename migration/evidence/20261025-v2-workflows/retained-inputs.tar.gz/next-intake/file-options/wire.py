from pathlib import Path
W=Path(__file__).resolve().parent/'staging/preview/native'
def change(rel,a,b):
 p=W/rel;s=p.read_text();assert s.count(a)==1,(rel,a[:80],s.count(a));p.write_text(s.replace(a,b))
change('adapters/torrent_intake.hpp','// Startup recovery before loading library/admitting operations.','bool hasPendingTorrentIntake(const ProfileLease&) noexcept;\n\n// Startup recovery before loading library/admitting operations.')
change('adapters/torrent_intake.cpp','std::expected<std::optional<core::TorrentHash>, Error> recoverTorrentIntake(','''bool hasPendingTorrentIntake(const ProfileLease& lease) noexcept {
  try{
    if(!lease.valid()){return true;}
    for(const auto* leaf:{Journal,JournalSaving,InventorySaving,BackupSaving}){if(named(lease.directoryHandle(),leaf)){return true;}}
    return false;
  }catch(...){return true;}
}
std::expected<std::optional<core::TorrentHash>, Error> recoverTorrentIntake(''')
change('app/session_bridge.hpp','#include "scheduler_presentation.hpp"','#include "scheduler_presentation.hpp"\n#include "torrent_intake_presentation.hpp"')
change('app/session_bridge.hpp','  bool torrentImport(QString metadata, QString destination, bool start);','  bool torrentImport(QString metadata, QString destination, bool start);\n  bool previewTorrentIntake(ui::TorrentIntakeRequest);\n  bool importTorrentFiles(ui::TorrentIntakeSubmission);')
change('app/session_bridge.hpp','  void torrentCreated(biglybtc::ui::TorrentCreationResultPresentation);','  void torrentCreated(biglybtc::ui::TorrentCreationResultPresentation);\n  void torrentIntakeReady(biglybtc::ui::TorrentIntakePresentation);\n  void torrentIntakeFinished(biglybtc::ui::TorrentIntakeResultPresentation);')
change('app/session_bridge.cpp','  storage::ProfileLease lease;','''  storage::ProfileLease lease;
  std::optional<storage::TorrentIntakeMetadata> intakeMetadata;
  std::optional<ui::TorrentIntakeRequest> intakeRequest;
  quint64 intakePreviewRevision = 0;''')
change('app/session_bridge.cpp','  qRegisterMetaType<ui::SavedServicesPresentation>();','''  qRegisterMetaType<ui::TorrentIntakeRequest>();
  qRegisterMetaType<ui::TorrentIntakePresentation>();
  qRegisterMetaType<ui::TorrentIntakeSubmission>();
  qRegisterMetaType<ui::TorrentIntakeResultPresentation>();
  qRegisterMetaType<ui::SavedServicesPresentation>();''')
change('app/session_bridge.cpp','bool SessionBridge::magnetImport(QString uri, QString destination) {','''bool SessionBridge::previewTorrentIntake(ui::TorrentIntakeRequest request) {
  if(profileClosed_||!request.session||request.session!=publishedColumnLayoutSession_||!request.request){return false;}
  return dispatch([this,request=std::move(request)](std::stop_token stop){
    auto packet=std::make_shared<ui::TorrentIntakePacket>();packet->source=request;
    try {
      if(!host_||request.session!=host_->columnLayoutSession){throw Failure{{storage::ErrorCode::Conflict,"The profile changed; load the torrent again"}};}
      if(host_->intakeRequest&&request.request<=host_->intakeRequest->request){throw Failure{{storage::ErrorCode::Conflict,"This file preview request is stale"}};}
      host_->intakeRequest=request;host_->intakeMetadata.reset();
      auto value=take(storage::inspectTorrentIntake(std::filesystem::path(request.metadata.toUtf8().toStdString()),stop));
      if(value.layout().files.size()>ui::MaximumIntakePreviewFiles){throw Failure{{storage::ErrorCode::Unsupported,"This torrent has too many files for the preview editor"}};}
      if(host_->intakePreviewRevision==std::numeric_limits<quint64>::max()){throw Failure{{storage::ErrorCode::Conflict,"File preview revisions are exhausted"}};}
      packet->revision=++host_->intakePreviewRevision;packet->hash=text(value.hash().hex());packet->name=text(value.layout().name);
      for(std::size_t n=0;n<value.layout().files.size();++n){
        const auto& file=value.layout().files[n];packet->files.push_back({static_cast<int>(n),text(file.path),file.bytes,file.padding});
      }
      if(!ui::validTorrentIntake(packet)){throw Failure{{storage::ErrorCode::Unsupported,"Torrent paths exceed the preview editor limits"}};}
      checkpoint(stop);host_->intakeMetadata.emplace(std::move(value));
    }catch(const Failure& error){packet->failure=text(error.error.message);}
    catch(const std::exception&){packet->failure=tr("The torrent file list could not be loaded");}
    ui::TorrentIntakePresentation result=std::move(packet);
    QMetaObject::invokeMethod(this,[this,result]{
      QPointer<SessionBridge> guard(this);
      if(!profileClosed_&&result->source.session==publishedColumnLayoutSession_){emit torrentIntakeReady(result);}
      if(!guard){return;}completionMonitor_->stop();busy_=false;emit busyChanged(false);
    },Qt::QueuedConnection);
  },false);
}
bool SessionBridge::importTorrentFiles(ui::TorrentIntakeSubmission submission) {
  if(profileClosed_||!submission.session||submission.session!=publishedColumnLayoutSession_||!submission.request){return false;}
  return dispatch([this,submission=std::move(submission)](std::stop_token stop){
    auto result=std::make_shared<ui::TorrentIntakeResultPacket>();
    result->session=submission.session;result->request=submission.request;result->revision=submission.revision;
    try {
      if(!host_||submission.session!=host_->columnLayoutSession||!host_->intakeRequest||!host_->intakeMetadata
          ||submission.request!=host_->intakeRequest->request||submission.revision!=host_->intakePreviewRevision){
        throw Failure{{storage::ErrorCode::Conflict,"The file preview is stale; load the torrent again"}};
      }
      if(host_->fileRecoveryRequired||storage::hasPendingFileOperation(host_->lease)
          ||storage::hasPendingOriginalCompaction(host_->lease)||storage::hasPendingTorrentIntake(host_->lease)){
        throw Failure{{storage::ErrorCode::Conflict,"Restart to finish pending storage recovery before importing"}};
      }
      const auto& layout=host_->intakeMetadata->layout();
      if(submission.files.size()!=layout.files.size()){throw Failure{{storage::ErrorCode::Conflict,"File choices do not match the loaded torrent"}};}
      bool selected=false;
      for(std::size_t n=0;n<submission.files.size();++n){
        if(layout.files[n].padding&&(!submission.files[n].skipped||submission.files[n].priority)){
          throw Failure{{storage::ErrorCode::Unsupported,"Padding files cannot be selected"}};
        }
        selected=selected||(!layout.files[n].padding&&!submission.files[n].skipped&&layout.files[n].bytes>0);
      }
      const bool start=submission.start&&selected;
      if(start&&(!host_->engine||!host_->engine->managedAvailable())){throw Failure{{storage::ErrorCode::Unsupported,"The engine is unavailable; add this torrent stopped instead"}};}
      checkpoint(stop); // No payload/network work happens before the explicit commit.
      const auto hash=take(storage::importTorrentWithFileOptions(host_->lease,*host_->intakeMetadata,
          std::filesystem::path(submission.destination.toUtf8().toStdString()),!start,submission.files));
      result->imported=true;result->hash=text(hash.hex());host_->intakeMetadata.reset();
      const auto details=engine::queryTorrent(host_->lease,hash);
      if(details){host_->known.insert_or_assign(hash.hex(),Host::Known{text(details->name),details->bytes});}
      if(start){
        const auto admitted=host_->engine->startManaged(host_->lease,{hash,host_->peerPort,false,false});
        if(admitted){result->started=true;host_->admissionFailures.erase(hash.hex());}
        else{host_->admissionFailures.insert_or_assign(hash.hex(),admitted.error());result->failure=tr("Torrent added; download could not start: %1").arg(text(admitted.error().message));}
      }
    }catch(const Failure& error){result->failure=text(error.error.message);}
    catch(const std::exception&){result->failure=tr("Torrent import did not finish; inspect recovery status before retrying");}
    if(host_&&storage::hasPendingTorrentIntake(host_->lease)){host_->fileRecoveryRequired=true;result->failure+=tr(" Restart to recover the accepted import.");}
    ui::TorrentIntakeResultPresentation packet=result;
    QMetaObject::invokeMethod(this,[this,packet]{
      if(!profileClosed_&&packet->session==publishedColumnLayoutSession_){emit torrentIntakeFinished(packet);}
    },Qt::QueuedConnection);
    if(host_){ready(host_->query({}),result->failure.isEmpty()?tr("Torrent added with the selected file choices"):result->failure);}
    else{failed(result->failure);}
  });
}

bool SessionBridge::magnetImport(QString uri, QString destination) {''')
change('ui/library_window.hpp','#include "file_model.hpp"','#include "file_model.hpp"\n#include "torrent_intake_presentation.hpp"')
# Header forward declarations vary; append namespace declaration beside existing one.
p=W/'ui/library_window.hpp';s=p.read_text()
marker='class LibraryWindow final'
at=s.index(marker);s=s[:at]+'class TorrentIntakeDialog;\n\n'+s[at:];p.write_text(s)
change('ui/library_window.hpp','  void setIntakeDefaults(quint64 session, QString directory);','''  void setIntakeDefaults(quint64 session, QString directory);
  void setTorrentIntake(TorrentIntakePresentation);
  void setTorrentIntakeFinished(TorrentIntakeResultPresentation);
  void rejectTorrentIntake(const TorrentIntakeRequest&);
  void rejectTorrentIntakeSubmission(const TorrentIntakeSubmission&);''')
change('ui/library_window.hpp','  void torrentImportRequested(QString metadata, QString destination, bool start);','''  void torrentImportRequested(QString metadata, QString destination, bool start);
  void torrentIntakeRequested(biglybtc::ui::TorrentIntakeRequest);
  void torrentIntakeSubmitted(biglybtc::ui::TorrentIntakeSubmission);''')
change('ui/library_window.hpp','  void openImportDialog(bool magnet);','  void openImportDialog(bool magnet);\n  void openTorrentIntake();')
change('ui/library_window.hpp','  bool busy_ = false;','''  QPointer<TorrentIntakeDialog> intakeDialog_;
  std::optional<TorrentIntakeRequest> activeIntakePreview_;
  std::optional<TorrentIntakeSubmission> activeIntakeSubmission_;
  bool busy_ = false;''')
change('ui/library_window.cpp','#include "torrent_creation_dialog.hpp"','#include "torrent_creation_dialog.hpp"\n#include "torrent_intake_dialog.hpp"')
change('ui/library_window.cpp','  defaultSaveDirectory_.clear();','''  activeIntakePreview_.reset();activeIntakeSubmission_.reset();
  if(intakeDialog_){intakeDialog_->invalidateSession();if(!guard){return;}}
  defaultSaveDirectory_.clear();''')
change('ui/library_window.cpp','void LibraryWindow::openImportDialog(bool magnet) {\n  if (!canImport() || downloadDispatching_) { return; }','void LibraryWindow::openImportDialog(bool magnet) {\n  if (!canImport() || downloadDispatching_) { return; }\n  if(!magnet){openTorrentIntake();return;}')
change('ui/library_window.cpp','  QPointer<LibraryWindow> optionsGuard(this);\n  if(fileOperationDialog_){','''  QPointer<LibraryWindow> optionsGuard(this);
  if(intakeDialog_){intakeDialog_->setBusy(value);}if(!optionsGuard){return;}
  if(!value&&activeIntakePreview_){rejectTorrentIntake(*activeIntakePreview_);if(!optionsGuard){return;}}
  if(!value&&activeIntakeSubmission_){rejectTorrentIntakeSubmission(*activeIntakeSubmission_);if(!optionsGuard){return;}}
  if(fileOperationDialog_){''')
change('ui/library_window.cpp','  if(fileOperationDialog_&&fileOperationDialog_->isVisible()&&!fileOperationDialog_->close()){','  if(intakeDialog_&&intakeDialog_->isVisible()&&!intakeDialog_->close()){event->ignore();return;}if(!optionsGuard){return;}\n  if(fileOperationDialog_&&fileOperationDialog_->isVisible()&&!fileOperationDialog_->close()){')
change('ui/library_window.cpp','void LibraryWindow::selectionChanged() {','''void LibraryWindow::openTorrentIntake() {
  if(!canImport()||downloadDispatching_){return;}
  if(!intakeDialog_){
    intakeDialog_=new TorrentIntakeDialog(this);intakeDialog_->setWindowModality(Qt::WindowModal);
    connect(intakeDialog_,&TorrentIntakeDialog::previewRequested,this,[this](TorrentIntakeRequest request){
      if(!canImport()||request.session!=columnSession_){if(intakeDialog_){intakeDialog_->rejectPreview(request);}return;}
      activeIntakePreview_=request;emit torrentIntakeRequested(std::move(request));
    });
    connect(intakeDialog_,&TorrentIntakeDialog::submitted,this,[this](TorrentIntakeSubmission submission){
      if(!canImport()||submission.session!=columnSession_){if(intakeDialog_){intakeDialog_->rejectSubmission(submission);}return;}
      activeIntakeSubmission_=submission;emit torrentIntakeSubmitted(std::move(submission));
    });
    connect(intakeDialog_,&TorrentIntakeDialog::previewCancelled,this,[this](TorrentIntakeRequest request){
      if(activeIntakePreview_&&*activeIntakePreview_==request){activeIntakePreview_.reset();emit cancelRequested();}
    });
    connect(intakeDialog_,&QObject::destroyed,this,[this]{activeIntakePreview_.reset();activeIntakeSubmission_.reset();});
  }
  QPointer<LibraryWindow> guard(this);const auto dialog=intakeDialog_;
  if(!dialog->beginSession(columnSession_,defaultSaveDirectory_)||!guard||!dialog){return;}
  dialog->setBusy(busy_);if(!guard||!dialog){return;}dialog->show();
}
void LibraryWindow::setTorrentIntake(TorrentIntakePresentation packet) {
  if(!packet||!activeIntakePreview_||packet->source!=*activeIntakePreview_||packet->source.session!=columnSession_){return;}
  activeIntakePreview_.reset();if(intakeDialog_){intakeDialog_->setPreview(std::move(packet));}
}
void LibraryWindow::setTorrentIntakeFinished(TorrentIntakeResultPresentation packet) {
  if(!packet||!activeIntakeSubmission_||packet->session!=columnSession_
      ||packet->session!=activeIntakeSubmission_->session||packet->request!=activeIntakeSubmission_->request
      ||packet->revision!=activeIntakeSubmission_->revision){return;}
  activeIntakeSubmission_.reset();if(intakeDialog_){intakeDialog_->setResult(std::move(packet));}
}
void LibraryWindow::rejectTorrentIntake(const TorrentIntakeRequest& request) {
  if(!activeIntakePreview_||*activeIntakePreview_!=request){return;}
  const auto copied=request;activeIntakePreview_.reset();if(intakeDialog_){intakeDialog_->rejectPreview(copied);}
}
void LibraryWindow::rejectTorrentIntakeSubmission(const TorrentIntakeSubmission& submission) {
  if(!activeIntakeSubmission_||activeIntakeSubmission_->session!=submission.session
      ||activeIntakeSubmission_->request!=submission.request||activeIntakeSubmission_->revision!=submission.revision){return;}
  const auto copied=submission;activeIntakeSubmission_.reset();if(intakeDialog_){intakeDialog_->rejectSubmission(copied);}
}

void LibraryWindow::selectionChanged() {''')
change('app/main_desktop.cpp','    QObject::connect(&window, &Window::torrentImportRequested, &bridge, &Bridge::torrentImport);','''    QObject::connect(&window, &Window::torrentImportRequested, &bridge, &Bridge::torrentImport);
    QObject::connect(&window,&Window::torrentIntakeRequested,&bridge,[&](biglybtc::ui::TorrentIntakeRequest r){if(!bridge.previewTorrentIntake(r)){window.rejectTorrentIntake(r);}});
    QObject::connect(&window,&Window::torrentIntakeSubmitted,&bridge,[&](biglybtc::ui::TorrentIntakeSubmission r){if(!bridge.importTorrentFiles(r)){window.rejectTorrentIntakeSubmission(r);}});
    QObject::connect(&bridge,&Bridge::torrentIntakeReady,&window,&Window::setTorrentIntake);
    QObject::connect(&bridge,&Bridge::torrentIntakeFinished,&window,&Window::setTorrentIntakeFinished);''')
