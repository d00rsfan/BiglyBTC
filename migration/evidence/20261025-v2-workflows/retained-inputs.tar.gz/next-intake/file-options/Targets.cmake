# Include from preview/native/tests/CMakeLists.txt after its existing targets.
# No production CMake file is replaced by this source-only capsule.
if(TARGET biglybtc_ui)
  target_sources(biglybtc_ui PRIVATE
    "${PROJECT_SOURCE_DIR}/ui/torrent_intake_presentation.hpp"
    "${PROJECT_SOURCE_DIR}/ui/torrent_intake_dialog.hpp"
    "${PROJECT_SOURCE_DIR}/ui/torrent_intake_dialog.cpp")
  add_executable(biglybtc-torrent-intake-dialog-tests "${PROJECT_SOURCE_DIR}/tests/torrent_intake_dialog_tests.cpp")
  set_target_properties(biglybtc-torrent-intake-dialog-tests PROPERTIES AUTOMOC ON)
  target_link_libraries(biglybtc-torrent-intake-dialog-tests PRIVATE biglybtc_ui Qt6::Test)
  target_compile_options(biglybtc-torrent-intake-dialog-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  add_test(NAME torrent-intake-file-options-ui COMMAND biglybtc-torrent-intake-dialog-tests)
  set_tests_properties(torrent-intake-file-options-ui PROPERTIES TIMEOUT 120 ENVIRONMENT "QT_QPA_PLATFORM=offscreen" LABELS "unit;ui;intake")
endif()
if(BIGLYBTC_LOCAL_ENGINE)
  add_executable(biglybtc-torrent-intake-file-options-tests "${PROJECT_SOURCE_DIR}/tests/torrent_intake_file_options_tests.cpp")
  target_link_libraries(biglybtc-torrent-intake-file-options-tests PRIVATE biglybtc_profile LibtorrentRasterbar::torrent-rasterbar)
  target_compile_options(biglybtc-torrent-intake-file-options-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  add_test(NAME torrent-intake-file-options COMMAND biglybtc-torrent-intake-file-options-tests)
  set_tests_properties(torrent-intake-file-options PROPERTIES TIMEOUT 120 LABELS "unit;intake;storage")
endif()
if(TARGET biglybtc_desktop_host AND NOT BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST STREQUAL "")
  add_executable(biglybtc-torrent-intake-files-bridge-tests "${PROJECT_SOURCE_DIR}/tests/torrent_intake_files_bridge_tests.cpp")
  set_target_properties(biglybtc-torrent-intake-files-bridge-tests PROPERTIES AUTOMOC ON)
  target_link_libraries(biglybtc-torrent-intake-files-bridge-tests PRIVATE biglybtc_desktop_host biglybtc_local_engine biglybtc_profile LibtorrentRasterbar::torrent-rasterbar Qt6::Test)
  target_compile_options(biglybtc-torrent-intake-files-bridge-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  add_test(NAME torrent-intake-file-options-worker COMMAND biglybtc-torrent-intake-files-bridge-tests)
  set_tests_properties(torrent-intake-file-options-worker PROPERTIES TIMEOUT 120 ENVIRONMENT "QT_QPA_PLATFORM=offscreen" LABELS "unit;intake;loopback;storage")
endif()
