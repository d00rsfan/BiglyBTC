from pathlib import Path
import json, subprocess, re
w = Path(__file__).resolve().parent / 'next-hosted'
w.mkdir(exist_ok=False)
rows = []
for run in [40194703148, 40194703171]:
    raw = subprocess.check_output(['gh', 'run', 'view', str(run), '--repo', 'd00rsfan/BiglyBTC', '--json', 'databaseId,name,status,conclusion,headSha,url'])
    v = json.loads(raw)
    assert v['status'] == 'completed' and v['conclusion'] == 'success' and v['headSha'] == '4f948e042df9467310a5752d4343b07915673f84'
    (w / (str(run) + '.json')).write_bytes(raw)
    with (w / (str(run) + '.log')).open('wb') as out:
        subprocess.run(['gh', 'run', 'view', str(run), '--repo', 'd00rsfan/BiglyBTC', '--log'], stdout=out, check=True)
    v['ctest_suite_counts'] = [int(x) for x in re.findall(r'100% tests passed, 0 tests failed out of (\d+)', (w / (str(run) + '.log')).read_text())]
    rows.append(v)
(w / 'hosted-final.json').write_text(json.dumps(rows, indent=2) + '\n')
print('Exact-source hosted SDK/desktop PASS:', [(v['name'], v['ctest_suite_counts']) for v in rows])
