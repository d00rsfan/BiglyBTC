#!/usr/bin/env python3
"""Root-run evidence checks and W-only publication staging; no subjects or Git writes."""
from pathlib import Path
from types import SimpleNamespace
import argparse
import copy
import gzip
import hashlib
import importlib.util
import io
import json
import re
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
H = Path(__file__).resolve().parent
R = Path('/home/yurii/Java/BiglyBT')
N = R.parent/'BiglyBTC'
W = R/'build/network-service-cohort-20261028'
A = W/'amendments/runtime-eight-private-recipes'
Q = W/'scoped-followup'
SOURCE = '013fa60f59898392a33855ba148961090bacca14'
HISTORICAL = 'b0c0270cc8c41deb5169767e583b49ec654c73ca'
COUNTS = {'gcc':24, 'clang':19, 'san':24}
EVIDENCE = 'migration/evidence/20261028-network-service-cohort'
REVIEW = 'migration/updates/network-service-cohort/20261028-bounded.md'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def dump(value): return (json.dumps(value,indent=2,ensure_ascii=True)+'\n').encode()
def git(repo,*args): return subprocess.check_output(['git','--no-replace-objects','-C',str(repo),*args])
def require(value,message):
    if not value: raise ValueError(message)
def label(path):
    path=Path(path).resolve()
    if path.is_relative_to(R.resolve()):return str(path.relative_to(R.resolve()))
    require(path.is_relative_to(N.resolve()),'Evidence outside declared repositories')
    return 'native/'+str(path.relative_to(N.resolve()))

def render_checkpoint(name,values):
    text=(H/name).read_text()
    for key,value in values.items():text=text.replace('@'+key+'@',str(value))
    require(not re.search(r'@[A-Z_]+@',text),'Unresolved checkpoint template field')
    return text

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for lane in COUNTS: p.add_argument('--'+lane+'-result',type=Path,required=True)
    p.add_argument('--include-retained-audit-resolver',action='store_true')
    p.add_argument('--original-result',type=Path,required=True)
    p.add_argument('--private-result',type=Path,required=True)
    p.add_argument('--promotion-result',type=Path,required=True)
    p.add_argument('--write',action='store_true',help='Write fresh W-only evidence and metadata after all gates')
    p.add_argument('--attempt',default='r1')
    args = p.parse_args()
    require(re.fullmatch('[A-Za-z0-9_-]+',args.attempt),'Invalid attempt')
    frozen = load(H/'manifest.json')
    for name,pin in frozen['inputs_sha256'].items(): require(sha(R/name)==pin,'Changed input: '+name)
    for name,pin in frozen['artifacts_sha256'].items(): require(sha(H/name)==pin,'Changed recipe: '+name)
    require(git(R,'rev-parse','HEAD').decode().strip()==frozen['original_head'],'Original HEAD changed')
    require(sha(R/'.git/index')==frozen['original_index_sha256'],'Original index changed')
    lock = load(R/'migration/upstreams.lock.json')
    require(len(lock['components'])==105 and len(lock['external_dependencies'])==19,'Registry shape changed')
    spec = importlib.util.spec_from_file_location('cohort_private_support',A/'private-runtime/support.py')
    support = importlib.util.module_from_spec(spec); spec.loader.exec_module(support)
    results = {lane:getattr(args,lane+'_result').resolve() for lane in COUNTS}
    proof_args = SimpleNamespace(source_commit=SOURCE,source_receipt=W/'source-runtime-fixes-r5.json',
        **{lane+'_result':path for lane,path in results.items()})
    snapshot,qualified = support.verify_all(proof_args)
    proposal=load(H/'component-proposals.json');require(proposal['qualified_source']==SOURCE,'Wrong component source')
    for item in proposal['components']:
        for path,pin in item['source_sha256'].items():require(snapshot['files_sha256'].get(path)==pin,'Component source pin differs: '+path)
    lanes = {lane:load(path) for lane,path in results.items()}
    require({lane:d['effective_suites'] for lane,d in lanes.items()}==COUNTS,'Wrong effective matrix')
    require({lane:d['actual_fresh_suites'] for lane,d in lanes.items()}=={'gcc':4,'clang':3,'san':4},'Wrong fresh matrix')
    closeout=load(support.PLAN['closeout']['path']); chain=support.source_authority.verify(SOURCE)
    # Delegated checks reparse actual XML/commands/source graphs and separate real-Tor receipts.
    inputs = {}
    members = {}
    def keep(path,archive=None):
        path=Path(path).resolve(); key=label(path); inputs[key]={'sha256':sha(path),'bytes':path.stat().st_size}
        if archive is not None:
            require(archive not in members,'Duplicate archive member')
            members[archive]=path.read_bytes()
        return inputs[key]['sha256']
    def commands(root,pin):
        rows=support.commands(root,pin)
        keep(root/'commands.json') # raw commands/private paths remain local
        return rows
    def xml_summary(path,name):
        keep(path)
        members[name]=dump([dict(row.attrib) for row in support.h.ET.parse(path).iter('testcase')])
    matrix = {}
    for lane,d in lanes.items():
        root=results[lane].parent
        for path in root.glob('*.json'): keep(path)
        xml_summary(root/'tests.xml',lane+'/testcases.json')
        # Verbose histories are retained locally; capture their hashes, not private paths/transcripts.
        for row in load(root/'commands.json'): keep(row['log'])
        for path in (root/'real-offline-tor').iterdir():
            if path.is_file(): keep(path)
        origins={name:{'kind':value['kind'],'source_commit':value['source_commit'],
            'junit_sha256':value['junit_sha256'],'normalized_row_sha256':value['normalized_row_sha256'],
            'image_sha256':value.get('pretest_image',{}).get('sha256'),
            'historical_gzip_sha256':value.get('historical_image',{}).get('sha256')}
            for name,value in d['effective_suite_origins'].items()}
        members[lane+'/effective-suite-origins.json']=dump(origins)
        matrix[lane]={'actual_suites':d['effective_suites'],'suite_names':d['suite_names'],
            'actual_fresh_suites':d['actual_fresh_suites'],'fresh_suite_names':d['fresh_suite_names'],
            'historical_suites':d['effective_suites']-d['actual_fresh_suites'],
            'historical_source':HISTORICAL,'fresh_source':SOURCE,'suite_origins':origins,
            'current_image_compile_only_suites':d['compile_only_suites'],
            'declared_compile_only_suites':qualified[lane]['declared_compile_only_suites'],
            'current_image_scope':d['current_image_scope'],'result_sha256':sha(results[lane]),
            'source_map_sha256':sha(root/'source-map.json'),
            'binaries':{k:{'sha256':v['sha256'],'bytes':v['bytes'],'scope':d['current_image_scope'][k]} for k,v in d['images_after'].items()},
            'real_offline_tor':{'status':d['real_offline_tor']['status'],
                'receipt_sha256':sha(root/'real-offline-tor/result.json'),
                'joined':d['real_offline_tor']['observed']['joined']}}
    original_path=args.original_result.resolve(); original=load(original_path); oracle=R/'build/mainline-scrape-single-tracker-20261028/runtime-owner/oracle'
    require(original['status']=='PASS_ACTUAL_ORIGINAL_SINGLE_TRACKER_RESPONSE_PROJECTION'
        and original['source_commit']==HISTORICAL and original['actual_cases']==16
        and original['scalar_comparisons']==80 and original['mismatches']==[], 'Original16/80 not passed')
    require(original['manifest_sha256']==sha(oracle/'manifest.json') and original['original_commit']=='cb8c6cb9bb97916cbc7e80338a017200ffc3e71f'
        and original['cohort_unchanged'] is True and original['driver_unchanged'] is True
        and original['original_recompiled'] is False and original['original_tracker_wire_parser_executed'] is False,
        'Original projection provenance differs')
    reference=support.PLAN['original_java_reference']
    require(original_path==Path(reference['path']).resolve() and sha(original_path)==reference['sha256'],'Historical original reference differs')
    old_gcc=closeout['lanes']['gcc'];old_replay=old_gcc['all_compiled_images_unchanged']['biglybtc-queue-facts-replay']
    old_root=Path(old_gcc['original_result_path']).parent
    require(original['native_driver_sha256']==old_replay['sha256']
        and original['build_receipt_sha256']==sha(old_root/'build-receipt.json')
        and original['build_source_map_sha256']==sha(old_root/'source-map.json'),'Original driver does not match actual historical GCC build')
    require(not git(N,'diff','--name-only',HISTORICAL,SOURCE,'--','preview/native/core','preview/native/tests/queue_facts_replay.cpp').strip(),
        'Historical original reducer/replay source changed')
    require(len(original['commands'])==3 and {row['name'] for row in original['commands']}=={'javac-owned-helpers','original','native'}
        and all(row.get('exit_code')==0 for row in original['commands']),'Original command failed')
    native_command=next(row['argv'] for row in original['commands'] if row['name']=='native')
    require(len(native_command)==1 and Path(native_command[0]).resolve()
        ==Path(old_replay['path']).resolve(),'Original replay command differs')
    expected={(row['id'],field) for row in load(oracle/'manifest.json')['cases'] for field in ('responseType','seeds','peers','start','eligible')}
    def observations(path,marker):
        values={}
        for line in path.read_text().splitlines():
            if line.startswith('OBS\t'):
                fields=line.split('\t'); require(len(fields)==4 and tuple(fields[1:3]) not in values,'Duplicate observation')
                values[tuple(fields[1:3])]=int(fields[3])
            else: require(line==marker+'\t16','Unexpected observation output')
        require(set(values)==expected,'Missing actual observations'); return values
    require(observations(original_path.parent/'original.stdout','PASS_SINGLE_TRACKER_ORIGINAL')
        == observations(original_path.parent/'native.stdout','PASS_QUEUE_FACTS_NATIVE'),'Actual original/native differences')
    keep(original_path)
    for name in ('original.stdout','native.stdout'):keep(original_path.parent/name,'single-tracker/'+name)
    div_ref=R/'build/azureus-storage-diversification-20261028/qualification-references.json'; reference=load(div_ref)
    div=R/reference['original_and_three_native_replay']['path']; d=load(div)
    require(sha(div)==reference['original_and_three_native_replay']['sha256']
        and d['status']==reference['status']=='PASS_ORIGINAL_AND_ACTUAL_NATIVE_REPLAY'
        and d['observations']==reference['observations']==63,'Diversification63 reference changed')
    for step in d['steps']:
        require(step['exit']==0,'Diversification command failed')
        for suffix in ('stdout','stderr'):
            file=div.parent/(step['name']+'.'+suffix);require(sha(file)==step[suffix+'_sha256'],'Reference output changed');keep(file)
    require(sha(div.parent/'original.stdout')==d['golden_sha256']==reference['golden_sha256'],'Reference golden changed')
    for row in d['native']:
        require(row['output_sha256']==d['golden_sha256'] and sha(row['build_receipt'])==row['build_receipt_sha256'],'Reference native receipt changed')
        keep(row['build_receipt'])
    keep(div);keep(div_ref);keep(div.parent/'original.stdout','diversification/original63.stdout')
    private_path=args.private_result.resolve(); private=load(private_path); promotion_path=args.promotion_result.resolve(); promotion=load(promotion_path)
    require(private['status']=='PASS_PRIVATE_RELOCATED_RUNTIME' and private['source_commit']==SOURCE
        and private['qualified_results']==qualified and private['shipping_approved'] is False
        and private['verified_leaves']==118 and private['loader_init_verified'] is True,'Private runtime not passed')
    require(promotion['status']=='PASS_PROMOTED_PRIVATE_DEVELOPMENT_DIST' and promotion['source_commit']==SOURCE
        and promotion['private_result']['sha256']==sha(private_path) and Path(promotion['private_result']['path']).resolve()==private_path
        and promotion['qualified_results']==qualified and promotion['shipping_approved'] is False
        and promotion['actual_private_qt_and_provider_init'] is True,'Actual private promotion missing')
    require(private['provider']==promotion['provider']==lanes['gcc']['provider'],'Private provider differs')
    require(private['distribution_scope']==promotion['distribution_scope']=='private-qualification-only'
        and private['published_dist_unchanged']==support.OLD_DIST_SHA and Path(promotion['installed_path']).resolve()==(N/'dist').resolve(),
        'Private/promotion scope or location differs')
    require(private['source_adoption_sha256']==promotion['source_adoption_sha256']==sha(W/'source-runtime-fixes-r5.json')
        and private['source_amendment']==promotion['source_amendment']==chain
        and chain['runtime_correction']==lanes['gcc']['source_amendment'],'Private source association differs')
    rows=commands(private_path.parent,private['commands_sha256']);commands(promotion_path.parent,promotion['commands_sha256'])
    require({x['binary'] for x in private['actual_tests']}==set(support.NAMES) and len(private['actual_tests'])==4,'Wrong private4')
    for item in private['actual_tests']:
        name=item['binary'];image=private['test_images'][name]
        require(item['exit']==rows[name]['exit']==0 and item['sha256']==image['sha256']==lanes['gcc']['images_after'][name]['sha256'],'Private executable differs')
        copied=private_path.parent/'owner-tests'/name
        require(item['mode']=='QtTest-default' and image['copy']==str(copied) and sha(copied)==image['sha256']
            and image['source']==lanes['gcc']['images_after'][name]['path'],'Private copied executable differs')
        require(rows[name]['command']==[str(copied),'-o',str(private_path.parent/(name+'.txt'))+',txt','-o',str(private_path.parent/(name+'.xml'))+',junitxml'],
            'Private actual command differs')
        require(item['xml_sha256']==sha(private_path.parent/(name+'.xml')),'Private XML changed')
        require(support.xml(private_path.parent/(name+'.xml'))==item['testcase_names'],'Private testcase mismatch')
        xml_summary(private_path.parent/(name+'.xml'),'private/'+name+'-testcases.json')
    current=support.verify_bundle(N/'dist');rollback=Path(promotion['rollback']);previous=support.verify_bundle(rollback,old=True)
    require(sha(N/'dist/BUILD_MANIFEST.json')==promotion['new_manifest_sha256']==private['manifest_sha256']
        and sha(rollback/'BUILD_MANIFEST.json')==promotion['previous_manifest_sha256']==support.OLD_DIST_SHA,'Dist/rollback receipt differs')
    require(len(current['files_sha256'])==promotion['new_leaves']==118 and len(previous['files_sha256'])==promotion['previous_leaves']==118,'Wrong dist leaf count')
    keep(private_path);keep(promotion_path)
    keep(N/'dist/BUILD_MANIFEST.json','distribution/current-BUILD_MANIFEST.json')
    keep(rollback/'BUILD_MANIFEST.json','distribution/previous-BUILD_MANIFEST.json')
    # Hash all histories, including failed/interrupted r1 attempts, without crediting or publishing private logs.
    history=[]
    for base in (W/'qualification/runs',W/'amendments/file-fd-default-recipes/qualification/runs',
        W/'amendments/managed-storage-include-recipes/qualification/runs',Q/'runs',
        W/'real-tor-standalone',W/'tor-config-diagnostic',A/'private-runtime/runs',A/'private-runtime/promotions'):
        for path in sorted(base.glob('*/*')):
            if path.is_file() and path.suffix in ('.json','.xml','.log'):
                pin=keep(path)
                if path.name=='result.json':
                    try: status=load(path).get('status')
                    except (ValueError,TypeError): status='UNPARSEABLE_RETAINED_HISTORY'
                    history.append({'path':label(path),'sha256':pin,'status':status,'credited':path in results.values()})
    for name in frozen['inputs_sha256']:
        path=R/name
        if path.suffix in ('.py','.json','.patch','.md'):keep(path,'inputs/'+name.removeprefix('build/'))
    for name in (*frozen['artifacts_sha256'],'manifest.json'):keep(H/name,'recipe/'+name)
    export=N/'migration/exports/20261028-tor-prototype.json'
    require(sha(export)==frozen['native_export_sha256'],'Native Tor export changed')
    keep(export,'source/20261028-tor-prototype.json')
    keep(R/'migration/upstreams.lock.json')
    p13_files={};p13_info=None
    if args.include_retained_audit_resolver:
        p13=R/'build/native-audit-resolver-20261028';manifest=load(p13/'manifest.json');review=load(p13/'root-review.json')
        require(sha(p13/'manifest.json')==frozen['p13_manifest_sha256'] and sha(p13/'root-review.json')==frozen['p13_root_review_sha256'],'P13 source/review changed')
        require(review['status']=='PASS_ROOT_SOURCE_REVIEW_AND_OWNED_GIT_FIXTURES' and review['fixture_exit']==0 and review['actual_fixture_methods']==18
            and sha(p13/'root-fixtures-r1.log')==review['fixture_log_sha256'],'P13 actual fixture proof differs')
        for item in manifest['paths']:
            rel=item['path']
            if rel=='migration/upstreams.lock.json':continue
            source=p13/'staging'/rel;require(sha(source)==item['source_sha256'],'P13 source changed');p13_files[rel]=source.read_bytes()
        require(len(p13_files)==5,'P13 file scope differs')
        p13_info={'manifest_sha256':sha(p13/'manifest.json'),'root_fixture_review_sha256':sha(p13/'root-review.json'),
            'actual_fixture_methods':18,'scope':'Exact retained original audit checkout only; portable/public export remains open.'}
    pack_path=R/'build/native-audit-bundle-20261028/runs/pack-r1/result.json'
    restore_path=R/'build/native-audit-bundle-20261028/runs/restore-r1/result.json'
    packed,restored=load(pack_path),load(restore_path)
    require(packed['status']=='ACTUAL_COMPLETE_INCREMENTAL_AUDIT_BUNDLE_CREATED'
        and restored['status']=='ACTUAL_LOCAL_INCREMENTAL_AUDIT_RESTORATION_VERIFIED'
        and restored['pack_receipt_sha256']==sha(pack_path) and restored['bundle']==packed['bundle']
        and restored['restored_inventory']==packed['inventory'],'Local audit receipts differ')
    require(packed['original_head_index_refs_worktree_preserved'] is True
        and restored['original_head_index_refs_worktree_preserved'] is True
        and restored['depth1_prerequisite_only'] is True,'Local audit preservation proof differs')
    inventory=restored['restored_inventory']
    require(inventory['audit_commits']==177 and len(inventory['declared_legacy_commits'])==48 and inventory['object_count']==21982,'Local audit scope differs')
    audit_reference={'pack_receipt_sha256':sha(pack_path),'restore_receipt_sha256':sha(restore_path),
        'archive_sha256':packed['bundle']['sha256'],'archive_bytes':packed['bundle']['bytes'],
        'scope':'Actual local incremental pack/depth1 restoration only; no public attachment/bootstrap/resolver-store integration claim.'}
    keep(pack_path,'audit-bundle/pack-receipt.json');keep(restore_path,'audit-bundle/restore-receipt.json')
    keep(R/'migration/ACTIVE.md','history/ACTIVE-before-publication.md')
    keep(R/'migration/STATE.md','history/STATE-before-publication.md')
    verification={'status':'VERIFIED_SCOPED_ACTUAL_NETWORK_SERVICE_COHORT','qualified_source':SOURCE,
        'source_commits':['3b18849f06a6287c4da7d97c067480156c6ef796','5809ac611bb5d49b8de1c5eab0c7dca3ef8cbe9a',
            '9d3058b8e3fd073a5c9102a17ce6104daa23c534',HISTORICAL,SOURCE],
        'matrix':matrix,'original_single_tracker':{'source_commit':HISTORICAL,'projection_source_unchanged':True,'current_image_executed':False,'actual_cases':16,'scalar_comparisons':80,'receipt_sha256':sha(original_path),
            'scope':'Actual original getters with explicit thin wrapper predicate; no tracker wire parser/full permission equality'},
        'diversification_reference':{'observations':63,'receipt_sha256':sha(div),'scope':d['scope'],'rerun':False},
        'private_runtime':{'actual_programs':4,'receipt_sha256':sha(private_path),'provider_sha256':private['provider']['artifact_sha256']},
        'private_development_promotion':{'receipt_sha256':sha(promotion_path),'manifest_sha256':promotion['new_manifest_sha256'],
            'rollback_manifest_sha256':promotion['previous_manifest_sha256'],'leaves':118,'shipping_approved':False,
            'previous_manifest_retained_as_evidence':True,'permanent_previous_tree_required':False},
        'original_head':frozen['original_head'],'original_index_sha256':frozen['original_index_sha256'],
        'component_count_preserved':105,'external_dependency_count_preserved':19,'cf_parents_closed':[],
        'public_network_qualified':False,'whole_phase_complete':False,'shipping_approved':False,
        'historical_closeout_sha256':support.PLAN['closeout']['sha256'],
        'matrix_scope':'Fresh4/3/4 at013 plus historical20/16/20 exact b0 origins; no all-current full-cohort claim.',
        'retained_local_history':history,'excluded_future':['numeric never-admitted UDP producer0f4f','dual-family27/Host identity','ancestor watcher11e0','original-root writer'],
        'local_audit_bundle_reference':audit_reference,
        'retained_audit_resolver_requested':args.include_retained_audit_resolver,'retained_audit_resolver':p13_info,
        'registry_validation_after_adoption_required':True,'publication_commit':None}
    if not args.write:
        print('CHECK_ONLY_PASS',SOURCE,COUNTS);return
    out=H/'runs'/args.attempt;out.mkdir(parents=True,exist_ok=False)
    # Archive summaries and public source/proof metadata. Never copy DSOs, raw traces, process homes or payloads.
    members['proof-inputs.json']=dump(inputs);members['native-source-sha256.json']=dump(snapshot['files_sha256'])
    archive=out/'retained-evidence.tar.gz';index=[]
    with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
        for name,data in sorted(members.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
            index.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    verification['raw_archive_sha256']=sha(archive)
    (out/'archive-index.json').write_bytes(dump(index))
    updated=copy.deepcopy(lock)
    for item in proposal['components']:
        row=next(x for x in updated['components'] if x['id']==item['id'])
        for commit in item['native_commits']:
            entry={'repository':'https://github.com/d00rsfan/BiglyBTC.git','commit':commit,'purpose':'integration'}
            if entry not in row['native_commits']:row['native_commits'].append(entry)
        for key,value in [('review_records',REVIEW),('evidence',EVIDENCE+'/verification.json')]:
            if value not in row[key]:row[key].append(value)
    for old,new in zip(lock['components'],updated['components']):
        for key in old:
            if key not in ('native_commits','review_records','evidence'):require(old[key]==new[key],'Changed component baseline/state')
    require(lock['external_dependencies']==updated['external_dependencies'] and lock['upstreams']==updated['upstreams'],'Changed inputs/dependencies')
    if args.include_retained_audit_resolver:
        biglybt=[row for row in updated['upstreams'] if row['id']=='BiglyBT'];require(len(biglybt)==1 and biglybt[0]['checkout_hint']=='.','Unexpected BiglyBT hint')
        biglybt[0]['checkout_hint']='../BiglyBT'
        probe=copy.deepcopy(updated['upstreams']);next(x for x in probe if x['id']=='BiglyBT')['checkout_hint']='.'
        require(probe==lock['upstreams'],'P13 changed an upstream baseline')
    checkpoint={'SOURCE':SOURCE,'EVIDENCE':EVIDENCE,'SOURCE_RECEIPT_SHA':sha(W/'source-runtime-fixes-r5.json'),
        'CLOSEOUT_SHA':support.PLAN['closeout']['sha256'],'PRIVATE_SHA':sha(private_path),'PROMOTION_SHA':sha(promotion_path),
        'CURRENT_MANIFEST_SHA':promotion['new_manifest_sha256'],'PREVIOUS_MANIFEST_SHA':promotion['previous_manifest_sha256'],
        'ORIGINAL_HEAD':frozen['original_head'],'ORIGINAL_INDEX':frozen['original_index_sha256'],
        'AUDIT_PACK_SHA':audit_reference['pack_receipt_sha256'],'AUDIT_RESTORE_SHA':audit_reference['restore_receipt_sha256'],
        'AUDIT_ARCHIVE_SHA':audit_reference['archive_sha256'],'AUDIT_ARCHIVE_BYTES':audit_reference['archive_bytes'],
        'P13_SCOPE':('This publication includes the reviewed retained-checkout resolver; root records actual registry validation after adoption.'
            if args.include_retained_audit_resolver else 'Resolver4974 remains separately staged; this publication does not adopt it.')}
    active=render_checkpoint('ACTIVE.template.txt',checkpoint)
    state=render_checkpoint('STATE.template.txt',checkpoint)
    for path,data in [('migration/upstreams.lock.json',dump(updated)),('migration/ACTIVE.md',active.encode()),('migration/STATE.md',state.encode()),
        ('MIGRATION_PLAN.md',(R/'MIGRATION_PLAN.md').read_bytes()),
        ('migration/history/plan-status-prefix-through-20261028.md',(R/'migration/history/plan-status-prefix-through-20261028.md').read_bytes()),
        (REVIEW,(H/'REVIEW.template.md').read_bytes())]:
        target=out/'metadata-staging'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    for path,data in p13_files.items():
        target=out/'metadata-staging'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    (out/'verification.json').write_bytes(dump(verification))
    staged={str(path.relative_to(out/'metadata-staging')):{'source_sha256':sha(path),
        'original_before_sha256':sha(R/path.relative_to(out/'metadata-staging')) if (R/path.relative_to(out/'metadata-staging')).is_file() else None,
        'native_before_sha256':sha(N/path.relative_to(out/'metadata-staging')) if (N/path.relative_to(out/'metadata-staging')).is_file() else None}
        for path in (out/'metadata-staging').rglob('*') if path.is_file()}
    (out/'metadata-staging-manifest.json').write_bytes(dump({'qualified_source':SOURCE,'cpp_requalification_claim':False,'files':staged}))
    (out/'component-coverage.json').write_bytes(dump(proposal))
    require(git(R,'rev-parse','HEAD').decode().strip()==frozen['original_head'] and sha(R/'.git/index')==frozen['original_index_sha256'],'Original HEAD/index changed during collection')
    require(support.source_snapshot(SOURCE)==snapshot,'Qualified source changed during collection')
    print('W_ONLY_STAGED',out,'ROOT_ADOPTION_REQUIRED')

if __name__=='__main__':main()
