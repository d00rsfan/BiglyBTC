"""Root-run cohort helpers; importing performs no qualification or writes."""
from pathlib import Path
import hashlib, json, os, re, subprocess, time, xml.etree.ElementTree as ET
R=Path('/home/yurii/Java/BiglyBT'); N=R.parent/'BiglyBTC'; W=Path(__file__).resolve().parent
PORT=R/'build/mainline-port-20261028'; P=PORT/'provider-candidate'
BINDING=N/'preview/native/engine/runtime-binding/provider-mainline-runtime.json'
BINDING_SHA='1267bf58a235dc6c32d9ffadab8bbd994ec81f2aa958f0cf621f8a71e4f6c84c'
PROVIDER_SHA='9fbb550bbc1f877ce34ce21849deab97971f5d3eacfbc531a7b777d28a3b2eea'
OLD_DIST_SHA='0508794edb9c2e80582068ffa9e4ebe0d0058732d91dce1fe016ad451a54ea1f'
CACHES={'gcc':N/'build/persistent-peer-accounting-20261021/bound-gcc', 'clang':N/'build/saved-services-20261018/clang', 'san':N/'build/saved-services-20261018/sanitized-desktop'}
CORE={'mainline-dht':'biglybtc-mainline-dht-tests', 'mainline-scrape-codec':'biglybtc-mainline-scrape-tests', 'azureus-database-runtime':'biglybtc-azureus-database-runtime-tests', 'azureus-storage-stats':'biglybtc-azureus-storage-stats-tests'}
GCC={**CORE,'library-action-ui':'biglybtc-library-action-ui-tests','managed-queue':'biglybtc-managed-queue-tests','managed-library-command-routing':'biglybtc-library-commands-bridge-tests','persistent-native-peer-session':'biglybtc-persistent-session-tests','mainline-checkpoint':'biglybtc-mainline-checkpoint-tests','magnet-host':'biglybtc-magnet-host-tests', **{x:'biglybtc-'+x+'-tests' for x in ('azureus-owned-service','azureus-owned-bridge','azureus-router-owner','azureus-router-binding','owned-ddb-control','owned-ddb-binding','owned-dht-bytes','owned-dht-accounting')}}
GCC['mainline-queued-owner']='biglybtc-mainline-queued-owner-tests'
PRODUCTS={'BiglyBTC':'app/BiglyBTC','BiglyBTC-headless':'app/BiglyBTC-headless','biglybtc-preview-smoke':'biglybtc-preview-smoke'}
ALIASES=[prefix+'/'+name for prefix in ('usr/lib/biglybtc/lib','dependencies/libtorrent/usr/lib/x86_64-linux-gnu') for name in ('libtorrent-rasterbar.so','libtorrent-rasterbar.so.2.0','libtorrent-rasterbar.so.2.0.12')]
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
 return h.hexdigest()
def write(path,value): Path(path).write_text(json.dumps(value,indent=2)+'\n')
def load(path): return json.loads(Path(path).read_bytes())
def environment(lane=None):
 e=os.environ.copy()
 for k in ('LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH','LD_DEBUG'): e.pop(k,None)
 e.update(QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1')
 if lane=='san': e.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
 return e
def source_snapshot(expected):
 def git(*args): return subprocess.check_output(['git','-C',str(N),*args]).decode().strip()
 assert re.fullmatch('[0-9a-f]{40}',expected) and git('rev-parse','HEAD')==expected,'Source HEAD differs'
 assert not git('status','--porcelain','--untracked-files=no'),'Tracked native tree is dirty'
 names=subprocess.check_output(['git','-C',str(N),'ls-files','-z','preview/native','preview/migration/tools']).decode().split('\0')
 return {'source_commit':expected,'native_tree':git('rev-parse','HEAD:preview/native'),'files_sha256':{x:sha(N/x) for x in names if x and (N/x).is_file()}}
def provider():
 assert sha(BINDING)==BINDING_SHA,'Provider binding changed'
 d=load(BINDING); artifact=Path(d['artifact']); record=BINDING.parent/d['source_build_record']
 assert sha(artifact)==PROVIDER_SHA and artifact.stat().st_size==9153448
 assert sha(record)==d['source_build_record_sha256']=='c848411975cecc955370cf0a95790fd4659a52714b8f57ce9c82fa7e9fbf54d3'
 return {'binding':str(BINDING),'binding_sha256':BINDING_SHA,'artifact':str(artifact),'artifact_sha256':PROVIDER_SHA,'record':str(record),'record_sha256':sha(record),'rebuilt':False}
def images(paths): return {k:{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for k,p in paths.items()}
def passed_xml(path,expected=None):
 cases=list(ET.fromstring(Path(path).read_bytes()).iter('testcase'))
 assert cases and not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped')),'Failed/empty/skipped XML'
 names=[c.get('name') for c in cases]
 if expected is not None: assert len(names)==len(expected) and set(names)==set(expected),'Actual suite inventory differs'
 return names
class Runner:
 def __init__(self,out,env): self.out=out;self.env=env;self.rows=[]
 def run(self,name,cmd,expected=0,timeout=1800):
  args=list(map(str,cmd)); start=time.monotonic(); row={'name':name,'command':args,'expected_exit':expected}; log=self.out/(name+'.log')
  try:
   with log.open('wb') as f: p=subprocess.run(args,env=self.env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
   row['exit']=p.returncode
  except BaseException as e: row['exception']=repr(e); raise
  finally:
   row['seconds']=round(time.monotonic()-start,3);row['log']=str(log)
   if log.exists(): row['log_sha256']=sha(log)
   self.rows.append(row);write(self.out/'commands.json',self.rows)
  print(name,p.returncode,flush=True);assert p.returncode==expected,name
  return log

def verify_native(path,lane,source,live=False):
 d=load(path);assert d['status']=='PASS' and d['lane']==lane and d['source_commit']==source
 suites=GCC if lane=='gcc' else CORE
 assert d['suite_names']==list(suites) and d['provider']['binding_sha256']==BINDING_SHA
 assert d['provider']['artifact_sha256']==PROVIDER_SHA
 assert sha(d['tests_xml'])==d['tests_xml_sha256'];passed_xml(d['tests_xml'],suites)
 assert d['images_before']==d['images_after']
 if live:
  for item in d['images_after'].values(): assert sha(item['path'])==item['sha256'],'Qualified binary changed'
 return d

def verify_bundle(root):
 d=load(root/'BUILD_MANIFEST.json')
 assert d['distribution_scope']=='private-qualification-only'
 for rel,pin in d['files_sha256'].items():
  p=root/rel; assert not Path(rel).is_absolute() and p.resolve().is_relative_to(root.resolve())
  assert sha(p)==pin,rel
 runtime=d['libtorrent_runtime'];assert runtime['artifact_sha256']==PROVIDER_SHA and runtime['runtime_manifest_sha256']==BINDING_SHA
 assert runtime['aliases']==ALIASES
 for rel in ALIASES: assert sha(root/rel)==PROVIDER_SHA,rel
 return d
