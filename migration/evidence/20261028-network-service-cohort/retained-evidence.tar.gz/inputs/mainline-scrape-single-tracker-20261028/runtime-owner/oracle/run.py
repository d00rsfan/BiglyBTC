#!/usr/bin/env python3
"""Root-run original accessor projection only. Builds no native/original code."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,sys,tempfile
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent
N=Path('/home/yurii/Java/BiglyBTC')
C=Path('/tmp/biglybtc-oracle/classes')
RET=N/'build/dependencies/java-oracle-17-20261021/retention.json'
JAVA=Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def inventory(root):
 out={}
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():out[p.relative_to(root).as_posix()]=sha(p)
 return out
def git(*args):return subprocess.check_output(['git','-C',str(N),*args],text=True).strip()
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--driver',type=Path,required=True)
 p.add_argument('--source-commit',required=True)
 p.add_argument('--build-receipt',type=Path,required=True,help='Actual compile_v4-compatible successful receipt, never an expected result')
 p.add_argument('--build-source-map',type=Path,required=True)
 p.add_argument('--attempt',required=True)
 a=p.parse_args();assert re.fullmatch('run-[A-Za-z0-9_-]+',a.attempt)
 m=load(H/'manifest.json')
 for rel,digest in m['artifacts_sha256'].items():assert sha(H/rel)==digest,rel
 assert sha(RET)==m['retention_sha256']
 retained=load(RET);assert retained['source_commit']==m['original_commit'] and retained['recompiled'] is False
 assert inventory(C)==retained['file_sha256']
 # The producer must be a real current matching-source root build. No driver
 # source is compiled here and an arbitrary executable is not associated by name.
 assert git('rev-parse','HEAD')==a.source_commit
 assert not git('status','--porcelain','--untracked-files=no','--','preview/native')
 assert not git('ls-files','--others','--exclude-standard','--','preview/native')
 files=git('ls-files','--','preview/native').splitlines();current={rel:sha(N/rel) for rel in files}
 build=load(a.build_receipt);built=load(a.build_source_map)
 assert build['exit']==0 and build['source_manifest_sha256']==sha(a.build_source_map)
 assert built==current,'Actual passed build source map is not current native graph'
 for rel,digest in m['native_sources_sha256'].items():assert current[rel]==digest,rel
 command=build['command'];assert '--build' in command and '--target' in command and 'biglybtc-queue-facts-replay' in command
 builddir=Path(command[command.index('--build')+1]).resolve()
 driver=a.driver.resolve();assert driver==(builddir/'tests/biglybtc-queue-facts-replay').resolve() and driver.is_file()
 before=sha(driver);dest=H/'runs'/a.attempt;dest.parent.mkdir(exist_ok=True);assert not dest.exists()
 work=Path(tempfile.mkdtemp(prefix='biglybtc-queue-oracle-',dir='/tmp'))
 for part in ('classes','empty-sourcepath','tmp'):(work/part).mkdir()
 environment={k:v for k,v in os.environ.items() if k not in ('CLASSPATH','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','LD_PRELOAD','LD_AUDIT')}
 commands=[];result={'status':'FAIL','original_commit':m['original_commit'],'source_commit':a.source_commit,'manifest_sha256':sha(H/'manifest.json'),'native_driver_sha256':before,'build_receipt_sha256':sha(a.build_receipt),'build_source_map_sha256':sha(a.build_source_map),'original_recompiled':False,'wrapper_predicate_is_explicit_thin_adapter':True,'original_tracker_wire_parser_executed':False,'configured_tracker_permission_qualified':False}
 def run(name,argv,tape=False):
  row={'name':name,'argv':[str(v) for v in argv]};commands.append(row);write(work/'commands.json',commands)
  with (work/(name+'.stdout')).open('w') as out,(work/(name+'.stderr')).open('w') as err:
   stream=(H/'vectors.tsv').open('rb') if tape else subprocess.DEVNULL
   try:
    child=subprocess.Popen(row['argv'],cwd=work,env=environment,stdin=stream,stdout=out,stderr=err)
    try:code=child.wait(timeout=40)
    except subprocess.TimeoutExpired:child.kill();child.wait();raise
    row['exit_code']=code;write(work/'commands.json',commands);assert code==0,name
   finally:
    if tape:stream.close()
 try:
  sources=sorted((H/'source').glob('*.java'));assert [s.name for s in sources]==m['java_sources']
  run('javac-owned-helpers',[JAVA/'javac','-J-XX:ActiveProcessorCount=2','--release','8','-encoding','UTF-8','-proc:none','-implicit:none','-sourcepath',work/'empty-sourcepath','-cp',C,'-d',work/'classes',*sources])
  allow={s.stem for s in sources}
  for path in (work/'classes').rglob('*.class'):assert path.relative_to(work/'classes').as_posix().split('$')[0].removesuffix('.class') in allow,path
  run('original',[JAVA/'java','-XX:ActiveProcessorCount=2','-Xmx128m','-Djava.security.manager=allow','-Dqueue.oracle.root='+str(work),'-Dqueue.oracle.cohort='+str(C),'-Djava.io.tmpdir='+str(work/'tmp'),'-Duser.home='+str(work/'forbidden-home'),'-Dazureus.config.path='+str(work/'forbidden-profile'),'-cp',work/'classes','SingleTrackerLauncher',work/'classes',C],True)
  run('native',[driver],True)
  expected={(row['id'],field) for row in m['cases'] for field in ('responseType','seeds','peers','start','eligible')}
  def observations(name,marker):
   values={}
   for line in (work/(name+'.stdout')).read_text().splitlines():
    if line.startswith('OBS\t'):
     fields=line.split('\t');assert len(fields)==4 and (fields[1],fields[2]) not in values;values[fields[1],fields[2]]=int(fields[3])
    else:assert line==marker+'\t'+str(len(m['cases'])),line
   assert set(values)==expected,name;return values
  original=observations('original','PASS_SINGLE_TRACKER_ORIGINAL');native=observations('native','PASS_QUEUE_FACTS_NATIVE')
  mismatch=[{'case':k[0],'field':k[1],'original':original[k],'native':native[k]} for k in sorted(expected) if original[k]!=native[k]]
  result.update(status='FAIL' if mismatch else 'PASS_ACTUAL_ORIGINAL_SINGLE_TRACKER_RESPONSE_PROJECTION',actual_cases=len(m['cases']),scalar_comparisons=len(expected),mismatches=mismatch)
  assert not mismatch,'Actual differences retained in result.json'
 finally:
  result['commands']=commands
  result['cohort_unchanged']=inventory(C)==retained['file_sha256']
  result['driver_unchanged']=sha(driver)==before
  write(work/'result.json',result);shutil.copytree(work,dest)
  print(str(dest),flush=True)
  assert result['cohort_unchanged'] and result['driver_unchanged']
 print(result['status'],result['actual_cases'],result['scalar_comparisons'])
if __name__=='__main__':main()
