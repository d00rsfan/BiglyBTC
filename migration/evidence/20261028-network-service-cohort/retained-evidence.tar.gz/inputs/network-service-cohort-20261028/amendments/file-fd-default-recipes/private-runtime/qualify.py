#!/usr/bin/env python3
"""Root-run private relocation; no compiler, provider rebuild or published writes."""
import argparse
import shutil
import tempfile
from support import *

def main():
    p=argparse.ArgumentParser(description=__doc__); add_inputs(p)
    p.add_argument('--attempt',required=True); a=p.parse_args()
    assert re.fullmatch('[A-Za-z0-9_-]+',a.attempt)
    initial, qualified=verify_all(a); prov=provider(); verify_bundle(N/'dist',old=True)
    out=HERE/'runs'/a.attempt; out.mkdir(parents=True,exist_ok=False)
    candidate=out/'candidate'; env=environment('gcc'); runner=Runner(out,env)
    result={'status':'FAILED','source_commit':a.source_commit,'shipping_approved':False}
    try:
        write(out/'source-before.json',initial)
        runner.run('stage',['python3',N/'preview/migration/tools/stage_preview.py','--build',CACHES['gcc'],
            '--output',candidate,'--libtorrent-package',N/'build/dependencies/packages/libtorrent-rasterbar2.0t64_2.0.12-1_amd64.deb',
            '--source-libtorrent',prov['artifact'],'--private-original-identity-provider-manifest',BINDING])
        bundle=verify_bundle(candidate); manifest_pin=sha(candidate/'BUILD_MANIFEST.json')
        private=candidate/'usr/lib/biglybtc'; provider_path=private/'lib/libtorrent-rasterbar.so.2.0.12'
        support=out/'test-support'; support.mkdir()
        qt_test=Path('/opt/Qt/6.12.0/gcc_64/lib/libQt6Test.so.6').resolve()
        shutil.copyfile(qt_test,support/'libQt6Test.so.6'); assert sha(qt_test)==sha(support/'libQt6Test.so.6')
        write(out/'test-support.json',{'source':str(qt_test),'sha256':sha(qt_test),'distribution_member':False})
        env.update(LD_LIBRARY_PATH=os.pathsep.join(map(str,[support,private/'lib',private/'qt/lib',
            candidate/'dependencies/libtorrent/usr/lib/x86_64-linux-gnu'])),QT_PLUGIN_PATH=str(private/'qt/plugins'),
            QT_QPA_PLATFORM_PLUGIN_PATH=str(private/'qt/plugins/platforms'))
        bins=out/'owner-tests'; bins.mkdir(); gcc=load(a.gcc_result); images={}; loaders={}
        for name in NAMES:
            image=gcc['images_after'][name]; src=Path(image['path']); target=bins/name
            assert sha(src)==image['sha256']; shutil.copyfile(src,target); target.chmod(0o755)
            assert sha(target)==image['sha256']
            images[name]={'source':str(src),'copy':str(target),'sha256':sha(target)}
            linked=runner.run(name+'-ldd',['ldd',target]).read_text()
            assert 'not found' not in linked and '/opt/Qt' not in linked
            loaded={lib:str(Path(path).resolve()) for lib,path in re.findall(
                r'^\s*(lib(?:Qt6[^ ]*|torrent-rasterbar[^ ]*)) => (/.*?) \(',linked,re.M)}
            assert 'libQt6Core.so.6' in loaded
            for lib,path in loaded.items():
                assert Path(path).is_relative_to(candidate.resolve()) or Path(path)==(support/'libQt6Test.so.6').resolve()
                if lib.startswith('libtorrent-rasterbar'): assert sha(path)==PROVIDER_SHA
            if POLICY['private_programs'][name]['requires_provider']:
                assert any(lib.startswith('libtorrent-rasterbar') for lib in loaded)
            loaders[name]=loaded; runner.run(name+'-elf',['readelf','-d',target])
        write(out/'test-images.json',images); write(out/'private-loaders.json',loaders)
        elf_paths=[]
        for path in sorted(candidate.rglob('*')):
            if path.is_file():
                with path.open('rb') as f: magic=f.read(4)
                if magic==b'\x7fELF': elf_paths.append(path)
        for i,path in enumerate(elf_paths):
            dynamic=runner.run('packaged-elf-'+str(i),['readelf','-d',path]).read_text()
            for tag in re.findall(r'\((?:RPATH|RUNPATH)\).*?\[(.*?)\]',dynamic):
                assert all(not part or part.startswith('$ORIGIN') for part in tag.split(':')),str(path)
        write(out/'packaged-elf.json',[str(x.relative_to(candidate)) for x in elf_paths])
        sample=Path(tempfile.mkdtemp(prefix='biglybtc-preview-',dir='/tmp')); sample.rmdir()
        runner.run('prepare-owned-profile',[candidate/'BiglyBTC-preview','--prepare',sample])
        for key in ('XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR'):
            path=sample/key.lower(); path.mkdir(mode=0o700); env[key]=str(path)
        env.update(BIGLYBTC_PREVIEW_PROFILE=str(sample/'profile'),BIGLYBTC_PREVIEW_CAPTURE=str(sample/'classic-preview.png'),LD_DEBUG='libs')
        runner.run('normal-launcher-usage',[candidate/'BiglyBTC'],expected=2,timeout=30)
        runner.run('offline-preview-owned-stop',['timeout','--signal=TERM','--kill-after=5s','8s',candidate/'BiglyBTC-preview'],expected=124,timeout=20)
        initialized={}
        for name in ('normal-launcher-usage','offline-preview-owned-stop'):
            text=(out/(name+'.log')).read_text(errors='replace')
            paths=[Path(x.strip()).resolve() for x in re.findall(r'calling init:\s*([^\n]+)',text)]
            assert provider_path.resolve() in paths and (private/'qt/lib/libQt6Core.so.6').resolve() in paths
            if name=='offline-preview-owned-stop': assert (private/'qt/plugins/platforms/libqoffscreen.so').resolve() in paths
            initialized[name]=[str(x) for x in paths if x.is_relative_to(candidate.resolve())]
        write(out/'actual-loader-init.json',initialized); env.pop('LD_DEBUG')
        actual=[]
        for name in NAMES:
            runner.run(name,[bins/name,'-o',str(out/(name+'.txt'))+',txt','-o',str(out/(name+'.xml'))+',junitxml'],
                timeout=POLICY['private_programs'][name]['timeout'])
            names=xml(out/(name+'.xml'))
            actual.append({'binary':name,'sha256':images[name]['sha256'],'exit':0,'mode':'QtTest-default',
                'testcase_names':names,'xml_sha256':sha(out/(name+'.xml'))})
        for name in NAMES: assert sha(bins/name)==images[name]['sha256']
        assert sha(candidate/'BUILD_MANIFEST.json')==manifest_pin; verify_bundle(candidate); verify_bundle(N/'dist',old=True)
        assert verify_all(a)==(initial,qualified) and provider()==prov
        result.update(status='PASS_PRIVATE_RELOCATED_RUNTIME',candidate=str(candidate),manifest_sha256=manifest_pin,
            verified_leaves=len(bundle['files_sha256']),provider=prov,qualified_results=qualified,
            source_adoption_sha256=sha(a.source_receipt),source_amendment=source_authority.verify(a.source_commit),test_images=images,actual_tests=actual,aliases=ALIASES,
            loader_init_verified=True,sample=str(sample),distribution_scope='private-qualification-only',
            published_dist_unchanged=OLD_DIST_SHA,source_snapshot_sha256=sha(out/'source-before.json'),
            repeated_mainline_full_or_active_owner=False,real_tor_rerun=False,provider_rebuilt=False)
    except BaseException as e: result['failure']=repr(e); raise
    finally:
        if (out/'commands.json').exists(): result['commands_sha256']=sha(out/'commands.json')
        write(out/'result.json',result)
    print('PRIVATE_RUNTIME_PASS',len(result['actual_tests']),'actual programs',flush=True)

if __name__=='__main__': main()
