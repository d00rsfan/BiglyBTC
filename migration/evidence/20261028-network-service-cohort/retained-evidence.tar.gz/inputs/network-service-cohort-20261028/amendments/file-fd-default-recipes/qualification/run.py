#!/usr/bin/env python3
"""Root-selected coherent native cohort; logs are files, no provider build."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,re
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';H=Path(__file__).resolve().parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(H.parent));import source_authority
OLD=R/'build/mainline-scrape-20261028';assert hashlib.sha256((OLD/'recipe_support_followup.py').read_bytes()).hexdigest()=='64e0bd2b9ec87b9babf90bdf8d1235746f7dc63c797c82c5e5a138a4c2ea893a'
sys.dont_write_bytecode=True;sys.path.insert(0,str(OLD));import recipe_support_followup as h
def git(path,*args):return subprocess.check_output(['git','-C',str(path),*args],text=True).strip()
def settings(cache):
 return {line.split(':',1)[0]:line.split('=',1)[1] for line in (cache/'CMakeCache.txt').read_text().splitlines() if line and not line.startswith(('#','//')) and ':' in line.split('=',1)[0] and '=' in line}
def dependencies(plan):
 result={}
 for name,d in plan['dependencies'].items():
  root=Path(d['path']);assert git(root,'rev-parse','HEAD')==d['commit'];assert not git(root,'status','--porcelain','--untracked-files=no')
  actual={rel:h.sha(root/rel) for rel in git(root,'ls-files').splitlines()};assert actual==d['files_sha256'];result[name]={'path':str(root),'commit':d['commit'],'files_sha256':actual}
 return result
def provider(plan):
 p=plan['provider'];manifest=Path(p['manifest']);m=h.load(manifest);record=manifest.parent/m['source_build_record'];review=Path(p['review'])
 assert h.sha(manifest)==p['manifest_sha256'];assert h.sha(record)==p['record_sha256']==m['source_build_record_sha256'];assert h.sha(review)==p['review_sha256']
 assert h.sha(Path(m['artifact']))==m['artifact_sha256']==p['artifact_sha256'];assert Path(m['artifact']).stat().st_size==m['artifact_bytes']
 assert h.load(review)['status']=='PASS_ROOT_EXACT_SOURCE_ARTIFACT_REVIEW'
 return {'binding':str(manifest),'binding_sha256':h.sha(manifest),'artifact':m['artifact'],'artifact_sha256':m['artifact_sha256'],'record':str(record),'record_sha256':h.sha(record),'review':str(review),'review_sha256':h.sha(review),'rebuilt':False}
def main():
 p=argparse.ArgumentParser();p.add_argument('lane',choices=('gcc','clang','san'));p.add_argument('--source-commit',required=True);p.add_argument('--jobs',required=True,type=int,choices=(1,2,3));p.add_argument('--attempt',default='r1');a=p.parse_args();assert re.fullmatch('[A-Za-z0-9_-]+',a.attempt)
 association=source_authority.verify(a.source_commit);plan=h.load(H/'plan.json');assert plan['status']=='FROZEN_ROOT_SELECTED_QUALIFICATION_PLAN';assert not git(N,'ls-files','--others','--exclude-standard','--','preview/native','preview/migration/tools');rule=plan['lanes'][a.lane];cache=h.CACHES[a.lane];initial=h.source_snapshot(a.source_commit);dep=dependencies(plan);prov=provider(plan)
 out=H/'runs'/(a.lane+'-'+a.attempt);out.mkdir(parents=True,exist_ok=False);env=h.environment(a.lane);env.pop('LSAN_OPTIONS',None);(out/'captures').mkdir();env['BIGLYBTC_CAPTURE_DIR']=str(out/'captures');runner=h.Runner(out,env)
 result={'status':'FAIL','source_amendment':association,'qualification_recipe_sha256':h.sha(Path(__file__)),'lane':a.lane,'source_commit':a.source_commit,'plan_sha256':h.sha(H/'plan.json'),'provider':prov,'actual_suites':0,'provider_rebuilt':False}
 try:
  h.write(out/'source-before.json',initial);h.write(out/'source-map.json',{k:v for k,v in initial['files_sha256'].items() if k.startswith('preview/native/')});h.write(out/'dependencies-before.json',dep)
  old=settings(cache);compiler=Path(old['CMAKE_CXX_COMPILER']);assert compiler.name=={'gcc':'g++-16','clang':'clang++-24','san':'g++-16'}[a.lane]
  if a.lane=='san':assert '-fsanitize=address,undefined' in old['CMAKE_CXX_FLAGS'] and '-fno-sanitize-recover=all' in old['CMAKE_CXX_FLAGS'] and '-fsanitize=address,undefined' in old['CMAKE_EXE_LINKER_FLAGS'] and 'detect_leaks=1' in env['ASAN_OPTIONS']
  runner.run('compiler',[compiler,'--version']);h.write(out/'compiler.json',{'path':str(compiler),'resolved':str(compiler.resolve()),'sha256':h.sha(compiler.resolve())})
  m=h.load(Path(prov['binding']));runner.run('configure',['cmake','-S',N/'preview/native','-B',cache,'-DLibtorrentRasterbar_DIR='+str(Path(m['install_root'])/'lib/cmake/LibtorrentRasterbar'),'-DBIGLYBTC_PERSISTENT_RUNTIME_MANIFEST='+prov['binding'],'-DBIGLYBTC_ORIGINAL_MLDHT_IDENTITY_READER=ON','-DBIGLYBTC_MLDHT_IDENTITY_SOURCE_DIR='+plan['dependencies']['mldht']['path'],'-DBIGLYBTC_TOR_CONTROL=ON','-DBIGLYBTC_TOR_AUTH_SOURCE_DIR='+plan['dependencies']['aznettor']['path']])
  now=settings(cache);assert now['CMAKE_CXX_COMPILER']==old['CMAKE_CXX_COMPILER'] and now['CMAKE_CXX_FLAGS']==old['CMAKE_CXX_FLAGS'] and now['CMAKE_EXE_LINKER_FLAGS']==old['CMAKE_EXE_LINKER_FLAGS']
  assert now['BIGLYBTC_ORIGINAL_MLDHT_IDENTITY_READER']=='ON' and now['BIGLYBTC_TOR_CONTROL']=='ON'
  targets=list(dict.fromkeys([plan['suites'][x]['target'] for x in rule['compile_suites'] if plan['suites'][x].get('target')]+rule['extra_targets']))
  h.write(out/'selected-plan.json',{'actually_execute':rule['execute_suites'],'compile_suites':rule['compile_suites'],'targets':targets,'jobs':a.jobs})
  runner.run('build',['nice','-n','5','cmake','--build',cache,'--parallel',a.jobs,'--target',*targets],timeout=7200)
  build=next(x for x in runner.rows if x['name']=='build');h.write(out/'build-receipt.json',{**build,'source_manifest_sha256':h.sha(out/'source-map.json')})
  inventory=h.load(runner.run('inventory',['ctest','--test-dir',cache,'--show-only=json-v1']));registered={x['name']:x for x in inventory['tests']};images={}
  for name in rule['compile_suites']:
   spec=plan['suites'][name];test=registered[name];binary=(cache/spec['binary']).resolve() if spec.get('binary') else None
   if spec.get('command_kind')=='python_fixture':
    assert len(test['command'])==3 and Path(test['command'][1]).resolve()==Path(plan['dependencies']['aznettor']['path'])/'fixture_test.py' and Path(test['command'][2]).resolve()==binary
   elif spec.get('command_kind')=='python_source':
    assert test['command'][1:]==['-B',str(N/spec['script'])]
   elif spec.get('command_kind')=='python_driver':
    assert test['command'][1:3]==['-B',str(N/spec['script'])] and Path(test['command'][test['command'].index('--driver')+1]).resolve()==binary
   elif spec.get('command_kind')=='cmake_env':
    assert test['command'][1:3]==['-E','env'] and Path(test['command'][-2]).resolve()==binary and test['command'][-1]==spec['control']
   else:assert Path(test['command'][0]).resolve()==binary
   props={x['name']:x['value'] for x in test['properties']};assert props['TIMEOUT']==spec['timeout'];
   if binary is not None:images[spec['target']]=binary
  for target,relative in plan['products'].items():
   if target in rule['extra_targets']:images[target]=cache/relative
  before=h.images(images);h.write(out/'binary-before-tests.json',before)
  selected=rule['execute_suites'];assert set(selected)<=set(rule['compile_suites']);assert all(re.fullmatch('[a-z0-9-]+',s) for s in selected)
  runner.run('tests',['ctest','--test-dir',cache,'--parallel','1','-R','^('+'|'.join(selected)+')$','--output-on-failure','--output-junit',out/'tests.xml'],timeout=2400);actual=h.passed_xml(out/'tests.xml',selected);assert all(c.get('status') not in ('notrun','disabled') for c in h.ET.fromstring((out/'tests.xml').read_bytes()).iter('testcase'))
  real=None
  if rule.get('real_offline_tor'):
   name='biglybtc-tor-owned-child-tests';binary=images[name];recipe=Path(plan['real_tor']['recipe']);assert h.sha(recipe)==plan['real_tor']['recipe_sha256']
   cmd=['python3',str(recipe),'--binary',str(binary),'--binary-sha256',before[name]['sha256'],'--source-commit',a.source_commit,'--build-receipt',str(out/'build-receipt.json'),'--build-receipt-sha256',h.sha(out/'build-receipt.json'),'--output',str(out/'real-offline-tor')]
   if a.lane=='gcc':cmd+=['--strace','/usr/bin/strace']
   runner.run('real-offline-tor',cmd,timeout=120);real=h.load(out/'real-offline-tor/result.json');assert real['status']=='PASS_REAL_EXTRACTED_OFFLINE_TOR'
  after=h.images(images);h.write(out/'binary-after-tests.json',after);assert after==before
  assert not git(N,'ls-files','--others','--exclude-standard','--','preview/native','preview/migration/tools');final=h.source_snapshot(a.source_commit);h.write(out/'source-after.json',final);assert final==initial and dependencies(plan)==dep and provider(plan)==prov
  result.update(real_offline_tor=real,status='PASS_ACTUAL_SELECTED_COHORT',actual_suites=len(actual),suite_names=selected,compiled_suites=rule['compile_suites'],compile_only_suites=[x for x in rule['compile_suites'] if x not in selected],images_before=before,images_after=after,tests_xml=str(out/'tests.xml'),tests_xml_sha256=h.sha(out/'tests.xml'),cache=str(cache),source_before_sha256=h.sha(out/'source-before.json'),source_after_sha256=h.sha(out/'source-after.json'),dependencies=dep,sanitizer_environment={x:env[x] for x in ('ASAN_OPTIONS','UBSAN_OPTIONS') if x in env})
 except BaseException as e:result['failure']=repr(e);raise
 finally:
  if (out/'commands.json').exists():result['commands_sha256']=h.sha(out/'commands.json')
  h.write(out/'result.json',result)
 print(a.lane,'PASS',result['actual_suites'],flush=True)
if __name__=='__main__':main()
