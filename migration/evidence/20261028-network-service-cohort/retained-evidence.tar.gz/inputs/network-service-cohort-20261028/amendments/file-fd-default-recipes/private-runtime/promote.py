#!/usr/bin/env python3
"""Explicit root-run private development promotion, with the prior dist retained."""
import argparse
from support import *

def main():
    p=argparse.ArgumentParser(description=__doc__); add_inputs(p)
    p.add_argument('--private-result',type=Path,required=True); p.add_argument('--attempt',required=True); a=p.parse_args()
    assert re.fullmatch('[A-Za-z0-9_-]+',a.attempt)
    initial, qualified=verify_all(a); prov=provider(); r=verify_private(a.private_result,a,qualified)
    dist=N/'dist'; old=verify_bundle(dist,old=True); candidate=Path(r['candidate']); new=verify_bundle(candidate)
    out=HERE/'promotions'/a.attempt; assert not out.exists()
    rollback=W/('previous-published-dist-'+a.attempt); assert not rollback.exists()
    assert candidate.stat().st_dev==dist.stat().st_dev==W.stat().st_dev
    out.mkdir(parents=True); env=environment('gcc'); runner=Runner(out,env)
    result={'status':'FAILED','source_commit':a.source_commit,'shipping_approved':False}
    moved_old=False; moved_new=False
    try:
        os.rename(dist,rollback); moved_old=True
        os.rename(candidate,dist); moved_new=True
        assert sha(dist/'BUILD_MANIFEST.json')==r['manifest_sha256']
        verify_bundle(dist); verify_bundle(rollback,old=True); private=dist/'usr/lib/biglybtc'
        env.update(QT_QPA_PLATFORM='offscreen',LD_DEBUG='libs',LD_LIBRARY_PATH=os.pathsep.join(map(str,
            [private/'lib',private/'qt/lib',dist/'dependencies/libtorrent/usr/lib/x86_64-linux-gnu'])),
            QT_PLUGIN_PATH=str(private/'qt/plugins'),QT_QPA_PLATFORM_PLUGIN_PATH=str(private/'qt/plugins/platforms'))
        log=runner.run('post-promotion-launch',[dist/'BiglyBTC'],expected=2,timeout=30)
        paths=[Path(x.strip()).resolve() for x in re.findall(r'calling init:\s*([^\n]+)',log.read_text(errors='replace'))]
        assert (private/'lib/libtorrent-rasterbar.so.2.0.12').resolve() in paths
        assert (private/'qt/lib/libQt6Core.so.6').resolve() in paths
        assert verify_all(a)==(initial,qualified) and provider()==prov
        verify_bundle(dist); verify_bundle(rollback,old=True)
        result.update(status='PASS_PROMOTED_PRIVATE_DEVELOPMENT_DIST',new_manifest_sha256=sha(dist/'BUILD_MANIFEST.json'),
            previous_manifest_sha256=OLD_DIST_SHA,new_leaves=len(new['files_sha256']),previous_leaves=len(old['files_sha256']),
            rollback=str(rollback),installed_path=str(dist),provider=prov,qualified_results=qualified,
            source_adoption_sha256=sha(a.source_receipt),source_amendment=source_authority.verify(a.source_commit),private_result={'path':str(a.private_result.resolve()),'sha256':sha(a.private_result)},
            post_relocation_usage_exit=2,actual_private_qt_and_provider_init=True,distribution_scope='private-qualification-only')
    except BaseException as e:
        result['failure']=repr(e)
        if moved_new and dist.exists(): os.rename(dist,out/'failed-promoted-dist')
        if moved_old: os.rename(rollback,dist)
        raise
    finally:
        if (out/'commands.json').exists(): result['commands_sha256']=sha(out/'commands.json')
        write(out/'result.json',result)
    print('PROMOTED_PRIVATE',result['new_manifest_sha256'],'rollback retained',flush=True)

if __name__=='__main__': main()
