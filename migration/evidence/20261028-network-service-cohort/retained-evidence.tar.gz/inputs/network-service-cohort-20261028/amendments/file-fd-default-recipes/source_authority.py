"""Exact root-adopted one-line source amendment; no runtime authority."""
from pathlib import Path
import hashlib,json,subprocess
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/network-service-cohort-20261028'
BASE='5809ac611bb5d49b8de1c5eab0c7dca3ef8cbe9a'
SOURCE='9d3058b8e3fd073a5c9102a17ce6104daa23c534'
REL='preview/native/services/tor_control/owned_child.cpp'
BEFORE='eb7cde44e0b4806e86b795c756ed9e27bcc2eb1723932f6e30b26fc5bbdca04b'
AFTER='f4cdee7eedfdccebb58b73e538a369dbe94ac1fd5f159139b23017dad453a015'
RECEIPT=W/'source-amendment-r3.json'
PIN='db3f11f2f6438e9a4f2ccf78645aba56b17bff65a7cd393588a3f5429159acc0'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(N),*args])
def verify(source):
 assert source==SOURCE and sha(RECEIPT)==PIN
 d=json.loads(RECEIPT.read_bytes())
 assert d['status']=='ACTUAL_ROOT_SOURCE_AMENDMENT' and d['base_commit']==BASE and d['native_code_commit']==source
 assert d['before_sha256']=={REL:BEFORE} and d['source_sha256']=={REL:AFTER} and d['changed_paths']==[REL]
 assert sha(d['manifest'])==d['manifest_sha256']=='faf3ec887922fb60d2c6b54ace3f0aba4f281234fc3b715b80575976fa1353b9'
 assert git('diff','--name-only',BASE,source).decode().splitlines()==[REL]
 before=git('show',BASE+':'+REL);after=git('show',source+':'+REL)
 assert hashlib.sha256(before).hexdigest()==BEFORE and hashlib.sha256(after).hexdigest()==AFTER
 assert before.replace(b'struct File {\n  Fd fd;',b'struct File {\n  Fd fd{};',1)==after
 assert sha(N/REL)==AFTER and git('rev-parse','HEAD').decode().strip()==source
 assert not git('status','--porcelain','--untracked-files=no').strip()
 return {'path':str(RECEIPT),'sha256':PIN,'base_commit':BASE,'source_commit':SOURCE,'source_sha256':{REL:AFTER}}
