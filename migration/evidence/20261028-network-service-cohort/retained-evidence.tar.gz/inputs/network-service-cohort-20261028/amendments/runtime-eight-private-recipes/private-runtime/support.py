"""Read-only proof checks shared by the explicit root-run private recipes."""
import importlib.util
import os
import re
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
R = Path('/home/yurii/Java/BiglyBT')
N = R.parent/'BiglyBTC'
W = R/'build/network-service-cohort-20261028'
QDIR = W/'scoped-followup'
sys.path.insert(0,str(HERE)); import source_authority
COMMON = R/'build/mainline-scrape-20261028/recipe_support_followup.py'
import hashlib
assert hashlib.sha256(COMMON.read_bytes()).hexdigest() == '64e0bd2b9ec87b9babf90bdf8d1235746f7dc63c797c82c5e5a138a4c2ea893a'
spec = importlib.util.spec_from_file_location('private_common', COMMON)
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
sha, load, write, Runner = h.sha, h.load, h.write, h.Runner
CACHES, source_snapshot, environment = h.CACHES, h.source_snapshot, h.environment
CAPSULE_FILES = {'private-runtime/support.py','private-runtime/source_authority.py',
    'private-runtime/qualify.py','private-runtime/promote.py','private-runtime/plan.json',
    'ADOPTION.md','changes.patch','source-checks.json'}
self_manifest = load(HERE.parent/'manifest.json')
assert set(self_manifest['artifacts_sha256']) == CAPSULE_FILES
for rel,pin in self_manifest['artifacts_sha256'].items():
    assert sha(HERE.parent/rel) == pin, 'Private recipe changed: '+rel
POLICY = load(HERE/'plan.json')
for path, pin in POLICY['input_sha256'].items():
    assert sha(path) == pin, 'Recipe input changed: '+path
spec = importlib.util.spec_from_file_location('cohort_provider_functions', W/'amendments/managed-storage-include-recipes/qualification/run.py')
native = importlib.util.module_from_spec(spec); spec.loader.exec_module(native)
PLAN = load(QDIR/'plan.json')
PROVIDER_SHA = POLICY['provider']['artifact_sha256']
BINDING = N/'preview/native/engine/runtime-binding/provider-original-identity-runtime.json'
ALIASES = [prefix+'/'+name for prefix in ('usr/lib/biglybtc/lib',
    'dependencies/libtorrent/usr/lib/x86_64-linux-gnu') for name in
    ('libtorrent-rasterbar.so', 'libtorrent-rasterbar.so.2.0', 'libtorrent-rasterbar.so.2.0.12')]
NAMES = tuple(POLICY['private_programs'])
OLD_DIST_SHA = POLICY['published_manifest_sha256']

def source_proof(source, receipt):
    receipt = Path(receipt).resolve()
    assert receipt == Path(PLAN['source_receipt']['path']).resolve()
    assert sha(receipt) == POLICY['source_adoption_sha256'] == PLAN['source_receipt']['sha256']
    association = source_authority.verify(source)
    assert association['runtime_correction']['receipt'] == PLAN['source_receipt']
    return source_snapshot(source)

def provider():
    p = native.provider(PLAN)
    assert p['binding_sha256'] == POLICY['provider']['manifest_sha256']
    assert p['record_sha256'] == POLICY['provider']['record_sha256']
    assert p['artifact_sha256'] == PROVIDER_SHA and Path(p['artifact']).stat().st_size == POLICY['provider']['artifact_bytes']
    approval = load(POLICY['provider']['approval'])
    assert approval['status'] == 'ROOT_APPROVED_FOR_PRIVATE_NATIVE_QUALIFICATION'
    assert approval['shipping_approved'] is False
    return p

def commands(root, pin):
    path = root/'commands.json'; assert sha(path) == pin
    rows = load(path); assert rows and len({x['name'] for x in rows}) == len(rows)
    for row in rows:
        assert row['exit'] == row['expected_exit'] and 'exception' not in row
        assert Path(row['log']).resolve() == (root/(row['name']+'.log')).resolve()
        assert sha(row['log']) == row['log_sha256']
    return {x['name']:x for x in rows}

def xml(path, expected=None):
    rows = list(h.ET.parse(path).iter('testcase'))
    assert rows and all(c.get('status') not in ('notrun','disabled') for c in rows)
    assert not any(c.find(tag) is not None for c in rows for tag in ('failure','error','skipped'))
    names = [c.get('name') for c in rows]
    if expected is not None: assert sorted(names) == sorted(expected)
    return names

def verify_native(path, lane, source, live=True):
    # Source-qualified validator verifies named fresh rows and the historical
    # row/image/XML/build/command origins separately. Never require invented
    # whole-cohort reruns or call newly relinked images historically executed.
    path = Path(path).resolve(); root = path.parent
    d = source_authority.scoped.verify_result(path,lane,source,live=live)
    rule = PLAN['lanes'][lane]
    assert d['effective_suites'] == POLICY['actual_suites'][lane] == len(rule['execute_suites'])
    assert d['actual_fresh_suites'] == POLICY['fresh_suites'][lane]
    assert d['effective_suites']-d['actual_fresh_suites'] == POLICY['historical_suites'][lane]
    declared_compile_only = [x for x in rule['compile_suites'] if x not in rule['execute_suites']]
    assert len(declared_compile_only) == POLICY['declared_compile_only_suites'][lane]
    assert d['provider'] == provider() and d['provider_rebuilt'] is False
    assert d['cache'] == str(CACHES[lane]) and d['dependencies'] == native.dependencies(PLAN)
    rows = commands(root,d['commands_sha256'])
    assert {'compiler','configure','build','inventory','tests','real-offline-tor'} == set(rows)
    assert all(row['exit'] == 0 for row in rows.values())
    expected = {PLAN['suites'][name]['target']:CACHES[lane]/PLAN['suites'][name]['binary']
        for name in rule['compile_suites'] if PLAN['suites'][name].get('binary')}
    expected.update({name:CACHES[lane]/relative for name,relative in PLAN['products'].items() if name in rule['extra_targets']})
    assert set(d['images_after']) == set(expected)
    for name,image in d['images_after'].items():
        assert Path(image['path']).resolve() == expected[name].resolve()
        if live: assert sha(image['path']) == image['sha256'] and Path(image['path']).stat().st_size == image['bytes']
    snapshot = load(root/'source-before.json')
    assert snapshot == source_snapshot(source)
    assert load(root/'source-map.json') == {k:v for k,v in snapshot['files_sha256'].items() if k.startswith('preview/native/')}
    # Each lane's new013 real Tor subject is mandatory and independently
    # checked; a historical real/mock result or skip can never replace it.
    real_root = root/'real-offline-tor'; real = load(real_root/'result.json')
    assert real == d['real_offline_tor'] and real['status'] == 'PASS_REAL_EXTRACTED_OFFLINE_TOR' and real['exit'] == 0
    assert real['source_commit'] == source and real['source_amendment'] == d['source_amendment']
    assert real['binary_sha256'] == d['images_after']['biglybtc-tor-owned-child-tests']['sha256']
    assert Path(real['build_receipt']['path']).resolve() == root/'build-receipt.json'
    assert real['build_receipt']['sha256'] == sha(root/'build-receipt.json')
    assert real['runtime_artifact']['sha256'] == PLAN['real_tor']['runtime_artifact_sha256']
    assert sha(real['runtime_artifact']['path']) == real['runtime_artifact']['sha256']
    for rel,pin in real['retained_sha256'].items():
        assert Path(rel).name == rel and sha(real_root/rel) == pin
    xml(real_root/'test.xml',['initTestCase','extractedTorAuthenticatesOfflineThenStopsAndCancelsAnotherActualChild','cleanupTestCase'])
    assert real['xml_sha256'] == sha(real_root/'test.xml') and real['observed_sha256'] == sha(real_root/'observed.json')
    assert real['observed'] == load(real_root/'observed.json')
    observed = real['observed']
    assert observed['status'] == 'PASS_REAL_EXTRACTED_OFFLINE_TOR' and observed['joined'] is True
    assert observed['cancelled_before_authentication'] is True and observed['cookie_bytes'] == 32
    assert observed['runtime_artifact_sha256'] == PLAN['real_tor']['runtime_artifact_sha256']
    if lane == 'gcc':
        import ipaddress
        addresses = real['network_trace']['observed_addresses']
        assert addresses and all(ipaddress.ip_address(value).is_loopback for value in addresses)
    if lane == 'san':
        assert d['sanitizer_environment'] == {k:environment('san')[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS')}
    return d

def verify_all(args):
    initial = source_proof(args.source_commit,args.source_receipt)
    qualified = {}
    for lane in CACHES:
        path = getattr(args,lane+'_result').resolve()
        d = verify_native(path,lane,args.source_commit)
        declared = [x for x in PLAN['lanes'][lane]['compile_suites'] if x not in PLAN['lanes'][lane]['execute_suites']]
        qualified[lane] = {'path':str(path),'sha256':sha(path),'effective_suites':d['effective_suites'],
            'actual_fresh_suites':d['actual_fresh_suites'],'historical_suites':d['effective_suites']-d['actual_fresh_suites'],
            'suite_names':d['suite_names'],'declared_compile_only_suites':declared,
            'current_image_scope':d['current_image_scope'],
            'origin_scope':{'historical_source_commit':source_authority.HISTORICAL,'fresh_source_commit':args.source_commit}}
    return initial,qualified

def verify_bundle(root, old=False):
    root = Path(root); d = load(root/'BUILD_MANIFEST.json')
    if old:
        assert sha(root/'BUILD_MANIFEST.json') == OLD_DIST_SHA
        h.verify_bundle(root)
    else:
        assert d['distribution_scope'] == 'private-qualification-only' and d['system_installation'] is False
        rt = d['libtorrent_runtime']
        assert rt['artifact_sha256'] == PROVIDER_SHA and rt['artifact_bytes'] == POLICY['provider']['artifact_bytes']
        assert rt['runtime_manifest_sha256'] == POLICY['provider']['manifest_sha256']
        assert rt['source_build_record_sha256'] == POLICY['provider']['record_sha256']
        assert rt['shipping_approved'] is False and rt['instrumented'] is False and rt['causal_qualified'] is False
        assert rt['aliases'] == ALIASES
        for rel in ALIASES: assert sha(root/rel) == PROVIDER_SHA
    assert len(d['files_sha256']) == 118
    for rel, pin in d['files_sha256'].items():
        assert not Path(rel).is_absolute() and (root/rel).resolve().is_relative_to(root.resolve())
        assert sha(root/rel) == pin
    return d

def verify_private(path, args, qualified):
    path = Path(path).resolve(); root = path.parent; d = load(path)
    assert d['status'] == 'PASS_PRIVATE_RELOCATED_RUNTIME' and d['source_commit'] == args.source_commit
    assert d['shipping_approved'] is False and d['distribution_scope'] == 'private-qualification-only'
    assert d['qualified_results'] == qualified and d['provider'] == provider()
    assert d['source_adoption_sha256'] == sha(args.source_receipt)
    assert d['source_amendment'] == source_authority.verify(args.source_commit)
    assert d['loader_init_verified'] is True and d['verified_leaves'] == 118 and d['aliases'] == ALIASES
    assert d['published_dist_unchanged'] == OLD_DIST_SHA
    rows = commands(root,d['commands_sha256'])
    assert len(d['actual_tests']) == len(NAMES) and {x['binary'] for x in d['actual_tests']} == set(NAMES)
    gcc = load(args.gcc_result)
    for item in d['actual_tests']:
        name = item['binary']; copy = root/'owner-tests'/name; image = d['test_images'][name]
        assert item['exit'] == rows[name]['exit'] == 0 and item['mode'] == 'QtTest-default'
        assert sha(copy) == image['sha256'] == item['sha256'] == gcc['images_after'][name]['sha256']
        assert image['source'] == gcc['images_after'][name]['path'] and image['copy'] == str(copy)
        assert sha(root/(name+'.xml')) == item['xml_sha256']
        assert xml(root/(name+'.xml')) == item['testcase_names']
        assert rows[name]['command'] == [str(copy),'-o',str(root/(name+'.txt'))+',txt','-o',str(root/(name+'.xml'))+',junitxml']
    assert sha(root/'source-before.json') == d['source_snapshot_sha256']
    assert load(root/'source-before.json') == source_snapshot(args.source_commit)
    candidate = Path(d['candidate']); assert candidate == root/'candidate'
    assert sha(candidate/'BUILD_MANIFEST.json') == d['manifest_sha256']
    verify_bundle(candidate)
    return d

def add_inputs(parser):
    parser.add_argument('--source-commit',required=True)
    parser.add_argument('--source-receipt',type=Path,required=True)
    for lane in CACHES: parser.add_argument('--'+lane+'-result',type=Path,required=True)
