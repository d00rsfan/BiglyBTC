"""Read-only exact integration/compiler/runtime chain; no subject execution."""
from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys

sys.dont_write_bytecode = True
H = Path(__file__).resolve().parent
R = Path('/home/yurii/Java/BiglyBT'); N = R.parent/'BiglyBTC'
W = R/'build/network-service-cohort-20261028'
SCOPED = W/'scoped-followup'
BASE = '5809ac611bb5d49b8de1c5eab0c7dca3ef8cbe9a'
HISTORICAL = 'b0c0270cc8c41deb5169767e583b49ec654c73ca'
SOURCE = '013fa60f59898392a33855ba148961090bacca14'

def sha(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def git(*args): return subprocess.check_output(['git','-C',str(N),*args])
def module(name, path, pin):
    assert sha(path) == pin
    spec = importlib.util.spec_from_file_location(name,path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result

# Unique module names avoid aliasing the historical/scoped authorities with
# this integration-chain adapter. Imports never call their runner main().
legacy = module('private_historical_source_authority',
    W/'amendments/managed-storage-include-recipes/source_authority.py',
    '14004f4bbc140106de7657cc67f7297deb572db731867e7dee733d219a3fbc73')
scoped = module('private_scoped_source_authority',SCOPED/'source_authority.py',
    '2351d8723bc307bf641cb24bfa68234005ade5bc441d0b392a19b86fd3d8deae')

def verify(source):
    policy = load(H/'plan.json')
    assert source == SOURCE == policy['source_commit']
    assert sha(SCOPED/'manifest.json') == policy['scoped_followup_manifest_sha256']
    adopted = W/'source-adoption-r2.json'; plan_path = W/'integration-plan-r1.json'
    assert sha(adopted) == 'bad9d1bc41343ecaf060ae967e60eef14959e7721d358232b3ee57b1e74e2c65'
    assert sha(plan_path) == '1ba54b280492123c015c6483d1e1fe811748dbcaf024793731abf14bbcd0b12a'
    d, integration = load(adopted), load(plan_path)
    assert d['source_commit'] == BASE and d['base_commit'] == integration['base_commit'] == '3b18849f06a6287c4da7d97c067480156c6ef796'
    assert d['integration_plan_sha256'] == sha(plan_path)
    assert d['before_sha256'] == integration['before_sha256'] and d['after_sha256'] == integration['after_sha256']
    assert set(git('diff','--name-only',d['base_commit'],BASE).decode().splitlines()) == set(d['after_sha256'])
    expected = dict(d['after_sha256'])
    for rel,pin in d['before_sha256'].items():
        if pin is None: assert not git('ls-tree','--name-only',d['base_commit'],'--',rel).strip()
        else: assert hashlib.sha256(git('show',d['base_commit']+':'+rel)).hexdigest() == pin
        assert hashlib.sha256(git('show',BASE+':'+rel)).hexdigest() == d['after_sha256'][rel]
    steps = []
    for name,pin,base,final,rel,before,after,manifest_pin in legacy.STEPS:
        path = W/name; receipt = load(path)
        assert sha(path) == pin and receipt['status'] == 'ACTUAL_ROOT_SOURCE_AMENDMENT'
        assert receipt['base_commit'] == base and receipt['native_code_commit'] == final
        assert receipt['before_sha256'] == {rel:before} and receipt['source_sha256'] == {rel:after} and receipt['changed_paths'] == [rel]
        assert sha(receipt['manifest']) == receipt['manifest_sha256'] == manifest_pin
        assert git('diff','--name-only',base,final).decode().splitlines() == [rel]
        old, new = git('show',base+':'+rel), git('show',final+':'+rel)
        assert hashlib.sha256(old).hexdigest() == before and hashlib.sha256(new).hexdigest() == after
        if rel == legacy.REL: assert old.replace(b'struct File {\n  Fd fd;',b'struct File {\n  Fd fd{};',1) == new
        else: assert old.replace(b'#include "persistent_session.hpp"\n',b'#include "persistent_session.hpp"\n#include "managed_storage.hpp"\n',1) == new
        expected[rel] = after
        steps.append({'path':str(path),'sha256':pin,'base_commit':base,'source_commit':final})
    assert set(git('diff','--name-only',BASE,HISTORICAL).decode().splitlines()) == set(legacy.UPDATED)
    ref = load(SCOPED/'plan.json')['source_receipt']
    current = scoped.verify(source,ref['path'],ref['sha256'])
    expected.update(current['source_sha256'])
    assert set(git('diff','--name-only',d['base_commit'],source).decode().splitlines()) == set(expected)
    for rel,pin in expected.items():
        assert hashlib.sha256(git('show',source+':'+rel)).hexdigest() == pin and sha(N/rel) == pin
    assert not git('ls-files','--others','--exclude-standard','--','preview/native','preview/migration/tools').strip()
    # Earlier original16/80 credit is projection-source credit only. The core
    # and replay source are exact; do not call a newly relinked image executed.
    unchanged = git('diff','--name-only',HISTORICAL,source,'--','preview/native/core','preview/native/tests/queue_facts_replay.cpp')
    assert not unchanged.strip()
    reference = load(SCOPED/'plan.json')['original_java_reference']
    assert sha(reference['path']) == reference['sha256']
    original_root = R/'build/mainline-scrape-single-tracker-20261028/runtime-owner/oracle/runs/run-r1'
    result_path = original_root/'result.json'
    assert Path(reference['path']).resolve() == result_path and reference['sha256'] == '15fbc2338a7dcc02bdd0542b805b72a185d934d628a0208b47fd83f60c84b093'
    assert reference['source_commit'] == HISTORICAL and reference['actual_cases'] == 16 and reference['scalar_comparisons'] == 80
    original = load(result_path)
    assert original['status'] == 'PASS_ACTUAL_ORIGINAL_SINGLE_TRACKER_RESPONSE_PROJECTION'
    assert original['source_commit'] == HISTORICAL and original['actual_cases'] == 16 and original['scalar_comparisons'] == 80
    assert not original['mismatches'] and original['cohort_unchanged'] is True and original['driver_unchanged'] is True
    return {'initial_integration':{'path':str(adopted),'sha256':sha(adopted),'base_commit':d['base_commit'],'source_commit':BASE},
        'compiler_steps':steps,'runtime_correction':current,'final_source_commit':source,
        'final_component_sha256':expected,'original_java_reference':reference,
        'original_reference_scope':'Historical actual16/80; unchanged core/replay source, no Java or new-image rerun.'}
