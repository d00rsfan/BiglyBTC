# Private013 qualification and separate promotion adapter (source only)

This child keeps the managed-storage-include private action files `qualify.py` and `promote.py` byte-exact. It changes only their read-only source/result adapter and policy. No compiler, original JVM, subject, private staging or promotion was run while preparing it. Native tree/provider/dist are unchanged.

The exact source chain is verified through original3b18849f06a6287c4da7d97c067480156c6ef796 integration→5809ac611bb5d49b8de1c5eab0c7dca3ef8cbe9a, compiler-only initializer→9d3058b8e3fd073a5c9102a17ce6104daa23c534 and include→b0c0270cc8c41deb5169767e583b49ec654c73ca, then reviewed8-path receiptfbefd→013fa60f59898392a33855ba148961090bacca14. All committed before/after maps, exact changed-path sets, capsule artifacts, clean current source and the retained closeout association are checked. The read-only author check verified29 cumulative changed component paths. The original16/80 result15fbc is retained at b0 with exact unchanged core/replay source; no Java or current-binary execution is inferred.

First root must complete the frozen scoped-followup15a2 recipe for all three lanes. This adapter calls its exact `verify_result(...,live=True)` and additionally verifies current target paths/images, provider/dependencies/command maps, source snapshot and each new013 real-Tor receipt, actual no-skip Qt XML, joined/cancelled observations, pinned runtime25f and GCC loopback-only socket evidence. Historical20/16/20 named PASS rows keep their actual b0 source, XML, build/commands and compressed historical ELF origins. Fresh4/3/4 are new013. Unique totals24/19/24 are not claimed as a full current-source rerun. Clang's five declared compile-only suites remain explicit; every other newly relinked unexecuted current image is labelled compile-only as well. Original failed initial global attempts and actual real-Tor failures are preserved, never rewritten as PASS.

Only after those actual gates, use the actual result filenames supplied by root:

```sh
P=/home/yurii/Java/BiglyBT/build/network-service-cohort-20261028/amendments/runtime-eight-private-recipes/private-runtime
W=/home/yurii/Java/BiglyBT/build/network-service-cohort-20261028
python3 "$P/qualify.py" --source-commit 013fa60f59898392a33855ba148961090bacca14 \
  --source-receipt "$W/source-runtime-fixes-r5.json" \
  --gcc-result "$GCC_RESULT" --clang-result "$CLANG_RESULT" --san-result "$SAN_RESULT" \
  --attempt private013-r1
```

The four actual private programs remain original-wire, single-tracker-owner, Tor default/mock lifecycle and preview smoke. They use the freshly staged exact25 provider and private Qt6.12; real-Tor mode is separately mandatory once per new lane and is not repeated by private qualification. Existing per-program deadlines, ELF/RPATH/ldd/actual loader initialization, isolated profile, exact118 leaves and all current approved-source/artifact gates remain byte-exact. No builds occur inside qualification. Candidate, logs and failures go only under this child `private-runtime/runs/<fresh-attempt>`. Before root starts, check free disk for one118-leaf candidate +QtTest support +four image copies +logs; there is no extra full dist rollback copy. The temporary generated preview is owned `/tmp/biglybtc-preview-*`, never a user profile.

Root reviews actual result/candidate and chooses promotion independently. With `PRIVATE_RESULT` set to that successful actual private result:

```sh
python3 "$P/promote.py" --source-commit 013fa60f59898392a33855ba148961090bacca14 \
  --source-receipt "$W/source-runtime-fixes-r5.json" \
  --gcc-result "$GCC_RESULT" --clang-result "$CLANG_RESULT" --san-result "$SAN_RESULT" \
  --private-result "$PRIVATE_RESULT" --attempt private013-r1
```

Promotion retains the complete old404f1429f97da909b18860e49d1cbb63b9cd56c78f8637fafe84662bc77013c8 dist by same-filesystem rename under `W/previous-published-dist-<attempt>`, moves only the qualified candidate, checks relocated usage/private provider+Qt initialization, and restores the complete prior tree on failure. No new manifest hash is guessed. Do not reuse an old output/attempt; every actual failed command remains retained.

The self-manifest has an explicit8-file immutable source-recipe allowlist. Runs, promotions, captures, outputs and runtime results are never auto-enumerated into their own recipe authority. Existing full-source recipes and all originals/providers/published/rollback trees remain immutable. Scope is private development only: no shipping/public route/dual-family Host/root-writeback/Tor-network activation, full phase parity or causal qualification is granted.
