#!/usr/bin/env python3
"""Root-run historical r3 closeout. Does not run a build, test or subject."""
from pathlib import Path
import argparse, gzip, hashlib, importlib.util, json, os, shutil, sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
R = Path('/home/yurii/Java/BiglyBT')
N = R.parent / 'BiglyBTC'
W = R / 'build/network-service-cohort-20261028'
Q = W / 'amendments/managed-storage-include-recipes/qualification'
H = Path(__file__).resolve().parent
SOURCE = 'b0c0270cc8c41deb5169767e583b49ec654c73ca'
SOURCE_FILES = ('source-before.json', 'source-map.json', 'dependencies-before.json',
                'binary-before-tests.json', 'selected-plan.json', 'compiler.json',
                'build-receipt.json', 'commands.json', 'result.json', 'tests.xml',
                'compiler.log', 'configure.log', 'build.log', 'inventory.log', 'tests.log')
LANES = ('gcc', 'clang', 'san')

def need(value, message):
    if not value:
        raise RuntimeError(message)

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(part)
    return digest.hexdigest()

def load(path):
    return json.loads(Path(path).read_bytes())

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

def pinned_module():
    manifest = load(H / 'manifest.json')
    for path, pin in manifest['input_sha256'].items():
        need(sha(path) == pin, 'Changed collector input: ' + path)
    need(sha(__file__) == manifest['collector_sha256'], 'Collector changed')
    spec = importlib.util.spec_from_file_location('r3_frozen_qualification', Q / 'run.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def named_rows(path, selected):
    rows = list(ET.parse(path).iter('testcase'))
    names = [row.get('name') for row in rows]
    need(len(names) == len(set(names)) and sorted(names) == sorted(selected), 'JUnit suite inventory differs')
    result = {}
    for row in rows:
        failure = row.find('failure') is not None or row.find('error') is not None
        skipped = row.find('skipped') is not None or row.get('status') in ('notrun', 'disabled')
        status = 'FAILED' if failure else 'SKIPPED' if skipped else 'PASSED'
        result[row.get('name')] = {
            'status': status, 'testcase_attributes': dict(row.attrib),
            'normalized_row_sha256': hashlib.sha256(ET.tostring(row)).hexdigest(),
            'junit_path': str(path), 'junit_sha256': sha(path),
            'counts_scope': 'One named CTest suite row; no unprinted Qt method credit.'}
    return result

def command_rows(root):
    rows = load(root / 'commands.json')
    need(len(rows) == len({row['name'] for row in rows}), 'Duplicate command name')
    need([row['name'] for row in rows[:5]] == ['compiler', 'configure', 'build', 'inventory', 'tests'], 'Incomplete command history')
    need(len(rows) in (5, 6) and (len(rows) == 5 or rows[-1]['name'] == 'real-offline-tor'), 'Unexpected command history')
    for row in rows:
        need('exit' in row and 'exception' not in row, 'Unfinished command: ' + row['name'])
        need(Path(row['log']).resolve() == (root / (row['name'] + '.log')).resolve(), 'Log association differs')
        need(sha(row['log']) == row['log_sha256'], 'Changed command log')
    need(all(row['exit'] == 0 for row in rows[:4]), 'Build/configure/inventory did not complete successfully')
    return {row['name']: row for row in rows}

def installed_sdk(provider):
    record = load(provider['record'])
    root = Path(record['install_root']).resolve()
    checked = {}
    for relative, pin in record['installed_sha256'].items():
        path = root / relative
        need(not Path(relative).is_absolute() and '..' not in Path(relative).parts and path.resolve().is_relative_to(root), 'SDK path escapes install')
        resolved = path.resolve()
        if resolved not in checked:
            checked[resolved] = sha(resolved)
        need(checked[resolved] == pin, 'Installed SDK changed: ' + relative)
    return {'install_root': str(root), 'leaves_verified': len(record['installed_sha256']),
            'record_sha256': provider['record_sha256'], 'files_sha256': record['installed_sha256']}

def collect(q, plan):
    initial = q.h.source_snapshot(SOURCE)
    need(not q.git(N, 'ls-files', '--others', '--exclude-standard', '--', 'preview/native', 'preview/migration/tools'), 'Untracked native inputs')
    authority = q.source_authority.verify(SOURCE)
    deps, provider = q.dependencies(plan), q.provider(plan)
    sdk = installed_sdk(provider)
    lanes, candidates, files = {}, {}, {}
    for lane in LANES:
        root = Q / 'runs' / (lane + '-r3')
        for name in SOURCE_FILES:
            path = root / name
            need(path.is_file() and not path.is_symlink(), 'Missing/untrusted completed input: ' + str(path))
            files[str(path)] = sha(path)
        result, commands = load(root / 'result.json'), command_rows(root)
        rule, selected = plan['lanes'][lane], load(root / 'selected-plan.json')
        need(result['status'] in ('FAIL', 'PASS_ACTUAL_SELECTED_COHORT'), 'Unexpected original result status')
        need(result['source_commit'] == SOURCE and result['lane'] == lane, 'Source/lane differs')
        need(result['source_amendment'] == authority and result['provider'] == provider, 'Authority/provider differs')
        need(result['qualification_recipe_sha256'] == sha(Q / 'run.py') and result['plan_sha256'] == sha(Q / 'plan.json'), 'Recipe association differs')
        need(result['commands_sha256'] == sha(root / 'commands.json'), 'Result/commands association differs')
        need(load(root / 'source-before.json') == initial, 'Source no longer equals pre-run snapshot')
        need(load(root / 'source-map.json') == {k: v for k, v in initial['files_sha256'].items() if k.startswith('preview/native/')}, 'Build source-map differs')
        need(load(root / 'dependencies-before.json') == deps, 'Dependencies differ')
        need(selected['actually_execute'] == rule['execute_suites'] and selected['compile_suites'] == rule['compile_suites'], 'Selected plan differs')
        build = load(root / 'build-receipt.json')
        need(build == {**commands['build'], 'source_manifest_sha256': sha(root / 'source-map.json')}, 'Build receipt association differs')
        images = load(root / 'binary-before-tests.json')
        need(q.h.images({key: Path(value['path']) for key, value in images.items()}) == images, 'A compiled image changed after tests')
        compiler = load(root / 'compiler.json')
        need(sha(compiler['resolved']) == compiler['sha256'], 'Compiler image changed')
        registered = {row['name']: row for row in load(root / 'inventory.log')['tests']}
        rows = named_rows(root / 'tests.xml', selected['actually_execute'])
        test_command = commands['tests']['command']
        need(test_command[:6] == ['ctest', '--test-dir', str(q.h.CACHES[lane]), '--parallel', '1', '-R']
             and test_command[6] == '^(' + '|'.join(selected['actually_execute']) + ')$'
             and test_command[-2:] == ['--output-junit', str(root / 'tests.xml')], 'JUnit command association differs')
        need(not any(row['status'] == 'FAILED' for row in rows.values()) or commands['tests']['exit'] != 0, 'Failed XML with successful CTest exit')
        for name, row in rows.items():
            spec = plan['suites'][name]
            row['command'] = registered[name]['command']
            row['source_before_path'] = str(root / 'source-before.json')
            row['source_before_sha256'] = sha(root / 'source-before.json')
            row['source_map_path'] = str(root / 'source-map.json')
            row['source_map_sha256'] = sha(root / 'source-map.json')
            row['build_receipt_path'] = str(root / 'build-receipt.json')
            row['build_receipt_sha256'] = sha(root / 'build-receipt.json')
            row['binary_before_path'] = str(root / 'binary-before-tests.json')
            row['binary_before_sha256'] = sha(root / 'binary-before-tests.json')
            row['commands_path'] = str(root / 'commands.json')
            row['commands_sha256'] = sha(root / 'commands.json')
            row['target'] = spec['target']
            if spec.get('binary'):
                image = images[spec['target']]
                need(Path(image['path']).resolve() == (q.h.CACHES[lane] / spec['binary']).resolve(), 'Suite/binary association differs')
                row['pretest_image'] = image
                if row['status'] == 'PASSED':
                    path = Path(image['path'])
                    with path.open('rb') as stream:
                        need(stream.read(4) == b'\x7fELF', 'Credited program is not ELF')
                    need('.so' not in path.name, 'Do not archive shared libraries')
                    candidates[image['sha256']] = image
        if 'real-offline-tor' in commands:
            log = root / 'real-offline-tor.log'
            files[str(log)] = sha(log)
        lanes[lane] = {'original_global_status': result['status'], 'original_result_path': str(root / 'result.json'), 'original_result_sha256': sha(root / 'result.json'),
                       'ctest_exit': commands['tests']['exit'], 'rows': rows,
                       'actual_counts': {status: sum(x['status'] == status for x in rows.values()) for status in ('PASSED', 'FAILED', 'SKIPPED')},
                       'compile_only_suites': [x for x in selected['compile_suites'] if x not in rows],
                       'all_compiled_images_unchanged': images,
                       'separate_real_tor_command': commands.get('real-offline-tor')}
    need(q.h.source_snapshot(SOURCE) == initial and q.dependencies(plan) == deps and q.provider(plan) == provider, 'Source/dependencies/provider changed during closeout')
    return {'schema': 1, 'status': 'VERIFIED_HISTORICAL_R3_CLOSEOUT_NOT_COHORT_PASS',
            'source_commit': SOURCE, 'source_snapshot': initial, 'source_amendment': authority,
            'provider': provider, 'installed_sdk': sdk, 'dependencies': deps, 'lanes': lanes,
            'raw_inputs_sha256': files, 'new_source_credit': False, 'dist_promoted': False,
            'cf_parents_closed': [], 'scope': 'Named actual CTest origins only; failures/global FAIL unchanged. Future reuse needs explicit affected-source reconciliation.'}, candidates

def archive_images(images, store, reserve, budget):
    store.mkdir(parents=True, exist_ok=True)
    need(not store.is_symlink() and store.resolve().is_relative_to((R / 'build').resolve()), 'Image-store path escapes build')
    need(shutil.disk_usage(store).free >= reserve + max((x['bytes'] for x in images.values()), default=0) + 4 * 1024 * 1024, 'Insufficient bounded one-image scratch space')
    records, used = {}, 0
    for pin, image in images.items():
        destination = store / (pin + '.elf.gz')
        if not destination.exists():
            temporary = store / (pin + '.partial-' + str(os.getpid()))
            digest, total = hashlib.sha256(), 0
            try:
                with Path(image['path']).open('rb') as source, temporary.open('xb') as raw:
                    with gzip.GzipFile(filename='', fileobj=raw, mode='wb', compresslevel=1, mtime=0) as target:
                        for data in iter(lambda: source.read(1024 * 1024), b''):
                            need(shutil.disk_usage(store).free >= reserve + 2 * 1024 * 1024, 'Free-space reserve reached')
                            digest.update(data); total += len(data); target.write(data)
                            need(used + raw.tell() <= budget, 'Compressed archive budget reached')
                    raw.flush(); os.fsync(raw.fileno())
                need(digest.hexdigest() == pin and total == image['bytes'] and sha(image['path']) == pin, 'Image changed while archiving')
                os.link(temporary, destination)  # Exclusive publication; never overwrite an existing CAS entry.
                used += destination.stat().st_size
            finally:
                temporary.unlink(missing_ok=True)
        need(not destination.is_symlink(), 'Symlinked CAS entry')
        digest, total = hashlib.sha256(), 0
        with gzip.open(destination, 'rb') as source:
            for data in iter(lambda: source.read(1024 * 1024), b''):
                total += len(data); need(total <= image['bytes'], 'Oversize archived image'); digest.update(data)
        need(total == image['bytes'] and digest.hexdigest() == pin, 'Bad archived image')
        records[pin] = {'path': str(destination), 'sha256': sha(destination), 'bytes': destination.stat().st_size,
                        'uncompressed_sha256': pin, 'uncompressed_bytes': total, 'compression': 'gzip-level1-mtime0'}
    return records

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--all-runners-joined', action='store_true', required=True)
    parser.add_argument('--write', action='store_true')
    parser.add_argument('--reserve-mib', type=int, default=256)
    parser.add_argument('--max-new-image-mib', type=int, default=768)
    args = parser.parse_args()
    need(args.reserve_mib >= 128 and 0 < args.max_new_image_mib <= 1024, 'Archive bounds outside supported limits')
    output = args.output.resolve()
    need(output.is_relative_to((H / 'runs').resolve()) and not output.exists(), 'Require fresh closeout output under this recipe/runs')
    q = pinned_module(); report, images = collect(q, load(Q / 'plan.json'))
    report['collector'] = {'path': str(Path(__file__).resolve()), 'sha256': sha(__file__),
                           'manifest_path': str(H / 'manifest.json'), 'manifest_sha256': sha(H / 'manifest.json')}
    if args.write:
        report['historical_images'] = archive_images(images, W / 'r3-closeout-images', args.reserve_mib * 1024 ** 2, args.max_new_image_mib * 1024 ** 2)
        # Archive only the explicit raw metadata/log allowlist, not profiles/traces/runtime libraries.
        raw_bytes = sum(Path(path).stat().st_size for path in report['raw_inputs_sha256'])
        need(shutil.disk_usage(H).free >= args.reserve_mib * 1024 ** 2 + raw_bytes + 8 * 1024 ** 2, 'Insufficient bounded metadata archive space')
        output.mkdir(parents=True)
        for original, pin in report['raw_inputs_sha256'].items():
            source = Path(original); need(sha(source) == pin, 'Input changed before archival')
            target = output / 'raw' / source.relative_to(Q / 'runs')
            target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, target)
            need(sha(target) == pin, 'Raw input copy differs')
        for lane in report['lanes'].values():
            for row in lane['rows'].values():
                if row['status'] == 'PASSED' and 'pretest_image' in row:
                    row['historical_image'] = report['historical_images'][row['pretest_image']['sha256']]
        need(q.h.source_snapshot(SOURCE) == report['source_snapshot'], 'Source changed while archiving')
        for lane in report['lanes'].values():
            need(q.h.images({key: Path(value['path']) for key, value in lane['all_compiled_images_unchanged'].items()}) == lane['all_compiled_images_unchanged'], 'Binary changed while archiving')
        plan = load(Q / 'plan.json')
        need(q.dependencies(plan) == report['dependencies'] and q.provider(plan) == report['provider']
             and installed_sdk(report['provider']) == report['installed_sdk'], 'Provider/SDK/dependencies changed while archiving')
        write(output / 'closeout.json', report)
    print(json.dumps({'status': report['status'], 'written': args.write,
                      'counts': {lane: item['actual_counts'] for lane, item in report['lanes'].items()},
                      'unique_passed_elf_images': len(images)}))

if __name__ == '__main__':
    main()
