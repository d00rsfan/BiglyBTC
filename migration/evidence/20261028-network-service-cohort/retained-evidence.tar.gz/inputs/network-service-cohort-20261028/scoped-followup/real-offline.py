#!/usr/bin/env python3
"""Root-run real offline subject only; never build/install/start a system daemon."""
import argparse, hashlib, ipaddress, json, os, re, subprocess, sys
from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
R = Path('/home/yurii/Java/BiglyBT')
N = R.parent/'BiglyBTC'
sys.dont_write_bytecode=True
sys.path.insert(0,str(HERE));import source_authority
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda:stream.read(1024*1024), b''):
            h.update(data)
    return h.hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def write(path, value): Path(path).write_text(json.dumps(value,indent=2)+'\n')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--binary-sha256',required=True)
    p.add_argument('--source-commit',required=True)
    p.add_argument('--source-receipt',type=Path,required=True)
    p.add_argument('--source-receipt-sha256',required=True)
    p.add_argument('--build-receipt',type=Path,required=True)
    p.add_argument('--build-receipt-sha256',required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--runtime-artifact',type=Path,default=R/'build/dependencies/tor-owned-0.4.9.11/runtime-fixture-artifact.json')
    p.add_argument('--strace',type=Path)
    a = p.parse_args()
    association = source_authority.verify(a.source_commit,a.source_receipt,a.source_receipt_sha256)
    out = a.output.resolve()
    assert out.is_relative_to(R/'build') and not out.exists()
    source = subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD'],text=True).strip()
    assert source == a.source_commit and re.fullmatch('[0-9a-f]{40}',source)
    assert not subprocess.check_output(['git','-C',str(N),'status','--porcelain','--untracked-files=no'],text=True).strip()
    for rel,pin in load(HERE/'real-source-pins.json')['effective_source_sha256'].items():
        assert sha(N/rel) == pin, 'Source adoption differs: '+rel
    assert sha(a.binary) == a.binary_sha256 and sha(a.build_receipt) == a.build_receipt_sha256
    artifact = a.runtime_artifact.resolve()
    assert sha(artifact) == '25f0d75d2a2cc482b3e912457099ee666622444a0ae714151257844ca5987356'
    runtime = load(artifact)
    for path,pin in runtime['files_sha256'].items(): assert sha(path) == pin
    assert sha(runtime['tor_artifact']['path']) == runtime['tor_artifact']['sha256']
    assert sha(runtime['launcher']['path']) == runtime['launcher']['sha256']
    out.mkdir(parents=True)
    env = os.environ.copy()
    for key in ('LD_PRELOAD','LD_AUDIT'): env.pop(key,None)
    env.update(BIGLYBTC_OWNED_TOR_EXECUTABLE=runtime['launcher']['path'],
        BIGLYBTC_OWNED_TOR_RUNTIME_ARTIFACT=str(artifact),BIGLYBTC_OWNED_TOR_RUNTIME_ARTIFACT_SHA256=sha(artifact),
        BIGLYBTC_OWNED_TOR_RESULT=str(out/'observed.json'),QT_QPA_PLATFORM='offscreen')
    command = [str(a.binary.resolve()),'--real-offline-tor','-o',str(out/'test.txt')+',txt','-o',str(out/'test.xml')+',junitxml']
    if a.strace:
        command = [str(a.strace.resolve()),'-f','-qq','-s','256','-e',
            'trace=connect,sendto,sendmsg,sendmmsg,bind,listen,accept,accept4','-o',str(out/'network-private.trace'),*command]
    result = {'status':'FAILED','source_amendment':association,'source_commit':source,'binary_sha256':a.binary_sha256,
        'build_receipt':{'path':str(a.build_receipt.resolve()),'sha256':a.build_receipt_sha256,
            'scope':'Root-supplied actual build provenance; no new compiler/source authority minted by runner'},
        'runtime_artifact':{'path':str(artifact),'sha256':sha(artifact)},'command':command,
        'subject':'Explicit package Tor through private same-PID loader launcher; not system installation/daemon adoption'}
    try:
        with (out/'process.log').open('wb') as log:
            completed = subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
        result['exit'] = completed.returncode
        assert completed.returncode == 0
        rows = list(ET.parse(out/'test.xml').iter('testcase'))
        assert {r.get('name') for r in rows} == {'initTestCase','extractedTorAuthenticatesOfflineThenStopsAndCancelsAnotherActualChild','cleanupTestCase'}
        assert not any(r.find(tag) is not None for r in rows for tag in ('failure','error','skipped'))
        observed = load(out/'observed.json')
        assert observed['status'] == 'PASS_REAL_EXTRACTED_OFFLINE_TOR' and observed['joined'] is True
        assert observed['runtime_artifact_sha256'] == sha(artifact)
        assert observed['cancelled_before_authentication'] is True and observed['cookie_bytes'] == 32
        if a.strace:
            text = (out/'network-private.trace').read_text(errors='strict')
            addresses = re.findall(r'inet_addr\("([^"]+)"\)|inet_pton\(AF_INET6, "([^"]+)"',text)
            seen = sorted({left or right for left,right in addresses})
            assert seen and all(ipaddress.ip_address(x).is_loopback for x in seen), 'Non-loopback socket endpoint in restricted trace'
            result['network_trace'] = {'sha256':sha(out/'network-private.trace'),'observed_addresses':seen,
                'scope':'Restricted socket-call trace; raw payload-bearing trace stays local/private, not public evidence'}
        assert sha(a.binary) == a.binary_sha256
        for path,pin in runtime['files_sha256'].items(): assert sha(path) == pin
        result.update(status='PASS_REAL_EXTRACTED_OFFLINE_TOR',observed=observed,xml_sha256=sha(out/'test.xml'),observed_sha256=sha(out/'observed.json'))
    except BaseException as error:
        result['failure'] = repr(error)
        raise
    finally:
        result['retained_sha256'] = {x.name:sha(x) for x in sorted(out.iterdir()) if x.is_file() and x.name != 'result.json'}
        write(out/'result.json',result)
    print('REAL_OFFLINE_TOR_PASS',flush=True)

if __name__ == '__main__': main()
