#!/usr/bin/env python3
"""Read-only scoped-result/origin verification; never reruns tests."""
from pathlib import Path
import argparse,sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
import source_authority as s
p=argparse.ArgumentParser();p.add_argument('lane',choices=('gcc','clang','san'));p.add_argument('--result',type=Path,required=True);p.add_argument('--source-commit',required=True);p.add_argument('--live',action='store_true');a=p.parse_args()
d=s.verify_result(a.result,a.lane,a.source_commit,a.live)
print(a.lane,'PASS_ORIGINS','effective',d['effective_suites'],'fresh',d['actual_fresh_suites'],'historical',d['effective_suites']-d['actual_fresh_suites'])
