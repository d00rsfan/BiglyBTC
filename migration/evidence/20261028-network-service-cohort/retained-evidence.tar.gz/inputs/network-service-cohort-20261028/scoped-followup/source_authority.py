"""Exact current-cohort source association; imports perform no writes/runs."""
from pathlib import Path
import gzip, hashlib, json, subprocess, xml.etree.ElementTree as ET

R=Path('/home/yurii/Java/BiglyBT'); N=R.parent/'BiglyBTC'; H=Path(__file__).resolve().parent
BASE='b0c0270cc8c41deb5169767e583b49ec654c73ca'
def sha(path):
 d=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):d.update(b)
 return d.hexdigest()
def load(path):return json.loads(Path(path).read_bytes())
def git(*args):return subprocess.check_output(['git','-C',str(N),*args]).decode().strip()
def pinned(path,pin):
 assert sha(path)==pin,'Changed input: '+str(path)
 return load(path)
def verify_recipe():
 for path,pin in load(H/'recipe-pins.json').items():assert sha(H/path if not Path(path).is_absolute() else path)==pin
def capsules(plan):
 before={};after={}
 for ref in plan['reviewed_capsules']:
  path=Path(ref['path']);d=pinned(path,ref['sha256'])
  for rel,pin in d['artifacts_sha256'].items():assert sha(path.parent/rel)==pin
  if 'current' in d:
   a={k:v['before_sha256'] for k,v in d['current'].items()};b={k:v['source_sha256'] for k,v in d['current'].items()}
  else:a=d['before_sha256'];b=d['source_sha256']
  assert not set(a)&set(before) and set(a)==set(b)
  before.update(a);after.update(b)
 assert len(after)==8
 return before,after
def verify(source,receipt_path,receipt_sha256):
 verify_recipe()
 plan=load(H/'plan.json');receipt=pinned(receipt_path,receipt_sha256)
 assert plan['source_receipt']=={'path':str(Path(receipt_path).resolve()),'sha256':receipt_sha256}
 assert receipt['base_commit']==BASE and receipt['source_commit']==source==plan['source_commit']
 assert git('rev-parse','HEAD')==source and not git('status','--porcelain','--untracked-files=no')
 before,after=capsules(plan)
 assert receipt['before_sha256']==before and receipt['source_sha256']==after
 assert receipt['reviewed_capsules']==plan['reviewed_capsules']
 assert receipt['historical_closeout']==plan['closeout']
 assert set(git('diff','--name-only',BASE,source).splitlines())==set(after)
 assert git('merge-base','--is-ancestor',BASE,source)==''
 for rel,pin in before.items():
  assert hashlib.sha256(subprocess.check_output(['git','-C',str(N),'show',BASE+':'+rel])).hexdigest()==pin
  assert hashlib.sha256(subprocess.check_output(['git','-C',str(N),'show',source+':'+rel])).hexdigest()==after[rel]
  assert sha(N/rel)==after[rel]
 # Existing owner methods/class data are byte-exact after removing ONLY these
 # reviewed public declaration and ordinary (nonvirtual) passive getter.
 cpp='preview/native/engine/persistent_session.cpp';hpp='preview/native/engine/persistent_session.hpp'
 oldcpp=subprocess.check_output(['git','-C',str(N),'show',BASE+':'+cpp]).decode();newcpp=(N/cpp).read_text()
 start=newcpp.index('std::optional<core::QueueOriginalScrapeResponse> PersistentSession::managedTrackerResponse(')
 end=newcpp.index('std::expected<void, AccountingError> PersistentSession::setObservationSink',start)
 assert newcpp[:start]+newcpp[end:]==oldcpp
 declaration='  // Passive worker-only copy of the current rich library response. No RPC,\n  // callback draining, status query or new permission; exact admission required.\n  std::optional<core::QueueOriginalScrapeResponse> managedTrackerResponse(\n      const core::TorrentHash&, std::uint64_t admission) const;\n'
 newhpp=(N/hpp).read_text();assert newhpp.count(declaration)==1
 assert newhpp.replace(declaration,'',1).encode()==subprocess.check_output(['git','-C',str(N),'show',BASE+':'+hpp])
 return {'base_commit':BASE,'source_commit':source,'receipt':{'path':str(Path(receipt_path).resolve()),'sha256':receipt_sha256},'before_sha256':before,'source_sha256':after,'reviewed_capsules':plan['reviewed_capsules'],'reuse_scope':'Exact historical b0 suite/image origins; reviewed additive getter preserves prior methods/data. Relinked images are compile-only unless executed fresh.'}
def row(path,name,pin):
 assert sha(path)==pin
 found=[x for x in ET.parse(path).iter('testcase') if x.get('name')==name]
 assert len(found)==1
 c=found[0];assert c.get('status') not in ('notrun','disabled')
 assert not any(c.find(k) is not None for k in ('failure','error','skipped'))
 return c
def closeout(plan,lane,verify_images=True):
 d=pinned(plan['closeout']['path'],plan['closeout']['sha256'])
 assert d['status']=='VERIFIED_HISTORICAL_R3_CLOSEOUT_NOT_COHORT_PASS' and d['source_commit']==BASE
 assert d['new_source_credit'] is False
 assert sha(d['collector']['path'])==d['collector']['sha256'] and sha(d['collector']['manifest_path'])==d['collector']['manifest_sha256']
 for path,pin in d['raw_inputs_sha256'].items():assert sha(path)==pin
 selected=plan['lanes'][lane]['execute_suites'];fresh=plan['fresh_suites'][lane]
 old=d['lanes'][lane];assert set(old['rows'])==set(selected) and old['original_global_status']=='FAIL'
 retained={k:v for k,v in old['rows'].items() if k not in fresh}
 assert len(retained)=={'gcc':20,'clang':16,'san':20}[lane]
 checked=set()
 for name,v in retained.items():
  assert v['status']=='PASSED'
  c=row(v['junit_path'],name,v['junit_sha256'])
  assert hashlib.sha256(ET.tostring(c)).hexdigest()==v['normalized_row_sha256'] and dict(c.attrib)==v['testcase_attributes']
  for key in ('source_before','source_map','build_receipt','binary_before','commands'):
   assert sha(v[key+'_path'])==v[key+'_sha256']
  assert load(v['source_before_path'])==d['source_snapshot']
  if 'pretest_image' not in v:continue
  image=v['pretest_image'];arch=v['historical_image']
  assert image==old['all_compiled_images_unchanged'][v['target']]
  assert arch==d['historical_images'][image['sha256']] and arch['uncompressed_sha256']==image['sha256'] and arch['uncompressed_bytes']==image['bytes']
  if verify_images and arch['path'] not in checked:
   assert sha(arch['path'])==arch['sha256'] and Path(arch['path']).stat().st_size==arch['bytes']
   digest=hashlib.sha256();size=0
   with gzip.open(arch['path'],'rb') as stream:
    for block in iter(lambda:stream.read(1024*1024),b''):
     size+=len(block);assert size<=arch['uncompressed_bytes'];digest.update(block)
   assert size==arch['uncompressed_bytes'] and digest.hexdigest()==arch['uncompressed_sha256'];checked.add(arch['path'])
 return d,retained
def sdk_current(d):
 sdk=d['installed_sdk'];root=Path(sdk['install_root']).resolve()
 for rel,pin in sdk['files_sha256'].items():
  path=root/rel;assert not Path(rel).is_absolute() and '..' not in Path(rel).parts and path.resolve().is_relative_to(root)
  assert sha(path)==pin
def dependencies_current(d):
 for item in d['dependencies'].values():
  root=Path(item['path'])
  def command(*args):return subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
  assert command('rev-parse','HEAD')==item['commit'] and not command('status','--porcelain','--untracked-files=no')
  assert {rel:sha(root/rel) for rel in command('ls-files').splitlines()}==item['files_sha256']
def effective_origins(plan,lane,retained,out,images):
 origins={name:{'kind':'historical_named_pass','source_commit':BASE,**v} for name,v in retained.items()}
 for name in plan['fresh_suites'][lane]:
  c=row(out/'tests.xml',name,sha(out/'tests.xml'));target=plan['suites'][name]['target']
  origins[name]={'kind':'fresh_named_pass','source_commit':plan['source_commit'],'status':'PASSED',
   'junit_path':str(out/'tests.xml'),'junit_sha256':sha(out/'tests.xml'),'testcase_attributes':dict(c.attrib),
   'normalized_row_sha256':hashlib.sha256(ET.tostring(c)).hexdigest(),'target':target,'pretest_image':images[target],
   'source_before_path':str(out/'source-before.json'),'source_before_sha256':sha(out/'source-before.json'),
   'source_map_path':str(out/'source-map.json'),'source_map_sha256':sha(out/'source-map.json'),
   'build_receipt_path':str(out/'build-receipt.json'),'build_receipt_sha256':sha(out/'build-receipt.json'),
   'binary_before_path':str(out/'binary-before-tests.json'),'binary_before_sha256':sha(out/'binary-before-tests.json'),
   'commands_path':str(out/'commands.json'),'commands_sha256':sha(out/'commands.json')}
 assert set(origins)==set(plan['lanes'][lane]['execute_suites'])
 return origins
def verify_result(path,lane,source,live=False):
 verify_recipe();plan=load(H/'plan.json');d=load(path);out=Path(path).parent
 assert d['status']=='PASS_SCOPED_WITH_EXPLICIT_HISTORICAL_ORIGINS' and d['lane']==lane and d['source_commit']==source==plan['source_commit']
 assert d['plan_sha256']==sha(H/'plan.json') and d['qualification_recipe_sha256']==sha(H/'run.py')
 ref=plan['source_receipt'];assert d['source_amendment']==verify(source,ref['path'],ref['sha256'])
 old,retained=closeout(plan,lane);sdk_current(old);dependencies_current(old)
 assert d['closeout']==plan['closeout'] and d['provider']==old['provider'] and d['dependencies']==old['dependencies']
 assert d['fresh_suite_names']==plan['fresh_suites'][lane] and d['actual_fresh_suites']==len(plan['fresh_suites'][lane])
 assert d['suite_names']==plan['lanes'][lane]['execute_suites'] and d['effective_suites']==len(d['suite_names'])
 assert d['images_before']==d['images_after']==load(out/'binary-before-tests.json')==load(out/'binary-after-tests.json')
 assert d['effective_suite_origins']==effective_origins(plan,lane,retained,out,d['images_before'])
 assert d['tests_xml']==str(out/'tests.xml') and d['tests_xml_sha256']==sha(out/'tests.xml')
 rows=list(ET.parse(out/'tests.xml').iter('testcase'));assert len(rows)==len(plan['fresh_suites'][lane]) and {c.get('name') for c in rows}==set(plan['fresh_suites'][lane])
 commands=load(out/'commands.json');assert sha(out/'commands.json')==d['commands_sha256']
 assert len(commands)==6 and [x['name'] for x in commands]==['compiler','configure','build','inventory','tests','real-offline-tor']
 for c in commands:
  assert c['exit']==0 and 'exception' not in c and sha(c['log'])==c['log_sha256']
 assert load(out/'build-receipt.json')=={**commands[2],'source_manifest_sha256':sha(out/'source-map.json')}
 assert commands[4]['command']==['ctest','--test-dir',d['cache'],'--parallel','1','-R','^('+'|'.join(d['fresh_suite_names'])+')$','--output-on-failure','--output-junit',str(out/'tests.xml')]
 assert d['source_before_sha256']==sha(out/'source-before.json') and d['source_after_sha256']==sha(out/'source-after.json')
 assert load(out/'source-before.json')==load(out/'source-after.json')
 snapshot=load(out/'source-before.json');assert snapshot['source_commit']==source and snapshot['native_tree']==git('rev-parse','HEAD:preview/native')
 names=git('ls-files','preview/native','preview/migration/tools').splitlines()
 assert snapshot['files_sha256']=={name:sha(N/name) for name in names if (N/name).is_file()}
 assert d['original_failed_attempt']=={'path':old['lanes'][lane]['original_result_path'],'sha256':old['lanes'][lane]['original_result_sha256'],'status':'FAIL'}
 assert d['compiled_suites']==plan['lanes'][lane]['compile_suites'] and d['compile_only_suites']==[x for x in d['compiled_suites'] if x not in d['fresh_suite_names']]
 expected_scope={k:('actual_fresh_test' if k in {plan['suites'][x]['target'] for x in d['fresh_suite_names']} else 'compile_only_current_image') for k in d['images_before']}
 assert d['current_image_scope']==expected_scope
 assert d['original_java_reference']==plan['original_java_reference'];assert sha(d['original_java_reference']['path'])==d['original_java_reference']['sha256']
 real=load(out/'real-offline-tor/result.json');assert real==d['real_offline_tor'] and real['status']=='PASS_REAL_EXTRACTED_OFFLINE_TOR'
 assert real['source_commit']==source and real['source_amendment']==d['source_amendment']
 assert real['binary_sha256']==d['images_before']['biglybtc-tor-owned-child-tests']['sha256']
 for name,pin in real['retained_sha256'].items():assert sha(out/'real-offline-tor'/name)==pin
 if live:
  for v in d['images_after'].values():assert sha(v['path'])==v['sha256'] and Path(v['path']).stat().st_size==v['bytes']
 return d
