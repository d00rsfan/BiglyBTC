# Adopt after the rating64e Targets.cmake library/UI sources and bulk d569 files.
if(NOT TARGET biglybtc_local_rating_profile)
  message(FATAL_ERROR "Adopt the exact local rating host library before wiring")
endif()
target_link_libraries(biglybtc_desktop_host PRIVATE biglybtc_local_rating_profile)
add_executable(biglybtc-local-rating-wiring-tests
  "${PROJECT_SOURCE_DIR}/tests/local_rating_wiring_tests.cpp")
set_target_properties(biglybtc-local-rating-wiring-tests PROPERTIES AUTOMOC ON)
target_link_libraries(biglybtc-local-rating-wiring-tests PRIVATE
  biglybtc_desktop_host biglybtc_local_rating_profile Qt6::Test)
target_compile_options(biglybtc-local-rating-wiring-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
add_test(NAME local-rating-wiring COMMAND biglybtc-local-rating-wiring-tests)
set_tests_properties(local-rating-wiring PROPERTIES TIMEOUT 120 LABELS unit
  ENVIRONMENT "QT_QPA_PLATFORM=offscreen")
