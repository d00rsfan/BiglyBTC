Actual local azrating wiring, source only. Apply after bulk d5695059 and rating
64e47fac. Window beforeimages are the exact frozen bulk AFTER files; app
beforeimages are current production files. Other bulk sources/actions, queue/
storage/network behavior, existing tests and all DDB services are untouched.

Adopt the eight source paths and the small CMake fragment after rating64e's
library/dialog/test registration. Existing app sources gain only additive fields,
declarations, signal routes and included method bodies. Main connects them with
QPointer lifetime guards. No second lease, engine owner, scheduler, timer or
provider is created. Existing Bridge dispatch/completion machinery owns jobs.

Torrent menu and context menu share My rating… for exactly one selected current
ordinary target. Existing bulk file actions stay enabled for multi-selection.
Offline preview remains non-writing. The modal editor reads only on its explicit
first activation. The worker validates session/library revision/Target before
reading, retains one exact authorized request+32-byte attribute token, then
revalidates all of them before saving under the sole Host lease. A forged token,
stale generation, changed profile, unresolved magnet or interrupted storage
operation never obtains write authority. The adapter performs the final metadata/
attribute/cache CAS. No torrent is stopped or admitted to open/edit a rating.

Only an actual successful save/no-op returns saved=true. PublicationSuggested
is deliberately not turned into a DDB queue or a publish-success message. Errors
are typed to the bound dialog, preserve its draft and require reopening. Profile
changes/close drop old routes; missing result/queue rejection cannot leave a
permanently busy editor. Direct result/property callbacks may delete the dialog
or Window, and late packets do not reach a replacement editor.

New tests contain actual generated original-format port0 profile read/save via
Window→Bridge→held-lease adapter, unchanged primary resume/payload verification,
lease reacquisition after joined close, actual stale/forged-token refusal, and
synthetic bulk-action/profile/busy/deletion routing fixtures. Port0 explicitly
creates no engine owner or network service; it does not certify a DDB operation.
Compilation, test counts and runtime evidence are pending root's central batch.
