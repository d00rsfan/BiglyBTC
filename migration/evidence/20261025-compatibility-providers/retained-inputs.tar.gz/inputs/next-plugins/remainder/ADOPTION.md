Finite CF-07 slice: original azrating local attributes + editor. It reuses the
already qualified local-rating policy and Java UTF-8 replacement code. Existing
payload/state-update methods and all prior plugin fixtures stay byte-exact.
No DDB lookup/publication, queue/timer, plugin loading or network activation is
implemented or implied. Whole azrating remains in progress.

Root adoption:

- Apply changes.patch to the four existing files; copy the six new source files.
  Targets.cmake gives one focused desktop test registration. Link
  biglybtc_local_rating_profile to the Host target when wiring it. Do not replace
  an independently changed torrent_state file wholesale; the patch is additive.
- Expose My rating for one current Target. Root allocates a LocalRatingRequest
  with nonzero session/request/library revision and stable Target generation.
  Connect dialog readRequested to a worker readLocalRating(heldLease,hash).
  Recheck session/Target/revision before every read/save; no stopping is needed
  just to open/edit local attributes. Snapshot maps local.value.score/comment,
  invalidScoreText/recoveredBackup and32 raw revision bytes to LocalRatingValues.
- Connect saveRequested to saveLocalRating, copying score/comment UTF-16 and
  the32 token bytes. After successful durable return publish saved=true; after
  failure publish the error and require reopening. Do not claim failure proves
  no publication: resilient writer errors can occur after a replacement. The
  dialog retains the draft, disables retry and closes only after actual success.
- The revision is SHA256 of the complete authoritative attribute dictionary plus
  the current original nickname. It rejects concurrent attribute/nickname edits.
  Raw info identity is authenticated through the existing selected original hash
  helper. Full32 pure-v2 reader compatibility is explicit; no swarm admission is
  granted here. Duplicate/stale inventory targets reject before mutation.
- Primary/cache loading is read-only. The new attributes-only state path copies
  the actual cached properties, CAS-checks primary+cache, persists that baseline,
  removes only matching cache rows, then publishes attributes. This preserves the
  existing primary info/resume/other fields; it never calls beginUpdate/recheck
  on the primary. Backups retain the existing recheck-safe writer behavior.
- Original getters treat non-byte string attributes as absent. Existing unknown
  fields, cached rows and malformed score text survive a no-op. Explicit writes
  replace only rating/comment. Text is bounded to1MiB encoded bytes/1Mi UTF-16
  units; larger inputs reject rather than truncate. Java trim is <=U+0020;
  an empty nickname uses the original literal Anonymous. Negative saved scores
  remain inspectable/preservable; ordinary editor choices are0..5.

The widget emits only intentions, owns copied facts, defers initial request and
control refresh past Qt setter tails, and fences direct child/owner deletion.
Opening it performs no filesystem/provider action until root's worker binding.
Comment text is retained when unrated rather than replacing stored text with a
localized warning label. No global rating, stars aggregate or publish success
is fabricated. All test counts/results remain pending root execution.
