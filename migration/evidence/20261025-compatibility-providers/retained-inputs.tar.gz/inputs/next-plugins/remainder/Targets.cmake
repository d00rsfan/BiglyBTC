# Root adoption fragment; no existing CMake file is overwritten by this capsule.
# Include after profile/plugin/UI targets are declared in a desktop build.
find_package(OpenSSL REQUIRED COMPONENTS Crypto)
add_library(biglybtc_local_rating_profile STATIC
  "${PROJECT_SOURCE_DIR}/adapters/local_rating.cpp")
target_include_directories(biglybtc_local_rating_profile PUBLIC "${PROJECT_SOURCE_DIR}/adapters")
target_link_libraries(biglybtc_local_rating_profile PUBLIC biglybtc_profile biglybtc_rating_data PRIVATE OpenSSL::Crypto)
target_compile_features(biglybtc_local_rating_profile PUBLIC cxx_std_23)
target_compile_options(biglybtc_local_rating_profile PRIVATE -Wall -Wextra -Wpedantic -Werror)
target_sources(biglybtc_ui PRIVATE
  "${PROJECT_SOURCE_DIR}/ui/local_rating_dialog.cpp"
  "${PROJECT_SOURCE_DIR}/ui/local_rating_dialog.hpp")
add_executable(biglybtc-local-rating-tests "${PROJECT_SOURCE_DIR}/tests/local_rating_tests.cpp")
set_target_properties(biglybtc-local-rating-tests PROPERTIES AUTOMOC ON)
target_link_libraries(biglybtc-local-rating-tests PRIVATE
  biglybtc_ui biglybtc_local_rating_profile OpenSSL::Crypto ZLIB::ZLIB Qt6::Test)
target_compile_options(biglybtc-local-rating-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
add_test(NAME local-rating-host-ui COMMAND biglybtc-local-rating-tests)
set_tests_properties(local-rating-host-ui PROPERTIES TIMEOUT 120 LABELS unit
  ENVIRONMENT "QT_QPA_PLATFORM=offscreen")
