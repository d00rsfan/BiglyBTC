#!/usr/bin/env python3
"""Exact source-only composition. Does not configure/build/run/install/approve."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil
HERE = Path(__file__).resolve().parent
W = HERE.parent
PARENT = W/'provider-candidate'
SOCKS = W/'next-network/socks4a'
COUNTERS = W/'next-queue/combined-counters'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value): path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def map_files(root):
    result={}
    for leaf in sorted(root.rglob('*')):
        assert not leaf.is_symlink(), str(leaf)
        if leaf.is_file(): result[str(leaf.relative_to(root))]=sha(leaf)
    return result
record_path=PARENT/'approval-r3/provider-source-build-record.json'
runtime_path=PARENT/'approval-r3/provider-runtime.json'
assert sha(record_path)=='34bbba203833a31e59f0e9101f232fc2aaebe2bf080bdb8b640a29d68bd4016f'
assert sha(runtime_path)=='e74def09b2257a266786b8ddb116382d300716687bf26bbe57072f5ff90e8737'
record=json.loads(record_path.read_text())
assert record['artifact_sha256']=='d367afd6499859c5a57d66bddd352a977ff76c7fb76b5925302c2c9008c7ddbd'
assert sha(Path(record['artifact']))==record['artifact_sha256']
original=map_files(PARENT/'source');assert original==record['source_inputs_sha256'] and len(original)==1072
assert all(sha(PARENT/'build'/rel)==digest for rel,digest in record['build_files_sha256'].items())
assert all(sha(PARENT/'install'/rel)==digest for rel,digest in record['installed_sha256'].items())
socks_manifest=SOCKS/'manifest.json';counter_manifest=COUNTERS/'provider-manifest.json'
assert sha(socks_manifest)=='6a61e5644b78dbe57d80a26ee679a6b4bab3e6ca8e58976bb6c53f656b4c4414'
assert sha(counter_manifest)=='d64c8eac8094d753e51585e04aa9336562ddef05b2ebe45df9a8ad91c829b8aa'
socks=json.loads(socks_manifest.read_text());counter=json.loads(counter_manifest.read_text())
for rel,digest in socks['artifacts'].items(): assert sha(SOCKS/rel)==digest
socks_paths=socks['provider_source_sha256'];counter_paths=counter['source_sha256']
assert len(socks_paths)==7 and len(counter_paths)==4 and not set(socks_paths)&set(counter_paths)
inputs=[('SOCKS4a',SOCKS/'provider/staging',socks['provider_before_sha256'],socks_paths),
        ('TrafficV2',COUNTERS/'staging',counter['before_sha256'],counter_paths)]
for name,root,before,after in inputs:
    for rel,digest in after.items():
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
        assert sha(root/rel)==digest
        assert original.get(rel)==before[rel], (name,rel)
assert not (HERE/'manifest.json').exists()
if (HERE/'source').exists():
    # Only resume this unapproved source preparation when every existing byte
    # already equals the exact final inputs; no partially unknown tree is used.
    expected=dict(original);expected.update(socks_paths);expected.update(counter_paths)
    assert map_files(HERE/'source')==expected
else:
    (HERE/'source').mkdir()
    for rel,digest in original.items():
        target=HERE/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(PARENT/'source'/rel,target);assert sha(target)==digest
    for name,root,before,after in inputs:
        for rel,digest in after.items():
            target=HERE/'source'/rel;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(root/rel,target);assert sha(target)==digest
final=map_files(HERE/'source');assert len(final)==1074
changed=set(socks_paths)|set(counter_paths)
assert all(final[rel]==digest for rel,digest in original.items() if rel not in changed)
assert len(set(original)-changed)==1063
source_map=dict(record['source_sha256'])
for rel in changed:
    source_map[rel]=final[rel]
assert len(source_map)==451 and all(final[rel]==digest for rel,digest in source_map.items())
assert all(final[rel]==digest for rel,digest in record['source_build_rules_sha256'].items())
assert all(final[rel]==digest for rel,digest in record['bundled_dependency_sha256'].items())
# v1 declarations, value layout and function bodies must survive verbatim.
old_header=(PARENT/'source/include/libtorrent/biglybtc_payload_counters.hpp').read_text()
new_header=(HERE/'source/include/libtorrent/biglybtc_payload_counters.hpp').read_text()
assert new_header.startswith(old_header.rsplit('}\n#endif',1)[0])
old_cpp=(PARENT/'source/src/torrent_handle.cpp').read_text()
new_cpp=(HERE/'source/src/torrent_handle.cpp').read_text()
a=old_cpp.index('\textern "C" unsigned biglybtc_payload_counter_abi_v1()')
b=old_cpp.index('\n\tstd::shared_ptr<torrent> torrent_handle::native_handle()',a)
assert old_cpp[a:b].strip() in new_cpp
shutil.copy2(record_path,HERE/'parent-record.json')
shutil.copy2(runtime_path,HERE/'parent-runtime-manifest.json')
if (HERE/'socks4a-fixture').exists():
    assert map_files(HERE/'socks4a-fixture')==map_files(SOCKS/'provider/fixture')
else:
    shutil.copytree(SOCKS/'provider/fixture',HERE/'socks4a-fixture')
patch=[]
for rel in sorted(changed):
    a=(PARENT/'source'/rel).read_text().splitlines(True) if rel in original else []
    patch.extend(difflib.unified_diff(a,(HERE/'source'/rel).read_text().splitlines(True),fromfile='a/'+rel if rel in original else '/dev/null',tofile='b/'+rel))
(HERE/'changes.patch').write_text(''.join(patch))
old_exports=record['required_exports']
exports=old_exports+['biglybtc_socks4a_abi_v1',*counter['new_exports']]
plan={'status':'SOURCE_ONLY_NOT_BUILT_NOT_APPROVED','upstream_commit':record['upstream_commit'],
      'parent_record_sha256':sha(record_path),'parent_runtime_manifest_sha256':sha(runtime_path),
      'parent_metadata_sha256':{str(f):sha(f) for f in sorted((PARENT/'approval-r3').rglob('*')) if f.is_file()},
      'overlay_manifests_sha256':{'socks4a':sha(socks_manifest),'traffic_v2':sha(counter_manifest)},
      'source_inputs_sha256':final,'source_sha256':dict(sorted(source_map.items())),
      'source_build_rules_sha256':record['source_build_rules_sha256'],
      'bundled_dependency_sha256':record['bundled_dependency_sha256'],
      'before_sha256':{rel:original.get(rel) for rel in sorted(changed)},
      'source_changes_sha256':{rel:final[rel] for rel in sorted(changed)},
      'required_exports':exports,'v1_abi_bytes_and_export_bodies_unchanged':True,
      'build_targets':['torrent-rasterbar','test_biglybtc_swarm','test_biglybtc_utf16_info',counter['provider_target']],
      'provider_test_names':['test_biglybtc_swarm','test_biglybtc_utf16_info',counter['provider_target']],
      'artifact_sha256':None,'runtime_approval':False}
save(HERE/'source-plan.json',plan)
headers={rel:final[rel] for rel in set(record['installed_sha256'])|{'include/libtorrent/biglybtc_socks4a.hpp'} if rel.startswith('include/libtorrent/')}
assert len(headers)==276
expected_install=sorted(set(record['installed_sha256'])|{'include/libtorrent/biglybtc_socks4a.hpp'})
assert len(expected_install)==285
save(HERE/'sdk-plan.json',{'status':'EXPECTED_SOURCE_HEADERS_ONLY_ACTUAL_INSTALL_PENDING',
     'parent_installed_sha256':record['installed_sha256'],'expected_headers_sha256':headers,
     'expected_install_paths':expected_install,'actual_installed_sha256':None,'actual_artifact_sha256':None})
save(HERE/'composition.json',{'status':'SOURCE_ONLY_UNEXECUTED','parent_full_source_leaves':1072,
    'final_full_source_leaves':len(final),'parent_source_inputs':449,'final_source_inputs':len(source_map),
    'unchanged_parent_leaves':1063,'changed_existing_leaves':9,'added_leaves':2,
    'source_build_rules_unchanged':13,'bundled_dependencies_unchanged':16,
    'parent_installed_paths':284,'expected_new_installed_paths':285,'expected_header_count':276,
    'v1_header_and_export_bodies_byte_exact':True,'all_paths_disjoint':True,
    'no_current_provider_or_native_mutation':True,'actual_build_or_tests':None,'approval_created':False})
(HERE/'ADOPTION.md').write_text('''Future private provider source only; not built, tested, installed or approved.\n\nExact d367 parent source/build/install/approval remains untouched. Full1072-leaf parent was checked before copying; compose SOCKS4a6a61e564 seven paths with counter subsetd64c8eac four disjoint paths. The new source has1074leaves/451C++ inputs;1063old leaves remain exact,9existing leaves change and2are added. All13build rules and16bundled dependency inputs stay exact. v1 counter declarations/layout and export bodies are verbatim; old swarm/v1 markers remain required. New markers are feature probes, not authority.\n\nsource-plan.json binds every source leaf plus required exports; sdk-plan.json binds276expected source headers and285expected installed paths. Parent284installed hashes are retained; actual new artifact/install/build hashes remain absent until a root-authorized build. Empty future build/install paths are not current runtime locations.\n\nAfter root assigns compiler budget: run `python3 -B build_candidate.py --execute --jobs 1` from this directory. It uses fresh source/build/install roots, nice5 compiler jobs, exact parent compiler/options, three provider unit targets and standalone socks4a-fixture. Full command logs, CTest XML, actual SDK/runtime/export/build maps become execution-r1/candidate-source-build-record.json with UNAPPROVED status. The script never writes a runtime manifest/catalog/approval or changes native/build cache. Print-only invocation is optional; it does not configure. Current recipe is unexecuted.\n\nDirect provider tests cover ABI failure/output/actual executor contracts plus current swarm/raw-info regressions; standalone Qt4a fixture captures numeric USERID/remote-name frames, HTTP reply and refusal only on explicitly owned loopback routes. These do not qualify positive protocol accounting or mapped native admission. Codec stages the independent app positive protocol/reset test. Before adoption root must approve exact measured source/header/artifact, then explicitly bind a new catalog branch and compose wire/runtime runners against these exact1074/451maps. Current449runner/e74approval must reject this different artifact. Re-run real wire/proxy/counter and copied-runtime negatives in the later authorized batch; no conditional bypass or future approval is generated here.\n\nNative SOCKS4a remains rejected. The separate6a61native USERID refusal remains correct for currentd367. Original mixed tracker/data proxy protocols, unsupported Tor/I2P/UDP/bind routes and global/finality claims are not expanded. No production user profile or original application execution.\n''')
# Parse authored recipe text without importing or executing its bodies.
for name in ['prepare.py','build_candidate.py']:
    ast.parse((HERE/name).read_text(),filename=name)
artifacts={str(f.relative_to(HERE)):sha(f) for f in sorted(HERE.rglob('*')) if f.is_file()}
manifest={'schema':1,'status':'SOURCE_PREPARED_UNCOMPILED_UNEXECUTED_UNAPPROVED',
  'source_directory':'source','source_count':451,'full_source_count':1074,
  'parent_record_sha256':sha(record_path),'parent_runtime_manifest_sha256':sha(runtime_path),
  'overlay_manifest_sha256':plan['overlay_manifests_sha256'],
  'before_sha256':plan['before_sha256'],'source_sha256':plan['source_changes_sha256'],
  'complete_source_map':'source-plan.json','expected_sdk_map':'sdk-plan.json','artifacts':artifacts,
  'actual_artifact_sha256':None,'approval_created':False,'executions':[]}
save(HERE/'manifest.json',manifest)
assert map_files(PARENT/'source')==original
assert sha(Path(record['artifact']))==record['artifact_sha256']
assert all(sha(PARENT/'build'/rel)==digest for rel,digest in record['build_files_sha256'].items())
assert all(sha(PARENT/'install'/rel)==digest for rel,digest in record['installed_sha256'].items())
assert sha(record_path)==plan['parent_record_sha256'] and sha(runtime_path)==plan['parent_runtime_manifest_sha256']
print(json.dumps({'status':manifest['status'],'manifest_sha256':sha(HERE/'manifest.json'),
                  'full_source_count':len(final),'source_count':len(source_map),'headers_expected':len(headers),'install_paths_expected':len(expected_install)}))
