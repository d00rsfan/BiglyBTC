#!/usr/bin/env python3
"""Only repeat the built fixture with owned-loopback permission; no compiler."""
import hashlib,json,os,re,shutil,signal,subprocess,time
from pathlib import Path
import xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
OUT=HERE/'execution'
BUILD=ROOT/'socks-build-r2'
def need(v,why):
 if not v:raise RuntimeError(why)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def tree(root,links=False):
 result={}
 for f in sorted(root.rglob('*')):
  if f.is_symlink():need(links and f.resolve(strict=True).is_relative_to(root.resolve(strict=True)) and f.is_file(),'Unsafe path '+str(f))
  if f.is_file():result[str(f.relative_to(root))]=sha(f)
 return result

def main():
    need(not OUT.exists(),'Fresh fixture-only receipt required')
    m=ROOT/'manifest.json';need(sha(m)=='ff3e45844f7005d18a0a11ade922ab7ce90dd3660ad884cc4474cf5fb2ce6969','Source capsule changed')
    for rel,digest in json.loads(m.read_text())['artifacts'].items():need(sha(ROOT/rel)==digest,'Frozen input changed '+rel)
    plan=json.loads((ROOT/'source-plan.json').read_text());sdk=json.loads((ROOT/'sdk-plan.json').read_text());parent=json.loads((ROOT/'parent-record.json').read_text())
    r1=ROOT/'execution-r1';old=json.loads((r1/'commands.json').read_text());r2=ROOT/'continuations/r2/execution'
    before=json.loads((r2/'baseline.json').read_text());r2commands=json.loads((r2/'commands.json').read_text())
    need([r['name'] for r in r2commands]==['socks-configure','socks-build','socks-tests'] and all(r['exit_code']==0 for r in r2commands[:2]) and r2commands[2]['exit_code']!=0,'Unexpected r2 outcome')
    need(all(sha(r2/(r['name']+'.log'))==r['log_sha256'] for r in r2commands),'r2 log changed')
    need('Owned origin listen failed' in (r2/'socks-tests.log').read_text(),'Not the preserved listener-denied setup failure')
    need(all(r['exit_code']==0 and not r['timed_out'] for r in old[:4]) and old[4]['exit_code']==1,'r1 outcome changed')
    need(all(sha(r1/(r['name']+'.log'))==r['log_sha256'] for r in old),'r1 log changed')
    cases=ET.parse(r1/'provider-tests.xml').getroot().findall('.//testcase')
    need({c.get('name') for c in cases}==set(plan['provider_test_names']) and len(cases)==3 and all(not any(c.findall(t) for t in ('failure','error','skipped')) for c in cases),'Original provider tests not exact PASS')
    source=tree(ROOT/'source');need(source==before['source_inputs_sha256']==plan['source_inputs_sha256'],'Source changed')
    install=tree(ROOT/'install',True);need(install==before['installed_sha256'],'Install changed')
    build={r:sha(ROOT/'build'/r) for r in parent['build_files_sha256']};need(build==before['build_files_sha256'],'Provider build changed')
    fail_cache=tree(ROOT/'socks4a-build');need(fail_cache==before['failed_socks_cache_sha256'],'r1 failed cache changed')
    parent_source=tree(Path(parent['source_root']));need(parent_source==parent['source_inputs_sha256'],'Parent source changed')
    parent_install=tree(Path(parent['install_root']),True);need(parent_install==parent['installed_sha256'],'Parent install changed')
    parent_build={r:sha(Path(parent['build_root'])/r) for r in parent['build_files_sha256']};need(parent_build==parent['build_files_sha256'],'Parent build changed')
    parent_metadata={p:sha(Path(p)) for p in plan['parent_metadata_sha256']};need(parent_metadata==plan['parent_metadata_sha256'],'Parent approval changed')
    OUT.mkdir()
    if (BUILD/'Testing').exists():shutil.copytree(BUILD/'Testing',HERE/'r2-Testing-before-reuse')
    baseline=dict(before);baseline['recipe_sha256']=sha(Path(__file__));baseline['fixture_binary_sha256']=sha(BUILD/'biglybtc-socks4a-provider-tests');baseline['r2_commands_sha256']=sha(r2/'commands.json')
    save(OUT/'baseline.json',baseline)
    env={k:v for k,v in os.environ.items() if not k.startswith('BIGLYBTC_') and k not in ('LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH','PYTHONPATH','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH')}
    env.update(PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',LD_LIBRARY_PATH=str(ROOT/'install/lib')+':/opt/Qt/6.12.0/gcc_64/lib')
    argv=['ctest','--test-dir',str(BUILD),'-R','^socks4a-provider$','--verbose','--output-on-failure','--no-tests=error','--output-junit',str(OUT/'socks-tests.xml'),'--parallel','1']
    started=time.monotonic();timed_out=False;log=OUT/'socks-tests.log'
    with log.open('x') as stream:
     child=subprocess.Popen(argv,cwd=HERE,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
     while True:
      remaining=120-(time.monotonic()-started)
      if remaining<=0:
       timed_out=True
       try:os.killpg(child.pid,signal.SIGTERM)
       except ProcessLookupError:pass
       try:child.wait(timeout=5)
       except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
       break
      try:child.wait(timeout=min(30,remaining));break
      except subprocess.TimeoutExpired:print('socks-tests running; full log retained',flush=True)
    save(OUT/'commands.json',[{'name':'socks-tests','argv':argv,'exit_code':child.returncode,'timed_out':timed_out,'seconds':time.monotonic()-started,'log_sha256':sha(log)}])
    need(child.returncode==0 and not timed_out,'Actual socks fixture failed; raw log retained')
    need(sha(BUILD/'biglybtc-socks4a-provider-tests')==baseline['fixture_binary_sha256'],'Fixture binary changed')
    tests=ET.parse(OUT/'socks-tests.xml').getroot().findall('.//testcase')
    need(len(tests)==1 and tests[0].get('name')=='socks4a-provider'
      and not any(tests[0].findall(t) for t in ('failure','error','skipped')),'SOCKS fixture not exact PASS')
    totals=re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped',(OUT/'socks-tests.log').read_text())
    need(len(totals)==1,'Missing actual Qt rows')
    need(tree(ROOT/'source')==source and tree(ROOT/'install',True)==install,'Provider source/install changed during fixture')
    need({r:sha(ROOT/'build'/r) for r in build}==build,'Successful provider build changed')
    need(tree(ROOT/'socks4a-build')==fail_cache,'Failed r1 cache changed')
    need({f.name:sha(f) for f in r1.iterdir() if f.is_file()}==baseline['r1_logs_sha256'],'r1 receipts changed')
    need(tree(Path(parent['source_root']))==parent_source and tree(Path(parent['install_root']),True)==parent_install,'Qualified parent changed')
    need({r:sha(Path(parent['build_root'])/r) for r in parent_build}==parent_build and {p:sha(Path(p)) for p in parent_metadata}==parent_metadata,'Parent build/approval changed')
    artifact=ROOT/'install/lib/libtorrent-rasterbar.so.2.0.12'
    exports_text=subprocess.check_output(['nm','-D','--defined-only',str(artifact)],text=True);(OUT/'exports.txt').write_text(exports_text)
    exports={line.split()[-1].split('@')[0] for line in exports_text.splitlines() if line.split()}
    need(set(plan['required_exports'])<=exports,'Required ABI export missing')
    dynamic=subprocess.check_output(['readelf','--dynamic',str(artifact)],text=True);(OUT/'dynamic.txt').write_text(dynamic)
    need('Library soname: [libtorrent-rasterbar.so.2.0]' in dynamic,'SONAME changed')
    loaded=subprocess.check_output(['ldd',str(BUILD/'biglybtc-socks4a-provider-tests')],text=True,env=env);(OUT/'loader.txt').write_text(loaded)
    need(str(ROOT/'install/lib/libtorrent-rasterbar.so.2.0') in loaded and 'not found' not in loaded,'Fixture loaded another provider')
    cache={}
    for line in (ROOT/'build/CMakeCache.txt').read_text().splitlines():
      if line and not line.startswith(('#','//')) and '=' in line:
        key,value=line.split('=',1);cache[key]=value
    record={'schema':1,'status':'BUILT_AND_DIRECTLY_TESTED_CANDIDATE_NOT_APPROVED','causal_qualified':False,'native_runtime_approved':False,
      'parent_record_sha256':sha(ROOT/'parent-record.json'),'source_plan_sha256':sha(ROOT/'source-plan.json'),
      'capsule_manifest_sha256':sha(m),'upstream_commit':parent['upstream_commit'],
      'overlay_manifests_sha256':plan['overlay_manifests_sha256'],'source_root':str(ROOT/'source'),'build_root':str(ROOT/'build'),'install_root':str(ROOT/'install'),
      'source_inputs_sha256':source,'source_sha256':plan['source_sha256'],'source_build_rules_sha256':plan['source_build_rules_sha256'],
      'bundled_dependency_sha256':plan['bundled_dependency_sha256'],'installed_sha256':install,'build_files_sha256':build,'cache':cache,
      'artifact':str(artifact),'artifact_sha256':sha(artifact),'artifact_bytes':artifact.stat().st_size,'required_exports':plan['required_exports'],
      'export_scan_sha256':sha(OUT/'exports.txt'),'dynamic_section_sha256':sha(OUT/'dynamic.txt'),'elf_soname':'libtorrent-rasterbar.so.2.0',
      'r1_commands':str(r1/'commands.json'),'r1_commands_sha256':sha(r1/'commands.json'),'r1_provider_tests_xml_sha256':sha(r1/'provider-tests.xml'),
      'r2_commands':str(ROOT/'continuations/r2/execution/commands.json'),'r2_commands_sha256':sha(ROOT/'continuations/r2/execution/commands.json'),
      'r3_commands':str(OUT/'commands.json'),'r3_commands_sha256':sha(OUT/'commands.json'),'r3_socks_tests_xml_sha256':sha(OUT/'socks-tests.xml'),
      'direct_provider_test_names':plan['provider_test_names'],'actual_socks_qt_rows':int(totals[0]),
      'continuation_baseline_sha256':sha(OUT/'baseline.json'),'continuation_recipe_sha256':sha(Path(__file__)),
      'r1_provider_rebuilt_or_retested':False,'r1_failed_cache_preserved':True,'approval_or_catalog_created':False}
    save(OUT/'candidate-source-build-record.json',record)
    print(json.dumps({'status':record['status'],'artifact_sha256':record['artifact_sha256'],'record_sha256':sha(OUT/'candidate-source-build-record.json'),'socks_qt_rows':int(totals[0])}),flush=True)
if __name__=='__main__':main()
