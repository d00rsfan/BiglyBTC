#!/usr/bin/env python3
"""Future private provider build/direct qualification; never emits an approval."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
import xml.etree.ElementTree as ET
HERE = Path(__file__).resolve().parent
SOURCE, BUILD, INSTALL = (HERE / name for name in ('source', 'build', 'install'))

def require(value, text):
    if not value:
        raise RuntimeError(text)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def leaves(root):
    result = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'Source symlink: '+str(path))
        if path.is_file():
            result[str(path.relative_to(root))] = sha(path)
    return result

def installed(root):
    result = {}
    for path in sorted(root.rglob('*')):
        if not path.is_file() and not path.is_symlink():
            continue
        leaf = path.resolve(strict=True)
        require(leaf.is_relative_to(root.resolve(strict=True)) and leaf.is_file(), 'Install path escaped')
        result[str(path.relative_to(root))] = sha(leaf)
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', help='Run only after root grants compiler budget')
    parser.add_argument('--jobs', type=int, choices=(1,2,3), default=1)
    args = parser.parse_args()
    manifest = json.loads((HERE/'manifest.json').read_text())
    for relative, digest in manifest['artifacts'].items():
        require(sha(HERE/relative) == digest, 'Frozen input changed: '+relative)
    plan = json.loads((HERE/'source-plan.json').read_text())
    sdk = json.loads((HERE/'sdk-plan.json').read_text())
    require(leaves(SOURCE) == plan['source_inputs_sha256'], 'Complete source map changed')
    baseline = json.loads((HERE/'parent-record.json').read_text())
    parent_source = Path(baseline['source_root'])
    def check_parent():
        require(leaves(parent_source) == baseline['source_inputs_sha256'], 'Qualified parent source changed')
        require(installed(Path(baseline['install_root'])) == baseline['installed_sha256'], 'Qualified parent install changed')
        require(all(sha(Path(baseline['build_root'])/rel) == digest for rel,digest in baseline['build_files_sha256'].items()), 'Qualified parent build changed')
        require(all(sha(Path(path)) == digest for path,digest in plan['parent_metadata_sha256'].items()), 'Qualified parent approval metadata changed')
    check_parent()
    configure = ['cmake','-S',str(SOURCE),'-B',str(BUILD),'-G','Ninja',
        '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-16',
        '-DCMAKE_CXX_STANDARD=23','-DCMAKE_CXX_STANDARD_REQUIRED=ON','-DCMAKE_CXX_EXTENSIONS=OFF',
        '-DCMAKE_INSTALL_PREFIX='+str(INSTALL),'-DCMAKE_INSTALL_LIBDIR=lib',
        '-DCMAKE_PREFIX_PATH=/home/yurii/Java/BiglyBTC/build/dependencies/sysroot/usr',
        '-DCMAKE_POLICY_DEFAULT_CMP0167=NEW','-DBUILD_SHARED_LIBS=ON','-Dbuild_tests=ON',
        '-Dbuild_examples=OFF','-Dbuild_tools=OFF','-Dpython-bindings=OFF','-Dlogging=ON',
        '-Di2p=ON','-Ddht=ON','-Dencryption=ON','-Ddeprecated-functions=ON']
    commands = [
        ('configure',configure,180),
        ('build',['nice','-n','5','cmake','--build',str(BUILD),'--parallel',str(args.jobs),
                  '--target',*plan['build_targets'],'--','-k','0'],2400),
        ('install',['cmake','--install',str(BUILD)],120),
        ('provider-direct-tests',['ctest','--test-dir',str(BUILD),'-R',
                  '^('+ '|'.join(plan['provider_test_names']) +')$','--verbose','--output-on-failure','--no-tests=error','--output-junit',str(HERE/'execution-r1/provider-tests.xml'),'--parallel','1'],180),
        ('socks-configure',['cmake','-S',str(HERE/'socks4a-fixture'),'-B',str(HERE/'socks4a-build'),'-G','Ninja',
                  '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-16',
                  '-DCMAKE_PREFIX_PATH='+str(INSTALL)+';/opt/Qt/6.12.0/gcc_64',
                  '-DLibtorrentRasterbar_DIR='+str(INSTALL/'lib/cmake/LibtorrentRasterbar')],180),
        ('socks-build',['nice','-n','5','cmake','--build',str(HERE/'socks4a-build'),'--parallel',str(args.jobs)],300),
        ('socks-tests',['ctest','--test-dir',str(HERE/'socks4a-build'),'-R','^socks4a-provider$',
                       '--verbose','--output-on-failure','--no-tests=error','--output-junit',str(HERE/'execution-r1/socks-tests.xml'),'--parallel','1'],120)]
    if not args.execute:
        print(json.dumps({'status':'PLAN_ONLY_NO_EXECUTION','commands':[{'name':n,'argv':c,'timeout':t} for n,c,t in commands]},indent=2))
        return
    require(not BUILD.exists() and not INSTALL.exists() and not (HERE/'socks4a-build').exists(),
            'Use a fresh provider-next build/install; preserve prior attempts')
    output = HERE/'execution-r1'; output.mkdir(exist_ok=False)
    env = {k:v for k,v in os.environ.items() if not k.startswith('BIGLYBTC_') and k not in
           ('LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH','PYTHONPATH','QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH')}
    env.update(PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen')
    receipts = []
    for name, argv, timeout in commands:
        started = time.monotonic(); timed_out = False; log = output/(name+'.log')
        if name.startswith('socks-'):
            env['LD_LIBRARY_PATH'] = str(INSTALL/'lib')+':/opt/Qt/6.12.0/gcc_64/lib'
        with log.open('x') as stream:
            child = subprocess.Popen(argv,cwd=HERE,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            while True:
                remaining = timeout-(time.monotonic()-started)
                if remaining <= 0:
                    timed_out = True
                    try: os.killpg(child.pid,signal.SIGTERM)
                    except ProcessLookupError: pass
                    try: child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=5)
                    break
                try:
                    child.wait(timeout=min(30,remaining));break
                except subprocess.TimeoutExpired:
                    print(name+' running; full log retained',flush=True)
        receipts.append({'name':name,'argv':argv,'exit_code':child.returncode,'seconds':time.monotonic()-started,
                         'timed_out':timed_out,'log_sha256':sha(log)})
        save(output/'commands.json',receipts)
        require(not timed_out and child.returncode == 0,'Command failed: '+name)
        require(leaves(SOURCE) == plan['source_inputs_sha256'],'Source changed during build/test')
        print(name+' PASS',flush=True)
    raw = installed(INSTALL)
    require(set(raw) == set(sdk['expected_install_paths']),'Unexpected installed SDK/runtime inventory')
    require(all(raw[rel] == digest for rel,digest in sdk['expected_headers_sha256'].items()),'Installed/source SDK header mismatch')
    artifact = INSTALL/'lib/libtorrent-rasterbar.so.2.0.12'
    exports_text = subprocess.check_output(['nm','-D','--defined-only',str(artifact)],text=True)
    (output/'exports.txt').write_text(exports_text)
    exports = {line.split()[-1].split('@')[0] for line in exports_text.splitlines() if line.split()}
    require(set(plan['required_exports']) <= exports,'Required old/new ABI export missing')
    dynamic = subprocess.check_output(['readelf','--dynamic',str(artifact)],text=True)
    (output/'dynamic.txt').write_text(dynamic)
    require('Library soname: [libtorrent-rasterbar.so.2.0]' in dynamic,'Provider SONAME changed')
    check_parent()
    direct = {}
    for name,expected in [('provider-tests',set(plan['provider_test_names'])),('socks-tests',{'socks4a-provider'})]:
        tests = ET.parse(output/(name+'.xml')).getroot().findall('.//testcase')
        require(len(tests) == len(expected) and {case.get('name') for case in tests} == expected
                and all(not any(case.findall(tag) for tag in ('failure','error','skipped')) for case in tests), 'Incomplete direct test cohort: '+name)
        direct[name] = {'names':sorted(expected),'xml_sha256':sha(output/(name+'.xml'))}
    totals = re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped',(output/'socks-tests.log').read_text())
    require(len(totals) == 1,'Missing successful actual SOCKS Qt rows')
    direct['socks_qt_rows'] = int(totals[0])
    record = {'schema':1,'status':'BUILT_AND_DIRECTLY_TESTED_CANDIDATE_NOT_APPROVED',
        'causal_qualified':False,'native_runtime_approved':False,
        'parent_record_sha256':sha(HERE/'parent-record.json'),'source_plan_sha256':sha(HERE/'source-plan.json'),
        'capsule_manifest_sha256':sha(HERE/'manifest.json'),'upstream_commit':baseline['upstream_commit'],
        'source_root':str(SOURCE),'build_root':str(BUILD),'install_root':str(INSTALL),
        'source_inputs_sha256':plan['source_inputs_sha256'],'source_sha256':plan['source_sha256'],
        'source_build_rules_sha256':plan['source_build_rules_sha256'],
        'bundled_dependency_sha256':plan['bundled_dependency_sha256'],'installed_sha256':raw,
        'build_files_sha256':{rel:sha(BUILD/rel) for rel in baseline['build_files_sha256']},
        'artifact':str(artifact),'artifact_sha256':sha(artifact),'artifact_bytes':artifact.stat().st_size,
        'required_exports':plan['required_exports'],'export_scan_sha256':sha(output/'exports.txt'),
        'dynamic_section_sha256':sha(output/'dynamic.txt'),'commands_sha256':sha(output/'commands.json'),
        'direct_qualification':direct,'recipe_sha256':sha(Path(__file__))}
    save(output/'candidate-source-build-record.json',record)
    print(json.dumps({'status':record['status'],'artifact_sha256':record['artifact_sha256'],
                      'record_sha256':sha(output/'candidate-source-build-record.json')}))

if __name__ == '__main__':
    main()
