R2 preserves frozen chapter-private-portable/ and changes only exact source/focused qualification handling. Root-run only; no author execution.

    nice -n 5 python3 -B build/storage-20261025/chapter-private-portable-r2/qualify.py --gcc-case chapter-next-gcc-tests-r1 --focused-case chapter-fortified-gcc-tests-r1 --attempt run-r1

Use actual root stems if names differ. HEAD must be clean471ebb75fc66fefb0208b0d086a934b68aced84b. Implementation remains c8afff5311e4ff650b17d09651e3db440a0c93e8. The pinned shared union helper requires original40 and focused2 receipts, credits38+2 exactly once, and proves complete source maps differ only in the five pinned test-only fortified-read fixes. No identical fullsnapshot or40-rerun assertion.

All private b0e/3342/9085072, stage3287, old distdeef, one1-job build, positive frozen bins, five cohorts, deployment11/canonical origin, exact13Qt/28captures, six aliases/privateQt/ELF checks and no-promotion/scope boundaries are inherited. The runtime Python fixture stays byte-exact; only C++ drivers/link seams changed in471. Original recipe and failed SAN history remain intact. Root runs after actual GCC focused2 success and with the cache idle; result is private-only, not shipping/causal/DHT/public-wire/full-CF authority.
