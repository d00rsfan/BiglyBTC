# Append after existing RuntimeBindingTests.cmake in the private bound lane.
# This non-digest cannot select anything until root's exact approval amendment.
if(BIGLYBTC_LOCAL_ENGINE AND NOT BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST STREQUAL "")
  file(SHA256 "${BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST}" _biglybtc_next_provider_manifest)
  if(_biglybtc_next_provider_manifest STREQUAL "UNAPPROVED_PROVIDER_NEXT_MANIFEST")
    if(NOT TARGET biglybtc-runtime-interposition-driver OR NOT TARGET biglybtc-runtime-interposer
        OR NOT EXISTS "${BIGLYBTC_PERSISTENT_NEGATIVE_LT_LIBRARY}")
      message(FATAL_ERROR "Next-provider qualification requires all existing runtime rejection fixtures")
    endif()
    find_package(Python3 REQUIRED COMPONENTS Interpreter)
    add_test(NAME provider-next-runtime-inputs COMMAND "${Python3_EXECUTABLE}" -B
      "${CMAKE_CURRENT_SOURCE_DIR}/provider_next_runtime_inputs_tests.py")
    set_tests_properties(provider-next-runtime-inputs PROPERTIES TIMEOUT 120
      LABELS "unit;qualified-provider;source-binding" ENVIRONMENT "PYTHONDONTWRITEBYTECODE=1")
    add_executable(biglybtc-provider-next-runtime-deployment-driver runtime_deployment_driver.cpp)
    target_link_libraries(biglybtc-provider-next-runtime-deployment-driver PRIVATE
      biglybtc_local_engine LibtorrentRasterbar::torrent-rasterbar ${CMAKE_DL_LIBS})
    target_include_directories(biglybtc-provider-next-runtime-deployment-driver PRIVATE
      "${PROJECT_BINARY_DIR}/engine/runtime-binding")
    target_compile_options(biglybtc-provider-next-runtime-deployment-driver PRIVATE -Wall -Wextra -Wpedantic -Werror)
    target_link_options(biglybtc-provider-next-runtime-deployment-driver PRIVATE
      "LINKER:--wrap=open" "LINKER:--wrap=fstat" "LINKER:--wrap=read")
    add_test(NAME provider-next-runtime-deployment COMMAND "${Python3_EXECUTABLE}" -B
      "${CMAKE_CURRENT_SOURCE_DIR}/runtime_deployment_tests.py"
      --driver "$<TARGET_FILE:biglybtc-provider-next-runtime-deployment-driver>"
      --provider "/home/yurii/Java/BiglyBT/build/storage-20261025/provider-next/install/lib/libtorrent-rasterbar.so.2.0.12"
      --manifest "${BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST}" --mode provider-next
      --alternate "${BIGLYBTC_PERSISTENT_NEGATIVE_LT_LIBRARY}"
      --interposition-driver "$<TARGET_FILE:biglybtc-runtime-interposition-driver>"
      --preload "${_biglybtc_runtime_preload}")
    set_tests_properties(provider-next-runtime-deployment PROPERTIES TIMEOUT 180
      LABELS "unit;qualified-provider;runtime-binding" ENVIRONMENT "PYTHONDONTWRITEBYTECODE=1")
  endif()
endif()
