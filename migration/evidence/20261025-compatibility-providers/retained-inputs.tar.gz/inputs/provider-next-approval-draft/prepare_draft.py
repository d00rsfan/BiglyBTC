"""Authoring-only exact draft; hashes files, never loads provider or runs subjects."""
from pathlib import Path
import ast, difflib, hashlib, json, re, shutil
import xml.etree.ElementTree as ET
HERE=Path(__file__).resolve().parent
W=HERE.parent
NATIVE=Path('/home/yurii/Java/BiglyBTC/preview/native')
CANDIDATE=W/'provider-next'
BINDING=NATIVE/'engine/runtime-binding'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
md=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
save=lambda path,value:path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
record_path=CANDIDATE/'continuations/r3/execution/candidate-source-build-record.json'
assert sha(record_path)=='3fcd415424d71e6082022f8be6bb1a75036a0fbf3b228228813e1a4cee1ffdca'
record=json.loads(record_path.read_bytes())
parent_path=BINDING/'provider-source-build-record.json'
assert sha(parent_path)=='34bbba203833a31e59f0e9101f232fc2aaebe2bf080bdb8b640a29d68bd4016f'
parent=json.loads(parent_path.read_bytes())
subset=W/'next-queue/combined-counters/provider-manifest.json'
socks=W/'next-network/socks4a/manifest.json'
assert sha(subset)=='d64c8eac8094d753e51585e04aa9336562ddef05b2ebe45df9a8ad91c829b8aa'
assert sha(socks)=='6a61e5644b78dbe57d80a26ee679a6b4bab3e6ca8e58976bb6c53f656b4c4414'
left,right=json.loads(subset.read_bytes()),json.loads(socks.read_bytes())
assert not set(left['source_sha256'])&set(right['provider_source_sha256'])
changes=left['source_sha256']|right['provider_source_sha256']
before_changes=left['before_sha256']|right['provider_before_sha256']
assert len(changes)==11
expected_full=dict(parent['source_inputs_sha256']);expected_selected=dict(parent['source_sha256'])
for name,value in before_changes.items():assert expected_full.get(name)==value
expected_full.update(changes);expected_selected.update(changes)
assert record['source_inputs_sha256']==expected_full and record['source_sha256']==expected_selected
assert len(expected_full)==1074 and len(expected_selected)==451
for key,root,count in [('source_inputs_sha256','source_root',1074),('source_sha256','source_root',451),('source_build_rules_sha256','source_root',13),('bundled_dependency_sha256','source_root',16),('installed_sha256','install_root',285),('build_files_sha256','build_root',4)]:
 assert len(record[key])==count
 for relative,digest in record[key].items():assert sha(Path(record[root])/relative)==digest,(key,relative)
assert record['source_build_rules_sha256']==parent['source_build_rules_sha256']
assert record['bundled_dependency_sha256']==parent['bundled_dependency_sha256']
headers={name:value for name,value in record['installed_sha256'].items() if name.startswith('include/')}
assert len(headers)==276 and all(expected_full[name]==value for name,value in headers.items())
assert sha(Path(record['artifact']))==record['artifact_sha256']=='b0e55bfbdc2be5dc2ebbefc953837d64c9e5151b0305332335071e37b6956937'
assert Path(record['artifact']).stat().st_size==9085072
# Match the complete closed tree inventories without accepting new links/specials.
for root,key,aliases in [(Path(record['source_root']),'source_inputs_sha256',set()),(Path(record['install_root']),'installed_sha256',{'lib/libtorrent-rasterbar.so','lib/libtorrent-rasterbar.so.2.0'})]:
 actual=set()
 for path in root.rglob('*'):
  if path.is_symlink():
   rel=path.relative_to(root).as_posix();assert rel in aliases
   assert path.resolve(strict=True)==root/'lib/libtorrent-rasterbar.so.2.0.12'
  elif path.is_dir():continue
  else:assert path.is_file()
  actual.add(path.relative_to(root).as_posix())
 assert actual==set(record[key])
sourceplan=json.loads((CANDIDATE/'source-plan.json').read_bytes())
assert sourceplan['source_changes_sha256']==changes
assert record['source_plan_sha256']==sha(CANDIDATE/'source-plan.json')
# Pin existing original recipes + exact historical successes and failures.
evidence={name:sha(CANDIDATE/name) for name in ['manifest.json','source-plan.json','sdk-plan.json','build_candidate.py','continuations/manifest.json']}
for name,digest in json.loads((CANDIDATE/'continuations/manifest.json').read_bytes())['artifacts'].items():
 assert sha(CANDIDATE/'continuations'/name)==digest
 if name.endswith('candidate-source-build-record.json'):continue
 evidence['continuations/'+name]=digest
for path in (CANDIDATE/'execution-r1').iterdir():
 if path.is_file():evidence[path.relative_to(CANDIDATE).as_posix()]=sha(path)
for field in ['r1_commands','r2_commands','r3_commands']:
 path=Path(record[field]);assert sha(path)==record[field+'_sha256']
 for entry in json.loads(path.read_bytes()):assert sha(path.parent/(entry['name']+'.log'))==entry['log_sha256']
for relative,names in [('execution-r1/provider-tests.xml',record['direct_provider_test_names']),('continuations/r3/execution/socks-tests.xml',['socks4a-provider'])]:
 cases=ET.parse(CANDIDATE/relative).getroot().findall('.//testcase')
 assert len(cases)==len(names) and {case.get('name') for case in cases}==set(names)
 assert not any(case.findall(tag) for case in cases for tag in ['failure','error','skipped'])
text=(CANDIDATE/'continuations/r3/execution/socks-tests.log').read_text()
assert re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped',text)==['6']
scan=(CANDIDATE/'continuations/r3/execution/exports.txt').read_text();export_counts={name:0 for name in record['required_exports']}
for line in scan.splitlines():
 fields=line.split()
 if len(fields)==3 and fields[1] in ('T','W'):
  name=fields[2].split('@')[0]
  if name in export_counts:export_counts[name]+=1
assert len(export_counts)==12 and set(export_counts.values())=={1}
constants={
 'RECORD_SHA':sha(record_path),'PARENT_SHA':sha(parent_path),'PREVIOUS_VERIFIER_SHA':sha(BINDING/'verify_provider_runtime.py'),
 'CANDIDATE_ROOT':str(CANDIDATE),'ARTIFACT_SHA':record['artifact_sha256'],
 'SOURCE_MAP_SHA':md(record['source_sha256']),'FULL_SOURCE_MAP_SHA':md(record['source_inputs_sha256']),
 'RULES_MAP_SHA':md(record['source_build_rules_sha256']),'BUNDLED_MAP_SHA':md(record['bundled_dependency_sha256']),
 'INSTALL_KEYS_SHA':md(sorted(record['installed_sha256'])),'BUILD_KEYS_SHA':md(sorted(record['build_files_sha256'])),
 'CHANGES':changes,'BEFORE_CHANGES':before_changes,'OVERLAYS':record['overlay_manifests_sha256'],
 'EXPORTS':record['required_exports'],'DIRECT_TEST_NAMES':record['direct_provider_test_names'],
 'RECORD_KEYS':sorted(record),'EVIDENCE_PINS':evidence,
 'EXTERNAL_INPUT_PINS':{str(path.relative_to(W)):sha(path) for path in [subset,socks]},
}
# RECORD_KEYS is a set in the verifier; all remaining literals are JSON/Python-compatible except null.
code='\n'.join(name+' = '+repr(set(value) if name=='RECORD_KEYS' else value) for name,value in constants.items())
# Sort set representation deterministically.
code=code.replace('RECORD_KEYS = '+repr(set(constants['RECORD_KEYS'])),'RECORD_KEYS = set('+repr(constants['RECORD_KEYS'])+')')
staging=HERE/'staging/preview/native';before=HERE/'before/preview/native'
for root in [staging/'engine/runtime-binding',staging/'engine',staging/'tests',before/'engine/runtime-binding',before/'engine',before/'tests',HERE/'templates',HERE/'patches']:
 root.mkdir(parents=True,exist_ok=True)
newhelper=(HERE/'verify_provider_next_runtime.py.in').read_text().replace('# @EXACT_CONSTANTS@',code)
ast.parse(newhelper)
(staging/'engine/runtime-binding/verify_provider_next_runtime.py').write_text(newhelper)
# No actual manifest/record is minted. Root copies the exact original record only after review.
manifest={'schema':1,'purpose':'source-bound-qualification-only','causal_qualified':False,
 'source_build_record':'provider-next-source-build-record.json','source_build_record_sha256':sha(record_path),
 **{key:record[key] for key in ['source_root','build_root','install_root','artifact','artifact_sha256','artifact_bytes']}}
save(HERE/'templates/provider-next-runtime.json.in',manifest)
outer=(BINDING/'verify_runtime_manifest.py').read_text()
const='NEXT_PROVIDER_MANIFEST_SHA = "UNAPPROVED_PROVIDER_NEXT_MANIFEST"\n'
anchor='MANIFEST_KEYS = {';assert outer.count(anchor)==1
outer=outer.replace(anchor,const+anchor)
branch='''    # Separate exact next-provider proposal. Placeholder cannot admit a digest.
    if manifest_sha == NEXT_PROVIDER_MANIFEST_SHA:
        import importlib.util
        import sys
        from types import SimpleNamespace
        sys.dont_write_bytecode = True
        spec = importlib.util.spec_from_file_location("biglybtc_next_provider_runtime",
            Path(__file__).with_name("verify_provider_next_runtime.py"))
        provider = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(provider)
        common = SimpleNamespace(fail=fail, digest=digest, regular=regular,
            canonical_directory=canonical_directory, verify_map=verify_map, MANIFEST_KEYS=MANIFEST_KEYS)
        return provider.inspect(manifest_path, imported_library, imported_include, common)
'''
anchor='    # Additional exact provider lane.';assert outer.count(anchor)==1
outer=outer.replace(anchor,branch+anchor)
receipt='''    if manifest_sha == NEXT_PROVIDER_MANIFEST_SHA:
        args.receipt.write_text(json.dumps({"manifest_sha256": manifest_sha,
            "artifact_sha256": manifest["artifact_sha256"], "artifact": manifest["artifact"],
            "source_files": 451, "full_source_files": 1074, "build_rules": 13,
            "bundled_inputs": 16, "installed_files": 285, "sdk_headers": 276, "build_files": 4,
            "causal_qualified": False, "purpose": "source-bound-qualification-only",
            "provider_counter_swarm_socks_candidate": True}, indent=2) + "\\n")
        return
'''
anchor='    if manifest_sha == PROVIDER_MANIFEST_SHA:\n        args.receipt';assert outer.count(anchor)==1
outer=outer.replace(anchor,receipt+anchor)
assert outer.replace(receipt,'').replace(branch,'').replace(const,'')==(BINDING/'verify_runtime_manifest.py').read_text()
(staging/'engine/runtime-binding/verify_runtime_manifest.py').write_text(outer)
# Same old guard; disjoint relocation hunk composes with counter/SOCKS export proof changes.
guard=(NATIVE/'engine/persistent_runtime_guard.cpp').read_text()
function='''bool relocatableNextProviderArtifact() {
  // Proposal only. Root must replace the unapproved manifest after full review.
  // Every original export/mapping/FD/hash check below remains mandatory.
  return std::string_view(runtime_binding::manifest)
          == "UNAPPROVED_PROVIDER_NEXT_MANIFEST"
      && std::string_view(runtime_binding::sha256)
          == "b0e55bfbdc2be5dc2ebbefc953837d64c9e5151b0305332335071e37b6956937"
      && runtime_binding::bytes == 9085072ULL;
}
'''
assert guard.count('bool hashed(int descriptor) {')==1
guard=guard.replace('bool hashed(int descriptor) {',function+'bool hashed(int descriptor) {')
anchor='&& !relocatableSelectedProviderArtifact()))';assert guard.count(anchor)==1
guard=guard.replace(anchor,'&& !relocatableSelectedProviderArtifact() && !relocatableNextProviderArtifact()))')
assert guard.replace(function,'').replace('&& !relocatableSelectedProviderArtifact() && !relocatableNextProviderArtifact()))',anchor)==(NATIVE/'engine/persistent_runtime_guard.cpp').read_text()
(staging/'engine/persistent_runtime_guard.cpp').write_text(guard)
# Append one exact fixture mode; existing source/selected/strict branches stay verbatim.
deploy=(NATIVE/'tests/runtime_deployment_tests.py').read_text()
constant='NEXT_MANIFEST = "UNAPPROVED_PROVIDER_NEXT_MANIFEST"\nNEXT_IMAGE = "'+record['artifact_sha256']+'"\n'
deploy=deploy.replace('INSTRUMENTED = {',constant+'INSTRUMENTED = {',1)
deploy=deploy.replace('choices=("source", "selected", "strict")','choices=("source", "selected", "provider-next", "strict")')
deploy=deploy.replace('    parser.add_argument("--alternate", type=Path)','    parser.add_argument("--manifest", type=Path)\n    parser.add_argument("--alternate", type=Path)')
branch='''    elif args.mode == "provider-next":
        if (len(NEXT_MANIFEST) != 64 or not args.manifest or digest(args.manifest) != NEXT_MANIFEST
                or original_sha != NEXT_IMAGE or provider.stat().st_size != 9085072
                or not args.alternate or not args.interposition_driver or not args.preload):
            raise ValueError("UNAPPROVED next provider or missing exact relocation rejection controls")
        declared = json.loads(args.manifest.read_bytes())
        if (Path(declared["artifact"]).resolve(strict=True) != provider
                or declared["artifact_sha256"] != NEXT_IMAGE or declared["artifact_bytes"] != 9085072):
            raise ValueError("Next-provider relocation input differs from the exact manifest")
'''
anchor='    elif original_sha not in INSTRUMENTED:';assert deploy.count(anchor)==1
deploy=deploy.replace(anchor,branch+anchor)
assert deploy.replace(branch,'').replace('    parser.add_argument("--manifest", type=Path)\n','').replace('choices=("source", "selected", "provider-next", "strict")','choices=("source", "selected", "strict")').replace(constant,'')==(NATIVE/'tests/runtime_deployment_tests.py').read_text()
(staging/'tests/runtime_deployment_tests.py').write_text(deploy)
(staging/'tests/provider_next_runtime_inputs_tests.py').write_text((HERE/'provider_next_runtime_inputs_tests.py.in').read_text())
# Preserve the existing old portable source pin: only account for the additive outer verifier change.
packaging=NATIVE.parent/'migration/tools/stage_preview.py';pack=(packaging).read_text();oldpin=sha(BINDING/'verify_runtime_manifest.py');assert pack.count(oldpin)==1
pack=pack.replace(oldpin,sha(staging/'engine/runtime-binding/verify_runtime_manifest.py'))
packout=HERE/'staging/preview/migration/tools/stage_preview.py';packout.parent.mkdir(parents=True,exist_ok=True);packout.write_text(pack)
assert pack.replace(sha(staging/'engine/runtime-binding/verify_runtime_manifest.py'),oldpin)==packaging.read_text()
# Existing CMake admission module is unchanged; it already delegates to the outer verifier.
context={str(path.relative_to(NATIVE.parent.parent)):sha(path) for path in [BINDING/'PersistentRuntimeBinding.cmake',BINDING/'verify_provider_runtime.py',NATIVE/'tests/RuntimeBindingTests.cmake',NATIVE/'tests/runtime_deployment_driver.cpp',NATIVE/'tests/provider_runtime_inputs_tests.py']}
sources={};befores={}
for path in sorted((HERE/'staging').rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(HERE/'staging').as_posix();sources[rel]=sha(path)
 native=NATIVE.parent.parent/rel
 old=native.read_bytes() if native.is_file() else b'';befores[rel]=sha(native) if native.is_file() else None
 if native.is_file():
  target=HERE/'before'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(old)
 (HERE/'patches'/ (rel.replace('/','_')+'.patch')).write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),path.read_text().splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel)))
 if path.suffix=='.py':ast.parse(path.read_text())
review={'status':'INDEPENDENT_SOURCE_RECORD_REVIEW_PASS_NOT_APPROVAL','candidate_record_sha256':sha(record_path),
 'source_expected_from':'exact34bb parent + independently frozen6a61 socks7 +d64c traffic4 disjoint deltas',
 'source_full':1074,'source_selected':451,'changed_existing':9,'added':2,'rules':13,'bundled':16,'installed':285,'sdk_headers':276,
 'build_files':4,'artifact_sha256':record['artifact_sha256'],'artifact_bytes':9085072,'required_actual_exports':export_counts,
 'actual_direct_provider_suites':3,'actual_socks_rows':4,'actual_socks_qt_including_lifecycle':6,
 'history':'r1configure/build/install/providerPASS +failed socksconfigure; r2configure/buildPASS+failed sandbox test; r3actualSOCKSPASS retained exactly',
 'all_recorded_leaf_hashes_match':True,'closed_source_install_inventories_match':True,'source_rules_dependencies_unchanged':True,
 'old_verifier_branches_and_runtime_modes_exactly_reconstructable':True,
 'old_packaging_only_changed_pin_for_additive_outer_verifier':True,'no_loader_build_test_or_subject_execution':True,
 'catalog_or_approval_created':False,'root_final_approval_required':True}
save(HERE/'review.json',review)
save(HERE/'draft-inputs.json',{'before_sha256':befores,'source_sha256':sources,'immutable_context_sha256':context,'candidate_record':str(record_path),'candidate_record_sha256':sha(record_path)})
print(json.dumps({'source_paths':len(sources),'review_sha256':sha(HERE/'review.json'),'source_sha256':sources},indent=2))
