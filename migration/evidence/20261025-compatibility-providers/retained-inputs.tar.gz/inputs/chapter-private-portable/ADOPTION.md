Root-run private qualification recipe only. Author did not run/import the helper,
build, stage, load a library or execute a subject. No native files were changed.

After the actual new-provider GCC40 matrix has completed, with the shared cache
idle, root runs once (replace the case with its actual successful receipt stem):

    nice -n 5 python3 -B build/storage-20261025/chapter-private-portable/qualify.py \
      --gcc-case chapter-next-gcc-tests-r1 --attempt run-r1

The GCC receipt/XML/source map must prove exactly40 passing/no-skip suites and
match current source. HEAD must be clean and exactly
c8afff5311e4ff650b17d09651e3db440a0c93e8 throughout. The cache must select GCC16,
bundled Qt, Qualified payload lane, combined EXPECT1, causal OFF and exact3342.
stage_preview.py performs its unchanged complete pinned source/SDK/header/receipt
preflight before copying the exact b0e image. No candidate-derived approval.

One --parallel1 build requests only BiglyBTC, BiglyBTC-headless, preview smoke,
persistent-session tests and the dedicated provider-next deployment driver.
Persistent-session was outside the41-target matrix and must be rebuilt against
the new SDK. Other positive binaries and preload controls already belong to that
matrix; all targets receive a read-only Ninja freshness check. A stale result
fails closed; this recipe does not silently build again or relax the assertion.
Compiler TMPDIR is the existing canonical W/compiler-tmp, then cleared before
runtime fixtures. Root must not overlap another build in the same cache.

The fresh run-rN owns candidate/verification/environment. HOME/XDG are isolated;
the preview uses the existing generated /tmp/biglybtc-preview-* producer. Optional
old BIGLYBTC/LD/Qt environment controls are removed. No real profile is selected.
Old published dist deefcbe40681c1cd2d7352869be399d4e75d5d935a691bdc921fba11db71b221
is validated before/after; no promotion or rollback action exists in this helper.

Exact semantic delta from immutable next-portable/qualify.py:

1. New namespace/source c8a/private b0e9085072 +3342; explicit
   --private-source-provider-manifest; old dist baseline becomes deefcbe.
2. Actual completed GCC40 gate, exact source cleanliness, cache and recipe pins.
   One bounded build; inherited product/loader/staging command limits remain.
3. New copied managed-combined-protocol positive and its explicit EXPECT1;
   existing payload/selected/actual owner/managed-download positives retained.
   Copied programs use their registered CTest deadlines (no relaxation).
4. Dedicated provider-next deployment command/driver, same unchanged manifest,
   preload/interposition controls; exactly11 actual successful cases required.
5. Every positive copied executable loads PACKAGED b0e through private LD path.
   Deployment --provider stays the canonical exact b0e named by3342, because the
   unchanged fixture validates that relation then makes independent copies.
   These separate controls do not claim mutation of the packaged leaf.
6. Explicit six-alias full SHA/size/canonical-target checks, private Qt/ICU loader
   origins and all bundled ELF RPATH checks; only six LT alias runtime hashes may
   differ from old dist. Test-only Qt6Test may use the retained /opt Qt installation
   as before; shipping Qt/ICU libraries must resolve inside candidate/qt/lib.
7. Exact13 successful smoke Qt rows and28 retained PNG names (existing plan),
   copied/frozen positive bins, all logs/commands/loader/RPATH/runtime maps and
   relocation evidence retained. Source and old/candidate bundle bytes rechecked.
8. Result remains PRIVATE_B0E_RUNTIME_QUALIFIED_NOT_PROMOTED and
   distribution_scope=private-qualification-only. No shipping, causal/finality,
   DHT/public-wire, system-installation or full-CF closure credit. Actual results
   exist only if root later reaches verification/result.json successfully.
