#!/usr/bin/env python3
"""Retain this bounded chapter after root's actual qualification and source push.

Reads receipts/XML/maps; never builds, runs a subject, loads a DSO, or changes
native/tracking files. The sole output is a fresh evidence directory. Full member
hashes live inside the compressed archive, rather than a second large flat JSON.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import re
import stat
import tarfile
import xml.etree.ElementTree as ET


HERE = Path(__file__).resolve().parent
W = HERE.parent
REPO = W.parents[1]
NATIVE = REPO.parent / 'BiglyBTC'
DESTINATION = REPO / 'migration/evidence/20261025-compatibility-providers'
ORIGINAL = 'cb8c6cb9bb97916cbc7e80338a017200ffc3e71f'
SOURCE_COMMIT = 'c8afff5311e4ff650b17d09651e3db440a0c93e8'
PLAN = 'chapter-next-plan-r3.json'
PLAN_SHA = '08f33ea58ce8644a3ada1978881fb8d21ed1e76ce1966d0aa723815ed0b12dcf'
RECORD = 'provider-next/continuations/r3/execution/candidate-source-build-record.json'
RECORD_SHA = '3fcd415424d71e6082022f8be6bb1a75036a0fbf3b228228813e1a4cee1ffdca'
IMAGE_SHA = 'b0e55bfbdc2be5dc2ebbefc953837d64c9e5151b0305332335071e37b6956937'
PRIVATE_MANIFEST_SHA = '3342ec8ae72ecafa4a1b887e664d0d066fffce4f7d864b0b130ca903be953a3a'

# These are current-chapter sources/recipes, not the two authorized next stages.
SOURCE_ROOTS = (
    'compatibility-evidence',
    'next-chapter-composed', 'next-chapter-amended-r2',
    'next-queue/remainder', 'next-queue/probes', 'next-queue/combined-counters',
    'next-queue/combined-negative', 'next-queue/rate-providers',
    'next-queue/rate-provider-integration', 'next-queue/eta-facts',
    'next-storage/corners', 'next-workflows/remainder',
    'next-plugins/remainder', 'next-plugins/rating-wiring',
    'next-network/remainder', 'next-network/proxy-diagnostics',
    'next-network/proxy-peer-trace', 'next-network/wildcard-outgoing',
    'next-network/proxy-udp-control', 'next-network/socks4a',
    'provider-next-approval-draft', 'provider-next-portable-amendment',
    'chapter-original-plan',
)
EXCLUDED_PARTS = {'__pycache__', '.git', 'CMakeFiles', 'classes', 'class-output',
                  'verified-socks4a', 'pause-recovery', 'owned-tree'}
EXCLUDED_SUFFIXES = {'.a', '.o', '.obj', '.class', '.jar', '.zip', '.gz',
                     '.xz', '.zst', '.so', '.dll', '.exe', '.pyc'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def regular(path):
    """Reject links/specials, including aliased ancestors of an input."""
    path = Path(path)
    require(path.is_absolute(), 'Input must be absolute: ' + str(path))
    require(path.resolve(strict=True) == path, 'Aliased input: ' + str(path))
    require(stat.S_ISREG(path.lstat().st_mode), 'Not a regular input: ' + str(path))
    return path


def body(path):
    return regular(path).read_bytes()


def sha(path):
    return hashlib.sha256(body(path)).hexdigest()


def load(path):
    return json.loads(body(path))


def relative_input(value):
    require(isinstance(value, str) and value, 'Missing relative receipt path')
    p = Path(value)
    require(not p.is_absolute() and '..' not in p.parts, 'Receipt must stay under W')
    return regular(W / p)


def pin(path, digest):
    require(sha(path) == digest, 'Changed input: ' + str(path))


def passed_xml(path):
    rows = list(ET.fromstring(body(path)).iter('testcase'))
    names = [row.get('name') for row in rows]
    require(names and None not in names and len(names) == len(set(names)),
            'Empty/duplicate/malformed CTest rows: ' + str(path))
    require(all(row.find(tag) is None for row in rows
                for tag in ('failure', 'error', 'skipped')),
            'Failed/error/skipped row: ' + str(path))
    require(all(row.get('status', 'run') == 'run' for row in rows),
            'Unexecuted CTest row: ' + str(path))
    for row in rows:
        output = row.findtext('system-out') or ''
        require(not re.search(r'^SKIP\s*:', output, re.MULTILINE),
                'Skipped Qt row: ' + str(path))
        for failed, skipped in re.findall(r'Totals:\s*\d+ passed, (\d+) failed, (\d+) skipped', output):
            require(failed == skipped == '0', 'Failed/skipped Qt row: ' + str(path))
    return names


def verify_matrix(completion):
    pin(W / PLAN, PLAN_SHA)
    plan = load(W / PLAN)
    expected = set(plan['suites'])
    require(len(expected) == len(plan['suites']) == 40, 'Changed 40-suite plan')
    lanes = completion['lanes']
    require(set(lanes) == {'gcc', 'clang', 'sanitizers'}, 'Three lanes required')
    result, required_paths, common_map = {}, set(), None
    for lane, stems in lanes.items():
        require(isinstance(stems, list) and stems, 'Missing final receipts: ' + lane)
        observed, records = set(), []
        for stem in stems:
            require(isinstance(stem, str) and re.fullmatch(r'chapter-[A-Za-z0-9_-]+', stem),
                    'Use an actual root check.py case stem')
            paths = {suffix: regular(W / (stem + suffix))
                     for suffix in ('-receipt.json', '-source.json', '.xml', '.log')}
            receipt = load(paths['-receipt.json'])
            require(receipt.get('exit') == 0, 'Incomplete/failed receipt: ' + stem)
            command = receipt.get('command', [])
            require(isinstance(command, list) and 'ctest' in command and
                    '--output-junit' in command and str(paths['.xml']) in command,
                    'Not the actual CTest receipt: ' + stem)
            require(receipt.get('source_manifest_sha256') == sha(paths['-source.json']),
                    'Wrong test source map: ' + stem)
            source_map = load(paths['-source.json'])
            require(source_map and all(isinstance(k, str) and k.startswith('preview/native/')
                    and isinstance(v, str) and re.fullmatch('[0-9a-f]{64}', v)
                    for k, v in source_map.items()), 'Malformed source map: ' + stem)
            if common_map is None:
                common_map = source_map
            require(source_map == common_map,
                    'Final lane source maps differ; supply final coherent receipts: ' + stem)
            names = set(passed_xml(paths['.xml']))
            require(names <= expected, 'Unexpected suite in ' + stem)
            observed |= names
            records.append({'case': stem, 'suites': len(names),
                            'seconds': receipt['seconds'],
                            'files_sha256': {p.name: sha(p) for p in paths.values()}})
            required_paths.update(paths.values())
        require(observed == expected, 'Missing suites in ' + lane + ': ' +
                ', '.join(sorted(expected - observed)))
        result[lane] = {'suites': len(observed), 'actual_runs': records}
    return result, common_map, required_paths


def verify_originals():
    first = W / 'chapter-original-plan/run-r1/failure.json'
    r = load(first)
    # The aggregate failure is intentionally retained. Its two completed frames
    # remain actual successful observations; corners were rerun separately.
    require(r['status'] == 'FAIL', 'Historical failed run was rewritten')
    priority, probes = (r['completed_results'][key] for key in ('priority', 'probes'))
    require(priority['status'] == 'PASS' and priority['actual_frames'] == 2 and
            priority['actual_scalar_comparisons'] == 8, 'Missing actual priority results')
    require(probes['status'] == 'PASS' and probes['cases'] == 7 and
            probes['comparisons'] == 14 and probes['differences'] == [],
            'Missing actual probe comparison')
    for kind in ('original', 'native'):
        p = W / ('chapter-original-plan/run-r1/probes-' + kind + '.stdout')
        pin(p, probes[kind + '_stdout_sha256'])
    corner_path = W / 'chapter-original-plan/amendments/corner-classpath/run-r2/result.json'
    corners = load(corner_path)
    require(corners['status'] == 'PASS' and corners['original_commit'] == ORIGINAL and
            not corners['original_core_recompiled'] and
            not corners['original_profile_or_process_access'], 'Invalid corner run')
    actual = corners['results']['corners']
    require(actual['status'] == 'PASS' and len(actual['cases']) == 2 and
            {case['kind'] for case in actual['cases']} == {3, 4} and
            all(case['status'] == 'PASS' for case in actual['cases']), 'Missing actual corners')
    durable = corner_path.parent / 'corners-generated'
    for case in actual['cases']:
        for rel, digest in case['actual_input'].items():
            require(not Path(rel).is_absolute() and '..' not in Path(rel).parts,
                    'Unsafe original corner input path')
            pin(durable / ('kind-' + str(case['kind'])) / rel, digest)
    rate_path = W / 'next-queue/rate-providers/oracle/run-r1/observations.json'
    rate = load(rate_path)
    require(rate['status'] == 'PASS' and rate['actual_observations'] == 23 and
            len(rate['original']) == 23 and rate['original'] == rate['native'],
            'Missing actual original rate arithmetic equality')
    return {'priority_frames': 2, 'priority_scalars': 8, 'probe_cases': 7,
            'probe_comparisons': 14, 'nonlinear_corners': 2, 'rate_observations': 23,
            'evidence_sha256': {str(p.relative_to(W)): sha(p)
                                for p in (first, corner_path, rate_path)},
            'limits': ['Priority: actual READY/policy/calculation, not scheduler parity.',
                       'Probes: selected original DLR/ETA getter method frames only.',
                       'Corners: actual raw FMFile bytes, not GM progress.',
                       'Rates: retained average + selected method bodies in authored containers; '
                       'no bound target ETA or whole peer/plugin/timer equality.']}


def verify_provider_and_preflight():
    pin(W / RECORD, RECORD_SHA)
    record = load(W / RECORD)
    artifact = regular(Path(record['artifact']))
    require(record['artifact_bytes'] == artifact.stat().st_size == 9085072 and
            record['artifact_sha256'] == IMAGE_SHA, 'Wrong provider artifact')
    pin(artifact, IMAGE_SHA)
    binding = NATIVE / 'preview/native/engine/runtime-binding/provider-next-runtime.json'
    pin(binding, PRIVATE_MANIFEST_SHA)
    private = load(binding)
    require(private['purpose'] == 'source-bound-qualification-only' and
            private['causal_qualified'] is False and
            private['source_build_record_sha256'] == RECORD_SHA, 'Private scope changed')
    preflight_path = W / 'provider-next-portable-preflight/run-r1/result.json'
    preflight = load(preflight_path)
    require(preflight['status'] == 'PASS_READ_ONLY_PACKAGING_PREFLIGHT' and
            len(preflight['cases']) == 7 and
            all(row['status'] == 'PASS' for row in preflight['cases']) and
            preflight['original_inputs_unchanged'] and preflight['owned_tree_restored'] and
            not preflight['lt_loader_compiler_engine_or_staging_invoked'] and
            not preflight['packaging_main_called'] and
            not preflight['shipping_or_runtime_approval_created'], 'Missing actual preflight7')
    review = load(W / 'provider-next/root-review-r1.json')
    require(review['candidate_record_sha256'] == RECORD_SHA and
            review['artifact_sha256'] == IMAGE_SHA and
            review['source_leaves'] == 1074 and review['selected_leaves'] == 451 and
            review['installed_leaves'] == 285 and review['required_exports'] == 12 and
            review['provider_suites'] == 3 and review['actual_socks_cases'] == 4,
            'Wrong root source/artifact/SDK review')
    provider_xml = W / 'provider-next/execution-r1/provider-tests.xml'
    socks_xml = W / 'provider-next/continuations/r3/execution/socks-tests.xml'
    pin(provider_xml, record['r1_provider_tests_xml_sha256'])
    pin(socks_xml, record['r3_socks_tests_xml_sha256'])
    require(set(passed_xml(provider_xml)) == set(record['direct_provider_test_names']) and
            len(passed_xml(provider_xml)) == 3 and passed_xml(socks_xml) == ['socks4a-provider'],
            'Wrong direct provider suite evidence')
    return {'scope': 'PRIVATE_SOURCE_BOUND_QUALIFICATION_ONLY', 'artifact_sha256': IMAGE_SHA,
            'artifact_bytes': 9085072, 'manifest_sha256': PRIVATE_MANIFEST_SHA,
            'record_sha256': RECORD_SHA, 'source_leaves': 1074, 'selected_leaves': 451,
            'installed_leaves': 285, 'required_exports': 12, 'portable_preflight_cases': 7,
            'portable_preflight_sha256': sha(preflight_path),
            'new_causal_credit': False, 'shipping_approval': False,
            'native_socks4a_admission_qualified_by_this_chapter': False}, binding


def collect_inputs(required):
    inputs, exclusions = {}, {'compiled_or_archive': 0, 'symlink_or_special': 0}

    def add(path):
        if not path.exists() and not path.is_symlink():
            return
        if any(part in EXCLUDED_PARTS for part in path.relative_to(W).parts):
            return
        if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
            exclusions['symlink_or_special'] += 1
            return
        if path.suffix in EXCLUDED_SUFFIXES or '.so.' in path.name:
            exclusions['compiled_or_archive'] += 1
            return
        with path.open('rb') as stream:
            magic = stream.read(8)
        if magic.startswith((b'\x7fELF', b'!<arch>\n', b'\xca\xfe\xba\xbe')):
            exclusions['compiled_or_archive'] += 1
            return
        regular(path)
        require(path.stat().st_size <= 64 * 1024 * 1024, 'Unexpected bulky leaf: ' + str(path))
        inputs[str(path.relative_to(W))] = path

    for rel in SOURCE_ROOTS:
        root = W / rel
        require(root.is_dir(), 'Missing current source capsule: ' + rel)
        for path in sorted(root.rglob('*')):
            if path.is_file() or path.is_symlink():
                add(path)
    # Source/build maps and all r1/r2/r3 failure/continuation receipts, without the
    # whole provider source, build, SDK, DSO, or previous immutable evidence bundle.
    provider = W / 'provider-next'
    for path in sorted(provider.iterdir()):
        if path.is_file():
            add(path)
    for rel in ('provider-next/execution-r1', 'provider-next/continuations',
                'provider-next/socks4a-fixture'):
        for path in sorted((W / rel).rglob('*')):
            if path.is_file() or path.is_symlink():
                add(path)
    # Preserve every current chapter attempt, not just the final successful XML.
    for path in sorted(W.iterdir()):
        if path.name.startswith('chapter-'):
            if path.is_file():
                add(path)
            elif path.is_dir():
                for child in sorted(path.rglob('*')):
                    if child.is_file() or child.is_symlink():
                        add(child)
    preflight = W / 'provider-next-portable-preflight'
    for path in sorted(preflight.rglob('*')):
        if (path.is_file() or path.is_symlink()) and 'owned-tree' not in path.parts:
            add(path)
    for rel in ('compile.py', 'check.py', 'run_matrix_build.py', 'current-checkpoint.json',
                'tmp-cache-relief-r1/receipt.json', 'tmp-cache-relief-r1/plan.json',
                'tmp-cache-relief-r1/files.json'):
        path = W / rel
        if path.exists():
            add(path)
    for path in sorted(HERE.iterdir()):
        if path.is_file():
            add(path)
    for path in required:
        add(path)
        require(str(path.relative_to(W)) in inputs, 'Required evidence excluded: ' + str(path))
    require(sum(p.stat().st_size for p in inputs.values()) <= 256 * 1024 * 1024,
            'Unexpected evidence growth; inspect scope rather than bulk-copy caches')
    return inputs, exclusions


def archive_inputs(destination, inputs):
    members = {rel: {'sha256': sha(p), 'bytes': p.stat().st_size}
               for rel, p in sorted(inputs.items())}
    member_body = (json.dumps({'root': str(W), 'files': members}, sort_keys=True,
                             separators=(',', ':')) + '\n').encode()
    archive_path = destination / 'retained-inputs.tar.gz'
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for rel, p in sorted(inputs.items()):
                    data = body(p)
                    require(hashlib.sha256(data).hexdigest() == members[rel]['sha256'],
                            'Input changed during retention: ' + rel)
                    info = tarfile.TarInfo('inputs/' + rel)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    archive.addfile(info, io.BytesIO(data))
                info = tarfile.TarInfo('MEMBERS.json')
                info.size, info.mode, info.mtime = len(member_body), 0o644, 0
                archive.addfile(info, io.BytesIO(member_body))
    return {'path': archive_path.name, 'sha256': sha(archive_path),
            'bytes': archive_path.stat().st_size, 'input_members': len(members),
            'uncompressed_input_bytes': sum(row['bytes'] for row in members.values()),
            'member_manifest': 'MEMBERS.json',
            'member_manifest_sha256': hashlib.sha256(member_body).hexdigest()}


def write_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completion', required=True,
                        help='Root-filled completion JSON, relative to W')
    parser.add_argument('--write', action='store_true',
                        help='Create the fresh fixed evidence directory after all checks')
    args = parser.parse_args()
    require(REPO == Path('/home/yurii/Java/BiglyBT'), 'Unexpected repository')
    completion_path = relative_input(args.completion)
    completion = load(completion_path)
    require(completion.get('schema') == 1, 'Unsupported completion schema')
    source = completion.get('native_source')
    require(source == SOURCE_COMMIT,
            'Require actual c8a chapter source; a later source needs separate review')
    commit_path = relative_input(completion['source_commit_receipt'])
    push_path = relative_input(completion['source_push_receipt'])
    commit, push = load(commit_path), load(push_path)
    require(commit.get('source_commit') == source and
            commit.get('all_staged_blob_bytes_verified') is True and
            isinstance(commit.get('paths_sha256'), dict) and len(commit['paths_sha256']) == 67,
            'Require actual current source commit and67 blob-verified paths')
    push_sources = [push[k] for k in ('source', 'source_commit') if k in push]
    require(push_sources and all(v == source for v in push_sources) and push.get('exit') == 0,
            'Actual matching source push receipt required')
    matrix, source_map, required = verify_matrix(completion)
    originals = verify_originals()
    provider, binding = verify_provider_and_preflight()
    required.update((completion_path, commit_path, push_path, W / PLAN))
    for value in completion.get('additional_receipts', []):
        required.add(relative_input(value))
    inputs, exclusions = collect_inputs(required)
    # No output is created by the default read-only verification mode.
    if not args.write:
        print(json.dumps({'status': 'READY_TO_RETAIN_CURRENT_LOCAL_EVIDENCE',
                          'native_source': source, 'lanes': {k: v['suites'] for k, v in matrix.items()},
                          'input_files': len(inputs), 'destination': str(DESTINATION)}))
        return
    require(not DESTINATION.exists() and not DESTINATION.is_symlink(), 'Evidence already exists')
    require(DESTINATION.parent.resolve(strict=True) == DESTINATION.parent, 'Aliased evidence root')
    DESTINATION.mkdir(mode=0o755)
    # Deliberately retain a visible incomplete marker after interruption; never
    # overwrite or silently resume a partly produced evidence namespace.
    marker = DESTINATION / 'INCOMPLETE.json'
    write_json(marker, {'status': 'RETENTION_IN_PROGRESS', 'completion_sha256': sha(completion_path)})
    try:
        archive = archive_inputs(DESTINATION, inputs)
        source_map_bytes = (json.dumps(source_map, sort_keys=True, separators=(',', ':')) + '\n').encode()
        (DESTINATION / 'qualified-source-map.json.gz').write_bytes(gzip.compress(source_map_bytes, mtime=0))
        (DESTINATION / 'private-provider-manifest.json').write_bytes(body(binding))
        (DESTINATION / 'root-completion.json').write_bytes(body(completion_path))
        record = {'schema': 1, 'status': 'LOCAL_BOUNDED_CHAPTER_QUALIFIED_SOURCE_PUSHED',
                  'native_source': source, 'original_baseline': ORIGINAL,
                  'prior_basis': '../20261025-v2-workflows/verification.json',
                  'matrix': matrix, 'actual_original_observations': originals,
                  'private_provider': provider, 'retained_archive': archive,
                  'excluded_inputs': exclusions,
                  'source_map_sha256': hashlib.sha256(source_map_bytes).hexdigest(),
                  'source_map_entries': len(source_map),
                  'hosted_qualification_claim': False, 'portable_promotion_claim': False,
                  'whole_compatibility_complete': False, 'target_eta_bound': False,
                  'native_socks4a_or_imported_scheduler_claim': False,
                  'sanitizer_scope': 'Native ASan/UBSan/leaks; provider remains uninstrumented. '
                                     'No inherited causal-counter certification is renewed.',
                  'source_receipts_sha256': {str(p.relative_to(W)): sha(p)
                                             for p in (completion_path, commit_path, push_path)}}
        write_json(DESTINATION / 'verification.json', record)
        text = (HERE / 'REVIEW.draft.md').read_text()
        text = text.replace('PENDING_NATIVE_SOURCE', source)
        text = text.replace('Final 40-suite cohort per lane; pending until actual receipts validate',
                            '40/40 passed in each final lane; actual receipts/maps retained')
        text = text.replace('DRAFT_PENDING_FINAL_LANES_AND_SOURCE_PUSH',
                            'LOCAL_QUALIFIED_SOURCE_PUSHED; HOSTED/PROMOTION RECORDED SEPARATELY')
        (DESTINATION / 'REVIEW.md').write_text(text)
        (DESTINATION / '.gitattributes').write_text('* -text\n')
        write_json(DESTINATION / 'artifacts.json', {
            'files_sha256': {p.name: sha(p) for p in sorted(DESTINATION.iterdir())
                             if p.is_file() and p != marker},
            'full_member_map': 'retained-inputs.tar.gz:MEMBERS.json'})
        marker.unlink()
    except BaseException:
        # A partial output is evidence of an interrupted attempt, not a completed
        # archive. Root may preserve it under a distinct name before another run.
        raise
    print(json.dumps({'status': record['status'], 'destination': str(DESTINATION),
                      'archive_members': archive['input_members'],
                      'archive_bytes': archive['bytes']}))


if __name__ == '__main__':
    main()
