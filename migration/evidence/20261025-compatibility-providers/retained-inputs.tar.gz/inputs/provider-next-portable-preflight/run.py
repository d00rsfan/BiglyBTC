#!/usr/bin/env python3
"""Root-run read-only packaging preflight; no packaging main/loader/subprocess.

Only the fresh run-* child beside this script is written. Mutations are restored
in one owned copied binding tree. Original providers/caches/bindings are inputs.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PACKAGING_SHA = "3287dc0627f9862a9b3a25d22c86abaa492b4c894a07c6c606aa03d7c973c387"
OLD_MANIFEST = "e74def09b2257a266786b8ddb116382d300716687bf26bbe57072f5ff90e8737"
NEW_MANIFEST = "3342ec8ae72ecafa4a1b887e664d0d066fffce4f7d864b0b130ca903be953a3a"
OLD_IMAGE = "d367afd6499859c5a57d66bddd352a977ff76c7fb76b5925302c2c9008c7ddbd"
NEW_IMAGE = "b0e55bfbdc2be5dc2ebbefc953837d64c9e5151b0305332335071e37b6956937"
BINDING_PINS = {
    "provider-runtime.json": OLD_MANIFEST,
    "provider-next-runtime.json": NEW_MANIFEST,
    "provider-source-build-record.json": "34bbba203833a31e59f0e9101f232fc2aaebe2bf080bdb8b640a29d68bd4016f",
    "provider-next-source-build-record.json": "3fcd415424d71e6082022f8be6bb1a75036a0fbf3b228228813e1a4cee1ffdca",
    "source-build-record.json": "436931d4c6b87274c60b89877afedc19e06485bc4f04d120a3ab3e1889abfc66",
    "verify_runtime_manifest.py": "db8dc81c8d2baf5cf3859d5706bacbea68253866bdbfc03b19d24cdcf2a7cb6c",
    "verify_provider_next_runtime.py": "0922c9960a507c0b453b240ba3ca5b56c595eaf256fbcf5ce4bcf2d968b88e32",
    "verify_provider_runtime.py": "fc9ae8203bb6f32f94d57a05c5ea174944bdf1dbbe41ae51d9caf987ac01d89a",
}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stamp(path):
    value = path.stat()
    return (value.st_dev, value.st_ino, value.st_mode, value.st_size, value.st_mtime_ns)


def regular(path):
    require(path.is_absolute() and path == path.resolve(strict=True)
            and not path.is_symlink() and stat.S_ISREG(path.stat().st_mode), "Noncanonical regular input: " + str(path))
    return path


def directory(path):
    require(path.is_absolute() and path == path.resolve(strict=True)
            and not path.is_symlink() and path.is_dir(), "Noncanonical directory input: " + str(path))
    return path


def tree(root):
    result = {}
    for path in sorted(root.rglob("*")):
        require(not path.is_symlink(), "Unexpected link in owned copied tree")
        if path.is_dir():
            continue
        result[path.relative_to(root).as_posix()] = digest(regular(path))
    return result


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--native", required=True, type=Path)
    parser.add_argument("--packaging-script", type=Path,
                        help="Exact3287 adopted file or immutable staged afterimage; copied before import")
    parser.add_argument("--old-build", required=True, type=Path)
    parser.add_argument("--new-build", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path,
                        help="Fresh run-* child of this durable harness directory")
    args = parser.parse_args()
    native, old_build, new_build = [directory(value) for value in (args.native, args.old_build, args.new_build)]
    require(old_build != new_build, "Old/new qualified caches must be distinct")
    source_script = regular(args.packaging_script or native.parent / "migration/tools/stage_preview.py")
    require(digest(source_script) == PACKAGING_SHA, "Adopt/package the exact frozen3287 source amendment first")
    binding = directory(native / "engine/runtime-binding")
    for name, expected in BINDING_PINS.items():
        require(digest(regular(binding / name)) == expected, "Changed original binding input: " + name)
    old_record = json.loads((binding / "provider-source-build-record.json").read_bytes())
    binding_pins = dict(BINDING_PINS)
    for name, field in (("provider-dynamic-symbols.txt", "export_scan_sha256"),
                        ("provider-dynamic-section.txt", "dynamic_section_sha256")):
        binding_pins[name] = old_record[field]
        require(digest(regular(binding / name)) == old_record[field], "Changed original static ELF evidence")
    old_manifest = json.loads((binding / "provider-runtime.json").read_bytes())
    new_manifest = json.loads((binding / "provider-next-runtime.json").read_bytes())
    old_image, new_image = [regular(Path(value["artifact"])) for value in (old_manifest, new_manifest)]
    require(digest(old_image) == OLD_IMAGE and digest(new_image) == NEW_IMAGE, "Changed original provider image")
    observed = [source_script, *[binding / name for name in binding_pins], old_image, new_image]
    configured_compilers = {}
    for build in (old_build, new_build):
        cache = regular(build / "CMakeCache.txt")
        compilers = [line.split("=", 1)[1] for line in cache.read_text().splitlines()
                     if line.startswith("CMAKE_CXX_COMPILER:")]
        require(len(compilers) == 1, "Missing/ambiguous configured compiler")
        expected = "/usr/bin/g++-16" if build == old_build else "/usr/bin/clang++-24"
        require(compilers[0] == expected, "Pass the actual old GCC16 and new Clang24 caches")
        configured_compilers[str(build)] = compilers[0]
        observed.append(cache)
        observed.extend(regular(build / "engine/runtime-binding" / name)
                        for name in ("configure-receipt.json", "persistent_runtime_config.hpp"))
    original_pins = {str(path): digest(path) for path in observed}
    original_stamps = {str(path): stamp(path) for path in observed}
    output = args.output
    require(output.is_absolute() and output.parent == HERE and output.name.startswith("run-")
            and not output.exists() and not output.is_symlink(), "Use a fresh run-* child beside the harness")
    require(HERE.stat().st_uid == os.getuid(), "Harness/output parent is not owned by this user")
    output.mkdir(mode=0o700)
    save(output / "input-pins.json", original_pins)
    save(output / "input-stamps.json", original_stamps)
    owned = output / "owned-tree"
    script = owned / "preview/migration/tools/stage_preview.py"
    copied = owned / "preview/native/engine/runtime-binding"
    script.parent.mkdir(parents=True)
    copied.mkdir(parents=True)
    script.write_bytes(source_script.read_bytes())
    for name in binding_pins:
        (copied / name).write_bytes((binding / name).read_bytes())
    baseline = tree(owned)
    save(output / "owned-baseline.json", baseline)
    rows = []
    current = {"name": "initialization"}
    try:
        spec = importlib.util.spec_from_file_location("owned_portable_preflight_source", script)
        packaging = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(packaging)  # Definitions only; __main__ is not called.

        def recorded(name, action, expected=None):
            nonlocal current
            current = {"name": name, "expected": "accept" if expected is None else "refuse"}
            try:
                result = action()
            except ValueError as error:
                if expected is None:
                    raise
                message = str(error)
                require(expected in message, "Unexpected refusal boundary: " + message)
                current["refusal"] = message[:2048]
            else:
                require(expected is None, "Invalid private preflight unexpectedly accepted")
                source, payload = result
                wanted = OLD_IMAGE if name == "old-e74-d367-old-gcc" else NEW_IMAGE
                require(source == (old_image if wanted == OLD_IMAGE else new_image)
                        and hashlib.sha256(payload).hexdigest() == wanted, "Accepted the wrong immutable image")
                current.update(artifact_sha256=wanted, artifact_bytes=len(payload))
            current["status"] = "PASS"
            rows.append(dict(current))
            save(output / "cases.json", rows)
            print(name + " PASS", flush=True)

        new_call = lambda: packaging.private_next_source_libtorrent(new_image, copied / "provider-next-runtime.json", new_build)
        recorded("old-e74-d367-old-gcc", lambda: packaging.selected_source_libtorrent(
            old_image, copied / "provider-runtime.json", old_build))
        recorded("private-b0e-3342-new-clang", new_call)
        recorded("private-new-vs-old-gcc-binding", lambda: packaging.private_next_source_libtorrent(
            new_image, copied / "provider-next-runtime.json", old_build),
            "Application was not configured against this exact private provider/SDK")
        recorded("old-manifest-cannot-enter-private-route", lambda: packaging.private_next_source_libtorrent(
            new_image, copied / "provider-runtime.json", new_build),
            "Changed/unqualified private-provider input")
        for name, leaf, replacement in (
                ("changed-private-record", "provider-next-source-build-record.json", b"{}\n"),
                ("changed-new-recursive-helper", "verify_provider_next_runtime.py", None),
                ("changed-old-recursive-helper", "verify_provider_runtime.py", None)):
            path = copied / leaf
            before = path.read_bytes()
            try:
                path.write_bytes(replacement if replacement is not None else before
                                 + b'\nraise RuntimeError("owned altered helper must never execute")\n')
                require(digest(path) != binding_pins[leaf], "Mutation did not change the copied input")
                recorded(name, new_call, "Changed/unqualified private-provider input: " + str(path))
                rows[-1]["owned_changed_sha256"] = digest(path)
                save(output / "cases.json", rows)
            finally:
                path.write_bytes(before)
                require(tree(owned) == baseline, "Owned copied binding restoration failed")
        require(tree(owned) == baseline, "Import/preflight unexpectedly changed the owned source tree")
        require(len(rows) == 7, "Incomplete bounded preflight case set")
        require(all(digest(regular(Path(path))) == expected and stamp(Path(path)) == original_stamps[path]
                    for path, expected in original_pins.items()),
                "Original script/binding/provider/cache generated input changed during preflight")
        save(output / "result.json", {"status": "PASS_READ_ONLY_PACKAGING_PREFLIGHT", "cases": rows,
             "source_sha256": PACKAGING_SHA, "original_inputs_unchanged": True, "owned_tree_restored": True,
             "configured_compilers": configured_compilers,
             "packaging_main_called": False, "lt_loader_compiler_engine_or_staging_invoked": False,
             "shipping_or_runtime_approval_created": False})
        print(json.dumps({"receipt": str(output / "result.json"), "cases": len(rows)}))
    except BaseException as error:
        save(output / "failure.json", {"status": "FAIL", "current": current,
             "type": type(error).__name__, "message": str(error)[:4096],
             "owned_tree_restored": tree(owned) == baseline,
             "original_inputs_unchanged": all(digest(regular(Path(path))) == expected
                 and stamp(Path(path)) == original_stamps[path] for path, expected in original_pins.items())})
        raise


if __name__ == "__main__":
    main()
