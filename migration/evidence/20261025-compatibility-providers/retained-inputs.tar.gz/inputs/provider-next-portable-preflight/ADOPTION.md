Source-only read-only preflight harness for portable amendment5d578934 / stage_preview.py3287dc06. No author executions, native/provider/cache/dist mutations or new approval.

Root invocation (paths are explicit; output must be a fresh run-* child beside run.py):

    python3 -B build/storage-20261025/provider-next-portable-preflight/run.py --native /home/yurii/Java/BiglyBTC/preview/native --old-build /home/yurii/Java/BiglyBTC/build/persistent-peer-accounting-20261021/bound-gcc --new-build /home/yurii/Java/BiglyBTC/build/saved-services-20261018/clang --output /home/yurii/Java/BiglyBT/build/storage-20261025/provider-next-portable-preflight/run-r1

Before native adoption, add --packaging-script pointing to the frozen amendment staging/preview/migration/tools/stage_preview.py. Only exact3287 source is accepted, copied to an owned standalone preview/migration/tools + preview/native/engine/runtime-binding tree before importing definitions. Packaging main is never called.

Seven expected cases: old e74/d367 with existing GCC16 cache accepts; private b0e/3342 with new Clang24 cache accepts; private new vs old GCC binding refuses; old valid manifest cannot enter private route; changed owned copy of3fcd record refuses; changed new recursive helper refuses; changed old recursive helper refuses. Helper mutants would raise if imported, so the expected ValueError must occur at the source-pin boundary first. No claim of actual PASS until root executes.

Only the owned copied tree is mutated. Each negative mutation is restored in finally and the full owned file map checked. Original script/binding/DSOs/cache metadata hashes plus dev/inode/mode/size/mtime are checked unchanged afterward. Cases, inputs, stamps, baseline and result/failure JSON remain under the new output. No loader, engine, compiler, subprocess, staging/install/main or profile access is invoked. GUI/headless loader and all alias checks remain root's actual private-packaging qualification.
