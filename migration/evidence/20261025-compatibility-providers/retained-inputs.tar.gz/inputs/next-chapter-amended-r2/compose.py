#!/usr/bin/env python3
"""Compose frozen native sources only; never configure/build/adopt/run tests."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
W = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
PARENT = W / 'next-chapter-composed'
CORRECTION = W / 'next-network/socks4a'
BASE = '4f948e042df9467310a5752d4343b07915673f84'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write_json(path, value): path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
def checked(directory, expected):
    path = directory / 'manifest.json'
    assert sha(path) == expected
    value = json.loads(path.read_text())
    for relative, digest in value['artifacts'].items():
        leaf = directory / relative
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        assert leaf.is_file() and not leaf.is_symlink() and sha(leaf) == digest
    return value
parent_sha = 'c47d14bf4d54a914fe2fe27cb8a453a7e318ecfaab2dac810d61de65f794f1df'
correction_sha = '6a61e5644b78dbe57d80a26ee679a6b4bab3e6ca8e58976bb6c53f656b4c4414'
p = checked(PARENT, parent_sha)
c = checked(CORRECTION, correction_sha)
assert p['source_count'] == len(p['source_sha256']) == 47
assert len(c['source_sha256']) == 3
assert not (OUT/'staging').exists() and not (OUT/'manifest.json').exists()
extra = 'preview/native/tests/network_policy_tests.cpp'
assert set(c['source_sha256']) - set(p['source_sha256']) == {extra}
for relative, digest in c['before_sha256'].items():
    before = CORRECTION/'before'/relative
    assert sha(before) == digest
    if relative in p['source_sha256']:
        assert digest == p['source_sha256'][relative]
        assert before.read_bytes() == (PARENT/'staging'/relative).read_bytes()
    else:
        original = subprocess.check_output(['git','show',BASE+':'+relative], cwd='/home/yurii/Java/BiglyBTC')
        assert hashlib.sha256(original).hexdigest() == digest and original == before.read_bytes()
for relative, digest in p['before_sha256'].items():
    if digest is not None: assert sha(PARENT/'before'/relative) == digest
for relative, digest in p['source_sha256'].items(): assert sha(PARENT/'staging'/relative) == digest
shutil.copytree(PARENT/'before', OUT/'before')
shutil.copytree(PARENT/'staging', OUT/'staging')
(OUT/'before'/extra).parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(CORRECTION/'before'/extra, OUT/'before'/extra)
for relative in c['source_sha256']:
    (OUT/'staging'/relative).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(CORRECTION/'staging'/relative, OUT/'staging'/relative)
sources = dict(p['source_sha256']); sources.update(c['source_sha256'])
before = dict(p['before_sha256']); before[extra] = c['before_sha256'][extra]
assert len(sources) == len(before) == 48
assert {str(f.relative_to(OUT/'staging')) for f in (OUT/'staging').rglob('*') if f.is_file()} == set(sources)
assert all(sha(OUT/'staging'/rel) == digest for rel,digest in sources.items())
unchanged = sorted(set(p['source_sha256'])-set(c['source_sha256']))
assert len(unchanged) == 45
assert all(sources[rel] == p['source_sha256'][rel] for rel in unchanged)
cmake = sorted(rel for rel in p['source_sha256'] if rel.endswith('/CMakeLists.txt'))
assert len(cmake) == 4 and all((OUT/'staging'/rel).read_bytes() == (PARENT/'staging'/rel).read_bytes() for rel in cmake)
patch = []
for relative in sorted(sources):
    prior = OUT/'before'/relative
    patch.extend(difflib.unified_diff(prior.read_text().splitlines(True) if prior.exists() else [], (OUT/'staging'/relative).read_text().splitlines(True), fromfile='a/'+relative if prior.exists() else '/dev/null',tofile='b/'+relative))
(OUT/'changes.patch').write_text(''.join(patch))
composition = json.loads((PARENT/'composition.json').read_text())
composition['parent_composition_sha256'] = sha(PARENT/'composition.json')
composition['parent_manifest_sha256'] = parent_sha
composition['correction_manifest_sha256'] = correction_sha
composition['excluded'] = ['Separate seven-path SOCKS4a provider candidate and provider fixture: no source build or native admission here']
composition['native_head_observed_at_amendment'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd='/home/yurii/Java/BiglyBTC',text=True).strip()
composition['amendment'] = {'changed_parent_paths': sorted(set(c['source_sha256']) & set(p['source_sha256'])), 'new_cumulative_path': extra, 'original_4f_beforeimage': c['before_sha256'][extra], 'parent_final_paths_unchanged': 45, 'all_four_cmake_files_byte_exact': True, 'source_count': 48}
for relative, digest in c['source_sha256'].items():
    composition['per_path_chain'].setdefault(relative,[]).append({'capsule':'next-network/socks4a','manifest_sha256':correction_sha,'before_sha256':c['before_sha256'][relative],'source_sha256':digest})
write_json(OUT/'composition.json',composition)
suite = json.loads((PARENT/'suite-plan.json').read_text())
suite['amendment'] = {'new_targets_or_ctest_names': [], 'affected_existing_targets': ['biglybtc-network-policy-tests','biglybtc-network-proxy-owner-tests'], 'reason': 'One additive pure USERID rejection family; numeric SOCKS4 actual-owner fixture requests/asserts supported empty USERID. All existing targets, provider gates and tests retained.', 'provider_socks4a_fixture_excluded': True}
write_json(OUT/'suite-plan.json',suite)
(OUT/'ADOPTION.md').write_text('''Source-only cumulative amendment,48 native paths against original4f948e042df9467310a5752d4343b07915673f84 beforeimages. No adoption, configure, build, tests or Java execution.\n\nCompose exact frozen parent c47d14bf with correction6a61e564. Forty-five parent final paths and all four CMake files remain byte-exact. Two parent paths change: network_policy.cpp rejects ignored SOCKS4 USERID; network_proxy_owner_tests.cpp uses/asserts supported empty USERID and existing post-close accounting invariant. The48th path is network_policy_tests.cpp with exact original4f beforeimage and one additive USERID refusal family. Before/after maps and cumulative patch are alternatives against the same base; do not apply both.\n\nParent next-chapter-composed/ADOPTION.md retains chapter scope and root qualification recipe. suite-plan.json preserves all six new target registrations and every affected existing cohort; no new target is needed for the pure correction. Actual counts remain null.\n\nThe separate seven-path SOCKS4a provider candidate/standalone fixture is excluded. Current d367/e74 provider and catalogs are untouched, SOCKS4a remains unsupported, and no current-provider USERID success is claimed. Original capsules remain unchanged.\n''')
dependencies = dict(p['dependency_manifest_sha256']);dependencies['next-chapter-composed/manifest.json']=parent_sha;dependencies['next-network/socks4a/manifest.json']=correction_sha
manifest = {'schema':1,'status':'SOURCE_COMPOSED_UNCOMPILED_UNEXECUTED_UNADOPTED','native_base_commit':BASE,'source_directory':'staging','source_count':len(sources),'before_sha256':before,'source_sha256':sources,'dependency_manifest_sha256':dependencies,'actual_test_counts':None,'executions':[]}
manifest['artifacts'] = {str(f.relative_to(OUT)):sha(f) for f in sorted(OUT.rglob('*')) if f.is_file() and f.name!='manifest.json'}
write_json(OUT/'manifest.json',manifest)
print(json.dumps({'manifest_sha256':sha(OUT/'manifest.json'),'source_count':len(sources),'unchanged_parent_paths':len(unchanged),'cmake_files_byte_exact':len(cmake),'new_path':extra}))
