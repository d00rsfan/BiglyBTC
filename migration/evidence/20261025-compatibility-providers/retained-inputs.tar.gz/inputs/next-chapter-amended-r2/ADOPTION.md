Source-only cumulative amendment,48 native paths against original4f948e042df9467310a5752d4343b07915673f84 beforeimages. No adoption, configure, build, tests or Java execution.

Compose exact frozen parent c47d14bf with correction6a61e564. Forty-five parent final paths and all four CMake files remain byte-exact. Two parent paths change: network_policy.cpp rejects ignored SOCKS4 USERID; network_proxy_owner_tests.cpp uses/asserts supported empty USERID and existing post-close accounting invariant. The48th path is network_policy_tests.cpp with exact original4f beforeimage and one additive USERID refusal family. Before/after maps and cumulative patch are alternatives against the same base; do not apply both.

Parent next-chapter-composed/ADOPTION.md retains chapter scope and root qualification recipe. suite-plan.json preserves all six new target registrations and every affected existing cohort; no new target is needed for the pure correction. Actual counts remain null.

The separate seven-path SOCKS4a provider candidate/standalone fixture is excluded. Current d367/e74 provider and catalogs are untouched, SOCKS4a remains unsupported, and no current-provider USERID success is claimed. Original capsules remain unchanged.
