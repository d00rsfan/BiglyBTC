"""Read-only exact c8a38 +471 focused2 proof; no subject/tool execution."""
from pathlib import Path
import hashlib
import json
import re
import stat
import xml.etree.ElementTree as ET

W = Path(__file__).resolve().parent.parent
IMPLEMENTATION = 'c8afff5311e4ff650b17d09651e3db440a0c93e8'
QUALIFIED = '471ebb75fc66fefb0208b0d086a934b68aced84b'
FOCUSED = {'persistent-runtime-reject-content', 'provider-next-runtime-deployment'}
BEFORE = {
    'preview/native/tests/persistent_runtime_negative_driver.cpp': '9d3e4d0b8e3fa29d2b9bb139d577ab353d6066f246cda7c27d90934acc52af69',
    'preview/native/tests/runtime_deployment_driver.cpp': 'd91fbc7073c79968a15794b12b20551abf0ec5685d2e11032a677c5b8a61681b',
    'preview/native/tests/RuntimeBindingTests.cmake': 'be76266fe1cd511a66b7ae28409adc380ac6fe5a8a026734c63c9bf297323fae',
    'preview/native/tests/RuntimeDeploymentTests.cmake': '37b4ec02b0f371dbca9e292a1fcd72898ac79535eb594ac3799ebd5dcfda8ee8',
    'preview/native/tests/CMakeLists.txt': 'a4b88be7339bade81513bb383c4043e2c9f267a109748f0d0383edc1da3f70f4',
}
AFTER = {
    'preview/native/tests/persistent_runtime_negative_driver.cpp': 'b2b299268ef840af3bd455aac4aab147f324206023faaf7e1b633a8225dcb772',
    'preview/native/tests/runtime_deployment_driver.cpp': '36554a5b0c01d4472b4c33d16f0ba6711fa5da26cc5cc8214b3eea0bb588aa41',
    'preview/native/tests/RuntimeBindingTests.cmake': '7954073dc92799de2e97fd7a566950b28c9a741623c5f1a3fe165c3ed2e55764',
    'preview/native/tests/RuntimeDeploymentTests.cmake': 'f657b7610a1fc991a141c1c156b00399360a9bcc1b0af0945dcb18a973d41c24',
    'preview/native/tests/CMakeLists.txt': '96c9c7cd2e7580168d93c5bfad480003f76f869d901ebf0f50f5bc34db52eda5',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def body(path):
    require(path.is_absolute() and path.resolve(strict=True) == path and
            stat.S_ISREG(path.lstat().st_mode), 'Unsafe evidence input: ' + str(path))
    return path.read_bytes()


def sha(path):
    return hashlib.sha256(body(path)).hexdigest()


def load(path):
    return json.loads(body(path))


def verify_fix():
    path = W / 'chapter-fortified-fix-commit.json'
    receipt = load(path)
    require(receipt['source_commit'] == QUALIFIED and
            receipt['parent'] == receipt['implementation_source'] == IMPLEMENTATION and
            receipt['test_only'] is True and receipt['production_and_provider_unchanged'] is True and
            receipt['all_staged_blob_bytes_verified'] is True and
            receipt['before_sha256'] == BEFORE and receipt['paths_sha256'] == AFTER and
            set(receipt['focused_suites']) == FOCUSED, 'Wrong exact five-file test-only followup')
    return path


def read_case(stem):
    require(isinstance(stem, str) and re.fullmatch(r'chapter-[A-Za-z0-9_-]+', stem),
            'Expected actual root check.py case stem')
    paths = {suffix: W / (stem + suffix)
             for suffix in ('-receipt.json', '-source.json', '.xml', '.log')}
    pins = {p.name: sha(p) for p in paths.values()}
    receipt = load(paths['-receipt.json'])
    command = receipt.get('command', [])
    require(isinstance(command, list) and 'ctest' in command and '--output-junit' in command and
            str(paths['.xml']) in command and
            receipt['source_manifest_sha256'] == sha(paths['-source.json']),
            'Mismatched actual CTest receipt/map/XML: ' + stem)
    source = load(paths['-source.json'])
    require(source and all(k.startswith('preview/native/') and
            re.fullmatch('[0-9a-f]{64}', v) for k, v in source.items()), 'Invalid source map')
    rows = list(ET.fromstring(body(paths['.xml'])).iter('testcase'))
    names = [row.get('name') for row in rows]
    require(names and None not in names and len(names) == len(set(names)), 'Invalid CTest XML')
    outcomes = {}
    for row in rows:
        text = row.findtext('system-out') or ''
        clean = row.get('status', 'run') == 'run' and all(row.find(k) is None
                   for k in ('failure', 'error', 'skipped')) and not re.search(r'^SKIP\s*:', text, re.M)
        clean = clean and all(failed == skipped == '0' for failed, skipped in re.findall(
                   r'Totals:\s*\d+ passed, (\d+) failed, (\d+) skipped', text))
        outcomes[row.get('name')] = bool(clean)
    return receipt, source, outcomes, paths, pins


def verify_lane(lane, original, focused):
    require(lane in ('gcc', 'clang', 'sanitizers'), 'Unknown compiler lane')
    fix_path = verify_fix()
    plan_path = W / 'chapter-next-plan-r3.json'
    require(sha(plan_path) == '08f33ea58ce8644a3ada1978881fb8d21ed1e76ce1966d0aa723815ed0b12dcf',
            'Changed frozen40-suite plan')
    expected = set(load(plan_path)['suites'])
    require(len(expected) == 40 and FOCUSED < expected, 'Wrong suite plan')
    old, before, old_outcomes, old_paths, old_pins = read_case(original)
    new, after, new_outcomes, new_paths, new_pins = read_case(focused)
    require(set(old_outcomes) == expected and set(new_outcomes) == FOCUSED,
            'Require original40 and exact focused2 XML')
    unaffected = expected - FOCUSED
    require(all(old_outcomes[name] for name in unaffected), 'Unsuccessful original unaffected suite')
    if lane == 'sanitizers':
        require(old['exit'] == 8 and all(not old_outcomes[name] for name in FOCUSED),
                'Preserve exact original SAN38PASS/2FAIL, not a fabricated passing aggregate')
    else:
        require(old['exit'] == 0 and all(old_outcomes.values()), 'Original GCC/Clang40 did not pass')
    require(new['exit'] == 0 and all(new_outcomes.values()), 'Focused2 not actually complete/PASS')
    require(before.keys() == after.keys() and
            {k for k in before if before[k] != after[k]} == set(BEFORE) and
            all(before[k] == v for k, v in BEFORE.items()) and
            all(after[k] == v for k, v in AFTER.items()),
            'Source maps differ beyond the exact five pinned test-only paths')
    latest = {name: {'passed': True, 'case': original, 'source': IMPLEMENTATION}
              for name in sorted(unaffected)}
    latest.update({name: {'passed': True, 'case': focused, 'source': QUALIFIED}
                   for name in sorted(FOCUSED)})
    result = {'suites': 40, 'original_unaffected_credit': 38, 'focused_latest_credit': 2,
              'original_case': original, 'focused_case': focused,
              'original_exit': old['exit'], 'focused_exit': new['exit'],
              'original_seconds': old['seconds'], 'focused_seconds': new['seconds'],
              'latest_actual_results': latest, 'original_inputs_sha256': old_pins,
              'focused_inputs_sha256': new_pins,
              'full_source_snapshots_identical': False,
              'all_production_and_provider_bytes_identical': True,
              'exact_test_only_changed_paths': sorted(BEFORE)}
    return result, before, after, set(old_paths.values()) | set(new_paths.values()) | {fix_path, plan_path}
