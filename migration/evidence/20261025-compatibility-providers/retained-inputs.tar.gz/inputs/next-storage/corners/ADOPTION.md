Finite CF01 covered EOF-short write; source only. Original FMFileAccessPieceReorderer.readWrite330–460 writes ascending fragments before a later getPieceIndex734–811 allocation. Native preplanning previously refused that whole request when tail relocation crossed an existing short slot.

Now exactly one highest allocated non-tail slot may be repaired before relocation when (1) its logical index precedes the final newly allocated piece, and (2) the same request supplies its entire missing suffix. Stream genuine caller bytes contiguously from captured EOF in≤64KiB writes, sync, then use unchanged tail-copy→sync→original-map-CAS→caller-write ordering. No zeros, unverified progress, hidden control field, swap journal or API signature is added. Errors fence the object; control reload/reopen observes only actually supplied old-prefix extension. All other missing-range cases still reject before mutation.

Three source paths; existing original-physical-file-io target needs no CMake change. All17 old test families/assertions remain exact;3 new families exercise R/X success/order and strict rejection, before/after actual repair/copy/input writes and map publication with explicit reopen, and bounded sparse multi-chunk repair. No compilation/tests/Java were executed by author.

Optional actual original FMFile→native→FMFile recipe reuses the retained Java17 core and already compiled small fixture classes (no javac/core rebuild):

    python3 -B build/storage-20261025/next-storage/corners/oracle.py \
      --codec-driver /ABS/BUILD/tests/biglybtc-original-file-io-driver \
      --work /tmp/biglybtc-eof-corner-r1

Two planned R/X cases: actual Java creates tail+short earlier piece; native verifies the exact missing suffix, applies a source-ordered covered write; independent original write and both final cross-readers require exact supplied logical bytes and raw size≤declared length. Scope is raw FMFile known-byte compatibility; no GM READY/resume/completion or runtime result credit until root executes.

Remaining: independent requests lacking genuine repair bytes remain Conflict. The fully allocated inherited EOF-short oversized layout in remainder/partial-raw-size.md case2 still has no exact availability-preserving permutation in the original whole-slot map. No truncation/zero-fill/automatic ownership guess is introduced; full CF01 stays open.
