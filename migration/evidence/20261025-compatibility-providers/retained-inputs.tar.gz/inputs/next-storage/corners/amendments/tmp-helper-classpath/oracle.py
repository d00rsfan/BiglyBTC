#!/usr/bin/env python3
"""Actual retained original FMFile -> native covered EOF write -> original FMFile.
Raw layout/known-byte scope only; no original GM READY/progress certificate.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parents[2]  # Exact frozen corner capsule

def require(value, why):
    if not value:
        raise RuntimeError(why)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--codec-driver', type=Path, required=True)
    parser.add_argument('--work', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((HERE / 'manifest.json').read_text())
    for rel, expected in manifest['artifacts'].items():
        require(digest(HERE / rel) == expected, 'Changed source capsule: ' + rel)
    for path, expected in manifest['oracle_inputs_sha256'].items():
        require(digest(Path(path)) == expected, 'Changed retained oracle input: ' + path)
    oracle = module('eof_original_recipe', Path(manifest['oracle_recipe']))
    retained = json.loads(Path(manifest['java_retention']).read_text())
    require(retained['source_commit'] == manifest['original']['commit'] and retained['recompiled'] is False,
            'Original retained class identity differs')
    classes = Path(manifest['original_classes']).resolve(strict=True)
    helpers = Path(manifest['fixture_classes']).resolve(strict=True)
    require(oracle.file_map(classes) == retained['file_sha256'], 'Original retained classes changed')
    require(oracle.file_map(helpers) == manifest['fixture_class_sha256'], 'Retained fixture classes changed')
    driver = args.codec_driver.resolve(strict=True); oracle.regular(driver)
    work = args.work.absolute()
    require(work.parent == Path('/tmp') and work.name.startswith('biglybtc-eof-corner-')
            and not work.exists() and work.resolve() == work, 'Fresh owned /tmp/biglybtc-eof-corner-* root required')
    work.mkdir(mode=0o700)
    sys.path.insert(0, str(Path(manifest['reference_root']) / 'migration/tools'))
    peer = module('eof_retained_peer_recipe', Path(manifest['reference_root']) / 'migration/tools/peer_interop.py')
    local_helpers = work / 'classes'
    shutil.copytree(helpers, local_helpers)
    require(oracle.file_map(local_helpers) == manifest['fixture_class_sha256'], 'Copied fixture classes changed')
    classpath = str(local_helpers) + os.pathsep + str(classes)
    env = {k: v for k, v in os.environ.items() if k not in
           ('CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'LD_PRELOAD')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    commands = []
    def run(name, command):
        commands.append({'name': name, 'argv': list(map(str, command)), 'cwd': str(work), 'timeout': 90})
        (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        with (work / (name + '.stdout')).open('wb') as out, (work / (name + '.stderr')).open('wb') as err:
            completed = subprocess.run(list(map(str, command)), cwd=work, env=env, stdout=out, stderr=err, timeout=90)
        require(completed.returncode == 0, 'Actual helper failed: ' + name)
    def java(name, root, tape):
        run(name, [*peer.jvm(work, classpath), 'StorageScriptOracle', root, tape])
    results = []
    first, piece, tail, available = 13312, 16384, 8072, 5000
    length = first + 2 * piece + tail
    pattern = bytes((i * 37 + i // 127 + 19) & 255 for i in range(length))
    for kind in (3, 4):
        case = work / ('kind-' + str(kind)); case.mkdir(mode=0o700)
        original = case / 'original'; original.mkdir(mode=0o700)
        for name, data in {'first.bin': pattern[:first], 'tail.bin': pattern[-tail:],
                           'prefix.bin': pattern[first:first + available],
                           'repair.bin': pattern[first + available:first + 2 * piece]}.items():
            (original / name).write_bytes(data)
        opening = f'OPEN\t{kind}\t3072\t{length}\t{piece}'
        tape = original / 'prepare.tsv'
        tape.write_text('\n'.join([opening, 'WRITE\t0\tfirst.bin', f'WRITE\t{length-tail}\ttail.bin',
                                   f'WRITE\t{first}\tprefix.bin', f'LENGTH\t{length}', 'FLUSH', 'CLOSE']) + '\n')
        java('prepare-' + str(kind), original, tape)
        native = case / 'native'; shutil.copytree(original, native)
        before = native / 'before.tsv'; before.write_text(f'{opening}\nREAD\t{first}\t{piece}\tbefore\nCLOSE\n')
        run('native-before-' + str(kind), [driver, native, before])
        observation = json.loads((native / 'read-before.json').read_text())
        require(observation['missing'] == [{'offset': first + available, 'length': piece - available}]
                and (native / 'read-before.bin').read_bytes()[:available] == pattern[first:first + available],
                'Actual original EOF-short input differs from declared known prefix')
        for root, who in ((native, 'native'), (original, 'original')):
            write_tape = root / 'covered-write.tsv'
            write_tape.write_text(f'{opening}\nWRITE\t{first+available}\trepair.bin\nFLUSH\nREAD\t0\t{length}\t{who}-whole\nCLOSE\n')
            if who == 'native':
                run('covered-native-' + str(kind), [driver, root, write_tape])
                require(not json.loads((root / 'read-native-whole.json').read_text())['missing'], 'Native supplied-byte stream has a gap')
            else:
                java('covered-original-' + str(kind), root, write_tape)
            require((root / ('read-' + who + '-whole.bin')).read_bytes() == pattern, 'Actual covered write changed logical input bytes')
            require((root / 'payload.bin.az!').stat().st_size <= length, 'Result still violates original raw-size bound')
        handoff = native / 'java-read.tsv'; handoff.write_text(f'{opening}\nREAD\t0\t{length}\tjava-handoff\nCLOSE\n')
        java('native-to-original-' + str(kind), native, handoff)
        require((native / 'read-java-handoff.bin').read_bytes() == pattern, 'Original could not read native covered EOF repair')
        reverse = original / 'native-read.tsv'; reverse.write_text(f'{opening}\nREAD\t0\t{length}\tnative-handoff\nCLOSE\n')
        run('original-to-native-' + str(kind), [driver, original, reverse])
        require((original / 'read-native-handoff.bin').read_bytes() == pattern
                and not json.loads((original / 'read-native-handoff.json').read_text())['missing'],
                'Native could not read actual original sequential result')
        results.append({'kind': kind, 'bytes': length, 'source_sha256': hashlib.sha256(pattern).hexdigest(),
                        'actual_input': oracle.file_map(case), 'status': 'PASS'})
        print('Actual original/native/original covered EOF repair kind' + str(kind) + ' PASS', flush=True)
    require(oracle.file_map(classes) == retained['file_sha256']
            and oracle.file_map(helpers) == manifest['fixture_class_sha256']
            and oracle.file_map(local_helpers) == manifest['fixture_class_sha256'], 'Retained/copied classes changed during handoff')
    (work / 'result.json').write_text(json.dumps({'status': 'PASS', 'scope': 'raw FMFile known bytes; no GM/progress claim',
        'native_driver': str(driver), 'native_driver_sha256': digest(driver), 'cases': results}, indent=2) + '\n')
if __name__ == '__main__':
    main()
