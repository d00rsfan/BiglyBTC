# Append first block in ui/CMakeLists.txt (AUTOMOC already enabled).
if(BIGLYBTC_DESKTOP)
  target_sources(biglybtc_ui PRIVATE
    file_operation_sequence.hpp
    file_operation_sequence.cpp)
endif()
# Append in tests/CMakeLists.txt. These generated-profile worker cases are
# offline (port0), so no runtime-bound owner gate or substitute skips are used.
if(BIGLYBTC_DESKTOP AND BIGLYBTC_LOCAL_ENGINE)
  add_executable(biglybtc-file-operation-sequence-tests file_operation_sequence_tests.cpp)
  set_target_properties(biglybtc-file-operation-sequence-tests PROPERTIES AUTOMOC ON)
  target_link_libraries(biglybtc-file-operation-sequence-tests PRIVATE
    biglybtc_desktop_host biglybtc_profile Qt6::Test LibtorrentRasterbar::torrent-rasterbar)
  target_compile_options(biglybtc-file-operation-sequence-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  add_test(NAME file-operation-sequence COMMAND biglybtc-file-operation-sequence-tests)
  set_tests_properties(file-operation-sequence PROPERTIES TIMEOUT 120
    LABELS "unit;ui;integration;fileops" ENVIRONMENT "QT_QPA_PLATFORM=offscreen")
endif()
