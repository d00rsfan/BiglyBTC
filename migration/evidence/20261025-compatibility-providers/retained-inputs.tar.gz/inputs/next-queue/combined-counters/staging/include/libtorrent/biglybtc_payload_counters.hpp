// Supported only by the reviewed BiglyBTC LT2.0.12 provider.
// This is a source/artifact-bound C++-handle ABI, not an upstream portable API.
#ifndef TORRENT_BIGLYBTC_PAYLOAD_COUNTERS_HPP
#define TORRENT_BIGLYBTC_PAYLOAD_COUNTERS_HPP

#include "libtorrent/config.hpp"
#include "libtorrent/fwd.hpp"
#include <cstdint>
#include <type_traits>

namespace libtorrent {
// Raw m_stat values copied in the provider, before the caller's existing
// on_resume callback returns to LT's normal clear/reset path. No epoch, total,
// reset, ownership/finality claim or private-class pointer crosses this ABI.
struct BiglybtcPayloadCountersV1 {
    std::int64_t received;
    std::int64_t sent;
    std::uint32_t files_checked;
    std::uint32_t reserved;
};
static_assert(sizeof(BiglybtcPayloadCountersV1) == 24, "Counter ABI size");
static_assert(std::is_standard_layout<BiglybtcPayloadCountersV1>::value
    && std::is_trivially_copyable<BiglybtcPayloadCountersV1>::value, "Counter ABI layout");

enum class BiglybtcPayloadCounterStatusV1 : std::uint32_t {
    Accepted = 0, InvalidArgument = 1, InvalidHandle = 2,
    WrongThread = 3, InvalidCounters = 4, Failed = 5
};

extern "C" TORRENT_EXPORT unsigned biglybtc_payload_counter_abi_v1() noexcept;
// Only call from a callback on this handle's real io_context executor thread.
// Unlike status(), this never dispatches or waits. Failure leaves *output
// unchanged. A temporary weak-lock is released before the function returns.
extern "C" TORRENT_EXPORT std::uint32_t biglybtc_read_payload_counters_v1(
    torrent_handle const* handle, BiglybtcPayloadCountersV1* output,
    std::uint32_t output_bytes) noexcept;

// Optional extension. Presence of this header/marker is NOT runtime approval;
// the consumer must authenticate and retain the exact mapped source-bound DSO.
#define TORRENT_BIGLYBTC_TRAFFIC_COUNTERS_ABI 2
struct BiglybtcTrafficCountersV2 {
    BiglybtcPayloadCountersV1 payload;
    std::int64_t protocol_received;
    std::int64_t protocol_sent;
    // Zero means protocol fields are unknown and MUST NOT be used as zeros.
    // Payload acceptance remains independent of optional protocol overflow.
    std::uint32_t protocol_known;
    std::uint32_t reserved;
};
static_assert(sizeof(BiglybtcTrafficCountersV2) == 48, "Traffic counter ABI size");
static_assert(std::is_standard_layout<BiglybtcTrafficCountersV2>::value
    && std::is_trivially_copyable<BiglybtcTrafficCountersV2>::value, "Traffic counter ABI layout");
enum class BiglybtcTrafficCounterStatusV2 : std::uint32_t {
    Accepted = 0, InvalidArgument = 1, InvalidHandle = 2,
    WrongThread = 3, InvalidCounters = 4, Failed = 5
};
extern "C" TORRENT_EXPORT unsigned biglybtc_traffic_counter_abi_v2() noexcept;
// SAME executor-thread/no-dispatch/weak-lock/output-unchanged contract as v1.
// One statistics copy supplies payload AND protocol; no IP/DHT/tracker total,
// lifetime/finality or reset-epoch authority is exported.
extern "C" TORRENT_EXPORT std::uint32_t biglybtc_read_traffic_counters_v2(
    torrent_handle const* handle, BiglybtcTrafficCountersV2* output,
    std::uint32_t output_bytes) noexcept;
}
#endif
