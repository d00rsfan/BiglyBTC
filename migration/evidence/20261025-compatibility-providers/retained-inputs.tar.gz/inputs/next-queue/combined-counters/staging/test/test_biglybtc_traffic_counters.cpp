// Optional ABI contract only; actual positive protocol traffic is qualified by
// the application owned-loopback test. No private torrent layout is included.
#include "test.hpp"
#include "libtorrent/biglybtc_payload_counters.hpp"
#include "libtorrent/add_torrent_params.hpp"
#include "libtorrent/bencode.hpp"
#include "libtorrent/create_torrent.hpp"
#include "libtorrent/disabled_disk_io.hpp"
#include "libtorrent/extensions.hpp"
#include "libtorrent/file_storage.hpp"
#include "libtorrent/session.hpp"
#include "libtorrent/session_params.hpp"
#include "libtorrent/settings_pack.hpp"
#include "libtorrent/torrent_handle.hpp"
#include "libtorrent/torrent_info.hpp"
#include <array>
#include <atomic>
#include <chrono>
#include <cstring>
#include <future>
#include <iterator>
#include <memory>
#include <utility>
#include <vector>

using namespace lt;
namespace {
struct Observation {
 std::uint32_t oldStatus=99,newStatus=99;
 BiglybtcPayloadCountersV1 oldValue{};
 BiglybtcTrafficCountersV2 newValue{};
};
struct Frame {std::atomic_bool reported{false};std::promise<Observation> promise;};
struct Reader final:torrent_plugin {
 torrent_handle handle;std::shared_ptr<Frame> frame;
 Reader(torrent_handle value,std::shared_ptr<Frame> target):handle(std::move(value)),frame(std::move(target)){}
 void on_files_checked() override {
  if(frame->reported.exchange(true))return;
  Observation actual;
  // Test compatibility of both exports on an actual executor callback. The
  // application production path chooses ONE read, never these two test reads.
  actual.oldStatus=biglybtc_read_payload_counters_v1(&handle,&actual.oldValue,sizeof(actual.oldValue));
  actual.newStatus=biglybtc_read_traffic_counters_v2(&handle,&actual.newValue,sizeof(actual.newValue));
  frame->promise.set_value(actual);
 }
};
session_params isolated() {
 settings_pack s;s.set_str(settings_pack::listen_interfaces,"");s.set_str(settings_pack::outgoing_interfaces,"127.0.0.1");
 s.set_str(settings_pack::dht_bootstrap_nodes,"");
 for(auto key:{settings_pack::enable_dht,settings_pack::enable_lsd,settings_pack::enable_upnp,settings_pack::enable_natpmp,
     settings_pack::enable_incoming_tcp,settings_pack::enable_outgoing_tcp,settings_pack::enable_incoming_utp,settings_pack::enable_outgoing_utp})s.set_bool(key,false);
 session_params p(s);p.disk_io_constructor=disabled_disk_io_constructor;return p;
}
std::shared_ptr<torrent_info> metadata() {
 file_storage files;files.add_file("counter-abi.bin",16384);
 create_torrent creator(files,16384,create_torrent::v1_only);sha1_hash piece;piece[0]=1;creator.set_hash(piece_index_t{0},piece);
 std::vector<char> raw;bencode(std::back_inserter(raw),creator.generate());error_code error;
 auto result=std::make_shared<torrent_info>(raw.data(),static_cast<int>(raw.size()),error);TEST_CHECK(!error);return result;
}
}
TORRENT_TEST(biglybtc_traffic_counter_versions_and_failure_output) {
 TEST_EQUAL(biglybtc_payload_counter_abi_v1(),1u);TEST_EQUAL(biglybtc_traffic_counter_abi_v2(),2u);
 TEST_EQUAL(sizeof(BiglybtcPayloadCountersV1),std::size_t(24));TEST_EQUAL(sizeof(BiglybtcTrafficCountersV2),std::size_t(48));
 BiglybtcTrafficCountersV2 output;std::memset(&output,0x5d,sizeof(output));
 std::array<unsigned char,sizeof(output)> before{};std::memcpy(before.data(),&output,sizeof(output));
 torrent_handle invalid;
 TEST_EQUAL(biglybtc_read_traffic_counters_v2(nullptr,&output,sizeof(output)),std::uint32_t(BiglybtcTrafficCounterStatusV2::InvalidArgument));
 TEST_CHECK(std::memcmp(&output,before.data(),sizeof(output))==0);
 TEST_EQUAL(biglybtc_read_traffic_counters_v2(&invalid,&output,sizeof(output)-1),std::uint32_t(BiglybtcTrafficCounterStatusV2::InvalidArgument));
 TEST_CHECK(std::memcmp(&output,before.data(),sizeof(output))==0);
 TEST_EQUAL(biglybtc_read_traffic_counters_v2(&invalid,&output,sizeof(output)),std::uint32_t(BiglybtcTrafficCounterStatusV2::InvalidHandle));
 TEST_CHECK(std::memcmp(&output,before.data(),sizeof(output))==0);
}
TORRENT_TEST(biglybtc_traffic_counter_actual_executor_and_wrong_thread) {
 auto frame=std::make_shared<Frame>();auto future=frame->promise.get_future();session owner(isolated());
 add_torrent_params p;p.ti=metadata();p.save_path=".";p.flags&=~(torrent_flags::paused|torrent_flags::auto_managed);
 p.extensions.push_back([frame](torrent_handle const& handle,client_data_t){return std::make_shared<Reader>(handle,frame);});
 error_code error;auto handle=owner.add_torrent(p,error);TEST_CHECK(!error);TEST_CHECK(handle.is_valid());if(error||!handle.is_valid())return;
 auto const ready=future.wait_for(std::chrono::seconds(10));TEST_CHECK(ready==std::future_status::ready);if(ready!=std::future_status::ready)return;
 auto const actual=future.get();
 TEST_EQUAL(actual.oldStatus,std::uint32_t(BiglybtcPayloadCounterStatusV1::Accepted));
 TEST_EQUAL(actual.newStatus,std::uint32_t(BiglybtcTrafficCounterStatusV2::Accepted));
 TEST_EQUAL(actual.newValue.payload.received,actual.oldValue.received);TEST_EQUAL(actual.newValue.payload.sent,actual.oldValue.sent);
 TEST_EQUAL(actual.newValue.payload.files_checked,actual.oldValue.files_checked);
 TEST_EQUAL(actual.newValue.payload.reserved,0u);TEST_EQUAL(actual.newValue.reserved,0u);TEST_EQUAL(actual.newValue.protocol_known,1u);
 TEST_EQUAL(actual.newValue.protocol_received,std::int64_t(0));TEST_EQUAL(actual.newValue.protocol_sent,std::int64_t(0));
 BiglybtcTrafficCountersV2 output;std::memset(&output,0x6b,sizeof(output));
 std::array<unsigned char,sizeof(output)> before{};std::memcpy(before.data(),&output,sizeof(output));
 TEST_EQUAL(biglybtc_read_traffic_counters_v2(&handle,&output,sizeof(output)),std::uint32_t(BiglybtcTrafficCounterStatusV2::WrongThread));
 TEST_CHECK(std::memcmp(&output,before.data(),sizeof(output))==0);
}
