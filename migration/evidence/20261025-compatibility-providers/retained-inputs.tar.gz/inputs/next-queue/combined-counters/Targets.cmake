# App tests only. Root merges this fragment; no shared/native CMake edit here.
if(BIGLYBTC_LOCAL_ENGINE)
  add_executable(biglybtc-managed-combined-counter-tests managed_combined_counter_tests.cpp)
  target_link_libraries(biglybtc-managed-combined-counter-tests PRIVATE biglybtc_core LibtorrentRasterbar::torrent-rasterbar)
  target_compile_options(biglybtc-managed-combined-counter-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  add_test(NAME managed-combined-counter-domain COMMAND biglybtc-managed-combined-counter-tests)
  set_tests_properties(managed-combined-counter-domain PROPERTIES TIMEOUT 30 LABELS "unit;queue;counters")
endif()
if(BIGLYBTC_LOCAL_ENGINE AND BIGLYBTC_DESKTOP AND NOT BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST STREQUAL "")
  add_executable(biglybtc-managed-combined-protocol-tests managed_combined_protocol_tests.cpp)
  set_target_properties(biglybtc-managed-combined-protocol-tests PROPERTIES AUTOMOC ON)
  target_link_libraries(biglybtc-managed-combined-protocol-tests PRIVATE biglybtc_local_engine LibtorrentRasterbar::torrent-rasterbar Qt6::Test)
  target_compile_options(biglybtc-managed-combined-protocol-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  add_test(NAME managed-combined-protocol COMMAND biglybtc-managed-combined-protocol-tests)
  # Root enables this V2-positive registration only with the independently
  # approved future provider. Legacy d367 qualification uses explicit value0.
  set_tests_properties(managed-combined-protocol PROPERTIES TIMEOUT 180
      ENVIRONMENT "BIGLYBTC_EXPECT_COMBINED_COUNTERS=1" LABELS "unit;queue;counters;loopback")
endif()

# Provider upstream test/CMakeLists already globs test_*.cpp, so a fresh
# configure adds target test_biglybtc_traffic_counters. No rule-file edit.
