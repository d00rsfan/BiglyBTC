# Existing Qualified target ONLY, after its original --wrap=dlsym option.
# No new executable, rows outside this suite, timeout or approval lane.
target_link_options(biglybtc-selected-swarm-admission-tests PRIVATE
  "LINKER:--wrap=dlopen" "LINKER:--wrap=dlclose")
