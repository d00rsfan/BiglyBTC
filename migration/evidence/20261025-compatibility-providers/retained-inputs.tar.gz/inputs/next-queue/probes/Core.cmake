# Root merges into existing core/CMakeLists.txt.
target_sources(biglybtc_core PRIVATE src/queue_download_probe.cpp)
