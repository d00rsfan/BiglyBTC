# Root merges into tests/CMakeLists.txt; author did not alter shared CMake.
add_executable(biglybtc-queue-download-probe-tests queue_download_probe_tests.cpp)
target_link_libraries(biglybtc-queue-download-probe-tests PRIVATE biglybtc_core)
target_compile_options(biglybtc-queue-download-probe-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
add_test(NAME queue-download-probes COMMAND biglybtc-queue-download-probe-tests)
set_tests_properties(queue-download-probes PROPERTIES TIMEOUT 30 LABELS "unit;queue")

# Optional replay of actual retained original-class outputs, not a second oracle.
add_executable(biglybtc-queue-download-probe-replay queue_download_probe_replay.cpp)
target_link_libraries(biglybtc-queue-download-probe-replay PRIVATE biglybtc_core)
target_compile_options(biglybtc-queue-download-probe-replay PRIVATE -Wall -Wextra -Wpedantic -Werror)
