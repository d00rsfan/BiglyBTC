package com.biglybt.plugin.startstoprules.defaultplugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import com.biglybt.core.download.DownloadManager;
import com.biglybt.core.download.DownloadManagerState;
import com.biglybt.core.download.DownloadManagerStats;
import com.biglybt.pif.PluginConfig;
import com.biglybt.pif.download.Download;
import com.biglybt.pif.download.DownloadStats;
import com.biglybt.pif.download.DownloadScrapeResult;
import com.biglybt.pifimpl.local.PluginCoreUtils;
import queueoracle.Providers;

/** Explicit primitives around unchanged retained RankCalculatorReal methods.
 * No copied speed/ETA/comparator arithmetic, core startup, disk or networking. */
public final class QueueProbeOracle {
    private static <T> T proxy(Class<T> type,InvocationHandler handler) {
        return type.cast(Proxy.newProxyInstance(QueueProbeOracle.class.getClassLoader(),new Class<?>[]{type},handler));
    }
    private static final class Fixture implements InvocationHandler {
        long payload,protocol,eta;
        boolean downloading;
        int position=2,downloadedCalls,moves;
        DownloadStats pluginStats;
        DownloadManagerStats coreStats;
        DownloadManagerState state;
        DownloadScrapeResult scrape;
        @Override public Object invoke(Object self,Method method,Object[] args) {
            final String name=method.getName();Providers.call(method.getDeclaringClass().getSimpleName()+"."+name);
            if(name.equals("hashCode")){return System.identityHashCode(self);}
            if(name.equals("equals")){return self==args[0];}
            if(name.equals("toString")){return "ExplicitProbeFixture";}
            switch(name) {
                case "getStats": return method.getReturnType()==DownloadStats.class?pluginStats:coreStats;
                case "getDownloadState": return state;
                case "getAggregatedScrapeResult": return scrape;
                case "getSeedCount": case "getNonSeedCount": case "getIntParameter": return 0;
                case "getLongParameter": case "getScrapeStartTime": return 0L;
                case "setSeedingRank": case "addListener": case "removeListener": return null;
                case "getState": return downloading?Download.ST_DOWNLOADING:Download.ST_QUEUED;
                case "getPosition": return position;
                case "moveTo": position=(Integer)args[0];++moves;return null;
                case "getDownloaded":
                    if(args==null||args.length!=1||!Boolean.TRUE.equals(args[0])) {
                        throw Providers.fail("Subject changed its include-protocol counter scope");
                    }
                    ++downloadedCalls;return payload+protocol;
                case "getSmoothedETA": return eta;
                default: throw Providers.fail("Unexpected probe provider method "+method);
            }
        }
    }
    public static void main(String[] args)throws Exception {
        Providers.verify();
        final BufferedReader reader=new BufferedReader(new InputStreamReader(System.in,"UTF-8"));
        int cases=0;
        for(String line;(line=reader.readLine())!=null;) {
            if(line.isEmpty()||line.startsWith("#")){continue;}
            final String[] f=line.split("\t",-1);
            if(f.length!=10){throw Providers.fail("Expected id/start/end/payload/protocol/end-payload/end-protocol/ETA/state/fallback-ETA");}
            Providers.reset();
            final Fixture fixture=new Fixture();
            fixture.payload=Long.parseLong(f[3]);fixture.protocol=Long.parseLong(f[4]);
            fixture.eta=Long.parseLong(f[7]);fixture.downloading=f[8].equals("running");
            if(!fixture.downloading&&!f[8].equals("queued")){throw Providers.fail("Invalid explicit state");}
            fixture.pluginStats=proxy(DownloadStats.class,fixture);
            fixture.coreStats=proxy(DownloadManagerStats.class,fixture);
            fixture.state=proxy(DownloadManagerState.class,fixture);
            fixture.scrape=proxy(DownloadScrapeResult.class,fixture);
            final Download download=proxy(Download.class,fixture);
            final DownloadManager manager=proxy(DownloadManager.class,fixture);
            PluginCoreUtils.link(download,manager);
            final PluginConfig config=proxy(PluginConfig.class,(self,method,arguments)->{
                Providers.call("PluginConfig."+method.getName());
                if(!method.getName().startsWith("getUnsafe")){throw Providers.fail("Unexpected config method");}
                if(method.getReturnType()==Boolean.TYPE){return false;}
                if(method.getReturnType()==Float.TYPE){return 0F;}
                if(method.getReturnType()==Integer.TYPE){return 0;}
                throw Providers.fail("Unexpected config type");
            });
            final StartStopRulesDefaultPlugin plugin=new StartStopRulesDefaultPlugin();plugin.plugin_config=config;
            final RankCalculatorReal subject=new RankCalculatorReal(plugin,download);
            try {
                subject.setDLRActive(Long.parseLong(f[1]));
                fixture.payload=Long.parseLong(f[5]);fixture.protocol=Long.parseLong(f[6]);
                subject.setDLRComplete(Long.parseLong(f[2]));
                // Exercise the actual never-completed ETA fallback too.
                fixture.eta=Long.parseLong(f[9]);
                if(fixture.downloadedCalls!=2||fixture.moves!=1||fixture.position!=1) {
                    throw Providers.fail("Actual subject did not capture both endpoints/move its tested download");
                }
                System.out.println("OBS\t"+f[0]+"\tspeed\t"+subject.getDLRLastTestSpeed());
                System.out.println("OBS\t"+f[0]+"\teta\t"+subject.getDLRLastTestETA());
                System.out.println("TRACE\t"+f[0]+"\t"+Providers.counts());
                ++cases;
            } finally {subject.destroy();PluginCoreUtils.clear();Providers.verify();}
        }
        System.out.println("PASS_QUEUE_PROBE_ORIGINAL\t"+cases);
    }
}
