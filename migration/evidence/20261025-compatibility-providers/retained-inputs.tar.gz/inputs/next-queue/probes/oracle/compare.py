#!/usr/bin/env python3
"""Compare actual retained RankCalculatorReal outputs; no expected arithmetic."""
import argparse
import hashlib
import json
from pathlib import Path


def observed(path, ids, marker):
    values = {}
    terminal = []
    for line in path.read_text().splitlines():
        fields = line.split('\t')
        if fields[0] == 'OBS':
            assert len(fields) == 4 and fields[1] in ids and fields[2] in ('speed', 'eta')
            key = (fields[1], fields[2])
            assert key not in values and str(int(fields[3])) == fields[3]
            values[key] = int(fields[3])
        elif fields[0] == 'TRACE':
            assert len(fields) == 3 and fields[1] in ids
        elif fields[0] == marker:
            terminal.append(fields)
        else:
            raise ValueError('Unexpected output: ' + line)
    assert terminal == [[marker, str(len(ids))]] and len(values) == len(ids) * 2
    return values


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original', type=Path, required=True)
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    ids = [line.split('\t')[0] for line in Path(__file__).with_name('vectors.tsv').read_text().splitlines()
           if line and not line.startswith('#')]
    assert len(ids) == len(set(ids)) and not args.output.exists()
    expected = observed(args.original, ids, 'PASS_QUEUE_PROBE_ORIGINAL')
    actual = observed(args.native, ids, 'PASS_QUEUE_PROBE_NATIVE')
    differences = [{'case': key[0], 'field': key[1], 'original': value, 'native': actual.get(key)}
                   for key, value in expected.items() if actual.get(key) != value]
    result = {'status': 'PASS' if not differences else 'FAIL', 'cases': len(ids),
              'comparisons': len(expected), 'differences': differences,
              'original_stdout_sha256': hashlib.sha256(args.original.read_bytes()).hexdigest(),
              'native_stdout_sha256': hashlib.sha256(args.native.read_bytes()).hexdigest(),
              'scope': 'Actual original DLR measurement/ETA-getter methods only. No scheduler/global-average/provider equality credit.'}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    if differences:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
