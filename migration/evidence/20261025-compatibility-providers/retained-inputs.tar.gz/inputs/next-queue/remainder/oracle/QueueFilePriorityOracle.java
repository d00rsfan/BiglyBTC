import com.biglybt.core.Core;
import com.biglybt.core.disk.DiskManagerFileInfo;
import com.biglybt.core.disk.DiskManagerPiece;
import com.biglybt.core.download.DownloadManager;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Actual original method and disk facts from a fresh generated partial profile. */
public final class QueueFilePriorityOracle {
    static void trace(DownloadManager manager, String phase) throws Exception {
        Method method=manager.getClass().getDeclaredMethod("calcFilePriorityStats");
        method.setAccessible(true);method.invoke(manager); // Unchanged original body.
        StringBuilder bits=new StringBuilder();
        for(DiskManagerPiece piece:manager.getDiskManager().getPieces()) {bits.append(piece.isDone()?'1':'0');}
        System.out.println("QGEOMETRY\t"+phase+"\t"+manager.getTorrent().getPieceLength()
            +"\t"+manager.getTorrent().getSize()+"\t"+bits);
        for(DiskManagerFileInfo file:manager.getDiskManagerFileInfoSet().getFiles()) {
            System.out.println("QFILE\t"+phase+"\t"+file.getIndex()+"\t"+file.getTorrentFile().getOffsetInTorrent()
                +"\t"+file.getLength()+"\t"+file.getPriority()+"\t"+file.isSkipped()
                +"\t"+file.getTorrentFile().isPadFile()+"\t"+file.getDownloaded());
        }
        int[] stats=manager.getStats().getFilePriorityStats();
        if(stats.length!=4) {throw new IllegalStateException("Original file priority stats shape changed");}
        System.out.println("QSTATS\t"+phase+"\t"+stats[0]+"\t"+stats[1]+"\t"+stats[2]+"\t"+stats[3]);
    }
    static void run(String[] args) throws Exception {
        if(!(System.getSecurityManager() instanceof ReferenceFence)||args.length!=1) {
            throw new IllegalArgumentException("ReferenceFence: LISTEN_PORT; existing generated original partial profile required");
        }
        Class.forName("com.biglybt.core.util.Debug");
        Path root=Paths.get(System.getProperty("biglybtc.test.root")).toRealPath();
        if(!root.getParent().equals(Paths.get("/tmp"))||!root.getFileName().toString().startsWith("biglybtc-queue-file-priority-")) {
            throw new IllegalArgumentException("Fresh owned generated fixture root required");
        }
        Core core=EngineOracle.configuredCore(Integer.parseInt(args[0]));boolean started=false;
        try {
            core.start();started=true;
            if(core.getGlobalManager().getDownloadManagers().size()!=1) {throw new IllegalStateException("Exactly one generated saved fixture required");}
            DownloadManager manager=core.getGlobalManager().getDownloadManagers().get(0);
            if(manager.getTorrent().getSize()>4*1024*1024L||manager.getTorrent().getNumberOfPieces()>1024
                ||manager.getDiskManagerFileInfoSet().getFiles().length>32) {throw new IllegalStateException("Bounded fixture required");}
            manager.initialize();long deadline=System.nanoTime()+90000000000L;
            while(manager.getState()!=DownloadManager.STATE_READY) {
                if(manager.getState()==DownloadManager.STATE_ERROR||System.nanoTime()>=deadline) {
                    throw new IllegalStateException("Actual original READY failed: "+manager.getErrorDetails());
                }
                Thread.sleep(25);
            }
            trace(manager,"loaded");
            boolean first=true;
            for(DiskManagerFileInfo file:manager.getDiskManagerFileInfoSet().getFiles()) {
                if(file.getTorrentFile().isPadFile()) {continue;}
                file.setPriority(first?3:-2);first=false;
            }
            trace(manager,"edited");
            manager.stopIt(DownloadManager.STATE_STOPPED,false,false);
        } finally {if(started) {core.stop();}}
        System.out.println("QUEUE_FILE_PRIORITY_ORIGINAL_TRACE_STOPPED");
    }
    public static void main(String[] args) {
        try {run(args);System.exit(0);}catch(Throwable failure) {failure.printStackTrace();System.exit(2);}
    }
}
