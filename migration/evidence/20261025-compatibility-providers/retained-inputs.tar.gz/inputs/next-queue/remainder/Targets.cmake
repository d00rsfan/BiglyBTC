# Root merges this fragment; no shared/native CMake was edited by the author.
# Core.cmake belongs in core/CMakeLists; the rest belongs in tests/CMakeLists.
add_executable(biglybtc-queue-file-priority-tests queue_file_priority_tests.cpp)
target_link_libraries(biglybtc-queue-file-priority-tests PRIVATE biglybtc_core)
target_compile_options(biglybtc-queue-file-priority-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
add_test(NAME queue-file-priority COMMAND biglybtc-queue-file-priority-tests)
set_tests_properties(queue-file-priority PROPERTIES TIMEOUT 30 LABELS "unit;queue")
# Optional actual-Java trace replay, run only with its observed stdout argument.
add_executable(biglybtc-queue-file-priority-replay queue_file_priority_replay.cpp)
target_link_libraries(biglybtc-queue-file-priority-replay PRIVATE biglybtc_core)
target_compile_options(biglybtc-queue-file-priority-replay PRIVATE -Wall -Wextra -Wpedantic -Werror)
# Existing managed-queue test target gains one actual owned transfer method;
# its runtime guard, registration and deadline remain unchanged.
