#!/usr/bin/env python3
"""Finite source overlay only; never writes native or executes a subject."""
from pathlib import Path
HERE = Path(__file__).resolve().parent
BASE = Path('/home/yurii/Java/BiglyBTC')
def edit(path, changes):
    raw = (BASE/path).read_bytes()
    before = HERE/'before'/path; target = HERE/'staging'/path
    before.parent.mkdir(parents=True,exist_ok=True); target.parent.mkdir(parents=True,exist_ok=True)
    before.write_bytes(raw); text = raw.decode()
    for old,new in changes:
        assert text.count(old)==1,(path,old[:80],text.count(old))
        text=text.replace(old,new)
    target.write_text(text)
edit('preview/native/engine/managed_storage.hpp',[
    ('#include "biglybtc/library.hpp"','#include "biglybtc/library.hpp"\n#include "biglybtc/queue_file_priority.hpp"'),
    ('  bool originalProgressRequiresPieces() const noexcept;','''  bool originalProgressRequiresPieces() const noexcept;
  std::expected<core::QueueFilePriorityStats,core::QueueFilePriorityError> filePriorityStatistics(
      std::span<const std::uint8_t>) const noexcept;'''),
])
edit('preview/native/engine/managed_storage.cpp',[
    ('  ManagedQueueMetadata queue;\n  storage::TorrentStateStore store;',
     '  ManagedQueueMetadata queue;\n  std::vector<compat::FilePolicy> filePolicies;\n  storage::TorrentStateStore store;'),
    ('bool ManagedStorage::originalProgressRequiresPieces() const noexcept { return impl_&&impl_->progressFromPieces; }',
     '''bool ManagedStorage::originalProgressRequiresPieces() const noexcept { return impl_&&impl_->progressFromPieces; }
std::expected<core::QueueFilePriorityStats,core::QueueFilePriorityError> ManagedStorage::filePriorityStatistics(
    std::span<const std::uint8_t> pieces) const noexcept {
  if(!impl_) return std::unexpected(core::QueueFilePriorityError::Geometry);
  return core::queueFilePriorityStatistics(impl_->layout,impl_->filePolicies,pieces);
}'''),
    ('const auto parsedPolicy=compat::originalFilePolicy(row,layout.files.size());',
     'auto parsedPolicy=compat::originalFilePolicy(row,layout.files.size());'),
    ('    result->queue=queue; result->swarmBridge=std::move(swarmBridge);',
     '    result->queue=queue; result->swarmBridge=std::move(swarmBridge); result->filePolicies=std::move(*parsedPolicy);'),
])
edit('preview/native/engine/persistent_session.cpp',[
    ('    core::QueueActivityMemory activity;','    core::QueueActivityMemory activity;\n    std::optional<core::QueueFilePriorityStats> filePriority;'),
    ('    const bool needPieces=pieces||originalProgress;','''    const bool priorityObservation=queuePolicy&&queuePolicy->downloadOrder==core::QueueDownloadOrder::FilePriority;
    const bool needPieces=pieces||originalProgress||priorityObservation;
    value.filePriority.reset();'''),
    ('    if(originalProgress) {\n      const auto projected=', '''    if(priorityObservation&&value.status.checked&&sample.pieces.size()==value.status.totalPieces) {
      const auto priority=value.storage.filePriorityStatistics(value.verified);
      if(priority) {value.filePriority=*priority;} // Missing/malformed observation grants no invented stats.
    }
    if(originalProgress) {
      const auto projected='''),
    ('      item.activity = value.activity;','''      item.activity = value.activity;
      if(value.filePriority) {item.filePriority.emplace(value.filePriority->begin(),value.filePriority->end());}'''),
])
edit('preview/native/core/include/biglybtc/application_settings.hpp',[
    ('Active speed/ETA probes and file-priority ranking need further providers; unavailable observations retain order.',
     'File-priority order uses verified original-file observations. Active speed/ETA probes need further providers; unavailable observations retain order.'),
])
