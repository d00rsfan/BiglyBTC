# Source-only fragment: first line core/CMakeLists, remaining lines tests/CMakeLists.
target_sources(biglybtc_core PRIVATE src/queue_rate_providers.cpp)

add_executable(biglybtc-queue-rate-provider-tests queue_rate_provider_tests.cpp)
target_link_libraries(biglybtc-queue-rate-provider-tests PRIVATE biglybtc_core)
target_compile_options(biglybtc-queue-rate-provider-tests PRIVATE -Wall -Wextra -Wpedantic -Werror -ffp-contract=off)
add_test(NAME queue-rate-providers COMMAND biglybtc-queue-rate-provider-tests)
set_tests_properties(queue-rate-providers PROPERTIES TIMEOUT 30 LABELS "unit;queue")
add_executable(biglybtc-queue-rate-provider-replay queue_rate_provider_replay.cpp)
target_link_libraries(biglybtc-queue-rate-provider-replay PRIVATE biglybtc_core)
target_compile_options(biglybtc-queue-rate-provider-replay PRIVATE -Wall -Wextra -Wpedantic -Werror -ffp-contract=off)
# Replay requires actual original stdout/inputs through oracle/run_trace.py; no CTest registration.
