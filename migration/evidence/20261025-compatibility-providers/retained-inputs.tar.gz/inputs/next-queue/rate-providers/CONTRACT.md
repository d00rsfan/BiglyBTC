Bounded pure queue-rate providers; source-only, not adopted/compiled/executed.
Original cb8c6cb9bb97916cbc7e80338a017200ffc3e71f. No sampler, timer, clock read,
session, alert consumer, IO, retained DTO alias or setting mutation is added.

The global StartStopRules gate is distinct from configurable smoothing:
ChangeFlagCheckerTask captures data+protocol cumulative bytes on nominal1500ms
callbacks, skips its first baseline and feeds ten populated-as-observed doubles
to MovingImmediateAverage. Its getAverage*1000/1500/1024 conversion casts double
to int with Java saturation. QueueGlobalReceiveAverage reproduces this arithmetic,
resync and position rollover with fixed storage. Faster supplied observations
remain pending until the next nominal interval; no invented catch-up callback.
Variable/delayed owner delivery is explicitly sample-timed nominal policy, not
an exact15-second wall-time throughput measure or original timer parity.

PEPeerManagerStatsImpl smooths PAYLOAD counters through GeneralUtils production
SmoothAverage1, the already qualified SourceRateAverage time ring. Default30s,
clamp10..1800, interval floor(window/60) clamped1..20. The old interval gates
seeing a new config; reconfiguration resets the average but retains the previous
qualified cumulative baseline. QueuePayloadRateSmoothing requires a supplied
source tick and charges each new qualifying tick once. It never substitutes a
status.download_rate, instant rate or combined/protocol counter.

QueueSmoothedEta reproduces the selected getETA(true) arithmetic/cache for known
facts: max(peer remaining,disk remaining excluding DND), actual smoothed payload
rate, >900ms wall-time recalculation, minimum1 for unfinished work, source infinite
constant on observed rate0, and actual signed completion duration. The original
10000*365*24*3600 expression wraps as int before long widening; its value is
1827387392. No peer manager/missing remaining/rate is unknown, never a made-up ETA.

Native safety boundaries are deliberate and excluded from exact original trace
equivalence: first cumulative observation is baseline-only (no pre-observation
burst); missing/negative/regressed counters, invalid scope, monotone clock reset
or observed gap>3000ms withdraw history and require a fresh baseline; stale
sequence cannot mutate current state. Wall rollback withdraws ETA rather than
using Java's recalculation branch. Initial wall<=900ms is not exposed as Java's
uncalculated0. Completion timestamps must be actual, ordered and not future.
Observed real zero remains known. Signed/wrapped physical counter corruption is
not admitted merely because Java long arithmetic can wrap. No whole CF04 claim.

All new native sources are isolated in staging/preview/native; existing shared
files remain untouched. Targets.cmake is a split adoption fragment: its first
target_sources line goes into core; tests/replay declarations go into tests.
Pure test counters/results must be taken from actual root execution.

Optional finite trace (only after root builds the replay):

    python3 -B build/storage-20261025/next-queue/rate-providers/oracle/run_trace.py \
      --native-replay /ABS/BUILD/tests/biglybtc-queue-rate-provider-replay \
      --attempt run-r1

It reuses the retained5432-class cohort and exact inert provider/fence classes,
compiles only QueueRateOracle/QueueRateLauncher, and uses the successful strict
post-bootstrap fence. Actual full MovingImmediateAverage is loaded from the
retained cohort. Global update/conversion and getETA are exact source selections
inside authored containers with explicit providers; the unsmoothed provider is
deliberately different. This is method-selection arithmetic evidence, not whole
StartStopRules/PEPeerControl initialization, per-target smoothing wrapper equality,
real traffic, original tick/clock behavior or scheduler integration. No numeric
expected outputs are authored. Generated classes/inputs/stdout/stderr and failures
are retained; original cohort is verified before/after, never rebuilt.
