#!/usr/bin/env python3
"""Finite root-invoked trace; compiles only two helper sources, no original core."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            result[str(path.relative_to(root))] = sha(path)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-replay', required=True, type=Path)
    parser.add_argument('--attempt', required=True)
    args = parser.parse_args()
    assert args.attempt.startswith('run-') and '/' not in args.attempt
    parent = HERE.parent
    for rel, digest in json.loads((parent / 'manifest.json').read_bytes())['artifacts'].items():
        assert sha(parent / rel) == digest, rel
    context = json.loads((HERE / 'inputs.json').read_bytes())
    for path, digest in context['files'].items():
        assert sha(Path(path)) == digest, path
    retained = json.loads(Path(context['retention']).read_bytes())
    cohort = Path(context['cohort'])
    assert retained['recompiled'] is False and retained['source_commit'] == context['original_commit']
    assert inventory(cohort) == retained['file_sha256']
    destination = HERE / args.attempt
    assert not destination.exists() and args.native_replay.is_file()
    destination.mkdir(mode=0o700)
    work = Path(tempfile.mkdtemp(prefix='biglybtc-queue-oracle-', dir='/tmp'))
    for name in ['classes', 'empty-sourcepath', 'tmp']:
        (work / name).mkdir(mode=0o700)
    for rel, digest in context['provider_classes'].items():
        source = Path(context['provider_root']) / rel
        assert sha(source) == digest, rel
        target = work / 'classes' / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    environment = {k: v for k, v in os.environ.items() if k not in
                   ['CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'LD_PRELOAD']}
    commands = []

    def run(name, command, vectors=False):
        record = {'name': name, 'argv': list(map(str, command)), 'timeout': 60}
        commands.append(record)
        (destination / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        with (destination / (name + '.stdout')).open('wb') as out, (destination / (name + '.stderr')).open('wb') as err:
            source = (HERE / 'vectors.tsv').open('rb') if vectors else subprocess.DEVNULL
            try:
                process = subprocess.Popen(record['argv'], cwd=work, env=environment, stdin=source,
                                           stdout=out, stderr=err, start_new_session=True)
                try:
                    process.wait(timeout=40)
                except subprocess.TimeoutExpired:
                    print('Queue rate trace active: ' + name, flush=True)
                    process.wait(timeout=20)
                finally:
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
                    record['exit'] = process.returncode
                    (destination / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
                assert process.returncode == 0, name
            finally:
                if vectors:
                    source.close()

    def observations(name, terminal):
        rows = (destination / (name + '.stdout')).read_text().splitlines()
        result = {}
        for line in rows[:-1]:
            fields = line.split('\t')
            assert len(fields) == 4 and fields[0] == 'OBS' and fields[2] in ['kib', 'eta']
            key = fields[1] + '/' + fields[2]
            assert key not in result and str(int(fields[3])) == fields[3]
            result[key] = int(fields[3])
        assert rows[-1] == terminal + '\t' + str(len(result))
        return result

    try:
        java = Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')
        run('javac-helpers', [java / 'javac', '-J-XX:ActiveProcessorCount=2', '--release', '8', '-encoding', 'UTF-8',
            '-proc:none', '-implicit:none', '-sourcepath', work / 'empty-sourcepath', '-cp',
            str(work / 'classes') + os.pathsep + str(cohort), '-d', work / 'classes',
            HERE / 'QueueRateLauncher.java', HERE / 'QueueRateOracle.java'])
        compiled = inventory(work / 'classes')
        assert all(compiled.get(k) == v for k, v in context['provider_classes'].items())
        assert all(Path(k).name.split('$')[0].removesuffix('.class') in ['QueueRateLauncher', 'QueueRateOracle']
                   for k in set(compiled) - set(context['provider_classes']))
        run('original', [java / 'java', '-XX:ActiveProcessorCount=2', '-Xmx128m', '-Djava.security.manager=allow',
            '-Dqueue.oracle.root=' + str(work), '-Dqueue.oracle.cohort=' + str(cohort),
            '-Djava.io.tmpdir=' + str(work / 'tmp'), '-Duser.home=' + str(work / 'forbidden-home'),
            '-Dazureus.config.path=' + str(work / 'forbidden-profile'), '-cp', work / 'classes',
            'QueueRateLauncher', work / 'classes', cohort], True)
        run('native', [args.native_replay.resolve()], True)
        expected = observations('original', 'PASS_QUEUE_RATE_ORIGINAL')
        actual = observations('native', 'PASS_QUEUE_RATE_NATIVE')
        assert inventory(work / 'classes') == compiled
        assert actual == expected, 'Actual method-selection differences retained in stdout'
        result = {'status': 'PASS', 'actual_observations': len(actual), 'original': expected, 'native': actual,
                  'scope': context['scope'], 'native_binary_sha256': sha(args.native_replay)}
    except BaseException as failure:
        (destination / 'failure.json').write_text(json.dumps({'error': repr(failure)}) + '\n')
        raise
    finally:
        try:
            shutil.copytree(work, destination / 'generated')
        finally:
            unchanged = inventory(cohort) == retained['file_sha256']
            (destination / 'original-cohort.json').write_text(json.dumps({'unchanged': unchanged}) + '\n')
            assert unchanged
    (destination / 'observations.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
