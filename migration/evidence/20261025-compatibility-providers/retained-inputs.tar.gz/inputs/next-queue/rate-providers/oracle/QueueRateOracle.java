package queueoracle;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import com.biglybt.core.util.SystemTime;
import com.biglybt.core.util.Constants;
import com.biglybt.core.util.average.Average;
import com.biglybt.core.util.average.MovingImmediateAverage;

/** Actual retained MovingImmediateAverage plus exact selected ETA/global method bodies.
 * Containers/providers are authored; no whole peer/controller initialization is claimed. */
public final class QueueRateOracle {
    interface Eta { long getETA(boolean smoothed); }
    static final class Fixed { long value; long getAverage(){return value;} }
    static final class Disk { long value; long getRemainingExcludingDND(){return value;} }
    static final class Stats { long value; long getSmoothedDataReceiveRate(){return value;} }
    static final class Totals { long data,protocol;
        long getDataBytesReceived(){return data;} long getProtocolBytesReceived(){return protocol;} }
    static final class EtaSubject implements Eta {
        long nbBytesRemaining,last_eta,last_eta_smoothed,last_eta_calculation,_timeFinished_mono,_timeStarted_mono;
        final Disk disk_mgr=new Disk(); final Stats _stats=new Stats(); final Fixed _averageReceptionSpeed=new Fixed();
	@Override
	public long getETA(boolean smoothed){
		final long now = SystemTime.getCurrentTime();

		if(now < last_eta_calculation || now - last_eta_calculation > 900){

			long dataRemaining = Math.max(nbBytesRemaining, disk_mgr.getRemainingExcludingDND());

			long jagged_result;
			long smooth_result;

			if(dataRemaining == 0){
				final long timeElapsed = (_timeFinished_mono - _timeStarted_mono) / 1000;
				// if time was spent downloading....return the time as negative
				if(timeElapsed > 1){
					jagged_result = timeElapsed * -1;
				}else{
					jagged_result = 0;
				}
				smooth_result = jagged_result;
			}else{

				{
					final long averageSpeed = _averageReceptionSpeed.getAverage();
					long lETA = (averageSpeed == 0) ? Constants.CRAPPY_INFINITE_AS_LONG : dataRemaining / averageSpeed;
					// stop the flickering of ETA from "Finished" to "x seconds" when we are
					// just about complete, but the data rate is jumpy.
					if(lETA == 0)
						lETA = 1;
					jagged_result = lETA;
				}
				{
					final long averageSpeed = _stats.getSmoothedDataReceiveRate();
					long lETA = (averageSpeed == 0) ? Constants.CRAPPY_INFINITE_AS_LONG : dataRemaining / averageSpeed;
					// stop the flickering of ETA from "Finished" to "x seconds" when we are
					// just about complete, but the data rate is jumpy.
					if(lETA == 0)
						lETA = 1;
					smooth_result = lETA;
				}
			}

			last_eta = jagged_result;
			last_eta_smoothed = smooth_result;
			last_eta_calculation = now;
		}

		return(smoothed ? last_eta_smoothed : last_eta);
	}

    }
    static final class GlobalSubject {
        private static final int PROCESS_CHECK_PERIOD=1500;
        final Average globalDownloadSpeedAverage=new MovingImmediateAverage(10);
        final Totals dmStats=new Totals();long prevReceived=-1;
        void update(){
			long recv = dmStats.getDataBytesReceived() + dmStats.getProtocolBytesReceived();

			if ( prevReceived != -1 ){

				globalDownloadSpeedAverage.update( recv - prevReceived );
			}

			prevReceived = recv;
        }
        int kib(){
				int	downloadKBSec = (int)((globalDownloadSpeedAverage.getAverage()*1000/PROCESS_CHECK_PERIOD)/1024);
            return downloadKBSec;
        }
    }
    public static void main(String[] args)throws Exception {
        Providers.verify();
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in,"UTF-8"));
        GlobalSubject global=new GlobalSubject();EtaSubject eta=new EtaSubject();boolean baseline=false;int observations=0;
        for(String line;(line=reader.readLine())!=null;){
            if(line.isEmpty()||line.startsWith("#")){continue;}
            String[] r=line.split("\t",-1);
            if(r[0].equals("RESET")&&r.length==2){global=new GlobalSubject();eta=new EtaSubject();baseline=false;continue;}
            if(r[0].equals("G")&&r.length==5){
                global.dmStats.data=Long.parseLong(r[3]);global.dmStats.protocol=Long.parseLong(r[4]);global.update();
                if(!baseline){baseline=true;continue;}
                System.out.println("OBS\t"+r[1]+"\tkib\t"+global.kib());++observations;
            }else if(r[0].equals("E")&&r.length==10&&r[9].equals("admitted")){
                SystemTime.supply(Long.parseLong(r[3]),Long.parseLong(r[2]));
                eta.nbBytesRemaining=Long.parseLong(r[4]);eta.disk_mgr.value=Long.parseLong(r[5]);
                eta._stats.value=Long.parseLong(r[6]);eta._averageReceptionSpeed.value=12345;
                eta._timeStarted_mono=Long.parseLong(r[7]);eta._timeFinished_mono=Long.parseLong(r[8]);
                System.out.println("OBS\t"+r[1]+"\teta\t"+eta.getETA(true));++observations;
            }else{throw new IllegalArgumentException("Malformed literal trace");}
        }
        Providers.verify();System.out.println("PASS_QUEUE_RATE_ORIGINAL\t"+observations);
    }
}
