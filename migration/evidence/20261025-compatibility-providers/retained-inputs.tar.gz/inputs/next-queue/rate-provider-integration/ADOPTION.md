Post8de optional global queue-rate binding; SOURCE ONLY, uncompiled/unexecuted.

Apply the small persistent_session.cpp.patch after combined-counters8de and
adopt the four new rate-providers3d3 sources/Targets.cmake fragment together.
Do not overwrite other engine amendments with this complete candidate copy.

One fixed QueueGlobalReceiveAverage belongs to the existing PersistentSession
owner. retain() feeds the same already validated session_stats counter sample,
responses sequence and existing elapsed timestamp after essential primitive
retention. Scope is OwnerCombined: LT peer payload+BT protocol for that owner,
not original Java global/client totals or IP/DHT/tracker overhead. No extra
clock read, post, pop, callback, allocation, session or timer is introduced.
The existing queue probe gets only a known average with no counter failure and
an actual last accepted stamp no more than3000ms old. Arithmetic uses the
source ten-slot nominal1500ms conversion; callback cadence remains native.
Original timer/global-scope parity is not asserted. Saturated/uncapped and
manual/force behavior otherwise stays within the existing probe/queue policy.

Per-target smoothing and source ETA remain pure/unbound in this amendment.
Original PEPeerControlImpl.checkCompletedPieces computes peer remaining by
summing piece/block remaining (excluding pieces already handed to checks),
then getETA(true) takes max(peer remaining, disk remaining excluding DND).
Current LT total_wanted-total_wanted_done is one disk-like remaining fact;
copying it twice would fabricate the second source. There is also no qualified
original main-loop tick or smoothing-config handoff in PersistentSession.
Do not feed status.downloadRate or a fabricated tick to the pure ETA provider.
A later real remaining/tick projection must separately qualify these inputs.

Root validation: build existing affected queue/managed suites and new
queue-rate-providers; run the finite optional original trace after building its
replay. An actual owned capped-download fixture should show warmup unavailable,
known accepted source arithmetic and a withdrawn gate after missing/failure.
No runtime result is claimed here. The scalar unit suite already exercises
warmup, source conversion, zero/extremes, history and clock/scope discontinuities.
