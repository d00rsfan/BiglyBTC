Corner-only retry, source-only. Original chapter-original-plan/run-r1 and frozen corners capsule remain unchanged. Priority and probe phases are disabled in this amendment; their actual PASS results are retained in the old attempt.

Run only after root checks the new source pins:

    python3 -B /home/yurii/Java/BiglyBT/build/storage-20261025/chapter-original-plan/amendments/corner-classpath/run.py \
      --build /home/yurii/Java/BiglyBTC/build/persistent-peer-accounting-20261021/bound-gcc \
      --attempt run-r2 --phase corners

The amended recipe copies exact already-compiled helper classes into its owned /tmp root before constructing the fenced JVM classpath. No javac, permissions or fixture changes. It retains original/current helper hash checks and adds copied-helper checks. The unchanged outer process/deadline/archive machinery retains all generated roots and raw logs on success or failure. No author execution.
