#!/usr/bin/env python3
"""Root-owned, explicitly invoked original traces; never builds native targets."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
JAVA = Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')


def need(value, why):
    if not value:
        raise RuntimeError(why)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(path):
    result = {}
    for leaf in sorted(path.rglob('*')):
        need(not leaf.is_symlink(), 'Symlink in retained/generated classes')
        if leaf.is_file():
            result[str(leaf.relative_to(path))] = sha(leaf)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', required=True, type=Path)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--phase', choices=['corners'], default='corners')
    args = parser.parse_args()
    need(args.attempt.startswith('run-') and '/' not in args.attempt and '\\' not in args.attempt,
         'Fresh run-* name required')
    manifest = json.loads((HERE / 'manifest.json').read_bytes())
    for rel, expected in manifest['files'].items():
        need(sha(HERE / rel) == expected, 'Changed execution recipe: ' + rel)
    pins = json.loads((HERE / 'inputs.json').read_bytes())
    for path, expected in pins['files'].items():
        need(sha(Path(path)) == expected, 'Changed frozen input: ' + path)
    cohort = Path(pins['cohort'])
    retained = json.loads(Path(pins['retention']).read_bytes())
    need(retained['source_commit'] == pins['original_commit'] and retained['recompiled'] is False,
         'Retained original identity differs')
    need(inventory(cohort) == retained['file_sha256'], 'Original cohort changed')
    build = args.build.resolve(strict=True)
    names = {'priority': 'biglybtc-queue-file-priority-replay',
             'probes': 'biglybtc-queue-download-probe-replay',
             'corners': 'biglybtc-original-file-io-driver'}
    phases = list(names) if args.phase == 'all' else [args.phase]
    binaries = {}
    for phase in phases:
        binary = build / 'tests' / names[phase]
        info = binary.lstat()
        need(stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid() and os.access(binary, os.X_OK),
             'Root-built owned executable required: ' + str(binary))
        binaries[phase] = binary
    destination = HERE / args.attempt
    need(not destination.exists(), 'Attempt is immutable; choose a new run-*')
    destination.mkdir(mode=0o700)
    env = {k: v for k, v in os.environ.items() if k not in
           ('CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'LD_PRELOAD')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    commands, roots, results, helper_maps = [], {}, {}, {}

    def write_json(leaf, data):
        (destination / leaf).write_text(json.dumps(data, indent=2) + '\n')

    def run(name, argv, cwd, timeout, stdin=None):
        record = {'name': name, 'argv': list(map(str, argv)), 'cwd': str(cwd), 'timeout': timeout}
        commands.append(record)
        write_json('commands.json', commands)
        start = time.monotonic()
        with (destination / (name + '.stdout')).open('wb') as out, \
                (destination / (name + '.stderr')).open('wb') as err:
            stream = stdin.open('rb') if stdin is not None else subprocess.DEVNULL
            try:
                process = subprocess.Popen(record['argv'], cwd=cwd, env=env, stdin=stream,
                                           stdout=out, stderr=err, start_new_session=True)
                try:
                    while True:
                        remaining = timeout - (time.monotonic() - start)
                        if remaining <= 0:
                            raise subprocess.TimeoutExpired(record['argv'], timeout)
                        try:
                            process.wait(timeout=min(40, remaining))
                            break
                        except subprocess.TimeoutExpired:
                            print('Original plan active: ' + name, flush=True)
                finally:
                    if process.poll() is None:
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                    record['exit'] = process.returncode
                    record['seconds'] = round(time.monotonic() - start, 3)
                    write_json('commands.json', commands)
                need(process.returncode == 0, 'Failed; raw output retained: ' + name)
            finally:
                if stdin is not None:
                    stream.close()
        record['stdout_sha256'] = sha(destination / (name + '.stdout'))
        record['stderr_sha256'] = sha(destination / (name + '.stderr'))
        write_json('commands.json', commands)
        return destination / (name + '.stdout')

    def fresh(phase, prefix):
        work = Path(tempfile.mkdtemp(prefix=prefix, dir='/tmp'))
        roots[phase] = work
        for leaf in ['classes', 'empty-sourcepath', 'tmp']:
            (work / leaf).mkdir(mode=0o700)
        return work

    def copy_classes(group, work):
        for rel, digest in pins[group + '_classes'].items():
            source = Path(pins[group + '_class_root']) / rel
            need(sha(source) == digest, 'Retained helper changed: ' + str(source))
            target = work / 'classes' / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)

    def javac(phase, work, sources):
        prior = inventory(work / 'classes')
        run(phase + '-javac', [JAVA / 'javac', '-J-XX:ActiveProcessorCount=2', '--release', '8',
            '-encoding', 'UTF-8', '-proc:none', '-implicit:none', '-sourcepath', work / 'empty-sourcepath',
            '-cp', str(work / 'classes') + os.pathsep + str(cohort), '-d', work / 'classes', *sources], work, 60)
        after = inventory(work / 'classes')
        need(all(after.get(k) == v for k, v in prior.items()), 'javac changed reused helpers')
        allowed = {source.stem for source in sources}
        need(all(Path(k).name.split('$')[0].removesuffix('.class') in allowed
                 for k in set(after) - set(prior)), 'Unexpected compiler output')
        helper_maps[phase] = after
        write_json(phase + '-compiled-classes.json', after)

    try:
        if 'priority' in phases:
            work = fresh('priority', 'biglybtc-queue-file-priority-')
            copy_classes('priority', work)
            javac('priority', work, [Path(p) for p in pins['priority_sources']])
            sys.path.insert(0, pins['reference_root'] + '/migration/tools')
            spec = importlib.util.spec_from_file_location('chapter_retained_peer', pins['peer_recipe'])
            peer = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(peer)
            classpath = str(work / 'classes') + os.pathsep + str(cohort)
            run('priority-metadata', [*peer.jvm(work, classpath), 'MultiFileOracle', work], work, 150)
            listen = peer.unused_port()
            run('priority-prepare', [*peer.jvm(work, classpath, [listen]), 'MultiEngineOracle',
                listen, 0, work / 'multi-1.torrent', work / 'expected/multi-fixture', 'prepare', 'priorities'], work, 150)
            trace = run('priority-original', [*peer.jvm(work, classpath, [listen]),
                'QueueFilePriorityOracle', listen], work, 150)
            replay = run('priority-native', [binaries['priority'], trace], work, 60)
            stats = [line.split('\t') for line in trace.read_text().splitlines() if line.startswith('QSTATS\t')]
            need(stats and 'PASS actual original file-priority observation replay' in replay.read_text(), 'Replay marker missing')
            results['priority'] = {'status': 'PASS', 'actual_frames': len(stats),
                'actual_scalar_comparisons': sum(len(row) - 2 for row in stats),
                'scope': 'Actual READY disk bits/policies and original calcFilePriorityStats; no payload transfer or scheduler parity'}
        if 'probes' in phases:
            work = fresh('probes', 'biglybtc-queue-oracle-')
            copy_classes('probe', work)
            javac('probes', work, [HERE / 'QueueProbeLauncher.java', Path(pins['probe_source'])])
            vectors = Path(pins['probe_vectors'])
            original = run('probes-original', [JAVA / 'java', '-XX:ActiveProcessorCount=2', '-Xmx128m',
                '-Djava.security.manager=allow', '-Dqueue.oracle.root=' + str(work),
                '-Dqueue.oracle.cohort=' + str(cohort), '-Djava.io.tmpdir=' + str(work / 'tmp'),
                '-Duser.home=' + str(work / 'forbidden-home'), '-Dazureus.config.path=' + str(work / 'forbidden-profile'),
                '-cp', work / 'classes', 'QueueProbeLauncher', work / 'classes', cohort], work, 80, vectors)
            native = run('probes-native', [binaries['probes']], work, 60, vectors)
            comparison = destination / 'probes-comparison.json'
            run('probes-compare', [sys.executable, '-B', pins['probe_compare'], '--original', original,
                '--native', native, '--output', comparison], work, 30)
            results['probes'] = json.loads(comparison.read_bytes())
            need(results['probes']['status'] == 'PASS', 'Original probe scalar mismatch')
        if 'corners' in phases:
            work = Path(tempfile.mkdtemp(prefix='biglybtc-eof-corner-', dir='/tmp'))
            work.rmdir()  # Frozen recipe requires a fresh absent owned name.
            roots['corners'] = work
            run('corners-original-native', [sys.executable, '-B', pins['corner_recipe'],
                '--codec-driver', binaries['corners'], '--work', work], destination, 600)
            results['corners'] = json.loads((work / 'result.json').read_bytes())
            need(results['corners']['status'] == 'PASS', 'Actual raw FMFile handoff failed')
    except BaseException as failure:
        write_json('failure.json', {'status': 'FAIL', 'error': repr(failure), 'completed_results': results})
        raise
    finally:
        archive_errors = {}
        for phase, expected in helper_maps.items():
            try:
                need(inventory(roots[phase] / 'classes') == expected, 'Generated helper classes changed after compile')
            except BaseException as error:
                archive_errors[phase + '-helper-classes'] = repr(error)
        for phase, work in roots.items():
            if work.exists():
                try:
                    shutil.copytree(work, destination / (phase + '-generated'))
                except BaseException as error:
                    archive_errors[phase] = repr(error)
        try:
            cohort_ok = inventory(cohort) == retained['file_sha256']
        except BaseException as error:
            cohort_ok = False
            archive_errors['original-cohort-check'] = repr(error)
        write_json('archive.json', {'generated_roots': {k: str(v) for k, v in roots.items()},
            'durable_roots': {k: str(destination / (k + '-generated')) for k in roots},
            'errors': archive_errors})
        write_json('final-original-cohort-check.json', {'unchanged': cohort_ok, 'files': len(retained['file_sha256'])})
        need(not archive_errors, 'Archive/cohort-check errors retained; original /tmp roots left untouched')
        need(cohort_ok, 'Original retained cohort changed; failure artifacts retained')
    write_json('result.json', {'status': 'PASS', 'results': results,
        'manifest_sha256': sha(HERE / 'manifest.json'), 'original_commit': pins['original_commit'],
        'binary_sha256': {k: sha(v) for k, v in binaries.items()}, 'original_core_recompiled': False,
        'original_profile_or_process_access': False})
    print('Original chapter plan PASS; actual counts and raw output: ' + str(destination), flush=True)


if __name__ == '__main__':
    main()
