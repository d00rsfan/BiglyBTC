Root execution plan only. No helper compilation, Java/native execution or
native mutation was performed by the author. Wait for the current GCC3-job
batch to finish; do not run this alongside the three occupied compiler slots.

Required existing/new executable targets, centrally built from the adopted
chapter source (the runner never builds them):

    cmake --build /home/yurii/Java/BiglyBTC/build/persistent-peer-accounting-20261021/bound-gcc \
      --parallel 3 --target biglybtc-queue-file-priority-replay \
      biglybtc-queue-download-probe-replay biglybtc-original-file-io-driver

The existing IO driver must relink against the adopted covered-EOF implementation;
an older passing driver is not equivalent. Root already owns the native suite
qualification, so this plan adds no test family, native compilation recipe,
provider approval or old-suite rerun. Execute once when binaries are ready:

    python3 -B build/storage-20261025/chapter-original-plan/run.py \
      --build /home/yurii/Java/BiglyBTC/build/persistent-peer-accounting-20261021/bound-gcc \
      --attempt run-r1

On a specific failure, preserve run-r1 and use a new run name plus
`--phase priority`, `--phase probes` or `--phase corners` for an affected-only
retry after an explicit correction. Do not overwrite prior attempts.

Exactly five helper sources require javac, in two sequential commands. Compile
only these with Java17, --release8, -proc:none/-implicit:none and an empty source
path; no original source is available for implicit compilation:

- Priority: MultiFileOracle.java, MultiEngineOracle.java and the frozen
  QueueFilePriorityOracle.java. Reuse the three exact compiled ReferenceFence/
  EngineOracle classes from frozen oracle-all-r7, copied into the fresh private
  helper directory. The retained original5432-class/resource cohort stays the
  second classpath entry. Actual Java creates metadata, prepares one partial
  v1 multifile profile with original priority settings, reloads it to READY,
  calls the unchanged calcFilePriorityStats, edits priorities and traces again.
  No remote peer or payload transfer is requested. The existing native replay
  consumes actual stdout and checks the production observer; no expected
  numeric result is authored here.
- Probes: the frozen QueueProbeOracle.java and the new QueueProbeLauncher.java.
  Reuse exactly12 necessary compiled provider/fence classes from the successful
  signature-amendment/run-r1 cohort, excluding the unused rank oracle/launcher.
  They include the explicit signature-only StringInterner scaffold. The new
  launcher is the successful post-VM-bootstrap launcher with only its two helper
  names changed. It installs the unchanged strict QueueOracleFence before any
  original subject loader exists; launch with java.security.manager=allow,
  never the already-failed pre-VM QueueOracleFence option. The actual retained
  RankCalculatorReal scalar methods see explicit combined endpoints and ETA
  providers. Both native and Java consume the same frozen vectors; the existing
  comparator derives counts only from actual outputs.

The corner phase needs no javac. It invokes the unchanged frozen corners/oracle.py
against the current IO driver, reusing its exact original/storage helper cohort.
It compares actual original and native supplied-byte writes and both cross-readers.
The original17 test-family bodies remain unchanged. Independent requests without
genuine missing suffix bytes and the fully allocated oversized EOF-short inherited
map remain outside this slice. No synthetic zero, truncation, GM READY/resume,
selected completion or whole CF01 claim follows from a raw FMFile result.

The runner preflights the frozen source/helper/retention pins and native observer/
replay/IO source before creating owned roots. It strips inherited Java/classpath/
preload overrides, bounds child groups, prints a40-second heartbeat, joins/kills
only its own groups, and verifies the unchanged original cohort afterward.
Every generated /tmp profile, helper-class directory, metadata, tape and output
is copied in finally to chapter-original-plan/run-*/<phase>-generated on success
or failure; command/stdout/stderr records are already durable there. Original
/tmp roots are retained. Archive failure refuses PASS. No live original profile,
process, public peer, multicast or original rebuild is permitted.

Counts/results remain unset until root executes. Probe agreement is inert
measurement/ETA-getter arithmetic only, not the native payload-scoped observation
provider, global average, active probing or whole scheduler equality. Priority
agreement covers actual original disk/policy projection only. Existing compiler
and owned payload tests remain separate evidence.
