#!/usr/bin/env python3
"""Source-only closed composition; writes only beside this script."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
W = OUT.parent
ORIGINAL = W.parents[1]
NATIVE = Path('/home/yurii/Java/BiglyBTC')
BASE = '4f948e042df9467310a5752d4343b07915673f84'
UPSTREAM = 'cb8c6cb9bb97916cbc7e80338a017200ffc3e71f'
LAYERS = [
    ('next-network/remainder', 'de9f1b71272a9aee96f114ecb1e440072026a24e905f92de83107d9093c202bb'),
    ('next-storage/corners', '09223916c8f9c1a63dc65a69e952fc5891005395aad133a80ccadf9ede1f43f9'),
    ('next-workflows/remainder', 'd56950593e6fc7615ef0a4712582369915d7cd1d165185295e8c6d526341aad2'),
    ('next-queue/remainder', 'e8f86582a51ad1d3c67e63990e0856decfb5602caad0638f87d5319be2038694'),
    ('next-queue/probes', 'd2f1c7828d9c47e7cd19025b6962f959cd9c523027091b91fbcc72f2dde8ce39'),
    ('next-plugins/remainder', '64e47facb08d2d2ba24e1b547d063824167ccd9da20c34c30e6e4d5f13ff372f'),
    ('next-plugins/rating-wiring', '9967a2157c7dbc4bcee0e130b259b5231690b7f4ce775dfd7daf3032a7f37018'),
]


def sha(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def read_json(path):
    return json.loads(path.read_bytes())


def pinned(path, digest):
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    assert sha(data) == digest, (path, sha(data), digest)
    return data


def key(path):
    result = path if path.startswith('preview/native/') else 'preview/native/' + path
    assert not Path(result).is_absolute() and '..' not in Path(result).parts
    return result


def git_bytes(repo, rev, path):
    result = subprocess.run(['git', '-C', str(repo), 'show', rev + ':' + path],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if result.returncode:
        assert result.returncode == 128 and b'does not exist' in result.stderr, result.stderr
        return None
    return result.stdout


observed_head = subprocess.check_output(['git', '-C', str(NATIVE), 'rev-parse', 'HEAD'], text=True).strip()
# A separate root publication may advance HEAD; each touched file must still
# equal the exact requested base blob below. Never silently rebase the capsule.
manifests = {}
artifact_count = 0
for name, digest in LAYERS:
    path = W / name / 'manifest.json'
    manifests[name] = json.loads(pinned(path, digest))
    for rel, expected in manifests[name].get('artifacts', {}).items():
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
        pinned(W / name / rel, expected)
        artifact_count += 1

# Retain the exact original source authorities, without running their subjects.
original_pins = {}
for name in ['next-queue/remainder', 'next-storage/corners', 'next-workflows/remainder']:
    m = manifests[name]
    original_pins.update(m.get('original_source_sha256', {}))
    if 'original' in m:
        original_pins[m['original']['path']] = m['original']['sha256']
network_pins = read_json(W / 'next-network/remainder/provenance.json')
original_pins.update({p: v['sha256'] for p, v in network_pins['original_sources'].items()})
probe_pins = read_json(W / 'next-queue/probes/oracle/source-pins.json')
original_pins.update({p: v['sha256'] for p, v in probe_pins['source'].items()})
rating_pins = read_json(W / 'next-plugins/remainder/source-pins.json')
plugin_pins = {}
for spec, facts in rating_pins['original_sources'].items():
    revision, rel = spec.split(':', 1)
    repo = ORIGINAL if revision == UPSTREAM else Path('/home/yurii/Java/BiglyBT-plugin-azrating')
    assert sha(git_bytes(repo, revision, rel)) == facts['sha256'], spec
    plugin_pins[spec] = facts['sha256']
for rel, digest in original_pins.items():
    assert sha(git_bytes(ORIGINAL, UPSTREAM, rel)) == digest, rel

base = {}
state = {}
chains = {}


def original(rel):
    if rel not in base:
        base[rel] = git_bytes(NATIVE, BASE, rel)
        actual = (NATIVE / rel).read_bytes() if (NATIVE / rel).is_file() else None
        assert actual == base[rel], ('native changed from committed baseline', rel)
    return base[rel]


for name, digest in LAYERS:
    m = manifests[name]
    if 'source_sha256' in m:
        after = m['source_sha256']
        before = m['before_sha256']
    else:
        after = {p: v['sha256'] if isinstance(v, dict) else v for p, v in m['sources'].items()}
        before = m.get('before_sha256', {p: v['before_sha256'] for p, v in m['sources'].items() if isinstance(v, dict)})
    for rel0, digest_after in after.items():
        rel = key(rel0)
        old = state.get(rel, original(rel))
        assert sha(old) == before.get(rel0), (name, rel, sha(old), before.get(rel0))
        new = pinned(W / name / 'staging' / rel, digest_after)
        # Exact beforeimage matching is required even for a chained replacement.
        # No three-way guess, dropped hunk or overwrite of a different base.
        state[rel] = new
        chains.setdefault(rel, []).append({'capsule': name, 'manifest_sha256': digest,
                                         'before_sha256': sha(old), 'source_sha256': sha(new)})
    for rel, digest_input in m.get('input_sha256', {}).items():
        assert sha(original(key(rel))) == digest_input, (name, rel)

for rel, digest in rating_pins['native_context_sha256'].items():
    assert sha(original(key(rel))) == digest, rel
for rel, digest in manifests['next-plugins/rating-wiring']['bulk_unchanged_source_sha256'].items():
    assert sha(state[rel]) == digest, rel
assert manifests['next-queue/probes']['dependency']['sha256'] == dict(LAYERS)['next-queue/remainder']
for path, digest in manifests['next-plugins/rating-wiring']['dependency_manifest_sha256'].items():
    assert dict(LAYERS)[path.removesuffix('/manifest.json')] == digest


def append(rel, text, fragment_names):
    old = original(rel)
    assert old is not None and rel not in state
    state[rel] = old.rstrip(b'\n') + b'\n\n' + text.strip().encode() + b'\n'
    chains[rel] = [{'operation': 'append exact scoped fragments', 'fragments': fragment_names,
                   'before_sha256': sha(old), 'source_sha256': sha(state[rel])}]


def fragment(name, filename):
    return (W / name / filename).read_text()


core = fragment('next-queue/remainder', 'Core.cmake') + '\n' + fragment('next-queue/probes', 'Core.cmake')
append('preview/native/core/CMakeLists.txt', core,
       ['next-queue/remainder/Core.cmake', 'next-queue/probes/Core.cmake'])

bulk = fragment('next-workflows/remainder', 'CMake.fragment.cmake')
bulk_ui, bulk_tests = bulk.split('# Append in tests/CMakeLists.txt.', 1)
bulk_tests = '# Append in tests/CMakeLists.txt.' + bulk_tests
rating = fragment('next-plugins/remainder', 'Targets.cmake')
rating_lib, rating_rest = rating.split('target_sources(biglybtc_ui PRIVATE', 1)
rating_ui, rating_tests = ('target_sources(biglybtc_ui PRIVATE' + rating_rest).split('add_executable(biglybtc-local-rating-tests', 1)
rating_tests = 'add_executable(biglybtc-local-rating-tests' + rating_tests
wiring = fragment('next-plugins/rating-wiring', 'CMake.fragment.cmake')
wiring_host, wiring_tests = wiring.split('add_executable(biglybtc-local-rating-wiring-tests', 1)
wiring_tests = 'add_executable(biglybtc-local-rating-wiring-tests' + wiring_tests

append('preview/native/ui/CMakeLists.txt', bulk_ui + '\n' + rating_ui,
       ['next-workflows/remainder/CMake.fragment.cmake:ui', 'next-plugins/remainder/Targets.cmake:ui'])
append('preview/native/app/CMakeLists.txt', 'if(BIGLYBTC_DESKTOP)\n' +
       '\n'.join('  ' + line if line else '' for line in (rating_lib + '\n' + wiring_host).splitlines()) + '\nendif()',
       ['next-plugins/remainder/Targets.cmake:profile-library', 'next-plugins/rating-wiring/CMake.fragment.cmake:host-link'])
tests = '\n'.join([fragment('next-queue/remainder', 'Targets.cmake'),
                   fragment('next-queue/probes', 'Targets.cmake'),
                   fragment('next-network/remainder', 'Targets.cmake'), bulk_tests,
                   'if(BIGLYBTC_DESKTOP AND BIGLYBTC_LOCAL_ENGINE)',
                   '\n'.join('  ' + line if line else '' for line in (rating_tests + '\n' + wiring_tests).splitlines()),
                   'endif()'])
append('preview/native/tests/CMakeLists.txt', tests,
       ['next-queue/remainder/Targets.cmake', 'next-queue/probes/Targets.cmake',
        'next-network/remainder/Targets.cmake', 'next-workflows/remainder/CMake.fragment.cmake:tests',
        'next-plugins/remainder/Targets.cmake:tests', 'next-plugins/rating-wiring/CMake.fragment.cmake:tests'])

# All existing CMake content is retained, with no provider, causal or engine-off
# gate changes. Queue pure tests are unconditional; new Qt targets stay desktop.
for rel in [p for p in state if p.endswith('CMakeLists.txt')]:
    assert state[rel].startswith(base[rel].rstrip(b'\n') + b'\n\n')
tests_source = state['preview/native/tests/CMakeLists.txt'].decode()
new_suites = ['network-proxy-owner', 'queue-file-priority', 'queue-download-probes',
              'file-operation-sequence', 'local-rating-host-ui', 'local-rating-wiring']
for suite in new_suites:
    assert tests_source.count('NAME ' + suite + ' ') == 1, suite
assert sha(state['preview/native/tests/managed_queue_tests.cpp']) == '5afee85833de86aeac936c55154f25e6595c7ac3cba2afbd61a93b0d5a1c2846'

# Nothing is written until all capsule/source/beforeimage checks above succeed.
for rel, data in sorted(state.items()):
    target = OUT / 'staging' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists(), target
    target.write_bytes(data)
    if base[rel] is not None:
        before_path = OUT / 'before' / rel
        before_path.parent.mkdir(parents=True, exist_ok=True)
        before_path.write_bytes(base[rel])

patch = ''.join(''.join(difflib.unified_diff(
    (base[rel] or b'').decode().splitlines(keepends=True), data.decode().splitlines(keepends=True),
    fromfile='a/' + rel if base[rel] is not None else '/dev/null', tofile='b/' + rel))
    for rel, data in sorted(state.items()))
(OUT / 'changes.patch').write_text(patch)
checks = {
    'status': 'SOURCE_COMPOSED_UNCOMPILED_UNEXECUTED_UNADOPTED',
    'input_artifact_hashes_checked': artifact_count,
    'native_base_commit': BASE,
    'native_head_observed': observed_head,
    'exact_beforeimages_and_chained_afterimages': True,
    'original_cb8_source_pins': original_pins,
    'rating_original_source_pins': plugin_pins,
    'per_path_chain': chains,
    'unchanged_cmake_original_content': True,
    'no_divergent_base_or_fuzzy_merge': True,
    'new_ctest_names_source_only': new_suites,
    'actual_test_counts': None,
    'excluded': ['unfrozen Driver4a draft'],
    'executions': [],
}
(OUT / 'composition.json').write_text(json.dumps(checks, indent=2, sort_keys=True) + '\n')
manifest = {
    'schema': 1,
    'status': checks['status'],
    'native_base_commit': BASE,
    'source_directory': 'staging',
    'dependency_manifest_sha256': {name + '/manifest.json': digest for name, digest in LAYERS},
    'before_sha256': {rel: sha(base[rel]) for rel in sorted(state)},
    'source_sha256': {rel: sha(data) for rel, data in sorted(state.items())},
    'source_count': len(state),
    'actual_test_counts': None,
    'executions': [],
    'artifacts': {str(p.relative_to(OUT)): sha(p.read_bytes()) for p in sorted(OUT.rglob('*'))
                  if p.is_file() and p.name != 'manifest.json'},
}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({'paths': len(state), 'manifest_sha256': sha((OUT / 'manifest.json').read_bytes()),
                  'composition_sha256': sha((OUT / 'composition.json').read_bytes()),
                  'patch_sha256': sha((OUT / 'changes.patch').read_bytes())}))
