R3 replaces only recipe source-union handling; r1/r2 remain immutable. No helper/subject execution or shared/native writes by author.

Root fills completion-template.json source_push_receipt with actual successful471 push receipt. Current actual commit receipts are prefilled: c8a implementation67 paths and471 test-only5 paths. Each lane has original/focused stems, prefilled to root announced actual names; change only if real receipt names differ.

The pinned fortified-qualification/union.py requires original40 rows; GCC/Clang all40 PASS, SAN exactly38 unaffected PASS plus the two known failures. Focused receipts require exit0 and exactly the two affected suites PASS. Latest credit is38+2=40 per lane. Both complete source maps must have identical keys and differ ONLY in the exact five BEFORE/AFTER test pins from the471 commit receipt. All non-test production/provider sources must remain byte-identical. Cross-lane maps agree at each source, not across c8a versus471. No identical full-snapshot or40-rerun claim.

    python3 -B build/storage-20261025/compatibility-evidence-r3/retain.py --completion compatibility-evidence-r3/completion-r1.json
    python3 -B build/storage-20261025/compatibility-evidence-r3/retain.py --completion compatibility-evidence-r3/completion-r1.json --write

Only the second command creates the fresh fixed migration/evidence/20261025-compatibility-providers root. All other original/provider/preflight/archive gates remain. Failed SAN2 and interrupted/fixed histories are retained, along with the actual focused receipts and exact5 followup capsule. Candidate package trees, copied ELF bins and HOME/XDG environment trees are excluded from compressed retention; private result/log/alias/RPATH evidence and captures remain included. Root separately exports the reviewed evidence and tracking in its final metadata batch; no automatic native export or commit.
