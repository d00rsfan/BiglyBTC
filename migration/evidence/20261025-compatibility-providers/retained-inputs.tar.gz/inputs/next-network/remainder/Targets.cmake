# Merge into tests/CMakeLists only after adopting the two source paths.
if(BIGLYBTC_LOCAL_ENGINE AND BIGLYBTC_DESKTOP
    AND BIGLYBTC_PAYLOAD_COUNTER_TEST_LANE STREQUAL "Qualified"
    AND NOT BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST STREQUAL "")
  find_package(Qt6 6.12.0 EXACT REQUIRED COMPONENTS Network Test)
  add_executable(biglybtc-network-proxy-owner-tests network_proxy_owner_tests.cpp)
  set_target_properties(biglybtc-network-proxy-owner-tests PROPERTIES AUTOMOC ON)
  target_link_libraries(biglybtc-network-proxy-owner-tests PRIVATE biglybtc_local_engine biglybtc_profile
    LibtorrentRasterbar::torrent-rasterbar Qt6::Core Qt6::Network Qt6::Test)
  target_compile_options(biglybtc-network-proxy-owner-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
  add_test(NAME network-proxy-owner COMMAND biglybtc-network-proxy-owner-tests)
  set_tests_properties(network-proxy-owner PROPERTIES TIMEOUT 180 LABELS "unit;network;loopback;qualified-runtime")
endif()
