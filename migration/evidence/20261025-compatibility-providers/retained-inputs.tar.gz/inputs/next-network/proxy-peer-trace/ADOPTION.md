Source-only next diagnostic, current d367 retained. No rebuild/rerun/native change.

Actual r2 establishes tracker GET success, two real SOCKS CONNECT upstream routes and checked downloader with0pieces/payload. It does not preserve the seed peer handshake/error events; the seed alert consumer discarded them. Thus a real SOCKS/data/provider or fixture-relay defect remains distinguishable only by those missing facts; do not relax encryption, SSRF, deadlines or data completion.

Add bounded96-byte prefix/Qt accepted relay counts in each direction, only after genuine CONNECT. Labels say queued, not socket-delivered payload proof. The exact read QByteArray is forwarded unchanged; a short/error write now explicitly diagnoses a broken fixture relay instead of silently dropping bytes. No raw passwords/SOCKS auth frame is retained. Up to four routes enter failure text.

The SAME single seed alert consumer retains only actual connect/disconnect/peer error/invalid request/upload/drop and selected protocol-log messages (last48,256characters each). Failure includes current actual seed status and accepted-peer/direct-source facts. No synthetic handshake/request, second alert consumer, new route, timer or sampler. Existing receiver completion predicate,30000ms deadline, source/byte/no-fallback assertions and successful actual close/storage checks are unchanged. Existing early-failure socket abort/close remains.

Root can rebuild the one fixture and run the existing isolated SOCKS4 row once. No passing or causal-fix claim is made here; precise received peer error/handshake/relay direction must drive the next correction.
