// Exact-source BiglyBTC provider extension, not upstream LT API.
// A marker alone does not authorize a runtime. Requires reviewed full source,
// imported header/artifact identity and the actual loaded-image qualification.
#ifndef BIGLYBTC_LIBTORRENT_SOCKS4A_HPP
#define BIGLYBTC_LIBTORRENT_SOCKS4A_HPP
#include "libtorrent/config.hpp"
namespace libtorrent {
// Private socks5_stream discriminator; no settings enum or object layout change.
inline constexpr int biglybtc_socks4a_version = 41;
extern "C" TORRENT_EXPORT unsigned biglybtc_socks4a_abi_v1() noexcept;
}
#endif
