Deferred admission, not implemented or enabled here.

1. Root must qualify the exact rebuilt source/header/artifact and actual mapped-image identity, including this provider marker in the same approved DSO. Existing default-unbound and instrumented exact-path rules remain. Marker/version/release alone never authorizes a provider.
2. Append NetworkProxyKind::Socks4a after Http; keep existing ordinals. Parse original V4a only after the new capability is bound. Translate to LT socks4 plus proxy_hostnames=true and explicit username; numeric Socks4 remains proxy_hostnames=false. Remove current USERID refusal only under that exact capability.
3. Keep password, UDP/DHT, incoming, IPv6/bind, unsupported Tor/I2P and no-bypass constraints. Original tracker SOCKS uses its own protocol; simultaneous different tracker/data protocols/endpoints remain unsupported until genuinely representable. This candidate does not authorize that mixed route.
4. Validate raw numeric4/4a packets and actual owned peer payload, HTTP success/refusal, no-direct-route observations and copied-runtime failure gates before native admission. No tab/UI action can activate routes. No configuration rewrite/default materialization.

Provider factory sets version before set_dst_name; the4a path preserves overlong input for explicit rejection. Current qualified d367 and all existing catalogs remain untouched.
