Source-only recipe. No helper or subject execution by the author. Root owns the
actual tests, source commit/push, tracking, hosted and promotion decisions.

After actual final results, copy completion-template.json to a new file under W.
Fill native_source with the actual full commit and source_commit_receipt /
source_push_receipt with relative W paths. Receipts use the existing root
{source,...} and {source,exit:0,...} schemas. Each lane is a list of actual
check.py case stems, without suffixes, e.g. chapter-next-clang-tests-r2. Do not
guess r1/r2 from this example. All listed runs must have exit0, no skipped rows,
matching command/XML/source map and collectively exactly the frozen40 suites.
Their full final source maps must agree. Failed/interrupted earlier attempts
are archived automatically but cannot satisfy a gate.

Optional additional_receipts are relative W paths for source publication,
hosted, portable or review records. They are retained, not interpreted as new
qualification/approval. A later publication record must explicitly state those
separate outcomes; verification.json is local qualification plus source push.

Root commands (no compiler, test executable, Java, loader, staging or Git write):

    python3 build/storage-20261025/compatibility-evidence/retain.py \
      --completion compatibility-evidence/completion-r1.json
    python3 build/storage-20261025/compatibility-evidence/retain.py \
      --completion compatibility-evidence/completion-r1.json --write

The first form verifies read-only. The second writes the NEW fixed namespace
migration/evidence/20261025-compatibility-providers, refusing an existing output.
It never exports into the sibling repository or changes shared docs/lock/index.
An interruption keeps INCOMPLETE.json; preserve that attempt rather than merging
it into a new output. Root may use one --write invocation after reviewing inputs.

Full member hashes are inside retained-inputs.tar.gz:MEMBERS.json. Source maps
are gzip-compressed, historical/current provider source/build/SDK binaries are
not copied. Records/maps/deltas and exact artifact references are preserved.
The 504 MB closed-fixture cache stays at tmp-cache-relief-r1/closed-fixtures.tar.gz;
only its receipt, plan and inventory enter this archive. Existing v2-workflows
evidence is referenced without duplication. The imported Scheduler and native
SOCKS4a/USERID capsules are excluded: those are the two next milestones.

REVIEW.draft.md is intentionally pending. The helper substitutes only actual
source + local completion status; it does not invent CI, dist or metadata success.
tracking-plan.json proposes registry changes only. Root resolves actual full
native hashes and appends source review/evidence records before declaring this
bounded chapter complete. Broad components keep first_ported/integrated null.
