#!/usr/bin/env python3
"""One-job private product staging and deployment-only qualification; no promotion."""
import argparse
import hashlib
import json
import importlib.util
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tempfile
import time
import xml.etree.ElementTree as ET
sys_source = '471ebb75fc66fefb0208b0d086a934b68aced84b'
implementation_source = 'c8afff5311e4ff650b17d09651e3db440a0c93e8'
N = Path('/home/yurii/Java/BiglyBTC')
W = Path('/home/yurii/Java/BiglyBT/build/storage-20261025')
HERE = W / 'chapter-private-portable-r3'
B = N / 'build/persistent-peer-accounting-20261021/bound-gcc'
DSO = W / 'provider-next/install/lib/libtorrent-rasterbar.so.2.0.12'
DSO_SHA = 'b0e55bfbdc2be5dc2ebbefc953837d64c9e5151b0305332335071e37b6956937'
PROVIDER = N / 'preview/native/engine/runtime-binding/provider-next-runtime.json'
PROVIDER_SHA = '3342ec8ae72ecafa4a1b887e664d0d066fffce4f7d864b0b130ca903be953a3a'
TESTS = {'provider-payload-counter': 'biglybtc-provider-payload-counter-tests',
         'selected-swarm-admission': 'biglybtc-selected-swarm-admission-tests',
         'persistent-native-peer-session': 'biglybtc-persistent-session-tests',
         'managed-download': 'biglybtc-managed-download-tests',
         'managed-combined-protocol': 'biglybtc-managed-combined-protocol-tests'}
CONTROL_TARGETS = ['biglybtc-provider-next-runtime-deployment-driver', 'biglybtc-runtime-interposition-driver', 'biglybtc-runtime-interposer']
STAGER_SHA = '3287dc0627f9862a9b3a25d22c86abaa492b4c894a07c6c606aa03d7c973c387'
DEPLOY_SHA = '7b04b000cf810cc1b5684232a38abe7262f1b40414355bf1f63fdc9bbf6cafe6'
PLAN_SHA = '08f33ea58ce8644a3ada1978881fb8d21ed1e76ce1966d0aa723815ed0b12dcf'
CAPTURE_PLAN_SHA = '1628b8ebd12bddc1fc093da923bb5b8a703d404de66775b0c8637d1cf0a7e703'
PREPARE_SHA = '6b924e7807770de74dc06202cbfbd0cc561a9fd2ac99805ec433caf2064e2ade'
DEPLOY_NAME = 'provider-next-runtime-deployment'

def require(value, reason):
    if not value:
        raise RuntimeError(reason)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def bundle(path):
    raw = path / 'BUILD_MANIFEST.json'
    value = json.loads(raw.read_text())
    for rel, digest in value['files_sha256'].items():
        leaf = path / rel
        require(not Path(rel).is_absolute() and '..' not in Path(rel).parts
                and leaf.resolve(strict=True).is_relative_to(path.resolve(strict=True))
                and leaf.is_file() and sha(leaf) == digest, 'Bundle byte/path mismatch: ' + rel)
    require({str(p.relative_to(path)) for p in path.rglob('*') if p.is_file()}
            == set(value['files_sha256']) | {'BUILD_MANIFEST.json'}, 'Bundle inventory mismatch')
    return sha(raw), value

def source():
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=N, text=True).strip() == sys_source,
            'Root source changed before private staging')
    require(subprocess.run(['git', 'diff', '--quiet', sys_source, '--', 'preview/native'], cwd=N).returncode == 0,
            'Native production source changed before staging')
    return {str(p.relative_to(N)): sha(p) for p in sorted((N / 'preview/native').rglob('*')) if p.is_file()}

def passed_xml(path):
    rows = list(ET.fromstring(path.read_bytes()).iter('testcase'))
    require(rows and len({t.get('name') for t in rows}) == len(rows), 'Invalid actual GCC XML')
    require(all(t.get('status', 'run') == 'run' and all(t.find(k) is None
                for k in ('failure', 'error', 'skipped')) for t in rows), 'Failed/skipped GCC suite')
    for row in rows:
        text = row.findtext('system-out') or ''
        require(not re.search(r'^SKIP\s*:', text, re.MULTILINE), 'Skipped GCC Qt row')
        require(all(f == k == '0' for f, k in re.findall(
            r'Totals:\s*\d+ passed, (\d+) failed, (\d+) skipped', text)), 'Nonpassing GCC Qt totals')
    return {t.get('name') for t in rows}

def property_value(test, name):
    values = [p['value'] for p in test['properties'] if p['name'] == name]
    require(len(values) == 1, 'Missing/duplicate registered property: ' + name)
    return values[0]

def qualification_module():
    path = W / 'fortified-qualification/union.py'
    require(sha(path) == '3f86476ecd6d8dcddc2c7e147aafd5fd079c756b4bd925a173494a5b4b397da0', 'Changed exact38+2 qualification helper')
    spec = importlib.util.spec_from_file_location('biglybtc_fortified_qualification', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gcc-case', required=True, help='Actual completed40-suite root check.py case stem')
    parser.add_argument('--focused-case', required=True, help='Actual471 two-suite root check.py case stem')
    parser.add_argument('--attempt', default='run-r1', help='Fresh run-rN under this namespace')
    args = parser.parse_args()
    require(re.fullmatch(r'chapter-[A-Za-z0-9_-]+', args.gcc_case), 'Invalid GCC case stem')
    require(re.fullmatch(r'chapter-[A-Za-z0-9_-]+', args.focused_case), 'Invalid focused case stem')
    require(re.fullmatch(r'run-r[1-9][0-9]*', args.attempt), 'Invalid fresh attempt name')
    OUT = HERE / args.attempt
    CANDIDATE = OUT / 'candidate'
    require(os.getpriority(os.PRIO_PROCESS, 0) >= 5, 'Run this recipe with nice -n5')
    before = source(); old_sha, old = bundle(N / 'dist')
    require(not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'],
                                      cwd=N, text=True).strip(), 'Require clean exact471 HEAD')
    gcc_receipt = W / (args.gcc_case + '-receipt.json')
    gcc_xml = W / (args.gcc_case + '.xml')
    gcc_map = W / (args.gcc_case + '-source.json')
    union_proof, implementation_map, qualified_map, union_paths = qualification_module().verify_lane(
        'gcc', args.gcc_case, args.focused_case)
    require(qualified_map == before, 'Current source is not exact qualified471 map')
    focused_receipt = W / (args.focused_case + '-receipt.json')
    require(sha(N / 'preview/migration/tools/stage_preview.py') == STAGER_SHA and
            sha(N / 'preview/native/tests/runtime_deployment_tests.py') == DEPLOY_SHA and
            sha(W / 'remainder-portable/plan.json') == CAPTURE_PLAN_SHA and
            sha(N / 'preview/native/packaging/preview.py') == PREPARE_SHA,
            'Changed reviewed packaging/deployment/profile/capture recipe')
    require(old_sha == 'deefcbe40681c1cd2d7352869be399d4e75d5d935a691bdc921fba11db71b221', 'Published dist baseline changed')
    require(sha(DSO) == DSO_SHA and DSO.stat().st_size == 9085072 and sha(PROVIDER) == PROVIDER_SHA,
            'Not the exact private b0e/3342 source provider')
    cache = (B / 'CMakeCache.txt').read_text()
    require('BIGLYBTC_BUNDLE_QT:BOOL=ON' in cache and 'BIGLYBTC_PAYLOAD_COUNTER_TEST_LANE:STRING=Qualified' in cache
            and 'BIGLYBTC_CAUSAL_QUALIFICATION_TESTS:BOOL=OFF' in cache
            and 'BIGLYBTC_EXPECT_COMBINED_COUNTERS:STRING=1' in cache
            and re.search(r'^CMAKE_CXX_COMPILER:[^=]+=/usr/bin/g\+\+-16$', cache, re.MULTILINE)
            and ('BIGLYBTC_PERSISTENT_RUNTIME_MANIFEST:FILEPATH=' + str(PROVIDER)) in cache,
            'Wrong exact private GCC cache/lane')
    OUT.mkdir(exist_ok=False)
    logs = OUT / 'verification'; logs.mkdir()
    save(logs / 'source-map.json', before)
    save(logs / 'baseline.json', {'source': sys_source, 'dist_manifest_sha256': old_sha,
        'dist_qualified_source': old.get('native_source', old.get('source_commit')),
        'provider_sha256': DSO_SHA, 'provider_manifest_sha256': PROVIDER_SHA,
        'recipe_sha256': sha(Path(__file__)),
        'implementation_source': implementation_source, 'qualification_union': union_proof,
        'qualification_helper_sha256': sha(W / 'fortified-qualification/union.py'),
        'gcc_matrix': {'case': args.gcc_case, 'receipt_sha256': sha(gcc_receipt),
                       'xml_sha256': sha(gcc_xml), 'source_sha256': sha(gcc_map)},
        'distribution_scope': 'private-qualification-only', 'shipping_approved': False,
        'stager_sha256': sha(N / 'preview/migration/tools/stage_preview.py')})
    commands = []
    env = {k: v for k, v in os.environ.items() if not k.startswith(('BIGLYBTC_', 'LD_', 'QT_', 'XDG_'))
           and k not in ('HOME', 'PYTHONPATH', 'PYTHONHOME', 'TMPDIR')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    environment_root = OUT / 'environment'; environment_root.mkdir(mode=0o700)
    for key in ('HOME', 'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_RUNTIME_DIR', 'XDG_DATA_HOME'):
        directory = environment_root / key.lower(); directory.mkdir(mode=0o700); env[key] = str(directory)
    # Compiler scratch is separate from the actual generated runtime profiles.
    compiler_tmp = W / 'compiler-tmp'
    require(compiler_tmp.is_dir() and not compiler_tmp.is_symlink() and
            compiler_tmp.resolve(strict=True) == compiler_tmp, 'Missing canonical compiler scratch root')
    env['TMPDIR'] = str(compiler_tmp)
    def run(name, argv, timeout=120, expected=0):
        started = time.monotonic(); timed_out = False
        with (logs / (name + '.log')).open('x') as out:
            child = subprocess.Popen(list(map(str, argv)), cwd=N, env=env, stdout=out, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            while True:
                remaining = timeout - (time.monotonic() - started)
                if remaining <= 0:
                    timed_out = True
                    try:
                        os.killpg(child.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=5)
                    break
                try:
                    child.wait(timeout=min(30, remaining)); break
                except subprocess.TimeoutExpired:
                    print(name + ' running; full log retained', flush=True)
        commands.append({'name': name, 'argv': list(map(str, argv)), 'exit_code': child.returncode,
            'expected_exit': expected, 'timed_out': timed_out, 'seconds': time.monotonic() - started,
            'log_sha256': sha(logs / (name + '.log'))})
        save(logs / 'commands.json', commands)
        require(not timed_out and child.returncode == expected, 'Command failed: ' + name)
        print(name + ' PASS', flush=True)
        return (logs / (name + '.log')).read_text()
    products = ['BiglyBTC', 'BiglyBTC-headless', 'biglybtc-preview-smoke']
    # Reconfigure/engine relinking can stale existing positives, controls and
    # Qt autogen outputs. Build the SAME finite target set checked below once.
    targets = list(dict.fromkeys(products + list(TESTS.values()) + CONTROL_TARGETS))
    all_targets = targets
    run('build-needed-products-and-owner-loader-tests', ['cmake', '--build', B, '--parallel', '1', '--target', *targets], 1200)
    require(source() == before, 'Source changed during one-job build')
    dry = run('no-stale-products', ['cmake', '--build', B, '--target', *all_targets, '--', '-n'], 60)
    require('no work to do' in dry.lower(), 'Stale executable after build')
    catalog_text = run('test-catalog', ['ctest', '--test-dir', B, '--show-only=json-v1'], 60)
    catalog = {v['name']: v for v in json.loads(catalog_text)['tests']}
    require(set(TESTS) <= catalog.keys() and DEPLOY_NAME in catalog,
            'Deployment cohort missing from registered GCC tests')
    run('stage', ['python3', N / 'preview/migration/tools/stage_preview.py', '--build', B, '--output', CANDIDATE,
        '--libtorrent-package', N / 'build/dependencies/packages/libtorrent-rasterbar2.0t64_2.0.12-1_amd64.deb',
        '--source-libtorrent', DSO, '--private-source-provider-manifest', PROVIDER], 300)
    candidate_sha, manifest = bundle(CANDIDATE)
    private = CANDIDATE / 'usr/lib/biglybtc'
    provider = manifest['libtorrent_runtime']
    require(manifest.get('distribution_scope') == provider.get('distribution_scope') == 'private-qualification-only'
            and provider.get('shipping_approved') is False and provider.get('causal_qualified') is False
            and provider.get('runtime_manifest_sha256') == PROVIDER_SHA
            and provider.get('source_build_record_sha256') == '3fcd415424d71e6082022f8be6bb1a75036a0fbf3b228228813e1a4cee1ffdca',
            'Private candidate scope/provenance changed')
    canonical = private / 'lib/libtorrent-rasterbar.so.2.0.12'
    aliases = {directory + '/' + name for directory in
        ('usr/lib/biglybtc/lib', 'dependencies/libtorrent/usr/lib/x86_64-linux-gnu')
        for name in ('libtorrent-rasterbar.so', 'libtorrent-rasterbar.so.2.0', 'libtorrent-rasterbar.so.2.0.12')}
    require(set(provider['aliases']) == aliases and len(provider['aliases']) == 6 and
            all((CANDIDATE / rel).resolve(strict=True) == canonical and
                (CANDIDATE / rel).stat().st_size == 9085072 and
                sha(CANDIDATE / rel) == DSO_SHA for rel in aliases), 'All six private aliases must resolve to exact b0e')
    save(logs / 'private-aliases.json', {rel: {'resolved': str((CANDIDATE / rel).resolve(strict=True)),
        'sha256': sha(CANDIDATE / rel)} for rel in sorted(aliases)})
    require(provider['artifact_sha256'] == DSO_SHA and provider['artifact_bytes'] == 9085072
            and provider['instrumented'] is False and sha(private / 'lib/libtorrent-rasterbar.so.2.0.12') == DSO_SHA,
            'Private provider identity differs')
    require(bundle(N / 'dist')[0] == old_sha and source() == before, 'Published/source bytes changed during staging')
    # Freeze executables and Python/DSO controls; no qualification executable is
    # run from the cache. Exact471 HEAD remains required through the final check.
    bins = logs / 'test-bin'; bins.mkdir()
    paths = [B / 'biglybtc-preview-smoke']
    for name in TESTS:
        require(Path(catalog[name]['command'][0]).name == TESTS[name], 'Unexpected CTest executable')
        paths.append(Path(catalog[name]['command'][0]))
    deploy = list(catalog[DEPLOY_NAME]['command'])
    require(deploy[deploy.index('--mode') + 1] == 'provider-next' and
            Path(deploy[deploy.index('--provider') + 1]) == DSO and
            Path(deploy[deploy.index('--manifest') + 1]) == PROVIDER,
            'Wrong canonical exact11-case registered deployment command')
    require(Path(deploy[deploy.index('--driver') + 1]).name == CONTROL_TARGETS[0],
            'Wrong dedicated private-provider deployment driver')
    paths += [Path(deploy[deploy.index(flag) + 1]) for flag in ('--driver', '--interposition-driver', '--preload')]
    py = Path(deploy[2]); require(py.name == 'runtime_deployment_tests.py', 'Unexpected deployment recipe')
    paths.append(py)
    frozen = {}
    for path in paths:
        require(path.is_file() and not path.is_symlink(), 'Unsafe qualification binary/input')
        destination = bins / path.name; require(not destination.exists(), 'Repeated fixture basename')
        shutil.copy2(path, destination); require(sha(path) == sha(destination), 'Qualification copy differs')
        frozen[str(path)] = str(destination)
    save(logs / 'frozen-inputs.json', {k: {'path': v, 'sha256': sha(Path(v))} for k, v in frozen.items()})
    save(OUT / 'staged.json', {'status': 'STAGED_NOT_PROMOTED', 'source': sys_source,
        'candidate': str(CANDIDATE), 'manifest_sha256': candidate_sha, 'previous_dist_sha256': old_sha,
        'source_map_sha256': sha(logs / 'source-map.json'), 'qualification_inputs_copied': True,
        'distribution_scope': 'private-qualification-only', 'shipping_approved': False})
    print('STAGED_PRIVATE_ONLY_NOT_PROMOTED ' + str(CANDIDATE), flush=True)
    env.pop('TMPDIR', None)
    env.update(QT_QPA_PLATFORM='offscreen', QT_SCALE_FACTOR='1',
        LD_LIBRARY_PATH=':'.join(map(str, [private / 'lib', private / 'qt/lib', CANDIDATE / 'dependencies/libtorrent/usr/lib/x86_64-linux-gnu'])),
        QT_PLUGIN_PATH=str(private / 'qt/plugins'), QT_QPA_PLATFORM_PLUGIN_PATH=str(private / 'qt/plugins/platforms'))
    # Verify actual loaded Qt/LT origin for every copied positive executable.
    for name, path in [('BiglyBTC', private / 'bin/BiglyBTC'), ('BiglyBTC-headless', private / 'bin/BiglyBTC-headless'),
                       ('smoke', bins / 'biglybtc-preview-smoke'),
                       ('deployment-driver', Path(frozen[deploy[deploy.index('--driver') + 1]])),
                       ('interposition-driver', Path(frozen[deploy[deploy.index('--interposition-driver') + 1]])),
                       *[(name, Path(frozen[catalog[name]['command'][0]])) for name in TESTS]]:
        loaded = run('loader-' + name, ['ldd', path], 30)
        require('not found' not in loaded and str(private / 'lib/libtorrent-rasterbar.so.2.0') in loaded,
                'Executable did not load the private selected provider: ' + name)
        if 'libQt6Core.so.6' in loaded:
            require(str(private / 'qt/lib/libQt6Core.so.6') in loaded, 'QtCore escaped private runtime')
        for line in loaded.splitlines():
            if '/opt/Qt' in line:
                require(line.lstrip().startswith('libQt6Test.so.6 => '), 'Shipping Qt escaped private runtime')
            match = re.match(r'\s*(libQt6[^ ]+|libicu[^ ]+) => (\S+)', line)
            if match and match[1] != 'libQt6Test.so.6':
                require(Path(match[2]).is_relative_to(private / 'qt/lib'),
                        'Shipping Qt/ICU escaped private runtime: ' + line)
    rpaths = {}; dynamic_logs = {}
    for relative in manifest['files_sha256']:
        leaf = CANDIDATE / relative
        if leaf.is_symlink() or leaf.read_bytes()[:4] != b'\x7fELF':
            continue
        dynamic = subprocess.check_output(['readelf', '--dynamic', str(leaf)], text=True, timeout=30)
        dynamic_logs[relative] = dynamic
        relevant = [line.strip() for line in dynamic.splitlines() if '(RPATH)' in line or '(RUNPATH)' in line]
        require(all('/opt/Qt' not in line and str(B) not in line and '/tmp/' not in line
                    and str(N / 'build') not in line and str(W) not in line for line in relevant), 'Nonportable runtime path: ' + relative)
        rpaths[relative] = relevant
    save(logs / 'all-elf-rpaths.json', rpaths)
    save(logs / 'all-elf-dynamic.json', dynamic_logs)
    runtime = lambda files: {k: v for k, v in files.items() if k.startswith('usr/lib/biglybtc/lib/') or k.startswith('usr/lib/biglybtc/qt/') or k.startswith('dependencies/libtorrent/usr/lib/')}
    prior_runtime, current_runtime = runtime(old['files_sha256']), runtime(manifest['files_sha256'])
    require(prior_runtime.keys() == current_runtime.keys(), 'Unexpected runtime inventory change')
    runtime_changed = [k for k in current_runtime if current_runtime[k] != prior_runtime[k]]
    require(set(runtime_changed) == aliases, 'Only the exact six LT provider aliases may change runtime bytes')
    save(logs / 'runtime-comparison.json', {'files': len(current_runtime), 'unchanged': len(current_runtime)-len(runtime_changed), 'changed_exact_selected_provider_aliases': runtime_changed})
    sample = Path(tempfile.mkdtemp(prefix='biglybtc-preview-', dir='/tmp')); sample.rmdir()
    run('prepare-generated-profile', ['python3', N / 'preview/native/packaging/preview.py', '--prepare', sample], 30)
    for key in ('XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_RUNTIME_DIR'):
        directory = sample / key.lower(); directory.mkdir(mode=0o700); env[key] = str(directory)
    env.update(BIGLYBTC_PREVIEW_PROFILE=str(sample / 'profile'), BIGLYBTC_PREVIEW_CAPTURE=str(sample / 'classic-preview.png'),
               BIGLYBTC_EXPECT_COMBINED_COUNTERS='1')
    sample_before_usage = {str(p.relative_to(sample)): sha(p) for p in sample.rglob('*') if p.is_file()}
    usage = run('normal-launcher-usage', [CANDIDATE / 'BiglyBTC'], 30, 2)
    require('Usage: BiglyBTC --profile ABSOLUTE_PROFILE' in usage, 'Unexpected normal launcher boundary')
    require({str(p.relative_to(sample)): sha(p) for p in sample.rglob('*') if p.is_file()} == sample_before_usage, 'Usage-only launcher touched the owned profile')
    smoke = run('smoke-private-runtime', [bins / 'biglybtc-preview-smoke', '-o', '-,txt'], 300)
    total = re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped', smoke)
    require(len(total) == 1 and int(total[0]) == 13, 'Incomplete smoke rows')
    captures = logs / 'captures'; captures.mkdir()
    expected_captures = json.loads((W / 'remainder-portable/plan.json').read_text())['retained_capture_names']
    actual = {p.name: p for p in sample.glob('*.png')}
    require(len(expected_captures) == len(actual) == 28 and set(expected_captures) == actual.keys(),
            'Expected exact retained28 preview captures')
    for name, path in actual.items():
        shutil.copy2(path, captures / name)
    results = []
    for name, target in TESTS.items():
        command = [frozen[catalog[name]['command'][0]], *catalog[name]['command'][1:]]
        text = run('cohort-' + name, command, int(property_value(catalog[name], 'TIMEOUT')))
        totals = re.findall(r'Totals:\s+(\d+) passed,\s+0 failed,\s+0 skipped', text)
        require(len(totals) == 1, 'Missing exact successful Qt totals: ' + name)
        results.append({'name': name, 'status': 'PASS', 'qt_rows': int(totals[0])})
    deploy = [frozen.get(arg, arg) for arg in deploy]
    # Preserve canonical --provider/manifest: the unchanged fixture checks their
    # exact relationship before creating independent copied-provider cases.
    # Positive copied bins above load the packaged b0e (verified by ldd); every
    # packaged alias is independently byte-identical to this canonical input.
    text = run('cohort-' + DEPLOY_NAME, deploy, int(property_value(catalog[DEPLOY_NAME], 'TIMEOUT')))
    receipt = json.loads(text.strip().splitlines()[-1]); receipt_path = Path(receipt['receipt'])
    copy = logs / 'relocation'; shutil.copytree(receipt_path.parent, copy)
    relocation = json.loads((copy / 'result.json').read_text())
    require(receipt['mode'] == relocation['mode'] == 'provider-next' and receipt['cases'] == 11
            and len(relocation['cases']) == 11 and relocation['provider_sha256'] == DSO_SHA
            and relocation['provider_unchanged'] is True and
            all(row['exit_code'] == 0 for row in relocation['cases']), 'Incomplete actual11-case relocation controls')
    results.append({'name': DEPLOY_NAME, 'status': 'PASS', 'cases': receipt['cases'],
                    'receipt_sha256': sha(copy / 'result.json')})
    require(source() == before and bundle(N / 'dist')[0] == old_sha and bundle(CANDIDATE)[0] == candidate_sha,
            'Published/private bundle changed during qualification')
    require(all(sha(Path(v)) == json.loads((logs / 'frozen-inputs.json').read_text())[k]['sha256'] for k, v in frozen.items()),
            'Frozen qualification inputs changed')
    record = {'status': 'PRIVATE_B0E_RUNTIME_QUALIFIED_NOT_PROMOTED', 'source': sys_source,
        'candidate': str(CANDIDATE), 'manifest_sha256': candidate_sha, 'files': len(manifest['files_sha256']),
        'previous_dist_manifest_sha256': old_sha, 'source_map_sha256': sha(logs / 'source-map.json'),
        'provider_sha256': DSO_SHA, 'provider_manifest_sha256': PROVIDER_SHA, 'cohort': results,
        'distribution_scope': 'private-qualification-only', 'shipping_approved': False, 'causal_qualified': False,
        'packaged_aliases': 6, 'deployment_copy_origin': str(DSO),
        'deployment_copy_origin_equals_packaged_by_full_sha256': True,
        'no_packaged_mutation_claim_from_deployment_controls': True,
        'dht_public_wire_or_full_cf_closure_credit': False,
        'gcc_matrix_receipt_sha256': sha(gcc_receipt),
        'focused_receipt_sha256': sha(focused_receipt), 'implementation_source': implementation_source,
        'matrix_credit': '38 original+c8a production +2 focused471; no whole40 rerun',
        'production_bytes_identical': True, 'full_source_snapshots_identical': False,
        'smoke_qt_rows': int(total[0]), 'captures': {name: sha(captures / name) for name in actual},
        'all_elf_rpaths': len(rpaths), 'runtime_files': len(current_runtime), 'runtime_unchanged': len(current_runtime)-len(runtime_changed), 'test_binaries_frozen_before_root_head_release': True,
        'build_jobs': 1, 'nice': os.getpriority(os.PRIO_PROCESS, 0), 'promoted': False,
        'system_installation': False, 'original_profile_or_process_access': False}
    save(logs / 'result.json', record)
    print(json.dumps({'status': record['status'], 'source': sys_source, 'suites': len(results),
                      'smoke_rows': int(total[0]), 'captures': len(actual), 'manifest': candidate_sha}), flush=True)
if __name__ == '__main__':
    main()
