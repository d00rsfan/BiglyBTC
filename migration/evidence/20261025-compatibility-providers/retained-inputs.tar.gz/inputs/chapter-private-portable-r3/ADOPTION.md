R3 finite target-list correction only; r2 and its actual failed run-r1 are preserved. Source471ebb75fc66fefb0208b0d086a934b68aced84b and implementationc8a, pinned38+2 union proof, private b0e/3342, stage3287, existing13Qt/28PNG/11-case and alias/Qt/ELF guards are unchanged. No author execution/native changes.

Root command after cache idle:

    nice -n 5 python3 -B build/storage-20261025/chapter-private-portable-r3/qualify.py --gcc-case chapter-next-gcc-tests-r1 --focused-case chapter-fortified-gcc-tests-r1 --attempt run-r1

Initial --parallel1 build now requests exactly the same11 deduplicated targets used by the dry freshness check: 3 products/smoke +5 positive tests +3 deployment/interposition controls. Persistent-session overlaps the former initial list; no whole40-suite build/run was added. The fortified CMake change regenerated the runtime header/relinked engine.a and left6 positive/control targets unrequested by r2's initial build. Its strict dry check correctly caught16 pending jobs before staging. Root also observed initial persistent-session MOC22ms older than regenerated moc_predefs; this single complete bounded build should settle it. Actual success still requires the unchanged no-work dry gate.

There is exactly one real build command, no automatic retry, no stale/timeout relaxation and no promotion. Fresh namespace chapter-private-portable-r3/run-r1 only. Published dist remains untouched. Preserve chapter-private-portable-r2/run-r1 and chapter-private-stale-explain-r1.log as failed-attempt evidence.
