Root-run recipe only; author has not executed it, built/tested or changed shared
metadata/native files. Default is a read-only status check (exit2 while pending).

Copy completion-template.json to a fresh completion-rN.json under this namespace.
Fill actual final qualified_source and source_push_receipt. Keep the two actual
phase receipts pinned. Any real later compile/test source changes require an
ordered followup_commit_receipts list with actual source_commit,parent,
paths_sha256 and all_staged_blob_bytes_verified=true; the chain must end at the
qualified source. Do not fabricate a final hash or successful status.

lanes gives actual passing root check.py case stems. Each lane must cover exactly
the 20 frozen suite names, with no failures/skips and final current source maps.
Failed earlier attempts are preserved in retention but do not satisfy a gate.
If runtime fixes later require different-source result unions, stop and amend
this recipe explicitly; it does not silently pretend identical snapshots.

oracle_attempt is the actual successful run_switchback.py directory: two cases,
all real commands PASS, bound raw stdout/stderr and native driver hash. The
legacy_result must retain all275 old-SDK headers, actual successful commands and
factory correspondence. An altered factory requires new denial qualification.
additional_receipts may retain actual hosted/portable/review status snapshots;
they are copied without inferred success. No prior archive/build/DSO/class cohort
is copied. Current source capsules, attempts, raw fixtures/logs/maps and a full
MEMBERS.json inside one tar.gz are retained in a new namespace only.

    python3 -B build/storage-20261025/next-two-evidence/finish.py --completion next-two-evidence/completion-r1.json
    python3 -B build/storage-20261025/next-two-evidence/finish.py --completion next-two-evidence/completion-r1.json --write

--write creates migration/evidence/20261025-proxy-scheduler and updates only the
pinned original metadata, new review and prepared native README afterimage.
It marks exactly the two pending milestone checkboxes complete, preserves all
eight open CF parents/component source baselines/states/targets/dependencies,
and installs latest STOP wording before labelled history. The original Java
README is untouched. A partial attempt keeps INCOMPLETE.json; preserve rather
than overwrite it. No commit/push/promotion/subject execution occurs.

Root validates registry/docs, then exact metadata export:

    python3 -B build/storage-20261025/next-two-evidence/finish.py --export
    python3 -B build/storage-20261025/next-two-evidence/finish.py --export --write

The export plan is W/next-two-metadata-plan.json, parent=actual qualifiedsource;
the export receipt binds all copied blobs. Native HEAD must remain clean at that
source until export. Root verifies staged blobs, commits/pushes metadata and
checkpoints. Then STOP; no further chapter. Notes/source templates claim no test
execution until actual root receipts satisfy all gates.
