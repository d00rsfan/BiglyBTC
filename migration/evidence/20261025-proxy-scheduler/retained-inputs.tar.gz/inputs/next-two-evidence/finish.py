#!/usr/bin/env python3
"""Root-only evidence/metadata recipe for the two authorized final milestones.

Default checks status without writes. --write retains/results/tracking only.
--export [--write] subsequently copies exact metadata; never builds/tests/Git writes.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import re
import shutil
import stat
import subprocess
import tarfile
import xml.etree.ElementTree as ET

H = Path(__file__).resolve().parent
W = H.parent
R = W.parents[1]
N = R.parent / 'BiglyBTC'
E_REL = 'migration/evidence/20261025-proxy-scheduler'
E = R / E_REL
REVIEW = 'migration/updates/compatibility.providers/20261025-final-two.md'
PHASE1 = 'b43971447b44db2f107b205204e1637bff8124ff'
PHASE2 = '6b44a2c21f88c32d6f94fe595d4a42877a895bc1'
BEFORE_SHA = '605296be66c20109314458506c516dd61f8bd6d5c52b48e3b298ead2ff4a0aa7'
ROOTS = ('next-two-composed', 'next-two-composed-r2', 'next-network/verified-socks4a',
         'next-queue/pause-recovery', 'next-two-evidence')
COMPONENTS = {'engine.network_binding': PHASE1, 'profile.application_settings_fields': PHASE1,
              'engine.live_settings': PHASE1, 'engine.queue_policy': PHASE2,
              'plugins.speed_scheduler_ownership': PHASE2, 'plugins.speed_scheduler_runtime': PHASE2,
              'ui.speed_scheduler_editor': PHASE2}


def need(value, why):
    if not value:
        raise ValueError(why)


def raw(path):
    need(path.is_absolute() and path.resolve(strict=True) == path and
         stat.S_ISREG(path.lstat().st_mode), 'Regular canonical input required: ' + str(path))
    return path.read_bytes()


def sha(path):
    return hashlib.sha256(raw(path)).hexdigest()


def load(path):
    return json.loads(raw(path))


def relative(value):
    need(isinstance(value, str) and value and not Path(value).is_absolute() and
         '..' not in Path(value).parts, 'Use an explicit W-relative receipt path')
    return W / value


def put(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def check_case(stem):
    need(isinstance(stem, str) and re.fullmatch(r'next-two-[A-Za-z0-9_-]+', stem), 'Actual root case required')
    paths = [W / (stem + suffix) for suffix in ('-receipt.json', '-source.json', '.xml', '.log')]
    receipt, source = load(paths[0]), load(paths[1])
    need(receipt['exit'] == 0 and 'ctest' in receipt['command'] and str(paths[2]) in receipt['command']
         and receipt['source_manifest_sha256'] == sha(paths[1]), 'Incomplete/mismatched CTest: ' + stem)
    rows = list(ET.fromstring(raw(paths[2])).iter('testcase'))
    names = [row.get('name') for row in rows]
    need(names and None not in names and len(names) == len(set(names)), 'Invalid XML: ' + stem)
    for row in rows:
        text = row.findtext('system-out') or ''
        need(row.get('status', 'run') == 'run' and all(row.find(k) is None for k in ('failure', 'error', 'skipped'))
             and not re.search(r'^SKIP\s*:', text, re.M)
             and all(a == b == '0' for a, b in re.findall(r'Totals:\s*\d+ passed, (\d+) failed, (\d+) skipped', text)),
             'Failed/skipped actual suite: ' + str(row.get('name')))
    return set(names), source, {'case': stem, 'seconds': receipt['seconds'],
                              'inputs_sha256': {p.name: sha(p) for p in paths}}, set(paths)


def verify(completion):
    need(sha(H / 'before.json') == BEFORE_SHA, 'Changed reviewed before pins')
    before = load(H / 'before.json')
    source = completion.get('qualified_source')
    need(isinstance(source, str) and re.fullmatch('[0-9a-f]{40}', source), 'Qualified source still pending')
    need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=N, text=True).strip() == source and
         not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=N, text=True).strip(),
         'Require clean actual qualified HEAD before metadata')
    required = set()
    for rel, digest in before['phase_receipt_sha256'].items():
        need(sha(W / rel) == digest, 'Changed original phase/adoption receipt')
        required.add(W / rel)
    first, second = load(W / 'next-two-socks4a-source-commit.json'), load(W / 'next-two-scheduler-source-commit.json')
    need(first['source_commit'] == PHASE1 and len(first['paths_sha256']) == 14 and
         second['source_commit'] == PHASE2 and second['parent'] == PHASE1 and len(second['paths_sha256']) == 9 and
         first['all_staged_blob_bytes_verified'] and second['all_staged_blob_bytes_verified'], 'Wrong actual phase sources')
    last = PHASE2
    followups = []
    for rel in completion['followup_commit_receipts']:
        path = relative(rel); row = load(path)
        need(row['parent'] == last and re.fullmatch('[0-9a-f]{40}', row['source_commit']) and
             row['paths_sha256'] and row['all_staged_blob_bytes_verified'], 'Unproven source followup')
        last = row['source_commit']; followups.append(row); required.add(path)
    need(last == source, 'Qualified source needs an explicit root commit receipt chain')
    push_path = relative(completion['source_push_receipt']); push = load(push_path)
    need(push.get('source_commit', push.get('source')) == source and push['exit'] == 0 and
         push.get('remote_main', source) == source,
         'Actual final source push required')
    required.add(push_path)
    need(sha(W / 'next-two-plan-r2.json') == before['plan_sha256'], 'Changed reviewed20-suite plan')
    expected = set(load(W / 'next-two-plan-r2.json')['suites']); need(len(expected) == 20, 'Wrong plan')
    current = {str(p.relative_to(N)): sha(p) for p in sorted((N / 'preview/native').rglob('*')) if p.is_file()}
    lanes = completion['lanes']; need(set(lanes) == {'gcc', 'clang', 'sanitizers'}, 'Three actual lanes required')
    matrix = {}
    for lane, stems in lanes.items():
        need(isinstance(stems, list) and stems, 'Pending compiler lane: ' + lane)
        observed, records = set(), []
        for stem in stems:
            names, tested_source, record, inputs = check_case(stem)
            need(names <= expected and tested_source == current, 'Not the final coherent source: ' + stem)
            observed.update(names); records.append(record); required.update(inputs)
        need(observed == expected, 'Missing20-suite coverage: ' + lane)
        matrix[lane] = {'suites': 20, 'runs': records}
    attempt = relative(completion['oracle_attempt']); oracle = load(attempt / 'result.json')
    need(oracle['status'] == 'PASS' and oracle['actual_cases'] == 2 and
         {case['name'] for case in oracle['cases']} == {'single', 'multi-forced'}, 'Actual Java switchback pending')
    commands = load(attempt / 'commands.json')
    need(commands and all(row['exit_code'] == 0 for row in commands), 'Oracle command failure')
    for row in commands:
        for suffix in ('stdout', 'stderr'):
            need(sha(attempt / (row['name'] + '.' + suffix)) == row[suffix + '_sha256'], 'Changed raw Java observation')
    driver = {row['argv'][0] for row in commands if row['name'].endswith('-native-import')}
    need(len(driver) == 1 and sha(Path(next(iter(driver)))) == oracle['native_driver_sha256'], 'Changed actual handoff driver')
    legacy_path = relative(completion['legacy_result']); legacy = load(legacy_path)
    need(legacy['status'] == 'PASS' and legacy['old_sdk_headers'] == 275 and
         all(row['exit_code'] == 0 for row in legacy['commands']), 'Old-SDK standalone denial proof pending')
    for row in legacy['commands']:
        for suffix in ('stdout', 'stderr'):
            need(sha(legacy_path.parent / (row['name'] + '.' + suffix)) == row[suffix + '_sha256'],
                 'Changed raw old-SDK proof')
    undefined = raw(legacy_path.parent / 'undefined-symbols.stdout').decode()
    dynamic = raw(legacy_path.parent / 'elf-dynamic.stdout').decode()
    need(not re.search(r'libtorrent|\b(?:dlopen|dlsym|dladdr|dlclose|dlinfo)\b', undefined) and
         all('libtorrent' not in line and 'libdl.' not in line for line in dynamic.splitlines() if '(NEEDED)' in line),
         'Old-SDK factory gained LT/loader linkage')
    factory = 'preview/native/engine/network_proxy_capability.cpp'
    need(current[factory] == first['paths_sha256'][factory] or legacy['source_commit'] == source,
         'Factory changed: qualify old-SDK denial again rather than reuse stale evidence')
    for rel, digest in before['original'].items():
        need(sha(R / rel) == digest, 'Shared metadata changed: ' + rel)
    for rel, digest in before['native'].items():
        need(not (N / rel).exists() if digest is None else sha(N / rel) == digest,
             'Native metadata before pins changed: ' + rel)
    need(not (R / REVIEW).exists() and not E.exists(), 'Evidence/review namespace already exists')
    for rel in completion['additional_receipts']:
        required.add(relative(rel))
    required.update({attempt / 'result.json', attempt / 'commands.json', legacy_path, W / 'next-two-plan-r2.json'})
    return source, before, matrix, oracle, legacy, followups, required


def retain(required):
    files = {}
    def add(p):
        if not p.is_file() or p.is_symlink():
            return
        rel = p.relative_to(W)
        if any(part in {'__pycache__', '.git', 'classes', 'CMakeFiles', 'candidate', 'test-bin', 'environment'} for part in rel.parts):
            return
        if p.suffix in {'.o', '.a', '.class', '.jar', '.so', '.gz', '.zip', '.pyc', '.zst', '.xz'} or '.so.' in p.name:
            return
        with p.open('rb') as stream:
            if stream.read(8).startswith((b'\x7fELF', b'!<arch>\n', b'\xca\xfe\xba\xbe')):
                return
        need(p.stat().st_size <= 64 * 1024 * 1024, 'Unexpected bulky evidence leaf')
        files[str(rel)] = p
    for root in ROOTS:
        need((W / root).is_dir(), 'Missing current two-milestone capsule: ' + root)
        for p in sorted((W / root).rglob('*')):
            add(p)
    for p in W.glob('next-two-*'):
        if p.is_file():
            add(p)
    for p in required:
        add(p); need(str(p.relative_to(W)) in files, 'Required raw evidence excluded')
    for rel in ('check.py', 'compile.py', 'run_matrix_build.py'):
        add(W / rel)
    need(sum(p.stat().st_size for p in files.values()) <= 256 * 1024 * 1024, 'Evidence scope unexpectedly grew')
    members = {rel: {'sha256': sha(p), 'bytes': p.stat().st_size} for rel, p in sorted(files.items())}
    encoded = (json.dumps({'root': str(W), 'files': members}, separators=(',', ':')) + '\n').encode()
    archive_path = E / 'retained-inputs.tar.gz'
    with archive_path.open('xb') as out, gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for rel, p in sorted(files.items()):
                value = raw(p); need(hashlib.sha256(value).hexdigest() == members[rel]['sha256'], 'Evidence changed during retention')
                entry = tarfile.TarInfo('inputs/' + rel); entry.size = len(value); entry.mode = 0o644
                archive.addfile(entry, io.BytesIO(value))
            entry = tarfile.TarInfo('MEMBERS.json'); entry.size = len(encoded); entry.mode = 0o644
            archive.addfile(entry, io.BytesIO(encoded))
    return {'path': archive_path.name, 'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size,
            'members': len(members), 'member_manifest_sha256': hashlib.sha256(encoded).hexdigest()}


def prepend(text, note):
    pos = text.index('\n') + 1
    return text[:pos] + '\n' + note + '\n\n## Historical records\n\n' + text[pos:]


def write_tracking(source, before, proof, oracle):
    note = ('The two authorized final milestones are qualified: verified native SOCKS4a/USERID source `' + PHASE1 +
        '` and imported-original Scheduler source `' + PHASE2 + '`, final qualified source `' + source +
        '`. Each GCC/Clang/leak-enabled ASan-UBSan lane passes20 affected suites; actual generated Java/native/Java '
        'pause switchback passes2 cases, and the standalone old-SDK denial proof covers275 headers without LT/loader linkage. '
        'These are bounded numeric SOCKS framing/authentication and explicit imported-pause recovery, not whole network/Scheduler parity. '
        'The current milestone plus two authorized milestones are finished: STOP. No next chapter or autonomous additional work. '
        'All CF01–CF08 remain open; no tracker/app-hostname4a proof, Java-enforced journal barrier, crash-recovery UI, '
        'new causal/DHT/public-wire, full network or performance closure is claimed.')
    docs = {}
    for rel in before['original']:
        if rel.endswith('upstreams.lock.json'):
            continue
        text = (R / rel).read_text()
        if rel.endswith('P08-01-compatibility-providers.md'):
            for title in ('Verified native SOCKS4a/USERID admission.', 'Imported-original Scheduler pause recovery.'):
                need(text.count('- [ ] ' + title) == 1, 'Changed pending milestone checkbox')
                text = text.replace('- [ ] ' + title, '- [x] ' + title)
        ref = ('evidence/' if rel == 'migration/STATE.md' else
               'migration/evidence/' if rel == 'MIGRATION_PLAN.md' else '../evidence/')
        docs[rel] = prepend(text, note + '\n\n[Final two-milestone evidence](' + ref + '20261025-proxy-scheduler/verification.json).')
    need(docs['migration/tasks/COMPATIBILITY-FOLLOWUPS.md'].count('- [ ] **CF-') == 8, 'Do not close CF parents')
    registry = load(R / 'migration/upstreams.lock.json')
    original = json.loads(json.dumps(registry))
    for row in registry['components']:
        if row['id'] not in COMPONENTS:
            continue
        for commit, purpose in [(COMPONENTS[row['id']], 'implementation')] + ([(source, 'integration')] if source != COMPONENTS[row['id']] else []):
            if not any(v['commit'] == commit for v in row['native_commits']):
                row['native_commits'].append({'repository': 'https://github.com/d00rsfan/BiglyBTC.git', 'commit': commit, 'purpose': purpose})
        for key, value in [('review_records', REVIEW), ('evidence', E_REL + '/verification.json')]:
            if value not in row[key]:
                row[key].append(value)
        prior = next(v for v in original['components'] if v['id'] == row['id'])
        need(row['state'] == prior['state'] and row['source_coverage'] == prior['source_coverage'] and
             row['target_paths'] == prior['target_paths'], 'Broader component coverage changed')
    need(registry['external_dependencies'] == original['external_dependencies'], 'Do not mint new provider authority')
    docs['migration/upstreams.lock.json'] = json.dumps(registry, indent=2, ensure_ascii=False) + '\n'
    review = (H / 'REVIEW.template.md').read_text().replace('QUALIFIED_SOURCE', source)
    docs[REVIEW] = review + '\n\n' + note + '\n'
    for rel, text in docs.items():
        p = R / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text)
    readme = (N / 'README.md').read_text() + '\n\n' + note + '\nSee [the final two-milestone record](' + E_REL + '/verification.json).\n'
    output = H / 'output'; output.mkdir(); (output / 'README.md').write_text(readme)
    exports = {rel: {'source': str(R / rel), 'sha256': sha(R / rel), 'before_sha256': before['native'][rel]} for rel in docs}
    exports['README.md'] = {'source': str(output / 'README.md'), 'sha256': sha(output / 'README.md'), 'before_sha256': before['native']['README.md']}
    for p in E.rglob('*'):
        if p.is_file() and p.name != 'INCOMPLETE.json':
            exports[str(p.relative_to(R))] = {'source': str(p), 'sha256': sha(p), 'before_sha256': None}
    put(W / 'next-two-metadata-plan.json', {'source': source, 'parent': source, 'tracking_files': sorted(docs),
        'evidence': E_REL, 'exports': exports, 'stop_after': True})


def export(write):
    plan = load(W / 'next-two-metadata-plan.json'); source = plan['source']
    need(plan['parent'] == source and plan['evidence'] == E_REL and plan['stop_after'], 'Wrong final export plan')
    need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=N, text=True).strip() == source and
         not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=N, text=True).strip(), 'Clean final metadata parent required')
    need(not (N / E_REL).exists(), 'Preserve all prior native evidence')
    for rel, row in plan['exports'].items():
        need(not Path(rel).is_absolute() and '..' not in Path(rel).parts and
             (rel in set(plan['tracking_files']) | {'README.md'} or rel.startswith(E_REL + '/')), 'Unexpected export target')
        target, origin = N / rel, Path(row['source'])
        need(origin.is_relative_to(R) and sha(origin) == row['sha256'] and not target.is_symlink() and
             (not target.exists() if row['before_sha256'] is None else sha(target) == row['before_sha256']), 'Changed metadata bytes')
    if write:
        for rel, row in plan['exports'].items():
            target = N / rel; target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(row['source'], target)
            need(sha(target) == row['sha256'], 'Export copy differs')
        put(W / 'next-two-metadata-export.json', {'source': source, 'stop_after': True,
            'files_sha256': {rel: sha(N / rel) for rel in plan['exports']}})
    print(json.dumps({'status': 'METADATA_EXPORTED' if write else 'METADATA_EXPORT_READY', 'source': source, 'stop': True}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completion', help='Actual root completion JSON relative to W')
    parser.add_argument('--write', action='store_true')
    parser.add_argument('--export', action='store_true')
    args = parser.parse_args()
    if args.export:
        export(args.write); return
    try:
        completion_path = relative(args.completion); completion = load(completion_path)
        source, before, matrix, oracle, legacy, followups, required = verify(completion)
    except (ValueError, KeyError, FileNotFoundError) as error:
        if args.write:
            raise
        print(json.dumps({'status': 'PENDING_ACTUAL_ROOT_PROOFS', 'reason': str(error)})); raise SystemExit(2)
    if not args.write:
        print(json.dumps({'status': 'READY_FINAL_TWO_MILESTONES', 'source': source, 'suites': 20, 'java_cases': 2})); return
    E.mkdir(); put(E / 'INCOMPLETE.json', {'source': source})
    required.add(completion_path)
    archive = retain(required)
    proof = {'status': 'TWO_AUTHORIZED_MILESTONES_QUALIFIED_STOP', 'qualified_source': source,
        'socks4a_implementation': PHASE1, 'scheduler_implementation': PHASE2, 'followup_commits': [v['source_commit'] for v in followups],
        'matrix': matrix, 'actual_java_cases': oracle['actual_cases'], 'actual_java_result_sha256': sha(relative(completion['oracle_attempt']) / 'result.json'),
        'old_sdk_headers': legacy['old_sdk_headers'], 'archive': archive,
        'prior_basis': '../20261025-compatibility-providers/completion.json', 'all_CF01_CF08_open': True,
        'stop_after': True, 'new_causal_or_DHT_or_full_network_Scheduler_performance_closure': False,
        'portable_or_hosted_success_inferred': False, 'source_push_receipt_sha256': sha(relative(completion['source_push_receipt']))}
    put(E / 'verification.json', proof)
    (E / 'REVIEW.md').write_text((H / 'REVIEW.template.md').read_text().replace('QUALIFIED_SOURCE', source))
    write_tracking(source, before, proof, oracle)
    (E / 'INCOMPLETE.json').unlink()
    # Bind final additive evidence after the incomplete marker is gone.
    put(E / 'artifacts.json', {p.name: sha(p) for p in E.iterdir() if p.is_file()})
    plan = load(W / 'next-two-metadata-plan.json')
    plan['exports'][E_REL + '/artifacts.json'] = {'source': str(E / 'artifacts.json'), 'sha256': sha(E / 'artifacts.json'), 'before_sha256': None}
    put(W / 'next-two-metadata-plan.json', plan)
    print(json.dumps({'status': proof['status'], 'archive_members': archive['members'], 'stop': True}))


if __name__ == '__main__':
    main()
