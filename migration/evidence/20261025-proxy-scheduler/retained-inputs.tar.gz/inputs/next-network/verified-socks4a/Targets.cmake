target_sources(biglybtc_local_engine PRIVATE network_proxy_capability.cpp)
# Existing network-policy and network-proxy-owner targets retain their linkage.
