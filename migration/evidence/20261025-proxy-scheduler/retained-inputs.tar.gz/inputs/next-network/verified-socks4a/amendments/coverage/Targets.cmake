target_sources(biglybtc_local_engine PRIVATE network_proxy_capability.cpp)
# In tests/CMakeLists.txt, after RuntimeBindingTests.cmake:
include("${CMAKE_CURRENT_SOURCE_DIR}/NetworkProxyCapabilityTests.cmake")
# Existing network-policy/network-proxy-owner/application-settings targets unchanged.
