#include "network_policy.hpp"
#if __has_include(<libtorrent/biglybtc_socks4a.hpp>)
#error This qualification must use the actual OLD SDK without a SOCKS4a header.
#endif
#include <iostream>
int main() {
  if (biglybtc::engine::verifiedSocks4Capability()) { return 1; }
  std::cout << "old-sdk-factory-capability=0; no-owner-or-network-created=1\n";
  return 0;
}
