#!/usr/bin/env python3
"""Root-invoked one-job OLD-SDK factory denial only; no CMake/provider/client build."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import time

HERE = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--attempt", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9a-f]{40}", args.source_commit) or not re.fullmatch(r"run-[A-Za-z0-9_-]+", args.attempt):
        raise ValueError("Exact post-adoption source commit and fresh run-N name required")
    manifest = json.loads((HERE / "manifest.json").read_bytes())
    for name, expected in manifest["artifacts_sha256"].items():
        if sha(HERE / name) != expected:
            raise ValueError("Changed frozen recipe: " + name)
    inputs = json.loads((HERE / "inputs.json").read_bytes())
    native = Path(inputs["native_root"])
    compiler = Path(inputs["compiler"])
    sdk = Path(inputs["old_install"]) / "include"
    boost = Path(inputs["boost_include"])
    environment = os.environ.copy()
    for key in ("CPATH", "CPLUS_INCLUDE_PATH", "C_INCLUDE_PATH", "OBJC_INCLUDE_PATH", "LIBRARY_PATH",
                "LD_LIBRARY_PATH", "LD_PRELOAD", "LD_AUDIT", "COMPILER_PATH", "GCC_EXEC_PREFIX"):
        environment.pop(key, None)
    head = subprocess.check_output(["git", "-C", str(native), "rev-parse", "HEAD"], env=environment, text=True).strip()
    if head != args.source_commit or sha(compiler) != inputs["compiler_sha256"]:
        raise ValueError("Wrong actual source HEAD or compiler")
    for name, expected in inputs["native_inputs"].items():
        raw = (native / name).read_bytes()
        committed = subprocess.check_output(["git", "-C", str(native), "show", head + ":" + name], env=environment)
        if hashlib.sha256(raw).hexdigest() != expected or raw != committed:
            raise ValueError("Source is not the exact adopted committed input: " + name)
    def old_sdk():
        actual = {str(p.relative_to(sdk)): sha(p) for p in sorted(sdk.rglob("*")) if p.is_file()}
        if actual != inputs["old_sdk_headers_sha256"] or (sdk / "libtorrent/biglybtc_socks4a.hpp").exists():
            raise ValueError("OLD SDK map changed or new capability header leaked in")
        if sha(sdk.parent / "lib/libtorrent-rasterbar.so.2.0.12") != inputs["old_provider_sha256"]:
            raise ValueError("Retained d367 artifact changed")
        if sha(boost / "boost/version.hpp") != inputs["boost_version_sha256"]:
            raise ValueError("Boost header input changed")
    old_sdk()
    output = HERE / args.attempt
    output.mkdir(mode=0o700)  # Fresh exclusive attempt; previous runs untouched.
    rows = []
    def run(name, argv, timeout=60):
        started = time.monotonic()
        completed = subprocess.run(list(map(str, argv)), cwd=output, env=environment,
                                   capture_output=True, timeout=timeout)
        (output / (name + ".stdout")).write_bytes(completed.stdout)
        (output / (name + ".stderr")).write_bytes(completed.stderr)
        rows.append({"name": name, "argv": list(map(str, argv)), "exit_code": completed.returncode,
                     "seconds": time.monotonic() - started, "stdout_sha256": sha(output / (name + ".stdout")),
                     "stderr_sha256": sha(output / (name + ".stderr"))})
        (output / "commands.json").write_text(json.dumps(rows, indent=2) + "\n")
        if completed.returncode:
            raise ValueError(name + " failed; retained command/stdout/stderr")
        return completed.stdout.decode(errors="replace")
    status = "FAIL"
    try:
        run("compiler-version", [compiler, "--version"], 10)
        common = ["nice", "-n", "5", compiler, "-std=c++23", "-O2", "-DNDEBUG", "-Wall", "-Wextra",
                  "-Wpedantic", "-Werror", "-fexceptions", "-pthread"]
        common += ["-D" + value for value in inputs["compile_definitions"]]
        common += ["-I", native / "preview/native/engine", "-I", native / "preview/native/core/include",
                   "-isystem", sdk, "-isystem", boost]
        factory = native / "preview/native/engine/network_proxy_capability.cpp"
        for name, source in (("factory", factory), ("driver", HERE / "assert_null.cpp")):
            run("compile-" + name, common + ["-MD", "-MF", output / (name + ".d"), "-c", source,
                                           "-o", output / (name + ".o")])
        binary = output / "assert-old-sdk-null"
        run("link", ["nice", "-n", "5", compiler, output / "factory.o", output / "driver.o", "-o", binary])
        dependencies = set()
        for name in ("factory", "driver"):
            text = (output / (name + ".d")).read_text().replace("\\\n", "")
            dependencies.update(Path(p).resolve(strict=True) for p in shlex.split(text.partition(":")[2]))
        lt = {p for p in dependencies if "/libtorrent/" in str(p)}
        if not lt or any(not p.is_relative_to(sdk) for p in lt):
            raise ValueError("A libtorrent header came from outside the OLD SDK")
        if any("provider-next" in str(p) for p in dependencies):
            raise ValueError("New provider path leaked into actual dependencies")
        (output / "headers-and-sources.json").write_text(json.dumps({str(p): sha(p) for p in sorted(dependencies)}, indent=2) + "\n")
        symbols = run("undefined-symbols", ["nm", "-u", output / "factory.o"], 10)
        dynamic = run("elf-dynamic", ["readelf", "-d", binary], 10)
        full = run("elf-symbols", ["readelf", "-Ws", binary], 10)
        if any(value in symbols + full for value in ("dlopen", "dlsym", "dladdr", "managedPayloadCounterRuntimePin", "biglybtc_socks4a_abi")):
            raise ValueError("Absent SDK branch retained a loader/marker/guard reference")
        if "libtorrent" in dynamic or "RPATH" in dynamic or "RUNPATH" in dynamic:
            raise ValueError("Standalone old-SDK proof unexpectedly depends on a provider/search path")
        actual = run("assert-null", [binary], 10)
        if actual != "old-sdk-factory-capability=0; no-owner-or-network-created=1\n":
            raise ValueError("Missing actual null-factory result")
        old_sdk()
        status = "PASS"
    finally:
        result = {"status": status, "source_commit": head, "recipe_manifest_sha256": sha(HERE / "manifest.json"),
                  "compiler_sha256": sha(compiler), "old_provider_sha256": inputs["old_provider_sha256"],
                  "old_sdk_headers": len(inputs["old_sdk_headers_sha256"]), "commands": rows,
                  "scope": "OLD-SDK standalone factory denial only; no whole-client or new-provider qualification"}
        binary = output / "assert-old-sdk-null"
        if binary.exists():
            result["binary_sha256"] = sha(binary)
        (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": status, "receipt": str(output / "result.json")}))

if __name__ == "__main__":
    main()
