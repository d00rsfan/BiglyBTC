from pathlib import Path
import hashlib,json,subprocess,time,xml.etree.ElementTree as ET
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');source='861d4f17f2454086de8ec44a9814c292ce1f41fe';out=w/'next-two-source-push.json';assert not out.exists()
source_map={str(p.relative_to(n)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((n/'preview/native').rglob('*')) if p.is_file()};expected=set(json.loads((w/'next-two-plan-r2.json').read_text())['suites'])
for lane in ['gcc','clang','san']:
 stem='next-two-'+lane+'-tests-r1';receipt=w/(stem+'-receipt.json');until=time.monotonic()+900
 while not receipt.exists():
  assert time.monotonic()<until,'Timed out waiting '+stem
  time.sleep(2)
 assert json.loads(receipt.read_text())['exit']==0,stem
 assert json.loads((w/(stem+'-source.json')).read_text())==source_map,stem
 rows=list(ET.parse(w/(stem+'.xml')).iter('testcase'));assert {r.get('name') for r in rows}==expected and len(rows)==20
 assert all(all(r.find(k) is None for k in ['failure','error','skipped']) for r in rows)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=n,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=n,text=True).strip()
assert subprocess.check_output(['git','branch','--show-current'],cwd=n,text=True).strip()=='main'
cmd=['git','push','origin','main'];r=subprocess.run(cmd,cwd=n,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(w/'next-two-source-push.log').write_text(r.stdout)
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=n,text=True).split()[0] if r.returncode==0 else None
value={'source_commit':source,'exit':r.returncode,'command':cmd,'remote_main':remote,'local_affected20_suites_per_three_lanes':True,'generated_java_switchback2_pass':True,'log_sha256':hashlib.sha256(r.stdout.encode()).hexdigest()};out.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));assert r.returncode==0 and remote==source
