CF04 pause recovery: finite source assessment, no runtime or implementation credit

Disposition
-----------
Do not adopt inherited hashes or replay an interrupted engine action automatically.
Persisted facts cannot distinguish a Scheduler-owned pause from a later manual
pause, nor an intent written before its effect from an effect completed before
its acknowledgement. A new pure policy cannot recover missing provenance.
No new authority/provider/UI source is staged here. Existing explicit Resume and
Stop remain the safe settlement paths. The next closed slice is an explicit
per-target review + Keep paused action described below; it requires a small Host
integration, rather than a guessed core-only recovery API.

Original facts (all at source-pins.json commits)
---------------------------------------------
* GlobalManagerImpl.pauseDownload2339–2408 records force_start and owner=PS_GENERAL
  before the stopped transition. DownloadImpl471–480 delegates PIF pause/resume
  to the manager; Scheduler does not get a private pause owner.
* GMloadDownloadManagers3040–3070 accepts legacy byte[] hashes (force=false,
  general owner), or {hash,force,owner?}; owner defaults1 and Java intValue
  narrows it. Later duplicate hashes replace prior map entries. saveDownloads
  3187–3204 writes hash/force/owner. Neither format has timestamp, origin process,
  admission or proof of the latest user's command. Native rejects ambiguous
  duplicate targets instead of inheriting Java last-wins authorization.
* GMresumeDownload2680–2739 requires actual manager identity, removes the pause,
  and only if stopped restores forced state or queues. GMresumeDownloads2783–2855
  filters owner (or PS_ANY); a general owner still does not identify Scheduler.
* SpeedSchedulerThread561–624 does pause -> stop reason -> append formatted hash.
  Helpers641–700/798–865 trust a matching trimmed hash in PausedTorrents.conf;
  no timestamp, force/manual revision or acknowledgement is stored. Ordinary
  removal deletes the first duplicate and rewrites/trims other lines in Java.
* Its unPauseTorrent756–780 resumes when PIF isPaused, otherwise restarts a
  nonrunning row, then removes the hash. Disabled run branch146–161 also attempts
  unpause for inherited hashes. Therefore disabling Java Scheduler is NOT a
  guaranteed 'leave all inherited rows paused' action. Native intentionally
  resumes only acknowledged current-session ownership.
* Resume Downloads On Start defaults false, but when explicitly enabled GM
  addDownloadManager1171–1194 can queue an inherited stopped pause and restore
  saved force. Preserve this independent startup policy during switchback; never
  claim Keep paused overrides a user's later Java startup/scheduling choices.

Current native boundaries
-------------------------
SchedulerService.reload clears in-memory authority on first load, changed data
leaf or ownership bytes. evaluate/beginAction require an acknowledged pair of
actual admission token + manualRevision plus the ownership record before Resume
or Restart. rebindOwnedPause transfers only this existing same-session grant.
BiglyBTC.scheduler-intent is <=1024 bytes: magic1, hash, token, manualRevision,
action. It has no persisted before/after inventory CAS, effect receipt or
cross-process owner identity. A journal's presence blocks all automatic actions.
Indeterminate failures also poison the service in memory. Reload is not a cure.

Host.downloadAction revokes authority before manual Start/Stop/Pause/Resume/Queue/
Force, then applies the saved transaction and exact actual engine command.
revokeForManual removes ALL matching canonical grant duplicates, preserving raw
unrelated lines, and clears only an intent with that selected hash prefix.
Memory authority stays revoked on cleanup failure. It does not certify that a
prior effect failed or succeeded. IO uncertainty remains blocked/diagnosed.
Current menu masks expose Resume and Stop for a paused row; Pause is excluded.
The editor shows the diagnostic but no per-hash recovery preview/decision.

Smallest closed implementation contract
--------------------------------------
1. Read-only review: same sole Host lease, current profile/session + library
   target/revision, Scheduler revision/raw-source CAS. Join each strict canonical
   hash with exactly one saved row/pause and, where present, actual admission.
   Display saved force/owner, inherited grant, and parsed action as observations.
   Malformed/unknown journal, missing/duplicate hash, replaced data or no current
   target refuses an executable decision; preserve all bytes, no recursive cleanup.
2. Explicit Keep paused: add a dedicated Host recovery command (or explicit
   allowed takeover) for an already-paused selected target. Revalidate saved pause,
   actual paused/retired state and current target/manual revision BEFORE effects.
   Revoke Scheduler authority and matching grants/journal, preserve pause_data and
   its force/owner fields. Do not issue Resume/Restart, restore force, recreate a
   manager or mint automatic authority. If actual state is not already paused,
   use the existing explicit Pause path and require its real success first.
3. Explicit Resume / Stop: reuse existing guarded manual commands and exact
   target validation. Resume deliberately restores saved pause force; Stop
   deliberately drops pause intent. Both invalidate old plans first. Show partial
   durable/engine failures as unresolved, with a freshly read result.
4. Clearing a known per-hash intent is a user override, not an assertion about
   the old effect. Unknown/malformed journals or unrelated poison cannot be
   globally dismissed. Reopening the profile may discard process-local poison
   only after actual owner join and successful current-source reads; retained
   journal/saving files still block. No clearing journal by merely changing XML.
5. UI needs immutable review/session/request/Scheduler+library revisions and a
   Keep paused/Resume/Stop choice, QPointer guarded result delivery. View opening
   performs only the explicit read. No automatic 'Trust inherited' option.

Switchback and qualification
---------------------------
Keep original PausedTorrents.conf formatting (uppercase groups, Java trim), saved
pause_data and unknown values. Do not project native journal contents into Java
pause owner IDs. Java ignores the native file but may act on old grant hashes;
removing a selected grant explicitly is therefore a material switchback choice.
An unrelated grant must remain byte-exact. Native-only IO uncertainty has no
Java transaction equivalent; record that limitation rather than claim equality.

original-fixtures.json gives the finite follow-up. Reuse existing frozen
ownership/tick and export/pause evidence for their exact scopes; no new claim is
made for execution, crash recovery, complete scheduler/plugin or whole CF04.
No original runtime/profile, native source, build, Git or shared docs were changed.
