Imported original Scheduler recovery — final source amendment

Base native: 917efac29b28738390e7e1aeb04a4d4a26237079. All five modified-file
beforeimages matched the actual native tree at freeze. No native files, subjects,
compilers, tests or network were executed or changed by the author.

This supersedes the stopped b0f4 draft for adoption, preserving that draft and the
2bfe audit. The historical audit's stronger NativeCurrent acknowledgement rules
must not be applied to imported Java permission: original wePausedTorrent trusts
persisted matching hashes, including stale/manual-pause cases. ImportedOriginal
uses a real saved-library hash + library/manual revisions, never a fake LT token.
It never enters the separate native acknowledgement map. Ordinary SchedulerTorrent
and existing native pause/token checks remain intact. Existing source policy
retains forced/disabled/category/global/seed decisions; unavailable saved completion
is skipped when enabled, not silently classified incomplete. Disabled policy does
not require a completion fact, matching the original unused branch.

Adopt the 9 manifest sources using their exact before_sha256 map and per-file
patches. scheduler_imported_service.inc is included by the existing service TU:
no adapter source registration is needed. tests/CMakeLists.txt appends Targets.cmake
only. SOCKS4a's separate four readNetworkPolicy Host hunks are disjoint; compose
the patches instead of overwriting either full Host candidate. The dd8e pure
candidate is historical/reference scope; this integration does not require its
separate projector to be linked.

Each imported effect checks the held sole lease, exact saved target, Scheduler
revision, ownership/config/XML/inventory identities and bytes. It publishes a
separately typed durable intent before saved/engine effects. A successful saved
Resume/Start must have the actual LibraryCommandResult and preserve all unrelated
raw inventory scope; real Host control/admission must also succeed before first-only
permission consumption. An indeterminate outcome retains the journal and blocks
replay across reopen. Manual commands revoke native and imported permission before
IO; the per-owner revoked set survives cleanup failure/reload. Explicit matching
manual settlement may remove the journal, but uncertainty is never auto-replayed.
The generic interrupted-action review workflow remains an explicit limitation;
this package does not create a new recovery UI or whole-CF04 completion claim.
Original Java ignores the native journal; no Java-enforced crash barrier is claimed.

The one old scheduler-host-engine fixture now starts with its existing pause schedule
enabled so it continues testing NativeCurrent isolation while disabled imported
release intentionally changes. Every old method/assertion/deadline remains. New
fixtures cover saved-only actual admissions (single/forced multifile), stale original
hash restart, first-only duplicate ownership removal, current-library staleness,
multiple commands, confirmed publication scope, failed manual cleanup/reload,
interrupted-intent refusal and explicit settlement. Domain-only caller acknowledgements
are labelled; real Host methods separately exercise the approved actual owner.
No passing count is claimed before root execution.

Root commands (use its approved configured build cache; no reconfigure option changes):

  cmake --build "$BUILD" --target biglybtc-scheduler-imported-integration-tests biglybtc-scheduler-imported-handoff-driver biglybtc-scheduler-host-engine-tests --parallel 3
  ctest --test-dir "$BUILD" -R '^(scheduler-imported-integration|scheduler-host-engine|scheduler-service)$' --output-on-failure

The new CTest is scheduler-imported-integration (240s, offscreen, actual module env).
The handoff driver has explicit arguments and is not an argument-free CTest. Root
must retain the actual source/runtime/module/build qualification alongside results.
After those binaries exist, run the bounded original/native/original recipe once:

  python3 -B oracle/run_switchback.py --driver "$BUILD/tests/biglybtc-scheduler-imported-handoff-driver" --module "$SCHEDULER_MODULE" --attempt run-r1

Run it from this immutable capsule (or use its absolute path). It self-checks every
capsule artifact/helper/cohort pin, compiles only the three helper sources against
retained Java17 classes, uses unchanged ReferenceFence and EngineOracle bootstrap,
and executes only generated /tmp roots with loopback/discovery disabled. Actual
unchanged GlobalManager creates and saves pause_data; a source-format Scheduler
permission line is authored using actual ByteFormatter. This is not a new execution
of the original Scheduler thread. Existing frozen tick/ownership observations retain
only their earlier predicate scope. Native Host consumes permission, joins and releases
the lease; unchanged Java reload checks pause absence and restored force. All roots,
helper classes, commands and raw output are archived in finally, including failures;
known generated roots are deleted only after successful archival/cohort recheck.
Unknown constructor failures before any receipt cannot claim a generated-profile
archive. Root owns all actual execution, counts and admission/publication credit.

The user authorized exactly two further milestones after the current one (SOCKS4a
and this imported recovery), then STOP. No subsequent chapter is part of this handoff.
