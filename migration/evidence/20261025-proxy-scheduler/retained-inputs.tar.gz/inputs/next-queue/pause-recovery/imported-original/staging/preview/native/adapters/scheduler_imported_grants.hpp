#pragma once

#include "scheduler_service.hpp"

namespace biglybtc::storage {

// Compatibility permission imported from Java's hash-only ownership file.
// This is NOT an acknowledged NativeCurrent grant or proof of a prior effect.
struct ImportedOriginalGrant {
  core::TorrentHash hash;
  std::uint64_t token = 0, manualRevision = 0;
  std::optional<core::SavedPause> savedPause;
};
struct ImportedOriginalCandidate {
  ImportedOriginalGrant grant;
  scheduler::ActionKind kind;
};
enum class ImportedGrantError { Bounds, Facts, PauseSource, OwnershipSource, Memberships, Policy, Memory };

// Inputs must come from one held-lease/current-target read, with source CAS
// retained by Host. Revocations survive failed disk cleanup for this profile.
// SavedPause absence is meaningful: Java may then choose Restart, not Resume.
std::expected<std::vector<ImportedOriginalGrant>, ImportedGrantError> selectImportedOriginalGrants(
    const core::LibrarySnapshot&, std::string_view ownershipBytes,
    std::span<const SchedulerTorrent> current,
    std::span<const core::TorrentHash> manuallyRevoked = {});

// Identity fence only; actual state/source CAS is still required before effects.
bool matchesImportedOriginalGrant(const ImportedOriginalGrant&, const SchedulerTorrent&) noexcept;

// Reuses the existing source-derived policy. Returns only imported Resume,
// Restart or SetStopReason candidates. New Pause commands remain ordinary
// acknowledged native actions. No mutation, module call, engine, IO or clock.
std::expected<std::vector<ImportedOriginalCandidate>, ImportedGrantError> evaluateImportedOriginalGrants(
    const scheduler::Configuration&, scheduler::LocalMinute, scheduler::RateState,
    bool enabled, bool overrideForced, const core::LibrarySnapshot&,
    std::string_view ownershipBytes, std::span<const SchedulerTorrent> current,
    std::span<const core::TorrentHash> manuallyRevoked = {});

} // namespace biglybtc::storage
