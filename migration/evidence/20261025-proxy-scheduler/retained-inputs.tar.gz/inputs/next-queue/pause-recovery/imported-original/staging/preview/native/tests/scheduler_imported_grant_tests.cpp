#include "scheduler_imported_grants.hpp"
#include "ownership_file.hpp"

#include <array>
#include <iostream>
#include <stdexcept>

namespace st = biglybtc::storage;
namespace core = biglybtc::core;
namespace policy = biglybtc::plugins::speed_scheduler;
namespace {
unsigned assertions = 0, families = 0;
void need(bool value, const char* why) { ++assertions; if (!value) { throw std::runtime_error(why); } }
template<class T, class E> T take(std::expected<T,E> value) {
  need(bool(value), "Expected admitted pure projection"); return std::move(*value);
}
core::TorrentHash hash(char value = 'x') { return take(core::TorrentHash::parse(std::string(20,value))); }
std::string formatted(const core::TorrentHash& value) {
  return take(policy::originalOwnershipHash({reinterpret_cast<const std::uint8_t*>(value.bytes().data()),value.bytes().size()}));
}
struct Fixture {
  core::LibrarySnapshot library;
  st::SchedulerTorrent item;
  policy::Configuration configuration;
  std::string ownership;
  Fixture(bool paused = true) {
    item.token = 17; item.manualRevision = 0; item.hash = hash();
    item.paused = paused; item.state = policy::TorrentState::Stopped;
    item.memberships = {"Uncategorized"};
    core::SavedDownload row; row.hash = item.hash; row.startup = core::StartupState::Stopped;
    row.originalState = 70; library.downloads.push_back(row);
    if (paused) { library.paused.push_back({item.hash,true,1}); }
    ownership = formatted(item.hash) + "\r\nforeign line\r\n";
  }
  auto select(std::span<const core::TorrentHash> revoked = {}) {
    return st::selectImportedOriginalGrants(library,ownership,std::span(&item,1),revoked);
  }
  auto evaluate(bool enabled = true, bool overrideForced = false,
      std::span<const core::TorrentHash> revoked = {}) {
    return st::evaluateImportedOriginalGrants(configuration,{0,10},{},enabled,overrideForced,
        library,ownership,std::span(&item,1),revoked);
  }
};
void importedPermissionIsNotNativeAcknowledgement() {
  Fixture f;
  const auto grants = take(f.select());
  need(grants.size() == 1 && grants[0].savedPause && grants[0].savedPause->forceStart,
      "Inherited source permission includes saved force without applying it");
  need(grants[0].token == 17 && grants[0].manualRevision == 0, "Bind current target only");
  auto candidates = take(f.evaluate());
  need(candidates.size() == 1 && candidates[0].kind == policy::ActionKind::Resume,
      "Source resumes inherited matching manual/general pause");
  f.library.paused[0].owner = 99;
  candidates = take(f.evaluate());
  need(candidates.size() == 1 && candidates[0].grant.savedPause->owner == 99,
      "Plugin does not require a Scheduler-specific GM pause owner");
  need(grants[0].savedPause->owner == 1, "Projection owns primitives, not later input aliases");
}
void staleHashWithoutPauseDataMeansOriginalRestart() {
  Fixture f(false);
  auto candidates = take(f.evaluate());
  need(candidates.size() == 1 && !candidates[0].grant.savedPause
      && candidates[0].kind == policy::ActionKind::Restart,
      "Source trusts stale ownership hash and restarts a stopped nonpaused target");
  f.item.state = policy::TorrentState::Downloading;
  need(take(f.evaluate()).empty(), "Running target is not restarted");
  f.ownership = "foreign line\n";
  need(take(f.select()).empty() && take(f.evaluate()).empty(), "No invented permission from saved row");
}
void disabledAndForcePredicatesRemainOriginal() {
  Fixture f; f.item.forceStarted = true;
  need(take(f.evaluate(true,false)).empty(), "Enabled policy protects forced target");
  need(take(f.evaluate(true,true)).size() == 1, "Explicit forced override follows source");
  auto candidates = take(f.evaluate(false,false));
  need(candidates.size() == 1 && candidates[0].kind == policy::ActionKind::Resume,
      "Original disabled loop releases imported permission even if forced");
  policy::Schedule filtered; filtered.onlyCategory = true; filtered.category = "X";
  f.configuration.schedules.push_back(filtered); f.item.membershipsAvailable = false;
  need(take(f.evaluate(false,false)).size() == 1, "Disabled branch does not require unused category lookup");
}
void scheduleHoldAndCategoryReleaseReusePolicy() {
  Fixture f; policy::Schedule rule;
  rule.days[0] = true; rule.start = 0; rule.end = 1439; rule.downloadsPaused = true;
  f.configuration.schedules.push_back(rule);
  auto candidates = take(f.evaluate());
  need(candidates.size() == 1 && candidates[0].kind == policy::ActionKind::SetStopReason,
      "Active pause schedule holds inherited target");
  f.configuration.schedules[0].excludeCategory = true;
  candidates = take(f.evaluate());
  need(candidates.size() == 1 && candidates[0].kind == policy::ActionKind::Resume,
      "Actual matching excluded category releases imported pause");
  f.item.membershipsAvailable = false;
  const auto unavailable = f.evaluate();
  need(!unavailable && unavailable.error() == st::ImportedGrantError::Memberships,
      "Missing category is not supplied as an empty membership");
}
void manualRevocationAndTargetRebindCannotResurrectPermission() {
  Fixture f; const auto grants = take(f.select());
  need(st::matchesImportedOriginalGrant(grants[0],f.item), "Initial current target matches");
  ++f.item.manualRevision;
  need(!st::matchesImportedOriginalGrant(grants[0],f.item), "Later native manual action invalidates old candidate");
  --f.item.manualRevision; ++f.item.token;
  need(!st::matchesImportedOriginalGrant(grants[0],f.item), "Different admission is not same candidate");
  const std::array revoked{f.item.hash};
  need(take(f.select(revoked)).empty() && take(f.evaluate(true,false,revoked)).empty(),
      "Explicit per-profile revoke survives an unchanged or failed-cleanup ownership file");
  need(f.ownership.find(formatted(f.item.hash)) == 0, "Pure revoke filtering has no file effects");
}
void ambiguousMalformedAndConflictingSourcesReject() {
  Fixture f; f.library.downloads.push_back(f.library.downloads[0]);
  need(!f.select(), "Duplicate saved target cannot be picked implicitly"); f.library.downloads.pop_back();
  const std::array duplicate{f.item,f.item};
  need(!st::selectImportedOriginalGrants(f.library,f.ownership,duplicate), "Duplicate current tokens/hash reject");
  f.library.issues.push_back({core::LibraryError::PauseType,0,true});
  need(!f.select(), "Malformed pause_data must not turn Resume into Restart"); f.library.issues.clear();
  f.item.paused = false;
  need(!f.select(), "Current isPaused and authenticated saved pause must agree");
  f.item.paused = true; f.item.token = 0;
  need(!f.select(), "No unbound target authority"); f.item.token = 17;
  need(!st::selectImportedOriginalGrants(f.library,
      std::string(policy::OwnershipFile::MaximumBytes + 1,'x'),std::span(&f.item,1)), "Bounded source bytes");
}
void duplicatePauseLastWinsAndRawBytesRemainOwned() {
  Fixture f; f.library.paused.push_back({f.item.hash,false,7});
  f.ownership = " \t" + formatted(f.item.hash) + "\t\r\n" + formatted(f.item.hash) + "\nunknown\r\n";
  const auto before = f.ownership; auto grants = take(f.select());
  need(grants.size() == 1 && grants[0].savedPause && !grants[0].savedPause->forceStart
      && grants[0].savedPause->owner == 7, "Java pause Map.put uses final duplicate source record");
  need(f.ownership == before, "Imported selection never normalizes or removes source lines");
  f.library.paused.clear(); f.ownership.clear();
  need(grants[0].savedPause && grants[0].savedPause->owner == 7, "Retained result owns its observations");
}
}
int main() {
  try {
    for (auto method : {importedPermissionIsNotNativeAcknowledgement, staleHashWithoutPauseDataMeansOriginalRestart,
        disabledAndForcePredicatesRemainOriginal, scheduleHoldAndCategoryReleaseReusePolicy,
        manualRevocationAndTargetRebindCannotResurrectPermission, ambiguousMalformedAndConflictingSourcesReject,
        duplicatePauseLastWinsAndRawBytesRemainOwned}) { method(); ++families; }
    std::cout << "PASS " << families << " imported-original-grant families; " << assertions
              << " assertions; pure candidates only, no native acknowledgement or effects\n";
    return 0;
  } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}
