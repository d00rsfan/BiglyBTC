Imported original Scheduler permission: pure candidate capsule, source-only.

This corrects the compatibility disposition in historical parent manifest2bfe.
Lack of a native acknowledgement does NOT invalidate Java's imported permission:
original wePausedTorrent deliberately trusts matching persisted hashes. The old
report remains useful only for what those hashes cannot prove about NativeCurrent.

ImportedOriginalGrant is a separate type. Exact source permission is ownership
file membership, not a private GM pause owner, native nonce or observed pause
history. A stale matching hash plus an unrelated/manual paused row can therefore
produce Resume. A matching stopped row without pause_data can produce Restart.
The disabled original polling branch releases imported permission even if forced;
the enabled branch respects override.forced. Existing source-derived policy
provides category/global/seed/state decisions. The projector never mints a native
acknowledged grant, executes effects, mutates files, calls a module or starts IO.

Selection requires an unambiguous current target/hash and authenticated parsed
saved pause facts. Malformed pause_data cannot be treated as missing. Original
pause Map.put last-wins is retained in the copied metadata. Native existing
SavedPause numeric/type admission is a boundary: no additional claim for raw
ill-typed fields or Java narrowing extremes. Unresolved other legacy rows cannot
authorize a target. Unknown ownership bytes remain untouched. Existing byte codec
retains its deliberately documented unterminated-foreign-line append boundary.

Root integration requirements (NOT implemented here):
* Under the same sole Host lease, retain raw ownership/config/XML/inventory CAS,
  profile/session, Scheduler revision and actual current target/manual revision.
  Candidate identity match is only one fence; recheck complete state + sources
  before applying an action. Imported and NativeCurrent records stay distinct.
* Add a separate imported action path in SchedulerService. Current beginAction
  correctly requires NativeCurrent authority and must not be weakened or seeded
  with imported records. Durably journal imported intent before any saved/engine
  effect; unknown/interrupted journal blocks execution rather than being replayed.
  Successful imported Resume/Restart removes only the FIRST source hash record,
  as Java does; it does not grant NativeCurrent authority. SetStopReason does not
  consume a record. Normal new Pause still follows acknowledged native handling.
* BEFORE every native manual Start/Stop/Pause/Resume/Queue/Force, revoke BOTH
  variants. Keep an explicit per-profile revoked-hash set even if CAS cleanup
  fails, and feed it to selection. Merely rebuilding selection with a higher
  manualRevision is not revocation. Clear this set only at actual profile-owner
  replacement after join/lease release. Native token/rebind semantics stay exact.
* schedulerTorrents currently requires a retained checked handle and omits saved-
  only paused rows. No pretend admission token may bridge this gap. Imported
  saved-only execution needs a separate authenticated current-library target
  route to the existing actual admission/control API; completion/membership facts
  must be available for the original policy. This pure capsule covers admitted
  current targets only; it does not close that Host lifecycle prerequisite.
* Keep the explicit uncertain-intent review path and partial failure reporting.
  Original's persisted permission policy and native transaction recovery are
  different questions. Do not infer success/failure from matching current state.

Root can adopt three new sources and the split Targets.cmake fragment without
changing old engine/service/UI code. The candidate tests are uncompiled and
unexecuted. They cover imported stale/manual permission, no-pause restart,
force/disabled/category branches, permanent explicit manual revocation, target
identity changes, malformed/duplicate source fences and owned copies.

original-trace-plan.json reuses frozen original observations for exactly their
predicate scope and specifies the remaining actual saved-state switchback.
No whole CF04/plugin/crash-recovery claim or new passing count is made.
