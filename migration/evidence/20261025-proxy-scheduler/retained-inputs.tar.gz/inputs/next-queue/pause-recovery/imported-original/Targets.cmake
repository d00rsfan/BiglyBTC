# Root merges into app/CMakeLists after biglybtc_scheduler_service exists.
target_sources(biglybtc_scheduler_service PRIVATE ../adapters/scheduler_imported_grants.cpp)
# Root merges into tests/CMakeLists inside the existing Scheduler/desktop gate.
add_executable(biglybtc-scheduler-imported-grant-tests scheduler_imported_grant_tests.cpp)
target_link_libraries(biglybtc-scheduler-imported-grant-tests PRIVATE biglybtc_scheduler_service)
target_compile_options(biglybtc-scheduler-imported-grant-tests PRIVATE -Wall -Wextra -Wpedantic -Werror)
add_test(NAME scheduler-imported-grants COMMAND biglybtc-scheduler-imported-grant-tests)
set_tests_properties(scheduler-imported-grants PROPERTIES TIMEOUT 30 LABELS "unit;scheduler")
