#include "scheduler_imported_grants.hpp"
#include "ownership_file.hpp"

#include <algorithm>
#include <map>
#include <new>
#include <set>

namespace biglybtc::storage {
namespace {
bool validHash(const core::TorrentHash& hash) noexcept {
  return hash.bytes().size() == 20 || hash.bytes().size() == 32;
}
std::span<const std::uint8_t> bytes(const core::TorrentHash& hash) noexcept {
  return {reinterpret_cast<const std::uint8_t*>(hash.bytes().data()), hash.bytes().size()};
}
}

bool matchesImportedOriginalGrant(const ImportedOriginalGrant& grant, const SchedulerTorrent& item) noexcept {
  return grant.token && grant.hash == item.hash && grant.token == item.token
      && grant.manualRevision == item.manualRevision;
}

std::expected<std::vector<ImportedOriginalGrant>, ImportedGrantError> selectImportedOriginalGrants(
    const core::LibrarySnapshot& library, std::string_view source,
    std::span<const SchedulerTorrent> current, std::span<const core::TorrentHash> revoked) {
  try {
    if (current.size() > scheduler::MaximumTorrents || library.downloads.size() > scheduler::MaximumTorrents
        || library.paused.size() > scheduler::MaximumTorrents || revoked.size() > scheduler::MaximumTorrents
        || source.size() > scheduler::OwnershipFile::MaximumBytes) {
      return std::unexpected(ImportedGrantError::Bounds);
    }
    // Other unsupported legacy rows cannot authorize a current target. Pause
    // parse errors are different: absence must never fabricate Restart.
    if (std::ranges::any_of(library.issues, [](const auto& issue) { return issue.pauseEntry; })) {
      return std::unexpected(ImportedGrantError::PauseSource);
    }
    const auto ownership = scheduler::OwnershipFile::read(std::string(source));
    if (!ownership) { return std::unexpected(ImportedGrantError::OwnershipSource); }
    std::map<std::string, std::size_t> counts;
    for (const auto& row : library.downloads) { if (row.hash) { ++counts[row.hash->hex()]; } }
    std::map<std::string, core::SavedPause> pauses;
    for (const auto& pause : library.paused) {
      if (!validHash(pause.hash)) { return std::unexpected(ImportedGrantError::PauseSource); }
      // Original Map.put overwrites an earlier pause record for the same hash.
      pauses.insert_or_assign(pause.hash.hex(), pause);
    }
    std::set<std::string> denied, hashes;
    std::set<std::uint64_t> tokens;
    for (const auto& hash : revoked) {
      if (!validHash(hash)) { return std::unexpected(ImportedGrantError::Facts); }
      denied.insert(hash.hex());
    }
    std::vector<ImportedOriginalGrant> result;
    result.reserve(current.size());
    for (const auto& item : current) {
      const auto state = static_cast<int>(item.state);
      if (!validHash(item.hash) || !item.token || state < 1 || state > 9
          || !tokens.insert(item.token).second || !hashes.insert(item.hash.hex()).second) {
        return std::unexpected(ImportedGrantError::Facts);
      }
      const auto key = item.hash.hex();
      const auto count = counts.find(key);
      if (count == counts.end() || count->second != 1) { return std::unexpected(ImportedGrantError::Facts); }
      const auto pause = pauses.find(key);
      if (item.paused != (pause != pauses.end())) { return std::unexpected(ImportedGrantError::PauseSource); }
      const auto present = ownership->contains(bytes(item.hash));
      if (!present) { return std::unexpected(ImportedGrantError::OwnershipSource); }
      if (!*present || denied.contains(key)) { continue; }
      result.push_back({item.hash, item.token, item.manualRevision,
          pause == pauses.end() ? std::nullopt : std::optional{pause->second}});
    }
    return result;
  } catch (const std::bad_alloc&) { return std::unexpected(ImportedGrantError::Memory); }
}

std::expected<std::vector<ImportedOriginalCandidate>, ImportedGrantError> evaluateImportedOriginalGrants(
    const scheduler::Configuration& configuration, scheduler::LocalMinute minute, scheduler::RateState rates,
    bool enabled, bool overrideForced, const core::LibrarySnapshot& library, std::string_view source,
    std::span<const SchedulerTorrent> current, std::span<const core::TorrentHash> revoked) {
  try {
    auto selected = selectImportedOriginalGrants(library, source, current, revoked);
    if (!selected) { return std::unexpected(selected.error()); }
    std::map<std::string, const ImportedOriginalGrant*> grants;
    for (const auto& grant : *selected) { grants.emplace(grant.hash.hex(), &grant); }
    const bool filters = enabled && std::ranges::any_of(configuration.schedules, [](const auto& rule) {
      return rule.enabled && (rule.onlyCategory || rule.excludeCategory);
    });
    std::vector<scheduler::Torrent> inputs;
    inputs.reserve(selected->size());
    for (const auto& item : current) {
      const auto found = grants.find(item.hash.hex());
      if (found == grants.end()) { continue; }
      if (filters && !item.membershipsAvailable) { return std::unexpected(ImportedGrantError::Memberships); }
      inputs.push_back({item.hash.hex(), item.complete, item.state, item.forceStarted,
          item.paused, true, item.memberships});
    }
    const auto evaluated = scheduler::evaluate(configuration, minute, inputs, rates, enabled, overrideForced);
    if (!evaluated) { return std::unexpected(ImportedGrantError::Policy); }
    std::vector<ImportedOriginalCandidate> result;
    result.reserve(evaluated->actions.size());
    for (const auto& action : evaluated->actions) {
      if (action.kind == scheduler::ActionKind::Pause) { continue; }
      const auto found = grants.find(action.id);
      if (found == grants.end()) { return std::unexpected(ImportedGrantError::Policy); }
      result.push_back({*found->second, action.kind});
    }
    return result;
  } catch (const std::bad_alloc&) { return std::unexpected(ImportedGrantError::Memory); }
}

} // namespace biglybtc::storage
