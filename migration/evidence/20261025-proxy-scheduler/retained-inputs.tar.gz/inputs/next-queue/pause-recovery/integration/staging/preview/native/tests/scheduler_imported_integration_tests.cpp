#include "scheduler_host_fixture.hpp"
#include "owned_engine_fixture.hpp"
#include "library_commands.hpp"
#include "library_view.hpp"
#include "ownership_file.hpp"
#include "persistent_session.hpp"
#include <QApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QtTest>

using namespace biglybtc;
namespace sh=test::scheduler_host;
namespace {
void prepare(test::OwnedEngineFixture& f,bool enabled,bool forced=false){
  sh::original(f.profile);
  libtorrent::entry cfg(libtorrent::entry::dictionary_type{});
  cfg["Bind IP"]="127.0.0.1";cfg["TCP.Listen.Port.Enable"]=0;cfg["peercontrol.udp.public.enable"]=0;
  cfg["Peer Source Selection Default.Tracker"]=0;cfg["Peer Source Selection Default.DHT"]=0;
  cfg["Peer Source Selection Default.PeerExchange"]=0;cfg["Plugin.DHT.dht.enabled"]=0;
  cfg["Plugin.SpeedScheduler.speedscheduler.enabled"]=enabled?1:0;cfg["Plugin.SpeedScheduler.thread.sleep.time"]=1000;
  cfg["Max Upload Speed KBs"]=7;cfg["Max Download Speed KBs"]=9;
  cfg["Resume Downloads On Start"]=0;cfg["opaque.imported.fixture"]="preserved";
  test::write(f.profile+"/biglybt.config",QByteArray::fromStdString(test::encoded(cfg)));
  auto state=sh::document(test::read(f.stateFile));const auto* attrs=state.find("attributes");sh::require(attrs,"State attributes");
  auto values=sh::document(QByteArray::fromStdString(state.originalBytes().substr(attrs->begin,attrs->end-attrs->begin)));
  sh::require(bool(values.replaceValue("parameters","d8:dndflagsi0ee")),"Original no-DND cache flags");
  sh::require(bool(values.replaceValue("skipfss","i0e")),"Original selected-size cache");
  sh::require(bool(state.replaceValue("attributes",values.serialize())),"Retain full state");
  test::write(f.stateFile,QByteArray::fromStdString(state.serialize()));
  auto held=storage::ProfileLease::acquire(f.native());sh::require(bool(held),"Generated lease");
  if(forced){sh::require(bool(storage::applyLibraryCommand(*held,*f.hash,core::DownloadAction::ForceStart)),"Saved forced intent");}
  sh::require(bool(storage::applyLibraryCommand(*held,*f.hash,core::DownloadAction::Pause)),"Saved original pause");
  const auto bytes=f.hash->bytes();auto encoded=storage::scheduler::originalOwnershipHash(
      {reinterpret_cast<const std::uint8_t*>(bytes.data()),bytes.size()});sh::require(bool(encoded),"Source ownership format");
  sh::write(sh::schedulerFile(f.profile,"PausedTorrents.conf"),QByteArray::fromStdString(*encoded+"\r\nopaque survivor\r\n"));
}
ui::Presentation lastRows(const QSignalSpy& spy){return spy.empty()?ui::Presentation{}:qvariant_cast<ui::Presentation>(spy.last()[0]);}
std::optional<ui::LibraryItem> row(const QSignalSpy& spy,const core::TorrentHash& hash){auto p=lastRows(spy);if(!p){return {};}
  const auto found=std::ranges::find(p->items,QString::fromStdString(hash.hex()),&ui::LibraryItem::hash);
  return found==p->items.end()?std::nullopt:std::optional{*found};
}
// Test-only opt-in retains the real generated tree at its original absolute
// paths, so the fenced Java readback needs no path rewriting. Even a failed
// assertion leaves the generated fixture available to the root runner's finally.
QString capture(test::OwnedEngineFixture& f,bool force,bool multi){
  const auto directory=qEnvironmentVariable("BIGLYBTC_IMPORTED_SCHEDULER_CAPTURE_DIRECTORY");if(directory.isEmpty()){return {};}
  const QFileInfo info(directory);sh::require(info.isDir()&&!info.isSymLink()&&info.isAbsolute()
      &&info.canonicalFilePath()==info.absoluteFilePath()&&directory.startsWith("/tmp/"),"Owned existing capture directory");
  const auto path=directory+QStringLiteral("/case-%1-%2.json").arg(multi?"multi":"single",force?"force":"ordinary");
  sh::require(!QFile::exists(path),"Fresh capture receipt");f.root.setAutoRemove(false);
  QJsonObject object;object["root"]=f.root.path();object["profile"]=f.profile;object["hash"]=QString::fromStdString(f.hash->hex());
  object["forced"]=force;object["multifile"]=multi;object["joined"]=false;
  sh::write(path,QJsonDocument(object).toJson());return path;
}
}
class SchedulerImportedIntegrationTests final:public QObject{
  Q_OBJECT
private slots:
  void initTestCase(){
    QApplication::setQuitOnLastWindowClosed(false);
    auto owner=engine::PersistentSession::create({1701,1702,1703});QVERIFY2(owner,"Approved actual runtime required; no skip");
    QVERIFY((*owner)->close(std::chrono::steady_clock::now()+std::chrono::seconds{5}).sessionJoined);
  }
  void importedTransactionHasSeparateIdentityAndOriginalFirstOnlyConsumption(){
    test::OwnedEngineFixture f(false);prepare(f,false);sh::ApprovedModule module;auto held=storage::ProfileLease::acquire(f.native());QVERIFY(held);
    auto service=module.factory()(*held);QVERIFY(service);
    const auto bytes=f.hash->bytes();const auto text=storage::scheduler::originalOwnershipHash({reinterpret_cast<const std::uint8_t*>(bytes.data()),bytes.size()});QVERIFY(text);
    sh::write(sh::schedulerFile(f.profile,"PausedTorrents.conf"),QByteArray::fromStdString(*text+"\n"+*text+"\nopaque survivor\n"));QVERIFY(service->reload(*held));
    storage::ImportedSchedulerTarget target;target.hash=*f.hash;target.libraryRevision=11;target.paused=true;target.complete=false;
    auto plan=service->evaluateImported(*held,{0,1},std::span(&target,1));QVERIFY(plan);QCOMPARE(plan->actions.size(),std::size_t{1});
    QCOMPARE(plan->actions[0].kind,storage::scheduler::ActionKind::Resume);
    auto stale=target;++stale.libraryRevision;QVERIFY(!service->beginImportedAction(*held,plan->actions[0],stale));
    QVERIFY(!QFile::exists(sh::schedulerFile(f.profile,"BiglyBTC.scheduler-intent")));
    QVERIFY(service->beginImportedAction(*held,plan->actions[0],target));
    QVERIFY(sh::read(sh::schedulerFile(f.profile,"BiglyBTC.scheduler-intent")).startsWith("BiglyBTC Scheduler imported intent 1\n"));
    // Actual saved transaction; caller-supplied success is a domain fixture.
    // The real owner effect is exercised by the next Host methods.
    QVERIFY(storage::applyLibraryCommand(*held,*f.hash,core::DownloadAction::Resume));
    QVERIFY(service->finishImportedAction(*held,plan->actions[0],storage::SchedulerActionResult::Succeeded));
    QCOMPARE(sh::read(sh::schedulerFile(f.profile,"PausedTorrents.conf")),QByteArray::fromStdString(*text+"\nopaque survivor\n"));
    storage::SchedulerTorrent native;native.token=91;native.hash=*f.hash;native.state=storage::scheduler::TorrentState::Stopped;
    const auto nativePlan=service->evaluate({0,1},std::span(&native,1),7,9);QVERIFY(nativePlan);QVERIFY(nativePlan->actions.empty());
    // Native manual revoke remains permanent in memory even if the file CAS
    // refuses cleanup; a later raw reload must not reimport that permission.
    sh::write(sh::schedulerFile(f.profile,"PausedTorrents.conf"),QByteArray::fromStdString(*text+"\nchanged\n"));
    QVERIFY(!service->revokeForManual(*held,*f.hash));QVERIFY(service->reload(*held));
    target.paused=false;target.libraryRevision=12;
    plan=service->evaluateImported(*held,{0,1},std::span(&target,1));QVERIFY(plan);QVERIFY(plan->actions.empty());
  }
  void savedOnlyInheritedPauseRunsOriginalPermissionWithoutFakeAdmission_data(){
    QTest::addColumn<bool>("multifile");QTest::addColumn<bool>("forced");
    QTest::newRow("single")<<false<<false;QTest::newRow("multi-forced")<<true<<true;
  }
  void savedOnlyInheritedPauseRunsOriginalPermissionWithoutFakeAdmission(){
    QFETCH(bool,multifile);QFETCH(bool,forced);test::OwnedEngineFixture f(multifile);prepare(f,false,forced);sh::ApprovedModule module;
    const auto retained=capture(f,forced,multifile);app::SessionBridge bridge(nullptr,{},{},module.factory());
    QSignalSpy rows(&bridge,&app::SessionBridge::snapshotReady),closed(&bridge,&app::SessionBridge::sessionClosed);
    QVERIFY(bridge.openNormal(f.native()));QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy()&&row(rows,*f.hash),30000);
    QTRY_COMPARE_WITH_TIMEOUT(sh::read(sh::schedulerFile(f.profile,"PausedTorrents.conf")),QByteArray("opaque survivor\r\n"),15000);
    QTRY_VERIFY_WITH_TIMEOUT(row(rows,*f.hash)&&row(rows,*f.hash)->state!=QStringLiteral("Paused"),15000);
    QVERIFY(!QFile::exists(sh::schedulerFile(f.profile,"BiglyBTC.scheduler-intent")));
    QVERIFY(bridge.closeSession());QTRY_COMPARE_WITH_TIMEOUT(closed.size(),1,15000);QVERIFY(closed.first()[1].toBool());QVERIFY(closed.first()[2].toBool());
    auto held=storage::ProfileLease::acquire(f.native());QVERIFY(held);const auto library=storage::readLibraryView(*held);QVERIFY(library);QVERIFY(library->pauses.empty());
    QCOMPARE(library->items[0].saved.forceStart,forced);QVERIFY(library->items[0].saved.startup!=core::StartupState::Stopped);
    const auto config=sh::document(test::read(f.profile+"/biglybt.config"));QCOMPARE(config.find("opaque.imported.fixture")->bytes,std::string_view("preserved"));
    if(!retained.isEmpty()){auto object=QJsonDocument::fromJson(sh::read(retained)).object();object["joined"]=true;sh::write(retained,QJsonDocument(object).toJson());}
  }
  void interruptedImportedIntentRequiresExplicitMatchingManualSettlement(){
    test::OwnedEngineFixture f(false);prepare(f,true);sh::ApprovedModule module;
    sh::write(sh::schedulerFile(f.profile,"BiglyBTC.scheduler-intent"),QByteArray::fromStdString(
        "BiglyBTC Scheduler imported intent 1\n"+f.hash->hex()+"\n11\n0\n1\n"));
    const auto inventory=test::read(f.profile+"/downloads.config");app::SessionBridge bridge(nullptr,{},{},module.factory());
    QSignalSpy rows(&bridge,&app::SessionBridge::snapshotReady),sessions(&bridge,&app::SessionBridge::columnLayoutSessionReady),reads(&bridge,&app::SessionBridge::schedulerReady),writes(&bridge,&app::SessionBridge::schedulerSaved),closed(&bridge,&app::SessionBridge::sessionClosed);
    QVERIFY(bridge.openNormal(f.native()));QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy()&&!sessions.empty()&&row(rows,*f.hash),30000);
    QCOMPARE(test::read(f.profile+"/downloads.config"),inventory);QVERIFY(QFile::exists(sh::schedulerFile(f.profile,"BiglyBTC.scheduler-intent")));
    const auto frame=lastRows(rows);QVERIFY(frame);QVERIFY(bridge.downloadAction({{QString::fromStdString(f.hash->hex()),frame->revision}},core::DownloadAction::Stop));
    QTRY_VERIFY_WITH_TIMEOUT(!bridge.busy()&&row(rows,*f.hash)&&row(rows,*f.hash)->state==QStringLiteral("Stopped"),15000);
    QCOMPARE(sh::read(sh::schedulerFile(f.profile,"PausedTorrents.conf")),QByteArray("opaque survivor\r\n"));QVERIFY(!QFile::exists(sh::schedulerFile(f.profile,"BiglyBTC.scheduler-intent")));
    const auto session=sessions.first()[0].toULongLong();QVERIFY(bridge.loadScheduler({session,1}));QTRY_COMPARE(reads.size(),1);QTRY_VERIFY(!bridge.busy());
    auto disable=sh::submission(sh::last(reads),2);disable.preferences.enabled=false;QVERIFY(bridge.saveScheduler(disable));QTRY_COMPARE(writes.size(),1);QTRY_VERIFY(!bridge.busy());QVERIFY2(sh::saved(writes)->saved,qPrintable(sh::saved(writes)->failure));
    QCOMPARE(row(rows,*f.hash)->state,QStringLiteral("Stopped"));QVERIFY(bridge.closeSession());QTRY_COMPARE_WITH_TIMEOUT(closed.size(),1,15000);
  }
};
QTEST_MAIN(SchedulerImportedIntegrationTests)
#include "scheduler_imported_integration_tests.moc"
