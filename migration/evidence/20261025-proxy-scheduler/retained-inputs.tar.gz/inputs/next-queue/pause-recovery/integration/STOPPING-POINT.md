STOPPED AT USER REQUEST — incomplete future integration, source-only

The user requested finishing the CURRENT parent milestone and then stopping.
This next integration must not be adopted or counted as the current milestone.
All preimages and current authored bytes are retained here. No build, test,
JVM, engine, network, native-tree mutation, Git or actual file-command execution
was performed by this task. The source text itself contains proposed future
effects; none has run. No new passing rows/cases or qualification is claimed.

Authored so far:
* SchedulerService separate ImportedSchedulerTarget (library revision, not LT
  token), typed plan/action and separate imported journal/pending state.
* Imported action selection reuses source-derived policy. Current native
  acknowledgements stay in their existing map. Manual revoke also records an
  imported-permission denial even if durable cleanup fails.
* begin checks held-lease/current target/revision and source CAS before intent.
  finish validates the selected publication scope and consumes the first matching
  source permission only after caller success; uncertainty remains journaled.
* Host saved-only/current-target projection uses actual checked observations or
  the existing qualified saved no-DiskManager completion projection. Missing
  completion remains optional/unavailable. Resume/Restart use existing actual
  saved and managed command routes, with no fake admission token.
* One old inherited-pause test fixture is intentionally enabled from startup so
  the pause schedule holds while that test still verifies NativeCurrent remains
  empty. Its existing assertions/cases are preserved.
* New focused integration test source is drafted; no compile/run credit. It has
  an opt-in generated-profile retention hook for future Java switchback.

NOT FINISHED / resume prerequisites:
1. Complete static review of source/lifetime/CAS and imported permission behavior,
   including multiple imported actions in one plan and scope-mask validation.
2. Compile the staged sources and fix actual diagnostics only after authorization.
   No compile-readiness or functional-pass promise is made.
3. CMake registrations have NOT been authored/adopted. New .inc is included by
   the modified service TU; the new QtTest target would link desktop Host,
   scheduler service, local engine/profile, QtTest and qualified LT, with the
   existing approved module env/engine-bound gate. Root owns eventual CMake.
4. Actual retained-original switchback helper/runner has NOT been authored.
   Earlier imported-original/original-trace-plan.json remains a proposal only;
   existing original method/ownership fixtures retain only their old scopes.
5. Complete owned stale/profile/manual/reentry/failure and Java/native/Java
   qualification before any authority or whole CF04 completion statement.
6. Broader inherited/interrupted recovery UI is still not implemented here.

Preserve prior pure imported-original dd8e and historical2bfe reports unchanged.
They are dependencies/history, not execution evidence for this unfinished draft.
