Lazy Scheduler manual revocation — narrow source correction after frozen19e7

Driver's independent review found that legacy owned open publishes its first ready
snapshot before Scheduler is loaded. A user command may therefore increment the
Host manual revision while no service exists to revoke/clean the imported hash.
Later service creation must not treat that changed revision as a fresh import grant.

The Host imported-target loop now excludes every nonzero current-Host manual revision
before source permission selection. This per-owner filter survives deferred service
creation and complements (not replaces) the existing service revoked set, which still
prevents reimport after cleanup failure/reload. No persistent original permission is
fabricated or upgraded to NativeCurrent. A new profile/Host starts a distinct owner.

Apply the two staged sources as deltas on integration-final19e7; all other sources,
CMake and original recipe stay unchanged. New Stop/Pause data rows use actual legacy
owned open. Direct initial snapshot delivery queues the real manual command before
idle work can load Scheduler and asserts factory count zero at that point. The
permission deliberately remains on disk (there was no service to clean it). Actual
load+save forces the existing poll before reply; manual inventory and permission must
remain exact with no imported intent. Joined close and held-lease saved state are
checked. Existing separate service test already covers failed cleanup followed by
reload and durable suppression. No passing rows/counts or runtime credit claimed.

merged-host/staging/preview/native/app/session_bridge.cpp is the separate full combined
Host afterimage requested for root adoption, not a third independent native path. It
composes corrected Oracle Host with final verified-SOCKS4a host-retention5699 over the
common6d4fbf95 base. merged-host/inputs retains the common base, original19e7 Host,
corrected Host and exact4a before/after. merge-receipt.json records the actual pure
text merge argv/exit/full pins; two inverse source merges recover each original side
byte-for-byte. No Git repository mutations or native writes were performed.

Root may commit4a first, then the imported recovery paths, and build both once. Root
owns tests/CMakeLists composition on actual471: append the unchanged19e7 Targets.cmake
after the4a include and preserve the fortified --wrap=__read_chk lane. Do not overwrite
current CMake using the old full19e7 afterimage. The source-only original switchback
recipe in19e7 remains valid; this amendment adds no new original helper/runtime proof.

Stop after the user-selected two additional milestones; this is a correction within
imported Scheduler recovery, not a new chapter.
