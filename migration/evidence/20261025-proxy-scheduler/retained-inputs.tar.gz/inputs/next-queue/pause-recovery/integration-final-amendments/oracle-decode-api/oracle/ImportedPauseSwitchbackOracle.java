import com.biglybt.core.Core;
import com.biglybt.core.download.DownloadManager;
import com.biglybt.core.util.ByteFormatter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

/** Actual retained GlobalManager pause/load/save; never starts Scheduler/plugin UI.
 * The hash line is generated using the already qualified original formatter.
 * Its imported-permission policy is separately bound to frozen actual tick data.
 */
public final class ImportedPauseSwitchbackOracle {
    private static void require(boolean value, String reason) {
        if (!value) { throw new IllegalStateException(reason); }
    }
    private static void run(String[] args) throws Exception {
        require(System.getSecurityManager() instanceof ReferenceFence, "Strict owned reference fence required");
        require(args.length == 4 && (args[0].equals("pause") || args[0].equals("inspect")),
            "pause|inspect, owned listener, selected hash, expected force");
        Path root = Paths.get(System.getProperty("biglybtc.test.root")).toRealPath();
        require(root.toString().startsWith("/tmp/biglybtc-engine-statistics-"), "Exact generated native fixture root");
        int port = Integer.parseInt(args[1]);
        require(port > 0 && port <= 65535, "Owned listener endpoint");
        boolean forced = Boolean.parseBoolean(args[3]);
        Core core = EngineOracle.configuredCore(port);
        boolean started = false;
        byte[] selectedHash = null;
        try {
            core.start(); started = true;
            List<DownloadManager> rows = core.getGlobalManager().getDownloadManagers();
            require(rows.size() == 1, "Only the generated selected download is admitted");
            DownloadManager selected = rows.get(0);
            selectedHash = selected.getTorrent().getHash().clone();
            require(ByteFormatter.encodeString(selectedHash).equals(args[2]), "Exact selected hash");
            Path payload = selected.getSaveLocation().toPath().toAbsolutePath().normalize();
            require(payload.startsWith(root) && !Files.isSymbolicLink(payload), "Generated payload only");
            if (args[0].equals("pause")) {
                // Invoke the unchanged GlobalManager method, not a reimplemented
                // pause-state algorithm or a proxy replacement of that method.
                require(core.getGlobalManager().pauseDownload(selected, false), "Actual original pause accepted");
                long deadline = System.nanoTime() + 90000000000L;
                while (!selected.isPaused() || selected.getState() != DownloadManager.STATE_STOPPED) {
                    require(System.nanoTime() < deadline, "Actual original stop deadline"); Thread.sleep(25);
                }
                core.getGlobalManager().saveState();
            } else {
                require(!selected.isPaused(), "Native imported Resume removed original saved pause");
                require(selected.isForceStart() == forced, "Original force restoration survives native handoff");
            }
            System.out.println("ROW\t" + args[2] + "\t" + selected.getState() + "\t"
                + selected.isForceStart() + "\t" + selected.isPaused());
        } finally {
            if (started) { core.stop(); }
        }
        if (args[0].equals("pause")) {
            require(selectedHash != null, "Actual original selected identity");
            Path ownership = root.resolve("profile/plugins/SpeedScheduler/PausedTorrents.conf");
            require(Files.isRegularFile(ownership) && !Files.isSymbolicLink(ownership), "Owned source-format permission file");
            require(new String(Files.readAllBytes(ownership), StandardCharsets.UTF_8).equals("opaque survivor\r\n"),
                "No hidden preexisting permission in fixture");
            Files.write(ownership, (ByteFormatter.nicePrint(selectedHash, false) + "\n").getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.APPEND);
        }
        System.out.println("ACTUAL_ORIGINAL_" + args[0].toUpperCase(java.util.Locale.ROOT) + "_JOINED");
    }
    public static void main(String[] args) {
        try { run(args); System.exit(0); }
        catch (Throwable error) { error.printStackTrace(); System.exit(2); }
    }
}
