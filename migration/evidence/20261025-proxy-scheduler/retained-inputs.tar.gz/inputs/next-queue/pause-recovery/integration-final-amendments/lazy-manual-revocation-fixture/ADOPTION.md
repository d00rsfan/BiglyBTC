Test setup correction only, after immutablec0019ef7 and19e7e74f.

The Pause row originally started with prepare(...), which had already saved Pause.
Host correctly excludes Pause from the action mask for an already paused item; that
row could not exercise manual revision revocation. Only the Pause row now performs
actual applyLibraryCommand(Resume) under the generated held lease before Bridge open,
asserts no saved pause remains, and preserves the source imported permission file.
Its direct initial callback therefore issues a valid new manual Pause before lazy
Scheduler load. Stop row, all original assertions/deadlines and production sources
are unchanged. This is a new source-only fixture amendment, not execution credit.

Apply this test delta afterc001. The combined Host remains1e1cfa19236e5f1d30a97e44b28697774fe259d58e5aa564bd57fcdac3cc7a50.
No builds, native writes, Java or engine/test execution. Root owns one cohesive batch.
