Oracle-only decode API correction after immutable19e7.

The actual root run in integration-final/oracle/run-r1 completed helper javac,
native prepare and unchanged original GlobalManager pause/save. It then failed in
the Python assertion harness: handoff.decode returns (decoded, raw_spans), not a
mapping alone. Both callsites now unpack that exact tuple. There are no other
recipe changes: all assertions, cohorts/pins, timeouts, fixtures, commands, heartbeat,
finally archival and Java method bodies remain exact. Inspection of the only other
imported helper APIs confirms jvm returns its argv list and unused_port an integer.
No source/helper bodies were imported or run by the amendment author.

run-r1 logs and archived generated roots remain untouched at the old location.
The new self-contained oracle directory copies the exact Java helper and inputs;
it self-checks its new immutable manifest before execution. Root should run:

  python3 -B /home/yurii/Java/BiglyBT/build/storage-20261025/next-queue/pause-recovery/integration-final-amendments/oracle-decode-api/oracle/run_switchback.py --driver "$BUILD/tests/biglybtc-scheduler-imported-handoff-driver" --module "$SCHEDULER_MODULE" --attempt run-r2

The fresh actual receipt location for tracking finalizer is:
  integration-final-amendments/oracle-decode-api/oracle/run-r2/result.json
under the same pause-recovery root. Its source_manifest_sha256 must equal this
amendment manifest; inherited production/source capsule remains19e7 +c001 +bfc4,
with merged Host1e1cfa19. Exact driver/module hashes are measured in the actual run.
No native production edits, compilation, tests, JVM or network execution here.
This is a correction within the second authorized additional milestone; STOP after
those two milestones. No new chapter or extra runtime equality claim is added.
