#!/usr/bin/env python3
"""Root-invoked generated Java -> native Host -> Java pause switchback.

No original rebuild. The unchanged Scheduler hash-predicate corpus is reused;
this recipe adds actual GlobalManager load/pause/save and actual native effects.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/yurii/Java/BiglyBT')
JAVA = Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')


def need(value, why):
    if not value:
        raise ValueError(why)


def sha(path):
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid(), 'Owned regular input: ' + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        need(not path.is_symlink(), 'No generated/cohort symlinks: ' + str(path))
        if path.is_file():
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--driver', required=True, type=Path)
    parser.add_argument('--module', required=True, type=Path)
    parser.add_argument('--attempt', required=True)
    args = parser.parse_args()
    need(args.attempt.startswith('run-') and '/' not in args.attempt, 'Fresh named attempt')
    parent = HERE.parent
    manifest = json.loads((parent / 'manifest.json').read_bytes())
    for rel, digest in manifest['artifacts'].items():
        need(sha(parent / rel) == digest, 'Changed recipe/capsule: ' + rel)
    inputs = json.loads((HERE / 'inputs.json').read_bytes())
    for name, digest in inputs['files'].items():
        need(sha(Path(name)) == digest, 'Changed reviewed original/helper input: ' + name)
    cohort = Path(inputs['cohort'])
    retained = json.loads(Path(inputs['retention']).read_bytes())
    need(retained['recompiled'] is False and retained['source_commit'] == inputs['original_commit'], 'Retained original cohort')
    need(inventory(cohort) == retained['file_sha256'], 'Changed original cohort')
    driver = args.driver.resolve(strict=True)
    module = args.module.resolve(strict=True)
    driver_hash, module_hash = sha(driver), sha(module)
    destination = HERE / args.attempt
    need(not destination.exists(), 'Attempt history must remain immutable')
    destination.mkdir(mode=0o700)
    work = Path(tempfile.mkdtemp(prefix='biglybtc-imported-switchback-', dir='/tmp'))
    for name in ('classes', 'empty-sourcepath'):
        (work / name).mkdir(mode=0o700)
    environment = {key: value for key, value in os.environ.items() if key not in
                   ('CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'LD_PRELOAD')}
    environment.update(QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1',
                       BIGLYBTC_SCHEDULER_TEST_MODULE=str(module))
    commands, generated, cases = [], {}, []

    def save_commands():
        (destination / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')

    def run(name, command, cwd=work, timeout=150):
        row = {'name': name, 'argv': list(map(str, command)), 'cwd': str(cwd), 'timeout_seconds': timeout}
        commands.append(row)
        save_commands()
        with (destination / (name + '.stdout')).open('xb') as out, (destination / (name + '.stderr')).open('xb') as err:
            child = subprocess.Popen(row['argv'], cwd=cwd, env=environment, stdout=out, stderr=err,
                                     start_new_session=True)
            started = time.monotonic()
            try:
                while child.poll() is None:
                    remaining = timeout - (time.monotonic() - started)
                    if remaining <= 0:
                        raise TimeoutError(name)
                    try:
                        child.wait(timeout=min(40, remaining))
                    except subprocess.TimeoutExpired:
                        print('Imported Scheduler switchback active: ' + name, flush=True)
            finally:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                row.update(exit_code=child.returncode, seconds=time.monotonic() - started)
                row['stdout_sha256'] = sha(destination / (name + '.stdout'))
                row['stderr_sha256'] = sha(destination / (name + '.stderr'))
                save_commands()
            need(child.returncode == 0, name + ' failed; raw logs retained')

    result = None
    try:
        sources = [ROOT / 'migration/fixtures/java/ReferenceFence.java',
                   ROOT / 'migration/fixtures/java/EngineOracle.java', HERE / 'ImportedPauseSwitchbackOracle.java']
        run('javac-helpers', [JAVA / 'javac', '-J-XX:ActiveProcessorCount=2', '--release', '8', '-encoding', 'UTF-8',
            '-proc:none', '-implicit:none', '-sourcepath', work / 'empty-sourcepath', '-cp', cohort,
            '-d', work / 'classes', *sources], timeout=90)
        helpers = inventory(work / 'classes')
        need(set(helpers) == {'ReferenceFence.class', 'EngineOracle.class', 'EngineOracle$1.class',
                            'ImportedPauseSwitchbackOracle.class'}, 'Unexpected helper compilation')
        sys.path.insert(0, str(ROOT / 'migration/tools'))
        from peer_interop import jvm, unused_port
        from handoff import decode
        classpath = str(work / 'classes') + os.pathsep + str(cohort)
        for name, shape, forced in [('single', 'single', False), ('multi-forced', 'multi', True)]:
            receipt = work / (name + '.json')
            run(name + '-native-prepare', [driver, 'prepare', receipt, shape, 'force' if forced else 'ordinary'])
            observed = json.loads(receipt.read_bytes())
            fixture = Path(observed['root'])
            need(fixture.parent == Path('/tmp') and fixture.name.startswith('biglybtc-engine-statistics-')
                 and fixture.resolve() == fixture and fixture.stat().st_uid == os.geteuid(), 'Exact owned generated root')
            generated[name] = fixture
            need(Path(observed['profile']) == fixture / 'profile', 'Exact generated profile')
            before = inventory(fixture)
            port = unused_port()
            run(name + '-java-pause', [*jvm(fixture, classpath, (port,)), 'ImportedPauseSwitchbackOracle',
                'pause', port, observed['hash'], str(forced).lower()], cwd=fixture)
            document, _ = decode((fixture / 'profile/downloads.config').read_bytes())
            pauses = document.get(b'pause_data', [])
            need(len(pauses) == 1 and pauses[0][b'force'] == int(forced) and pauses[0][b'owner'] == 1,
                 'Actual original pause saved force/general-owner fields')
            original_pause = inventory(fixture)
            run(name + '-native-import', [driver, 'execute', receipt])
            joined = json.loads(receipt.read_bytes())
            need(joined['joined'] is True, 'Actual native joined close')
            native_after = inventory(fixture)
            port = unused_port()
            run(name + '-java-inspect', [*jvm(fixture, classpath, (port,)), 'ImportedPauseSwitchbackOracle',
                'inspect', port, observed['hash'], str(forced).lower()], cwd=fixture)
            after, _ = decode((fixture / 'profile/downloads.config').read_bytes())
            need(not after.get(b'pause_data', []), 'Actual original reopened unpaused state')
            need((fixture / 'profile/plugins/SpeedScheduler/PausedTorrents.conf').read_bytes() == b'opaque survivor\r\n',
                 'Unrelated original ownership bytes retained')
            cases.append({'name': name, 'hash': observed['hash'], 'forced': forced, 'generated_root': str(fixture),
                          'before': before, 'actual_original_pause': original_pause, 'native_joined': native_after,
                          'actual_original_reload': inventory(fixture)})
            print('PASS actual original/native/original imported pause: ' + name, flush=True)
        need(inventory(work / 'classes') == helpers, 'Helper classes changed while running')
        result = {'status': 'PASS', 'actual_cases': len(cases), 'cases': cases,
                  'native_driver_sha256': driver_hash, 'module_sha256': module_hash,
                  'scope': inputs['scope'], 'source_manifest_sha256': sha(parent / 'manifest.json')}
    except BaseException as failure:
        (destination / 'failure.json').write_text(json.dumps({'error': repr(failure)}, indent=2) + '\n')
        raise
    finally:
        # Receipts may have appeared before a failed native prepare returned.
        # Retain any such exact owned root too, never scan/collect other profiles.
        for receipt in work.glob('*.json'):
            try:
                value = json.loads(receipt.read_bytes())
                path = Path(value['root'])
                if (path.parent == Path('/tmp') and path.name.startswith('biglybtc-engine-statistics-')
                        and path.resolve() == path and path.stat().st_uid == os.geteuid()):
                    generated.setdefault(receipt.stem, path)
            except (ValueError, KeyError, OSError):
                pass
        try:
            shutil.copytree(work, destination / 'generated-helpers')
            for name, path in generated.items():
                inventory(path)  # Refuse links before archive traversal.
                shutil.copytree(path, destination / 'generated-profiles' / name)
            need(inventory(cohort) == retained['file_sha256'], 'Original cohort changed')
            if result is not None:
                (destination / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
        except BaseException as failure:
            (destination / 'archive-failure.json').write_text(json.dumps({'error': repr(failure)}) + '\n')
            raise
        else:
            for path in set(generated.values()):
                shutil.rmtree(path)
            shutil.rmtree(work)


if __name__ == '__main__':
    main()
