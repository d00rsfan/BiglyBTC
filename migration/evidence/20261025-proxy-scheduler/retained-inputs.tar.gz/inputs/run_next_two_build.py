from pathlib import Path
import json,os,subprocess,sys
w=Path(__file__).resolve().parent;case,build,jobs=sys.argv[1:];p=json.loads((w/"next-two-plan-r2.json").read_text());env=os.environ.copy();env.update(BIGLYBTC_STORAGE_BUILD=build,BIGLYBTC_STORAGE_JOBS=jobs);targets=p["targets"] if build.endswith("bound-gcc") else [t for t in p["targets"] if t not in p["primary_only_targets"]];raise SystemExit(subprocess.run(["python3",str(w/"compile.py"),case,*targets],env=env).returncode)
