from pathlib import Path
import json,os,subprocess,sys
w=Path(__file__).resolve().parent;case,build,plan=sys.argv[1:];d=json.loads((w/plan).read_text());env=os.environ.copy();env['BIGLYBTC_STORAGE_BUILD']=build
raise SystemExit(subprocess.run(['python3',str(w/'check.py'),case,*d['suites']],env=env).returncode)
