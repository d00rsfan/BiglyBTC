from pathlib import Path
import concurrent.futures,json,subprocess,time
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');source='861d4f17f2454086de8ec44a9814c292ce1f41fe'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=n,text=True).strip()==source

def wait_receipt(stem):
 p=w/(stem+'-receipt.json');until=time.monotonic()+7200
 while not p.exists():
  if time.monotonic()>until:raise RuntimeError('Timed out waiting for owned batch '+stem)
  time.sleep(2)
 r=json.loads(p.read_text());assert r['exit']==0,(stem,r['exit']);return r

def lane(name,build,build_case,test_case):
 try:
  wait_receipt(build_case)
  if name!='gcc':
   assert not (w/(test_case+'-receipt.json')).exists()
   subprocess.run(['python3','-B',str(w/'run_matrix_checks.py'),test_case,build,'next-two-plan-r2.json'],cwd=w.parents[1],check=True)
  wait_receipt(test_case)
  if name=='gcc':
   script=w/'next-queue/pause-recovery/integration-final/oracle/run_switchback.py'
   cmd=['python3','-B',str(script),'--driver',str(n/build/'tests/biglybtc-scheduler-imported-handoff-driver'),'--module',str(n/build/'app/BiglyBTC-plugin-SpeedScheduler.so'),'--attempt','run-r1']
   with (w/'next-two-original-switchback-r1.log').open('x') as out:subprocess.run(cmd,cwd=script.parent.parent,stdout=out,stderr=subprocess.STDOUT,check=True)
  return {'lane':name,'status':'PASS','test_case':test_case}
 except Exception as e:return {'lane':name,'status':'FAIL','error':repr(e)}
lanes=[('gcc','build/persistent-peer-accounting-20261021/bound-gcc','next-two-gcc-build-r3','next-two-gcc-tests-r1'),('clang','build/saved-services-20261018/clang','next-two-clang-build-r1','next-two-clang-tests-r1'),('sanitizers','build/saved-services-20261018/sanitized-desktop','next-two-san-build-r3','next-two-san-tests-r1')]
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(lane,*v) for v in lanes]
 for f in concurrent.futures.as_completed(futures):
  r=f.result();results.append(r);(w/'next-two-remaining-status.json').write_text(json.dumps({'source':source,'results':results},indent=2)+'\n');print(json.dumps(r),flush=True)
assert all(r['status']=='PASS' for r in results),results
