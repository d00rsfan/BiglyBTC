import com.biglybt.core.Core;
import com.biglybt.core.CoreFactory;
import com.biglybt.core.config.COConfigurationManager;
import com.biglybt.core.download.DownloadManager;
import com.biglybt.core.download.DownloadManagerInitialisationAdapter;
import com.biglybt.core.peer.PEPeerManager;
import com.biglybt.pif.PluginManager;
import com.biglybt.pif.PluginManagerDefaults;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

/** Full original engine, generated profile, guarded owned-loopback peer only. */
public final class EngineOracle {
    private static void guard() {
        if (!(System.getSecurityManager() instanceof ReferenceFence)) {
            throw new IllegalStateException("Reference engine requires its test guard");
        }
    }

    static Core configuredCore(int listenPort) throws Exception {
        guard();
        Class.forName("com.biglybt.core.util.Debug");
        COConfigurationManager.setParameter("TCP.Listen.Port", listenPort);
        COConfigurationManager.setParameter("TCP.Listen.Port.Enable", true);
        COConfigurationManager.setParameter("UDP.Listen.Port.Enable", false);
        COConfigurationManager.setParameter("UDP.NonData.Listen.Port.Enable", false);
        COConfigurationManager.setParameter("Bind IP", "127.0.0.1");
        COConfigurationManager.setParameter("Enforce Bind IP", true);
        COConfigurationManager.setParameter("Check Bind IP On Start", false);
        COConfigurationManager.setParameter("IPV6 Enable Support", false);
        COConfigurationManager.setParameter("network.tcp.read.select.time", 25);
        COConfigurationManager.setParameter("network.tcp.write.select.time", 25);
        COConfigurationManager.setParameter("Use Resume", true);
        COConfigurationManager.setParameter("Rename Incomplete Files", true);
        COConfigurationManager.setParameter("Rename Incomplete Files Extension", ".az!");
        COConfigurationManager.setParameter("Move Completed When Done", false);
        COConfigurationManager.setParameter("Save Torrent Files", false);
        COConfigurationManager.setParameter("update.start", false);
        COConfigurationManager.setParameter("update.periodic", false);
        COConfigurationManager.setParameter("VersionCheck.CheckAtStart", false);
        PluginManagerDefaults defaults = PluginManager.getDefaults();
        for (String plugin : defaults.getDefaultPlugins()) {
            defaults.setDefaultPluginEnabled(plugin, false);
        }
        return CoreFactory.create();
    }

    public static void main(String[] args) throws Exception {
        guard();
        Class.forName("com.biglybt.core.util.Debug");
        Path work = Paths.get(System.getProperty("biglybtc.test.root"));
        int listenPort = Integer.parseInt(args[0]);
        int seedPort = Integer.parseInt(args[1]);
        Path torrent = Paths.get(args[2]);
        Path expected = Paths.get(args[3]);
        String role = args.length > 4 ? args[4] : "receive";
        int expectedPartialPieces = args.length > 5 ? Integer.parseInt(args[5]) : 1;
        if (expectedPartialPieces < 1 || expectedPartialPieces > 8) {
            throw new IllegalArgumentException("Invalid expected generated piece count");
        }
        if (!role.equals("receive") && !role.equals("partial") && !role.equals("seed")
                && !role.equals("prepare-partial") && !role.equals("reopen")
                && !role.equals("resume-saved") && !role.equals("inspect-partial")) {
            throw new IllegalArgumentException("Unknown reference engine role");
        }
        Path payload = work.resolve("payload");
        Files.createDirectories(payload);
        if (role.equals("seed")) {
            Files.write(payload.resolve("generated.bin"), Files.readAllBytes(expected));
        } else if (role.equals("partial") || role.equals("prepare-partial")) {
            Files.write(payload.resolve("generated.bin.az!"), Arrays.copyOf(Files.readAllBytes(expected), 24576));
        }
        Core core = configuredCore(listenPort);
        boolean started = false;
        try {
            core.start();
            started = true;
            guard();
            DownloadManager manager;
            if (role.equals("reopen") || role.equals("resume-saved") || role.equals("inspect-partial")) {
                java.util.List<DownloadManager> saved = core.getGlobalManager().getDownloadManagers();
                if (saved.size() != 1) { throw new IllegalStateException("Expected exactly one saved original download"); }
                manager = saved.get(0);
                System.out.println("ENGINE_REOPEN_EXISTING " + manager.getState());
            } else {
                manager = core.getGlobalManager().addDownloadManager(
                torrent.toString(), null, payload.toString(), DownloadManager.STATE_STOPPED,
                true, false, new DownloadManagerInitialisationAdapter() {
                    public int getActions() { return ACT_NONE; }
                    public void initialised(DownloadManager download, boolean seeding) {
                        download.getDownloadState().setNetworks(new String[]{"Public"});
                        download.getDownloadState().setPeerSources(new String[]{"Plugin", "Incoming"});
                    }
                });
            }
            if (manager == null) { throw new IllegalStateException("Original engine rejected generated metadata"); }
            manager.initialize();
            long deadline = System.nanoTime() + 90000000000L;
            boolean injected = false;
            boolean verified = false;
            boolean preparedPartial = false;
            boolean reopenedReady = false;
            while (System.nanoTime() < deadline) {
                guard();
                int state = manager.getState();
                if (state == DownloadManager.STATE_ERROR) {
                    throw new IllegalStateException("Original engine error: " + manager.getErrorDetails());
                }
                if (state == DownloadManager.STATE_READY) {
                    if (role.equals("reopen")) {
                        int done = 0;
                        for (com.biglybt.core.disk.DiskManagerPiece piece : manager.getDiskManager().getPieces()) {
                            if (piece.isDone()) { ++done; }
                        }
                        if (done != manager.getDiskManager().getPieces().length) {
                            throw new IllegalStateException("Reopened Java state lost verified pieces: " + done);
                        }
                        reopenedReady = true;
                        System.out.println("ENGINE_REOPEN_PIECES " + done);
                    }
                    if (role.equals("partial") || role.equals("prepare-partial")
                            || role.equals("resume-saved") || role.equals("inspect-partial")) {
                        int done = 0;
                        for (com.biglybt.core.disk.DiskManagerPiece piece : manager.getDiskManager().getPieces()) {
                            if (piece.isDone()) { ++done; }
                        }
                        if (done != expectedPartialPieces) { throw new IllegalStateException("Partial data recheck differs; wanted " + expectedPartialPieces + ", got " + done); }
                        System.out.println("ENGINE_PARTIAL_RECHECK " + done);
                    }
                    manager.startDownload();
                    if (role.equals("prepare-partial") || role.equals("inspect-partial")) {
                        preparedPartial = true;
                        break;
                    }
                }
                PEPeerManager peers = manager.getPeerManager();
                if (!injected && peers != null && !role.equals("seed") && !role.equals("reopen")) {
                    peers.addPeer("127.0.0.1", seedPort, 0, false, null);
                    injected = true;
                }
                if (manager.isDownloadComplete(false)) {
                    if (role.equals("reopen") && !reopenedReady) { Thread.sleep(50); continue; }
                    if (role.equals("seed") && state != DownloadManager.STATE_SEEDING) {
                        Thread.sleep(50);
                        continue;
                    }
                    Path actual = manager.getDiskManagerFileInfoSet().getFiles()[0].getFile(true).toPath();
                    if (!Arrays.equals(Files.readAllBytes(actual), Files.readAllBytes(expected))) {
                        throw new IllegalStateException("Java/native peer transfer bytes differ");
                    }
                    if (!verified) {
                        System.out.println("ENGINE_TRANSFER_VERIFIED " + Files.size(actual));
                        verified = true;
                        if (role.equals("reopen")) { System.out.println("ENGINE_REOPEN_VERIFIED " + actual); }
                        if (role.equals("seed")) { Files.write(work.resolve("ready"), new byte[]{1}); }
                    }
                    if (!role.equals("seed") || Files.exists(work.resolve("stop"))) { break; }
                }
                Thread.sleep(50);
            }
            if (!preparedPartial && !manager.isDownloadComplete(false)) {
                throw new IllegalStateException("Original engine transfer deadline expired; state=" + manager.getState());
            }
            if (preparedPartial) { System.out.println("ENGINE_PARTIAL_PROFILE_PREPARED"); }
            if (role.equals("seed") && !Files.exists(work.resolve("stop"))) {
                throw new IllegalStateException("Original seed control deadline expired");
            }
            guard();
        } finally {
            if (started) { core.stop(); }
        }
        guard();
        if (!Files.isRegularFile(work.resolve("profile/downloads.config"))) {
            throw new IllegalStateException("Original engine did not persist its compatible inventory");
        }
        System.out.println("ENGINE_STATE_PERSISTED");
        System.exit(0);
    }
}
