import java.io.File;
import java.io.FilePermission;
import java.net.InetAddress;
import java.security.Permission;
import java.util.HashSet;
import java.util.Set;

/** Test-only JDK17 guard for source-built reference cores, never production code. */
public final class ReferenceFence extends SecurityManager {
    private final String root;
    private final Set<Integer> ports = new HashSet<>();

    public ReferenceFence() throws Exception {
        root = new File(System.getProperty("biglybtc.test.root")).getCanonicalPath();
        if (!root.startsWith("/tmp/biglybtc-")) {
            throw new IllegalArgumentException("A generated /tmp test root is required");
        }
        for (String value : System.getProperty("biglybtc.test.ports", "").split(",")) {
            if (value.isEmpty()) { continue; }
            int port = Integer.parseInt(value);
            if (port < 1 || port > 65535) { throw new IllegalArgumentException("Invalid test port"); }
            ports.add(port);
        }
    }

    private String canonical(String path) {
        try { return new File(path).getCanonicalPath(); }
        catch (Exception error) { throw new SecurityException("Unresolvable test path"); }
    }

    private void writable(String path) {
        String target = canonical(path);
        if (!target.equals(root) && !target.startsWith(root + File.separator)) {
            throw new SecurityException("Write outside generated test root");
        }
    }

    private static boolean loopback(String host) {
        if (host.equals("::1") || host.equals("[::1]")) { return true; }
        String[] parts = host.split("\\.", -1);
        if (parts.length != 4 || !parts[0].equals("127")) { return false; }
        for (String part : parts) {
            if (part.isEmpty() || part.length() > 3) { return false; }
            int value = 0;
            for (int i = 0; i < part.length(); ++i) {
                char c = part.charAt(i);
                if (c < '0' || c > '9') { return false; }
                value = value * 10 + c - '0';
            }
            if (value > 255) { return false; }
        }
        return true;
    }

    @Override public void checkConnect(String host, int port) {
        if (!loopback(host) || (port != -1 && !ports.contains(port))) {
            throw new SecurityException("Network endpoint outside owned loopback tests");
        }
    }
    @Override public void checkConnect(String host, int port, Object context) { checkConnect(host, port); }
    @Override public void checkAccept(String host, int port) {
        if (!loopback(host)) { throw new SecurityException("Non-loopback test connection"); }
    }
    @Override public void checkListen(int port) {
        if (port != 0 && !ports.contains(port)) { throw new SecurityException("Non-test listener"); }
    }
    @Override public void checkMulticast(InetAddress address) { throw new SecurityException("Multicast disabled in tests"); }
    @Override public void checkExec(String command) { throw new SecurityException("Child execution disabled in tests"); }
    @Override public void checkWrite(String path) { writable(path); }
    @Override public void checkDelete(String path) { writable(path); }
    @Override public void checkRead(String path) {
        String target = canonical(path);
        if (target.startsWith("/home/") || target.startsWith("/root/")) {
            throw new SecurityException("User profiles excluded from reference tests");
        }
    }
    @Override public void checkRead(String path, Object context) { checkRead(path); }
    @Override public void checkLink(String library) {
        // The frozen reference workload uses JDK networking/disk only. Bundled
        // third-party JNI helpers must not bypass the process-local guard.
        if (!library.equals("net") && !library.equals("nio") && !library.equals("zip")
                && !library.equals("management") && !library.equals("extnet")) {
            throw new SecurityException("Non-JDK test native library");
        }
    }
    @Override public void checkPermission(Permission permission) {
        if (permission instanceof RuntimePermission && permission.getName().equals("setSecurityManager")) {
            throw new SecurityException("Reference test guard cannot be replaced");
        }
        if (permission instanceof java.nio.file.LinkPermission) {
            throw new SecurityException("Links disabled in generated reference tests");
        }
        if (permission instanceof FilePermission) {
            String actions = permission.getActions();
            if (actions.contains("write") || actions.contains("delete")) { writable(permission.getName()); }
            if (actions.contains("execute")) { throw new SecurityException("Execution disabled in reference tests"); }
        }
    }
    @Override public void checkPermission(Permission permission, Object context) { checkPermission(permission); }
}
