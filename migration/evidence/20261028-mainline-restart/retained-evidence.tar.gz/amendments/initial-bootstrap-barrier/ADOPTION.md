# Warm Mainline startup sequencing

Source-only production correction; no tests or deadlines changed. Clang actual `native-clang/tests.log` retains failed warm-state lookup, failed mixed-legacy-hint lookup and eventual180s suite timeout.

The dedicated session previously enabled DHT during LT constructor startup. With no router DNS delay, `run_all_updates` starts DHT before `reopen_listen_sockets`. The zero-node tracker clears its saved contacts/IDs; later sockets bootstrap without those contacts or a completion callback. Independently, a lookup submitted when only `is_dht_running()` is true can finish empty before routing bootstrap. Cold tests waited for real bootstrap progress and did not expose either ordering issue.

Only nonempty validated restored contacts/IDs take the new path: constructor retains the exact state with DHT disabled and no bootstrap DNS. After actual successful UDP listen, the sole service pump enables DHT with the SAME configured bootstrap string. `stop_dht` does not erase retained `m_dht_state`; UDP sockets are created even when DHT is disabled. Actual initial node count is read ONCE from the synchronous DHT-only state after the running barrier. LT emits one completion per initial node; count every initial callback (including empty-family callbacks) and issue registered rounds only after the whole count. Unknown/zero/>64 node count and dropped alerts fail explicitly. No generic retry, replacement lookup, timer, public route, settings restore or source identity transformation.

Cold empty-state construction/issuance stays unchanged. Fixed service bindings are not mutated during lifetime; later `new_socket` callbacks are not counted as invented initial completions. Existing immediate warm/legacy regression methods stay byte-exact, with all actual wire-ID/peer/token checks and15s/180s deadlines. Root should first rerun the failed existing suite against this one production delta, retain old receipts, then qualify affected lanes.

Apply only `preview/native/engine/mainline_dht.cpp` using the exact beforeimage. No new SDK/provider or CMake dependency. Runtime success remains pending root execution.
