from pathlib import Path
import os,subprocess,time,json,sys,hashlib,xml.etree.ElementTree as ET
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/mainline-restart-20261028';P=R/'build/network-reliability-20261028/provider-socks-lifecycle';lane=sys.argv[1]
cache={'gcc':N/'build/persistent-peer-accounting-20261021/bound-gcc','clang':N/'build/saved-services-20261018/clang','san':N/'build/saved-services-20261018/sanitized-desktop'}[lane]
out=W/('native-'+lane+(sys.argv[2] if len(sys.argv)>2 else ''));out.mkdir(exist_ok=False);rows=[]
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1');env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None)
if lane=='san':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
source=subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD'],text=True).strip()
def run(name,cmd,timeout=1800):
 t=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:p=subprocess.run(list(map(str,cmd)),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 rows.append(dict(name=name,command=list(map(str,cmd)),exit=p.returncode,seconds=round(time.monotonic()-t,3)));(out/'commands.json').write_text(json.dumps({'lane':lane,'source_commit':source,'commands':rows},indent=2)+'\n');print(lane,name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
if '--reuse-configure' not in sys.argv:
 run('configure',['cmake','-S',N/'preview/native','-B',cache,'-DLibtorrentRasterbar_DIR='+str(P/'install/lib/cmake/LibtorrentRasterbar'),'-DBIGLYBTC_PERSISTENT_RUNTIME_MANIFEST='+str(N/'preview/native/engine/runtime-binding/provider-socks-runtime.json')])
else:
 previous=json.loads((W/('native-'+lane)/'commands.json').read_bytes());assert previous['commands'][0]['name']=='configure' and previous['commands'][0]['exit']==0
 (out/'configuration-reuse.json').write_text(json.dumps({'receipt':str(W/('native-'+lane)/'commands.json'),'reason':'Only C++ source/test fixes changed; CMake inputs and provider unchanged'},indent=2)+'\n')
targets=['biglybtc-mainline-dht-tests','biglybtc-mainline-checkpoint-tests','biglybtc-network-policy-tests','biglybtc-managed-magnet-tests']
tests=['mainline-dht','mainline-checkpoint','network-policy','managed-magnet']
if lane=='gcc':
 targets+=['BiglyBTC','BiglyBTC-headless','biglybtc-preview-smoke','biglybtc-engine-live-settings-tests','biglybtc-owned-fixture-read-tests']
 tests+=['engine-live-settings','owned-fixture-read-diagnostic']
run('build',['nice','-n','5','cmake','--build',cache,'--parallel',os.environ.get('BIGLYBTC_CHAPTER_JOBS','1' if lane=='san' else '2'),'--target',*targets])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
products={t:cache/'tests'/t for t in targets if (cache/'tests'/t).is_file()}
if lane=='gcc':products.update({'BiglyBTC':cache/'app/BiglyBTC','BiglyBTC-headless':cache/'app/BiglyBTC-headless','preview-smoke':cache/'biglybtc-preview-smoke'})
(out/'binary-before-tests.json').write_text(json.dumps({'source_commit':source,'images_sha256':{k:sha(v) for k,v in products.items()}},indent=2)+'\n')
run('tests',['ctest','--test-dir',cache,'-R','^('+'|'.join(tests)+')$','--output-on-failure','--output-junit',out/'tests.xml'],timeout=1200)
actual=list(ET.fromstring((out/'tests.xml').read_bytes()).iter('testcase'));assert {x.get('name') for x in actual}==set(tests) and not any(x.find(t) is not None for x in actual for t in ('failure','error','skipped'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();result={'status':'PASS','lane':lane,'source_commit':source,'actual_suites':len(actual),'suite_names':tests,'provider_sha256':sha(P/'install/lib/libtorrent-rasterbar.so.2.0.12'),'binary_sha256':{t:sha(cache/'tests'/t) for t in targets if (cache/'tests'/t).exists()},'sanitizer_environment':{k:v for k,v in env.items() if k in ('ASAN_OPTIONS','UBSAN_OPTIONS')}};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(lane,'PASS',len(actual),'actual suites',flush=True)
