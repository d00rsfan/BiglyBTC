from pathlib import Path
import json,hashlib,os,subprocess,re
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/mainline-restart-20261028';out=W/'private-runtime';candidate=out/'candidate';dist=N/'dist';rollback=W/'previous-published-dist-20261028-restart';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify(root):
 m=json.loads((root/'BUILD_MANIFEST.json').read_bytes())
 for rel,pin in m['files_sha256'].items():assert sha(root/rel)==pin,rel
 return m
r=json.loads((out/'result.json').read_bytes());assert r['status']=='PASS_PRIVATE_RELOCATED_RUNTIME';assert sha(candidate/'BUILD_MANIFEST.json')==r['manifest_sha256'];new=verify(candidate);old=verify(dist);oldpin=sha(dist/'BUILD_MANIFEST.json');assert oldpin=='985ce9fd51be4886a83cd36390e3f3bb820fe3786a9a65c4902ef2f50b6bb4ed';assert not rollback.exists()
os.rename(dist,rollback)
try:
 os.rename(candidate,dist);verify(dist);verify(rollback)
 private=dist/'usr/lib/biglybtc';env=os.environ.copy()
 for k in ('LD_PRELOAD','LD_AUDIT'):env.pop(k,None)
 env.update(QT_QPA_PLATFORM='offscreen',LD_DEBUG='libs',LD_LIBRARY_PATH=os.pathsep.join(map(str,[private/'lib',private/'qt/lib',dist/'dependencies/libtorrent/usr/lib/x86_64-linux-gnu'])),QT_PLUGIN_PATH=str(private/'qt/plugins'),QT_QPA_PLATFORM_PLUGIN_PATH=str(private/'qt/plugins/platforms'))
 with (W/'post-promotion-launch.log').open('wb') as f:p=subprocess.run([str(dist/'BiglyBTC')],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30)
 assert p.returncode==2
 paths=[Path(s.strip()).resolve() for s in re.findall(r'calling init:\s*([^\n]+)',(W/'post-promotion-launch.log').read_text(errors='replace'))];assert (private/'lib/libtorrent-rasterbar.so.2.0.12').resolve() in paths and (private/'qt/lib/libQt6Core.so.6').resolve() in paths
except BaseException:
 if dist.exists():os.rename(dist,W/'failed-promoted-dist')
 os.rename(rollback,dist);raise
receipt={'status':'PASS_PROMOTED','new_manifest_sha256':sha(dist/'BUILD_MANIFEST.json'),'previous_manifest_sha256':oldpin,'new_leaves':len(new['files_sha256']),'previous_leaves':len(old['files_sha256']),'rollback':str(rollback),'installed_path':str(dist),'post_relocation_usage_exit':p.returncode,'actual_private_qt_and_provider_init':True,'provider_sha256':sha(private/'lib/libtorrent-rasterbar.so.2.0.12'),'shipping_approved':False};(W/'dist-promotion.json').write_text(json.dumps(receipt,indent=2)+'\n');print('promoted dist',receipt['new_manifest_sha256'],len(new['files_sha256']),'leaves; complete rollback retained')
