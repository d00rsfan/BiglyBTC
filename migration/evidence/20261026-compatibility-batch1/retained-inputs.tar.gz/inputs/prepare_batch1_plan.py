from pathlib import Path
import json,os
w=Path(__file__).resolve().parent;d=json.loads((w/'initial-test-catalog.json').read_text());names='network-policy engine-live-settings network-binding network-binding-owner network-proxy-owner network-proxy-capability-present network-proxy-capability-foreign-marker managed-download managed-seeding managed-combined-protocol selected-swarm-admission original-torrent-identity original-identity-callers managed-storage metadata-disk-router original-storage-controls file-operations file-operation-dialog file-operations-host file-operation-sequence scheduler-service scheduler-dialog scheduler-host scheduler-host-engine scheduler-imported-integration managed-queue options-host'.split();tests={r['name']:r for r in d['tests']};assert len(names)==len(set(names)) and not set(names)-tests.keys();targets=[]
for name in names:
 argv=tests[name]['command'];found=[Path(a).name for a in argv if '/tests/biglybtc-' in a and not a.endswith('.so')];assert len(found)==1,(name,argv)
 if found[0] not in targets:targets.append(found[0])
targets+=['biglybtc-network-proxy-foreign-marker','BiglyBTC','BiglyBTC-headless','biglybtc-preview-smoke','biglybtc-selected-hybrid-handoff-driver'];p={'source':json.loads((w/'batch1-adoption.json').read_text())['source_commit'],'suites':names,'targets':targets,'primary_only_targets':['biglybtc-preview-smoke','biglybtc-selected-hybrid-handoff-driver'],'scope':'Four related compatibility milestones, affected27suite boundary; reuse prior full-source proofs; root owns builds.'};(w/'batch1-plan.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({'suites':len(names),'targets':len(targets),'primary':p['primary_only_targets']}))
for name in ['run_matrix_checks.py']:
 import shutil
 shutil.copy2(w.parent/'storage-20261025'/name,w/name)
