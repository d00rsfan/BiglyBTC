#!/usr/bin/env python3
"""Root-run batch1 evidence/tracking. No builds, subjects, Git writes or provider approval."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import re
import shutil
import stat
import subprocess
import tarfile
import xml.etree.ElementTree as ET

H=Path(__file__).resolve().parent;W=H.parent;R=W.parents[1];N=R.parent/'BiglyBTC'
E_REL='migration/evidence/20261026-compatibility-batch1';E=R/E_REL
REVIEW='migration/updates/compatibility.providers/20261026-batch1.md'
BASE='9e7f43ec14476bb8091c803a2b37c490b46d4435';CANDIDATE='699835f1fe9a5ba0b699dd7e06db2dc6aac9f9ed'
PHASES=('fileops','network','hybrid','scheduler')
ROOTS=('batch1-composed','fileops-performance','network','hybrid-interop','scheduler-recovery','batch1-evidence')
COMPONENTS={'library.file_operations':('fileops','implementation'),
 'engine.network_binding':('network','implementation'),
 'formats.original_torrent_identity':('hybrid','tests'),
 'storage.original_managed_io':('hybrid','tests'),'profile.torrent_state':('hybrid','tests'),
 'plugins.speed_scheduler_ownership':('scheduler','implementation'),
 'plugins.speed_scheduler_runtime':('scheduler','implementation'),'ui.speed_scheduler_editor':('scheduler','implementation')}
MAPS={}
BEFORE_SHA='280df8e4c3e80fb06c975fa3e862b60b46e8526cc04e19af51b5901d33efd342'

def need(ok,why):
 if not ok:raise ValueError(why)
def raw(p):
 need(p.is_absolute() and p.resolve(strict=True)==p and stat.S_ISREG(p.lstat().st_mode),'Canonical regular input: '+str(p));return p.read_bytes()
def sha(p):return hashlib.sha256(raw(p)).hexdigest()
def load(p):return json.loads(raw(p))
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def rel(v):
 need(isinstance(v,str) and v and not Path(v).is_absolute() and '..' not in Path(v).parts,'Explicit W-relative path required');return W/v
def git(*args):return subprocess.check_output(['git',*args],cwd=N)
def source_map(commit):
 if commit in MAPS:return MAPS[commit]
 need(re.fullmatch('[0-9a-f]{40}',commit),'Full actual commit required')
 child=subprocess.Popen(['git','archive',commit,'preview/native'],cwd=N,stdout=subprocess.PIPE)
 result={}
 try:
  with tarfile.open(fileobj=child.stdout,mode='r|') as archive:
   for entry in archive:
    if entry.isdir():continue
    need(entry.isfile(),'Nonregular committed native input');stream=archive.extractfile(entry);digest=hashlib.sha256()
    for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    result[entry.name]=digest.hexdigest()
 finally:
  child.stdout.close();need(child.wait()==0,'Cannot read committed source graph')
 MAPS[commit]=result;return result

def changed(parent,commit):
 names=git('diff-tree','--no-commit-id','--name-only','-r',parent,commit).decode().splitlines()
 before,after=source_map(parent),source_map(commit)
 need(names and all(p.startswith('preview/native/') and p in after for p in names),'Source transition must contain declared native leaves, no deletions/metadata')
 return {p:after[p] for p in names},{p:before.get(p) for p in names}
def commit_receipt(path,parent):
 row=load(path);commit=row['source_commit'];actual,before=changed(parent,commit)
 need(row['parent']==parent and row['paths_sha256']==actual and row['all_staged_blob_bytes_verified'] is True,'Unproven actual commit transition: '+str(path))
 need(git('rev-parse',commit+'^').decode().strip()==parent,'Wrong actual commit parent');return row,before

def testcase_pass(row):
 text=row.findtext('system-out') or ''
 return row.get('status','run')=='run' and all(row.find(k) is None for k in ('failure','error','skipped')) and not re.search(r'^SKIP\s*:',text,re.M) and all(a==b=='0' for a,b in re.findall(r'Totals:\s*\d+ passed, (\d+) failed, (\d+) skipped',text))
def case(stem,expected,source_ids,build_root):
 need(isinstance(stem,str) and re.fullmatch(r'batch1-[A-Za-z0-9_-]+',stem),'Actual batch1 case required')
 paths=[W/(stem+x) for x in ('-receipt.json','-source.json','.xml','.log')];receipt,observed=load(paths[0]),load(paths[1])
 need(receipt['source_manifest_sha256']==sha(paths[1]) and 'ctest' in receipt['command'] and receipt['command'][receipt['command'].index('--test-dir')+1]==build_root and str(paths[2]) in receipt['command'],'Unbound actual CTest command')
 identities=[s for s in source_ids if source_map(s)==observed];need(identities,'Case has an undeclared source graph: '+stem)
 rows=list(ET.fromstring(raw(paths[2])).iter('testcase'));names=[x.get('name') for x in rows]
 need(names and None not in names and len(names)==len(set(names)) and set(names)<=expected,'Wrong/duplicate actual test inventory')
 passed={x.get('name'):x.findtext('system-out') or '' for x in rows if testcase_pass(x)}
 need(receipt['exit']==0 if len(passed)==len(rows) else receipt['exit']!=0,'CTest exit/XML disagreement')
 return identities[-1],passed,{'case':stem,'seconds':receipt['seconds'],'source_commit':identities[-1],
  'source_manifest_sha256':sha(paths[1]),'commit_association':'exact committed source-map equality','passed':sorted(passed),'uncredited':sorted(set(names)-set(passed)),
  'inputs_sha256':{p.name:sha(p) for p in paths}},set(paths)

def verify(c):
 need(sha(H/'before.json')==BEFORE_SHA,'Changed reviewed before pins');before=load(H/'before.json')
 need(sha(W/'batch1-plan.json')==before['plan_sha256'],'Changed reviewed27-suite plan')
 for name,digest in before['pinned_inputs'].items():need(sha(W/name)==digest,'Changed frozen root/capsule input: '+name)
 expected=set(load(W/'batch1-plan.json')['suites']);need(len(expected)==27,'Wrong batch1 inventory')
 required={W/'batch1-plan.json',H/'before.json',W/'checkpoint.json'}|{W/name for name in before['pinned_inputs']};phases={};parent=BASE
 for phase in PHASES:
  path=W/('batch1-'+phase+'-commit.json');row,_=commit_receipt(path,parent);phases[phase]=row['source_commit'];parent=row['source_commit'];required.add(path)
 need(parent==CANDIDATE,'Wrong four-component source graph')
 source_ids=[parent];transitions=[]
 for spec in c['followups']:
  path=rel(spec['receipt']);row,old=commit_receipt(path,parent);commit=row['source_commit'];paths=row['paths_sha256']
  affected=set(spec['affected_suites']);need(affected and affected<=expected,'Explicit affected suites required')
  review_path=rel(spec['impact_review']);review=load(review_path)
  need(sha(review_path)==spec['impact_review_sha256'] and review['status']=='PASS_SOURCE_IMPACT_REVIEW' and review['parent']==parent and review['source_commit']==commit and review['before_sha256']==old and review['source_sha256']==paths and set(review['affected_suites'])==affected,'Missing exact root impact review')
  only_tests=all(p.startswith('preview/native/tests/') for p in paths)
  need(spec['kind'] in ('tests_only','production') and (spec['kind']=='tests_only')==only_tests,'False test-only classification')
  same_production={p:v for p,v in source_map(parent).items() if not p.startswith('preview/native/tests/')}=={p:v for p,v in source_map(commit).items() if not p.startswith('preview/native/tests/')}
  need(same_production or (review.get('production_dependency_reviewed') is True and review.get('unaffected_suite_dependency_reason')),'Production delta needs explicit dependency/affected retarget review')
  transitions.append({'parent':parent,'source_commit':commit,'kind':spec['kind'],'affected_suites':sorted(affected),'same_production_graph':same_production,'paths_sha256':paths,'impact_review_sha256':sha(review_path)})
  required.update((path,review_path));parent=commit;source_ids.append(commit)
 source=c['qualified_source'];need(parent==source,'Qualified source pending or missing receipt chain')
 need(git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain','--untracked-files=all').strip(),'Require clean actual qualified native HEAD')
 current={str(p.relative_to(N)):sha(p) for p in sorted((N/'preview/native').rglob('*')) if p.is_file()};need(current==source_map(source),'Working graph differs from final committed source')
 push_path=rel(c['source_push_receipt']);push=load(push_path)
 need(push.get('source_commit',push.get('source'))==source and push['exit']==0 and push.get('remote_main',source)==source,'Final source push pending');required.add(push_path)
 matrix={};case_rows={};pass_text={}
 need(set(c['lanes'])=={'gcc','clang','sanitizers'},'Three actual lanes required')
 for lane,spec in c['lanes'].items():
  selected={};records=[]
  for stem in spec['cases']:
   tested,passed,record,inputs=case(stem,expected,source_ids,before['lane_build_roots'][lane]);records.append(record);required.update(inputs);case_rows[stem]=record
   at=source_ids.index(tested);later=transitions[at:]
   for suite in record['uncredited']:
    if not any(suite in t['affected_suites'] for t in later):selected.pop(suite,None);pass_text.pop((lane,suite),None)
   for suite,text in passed.items():
    if any(suite in t['affected_suites'] for t in later):continue
    selected[suite]={'case':stem,'tested_source_commit':tested,'source_manifest_sha256':record['source_manifest_sha256'],'qualification_source_commit':source,'unaffected_transitions':[t['source_commit'] for t in later]};pass_text[(lane,suite)]=text
  need(set(selected)==expected,'Actual PASS coverage pending for '+lane+': '+','.join(sorted(expected-set(selected))))
  built_maps={}
  for stem in spec['build_cases']:
   paths=[W/(stem+x) for x in ('-receipt.json','-source.json','.log')];r=load(paths[0]);mapping=load(paths[1])
   need(r['exit']==0 and r['source_manifest_sha256']==sha(paths[1]) and any(source_map(s)==mapping for s in source_ids) and r['command'][r['command'].index('--build')+1]==before['lane_build_roots'][lane],'Unbound compiler/build receipt');required.update(paths)
   built_maps.setdefault(hashlib.sha256(json.dumps(mapping,sort_keys=True,separators=(',',':')).encode()).hexdigest(),set()).update(r['command'][r['command'].index('--target')+1:r['command'].index('--') if '--' in r['command'] else len(r['command'])])
  need(spec['build_cases'],'Actual build provenance required')
  for suite,row in selected.items():need(before['suite_targets'][suite] in built_maps.get(hashlib.sha256(json.dumps(source_map(row['tested_source_commit']),sort_keys=True,separators=(',',':')).encode()).hexdigest(),set()),'Selected suite requires actual matching-source target build: '+lane+'/'+suite)
  matrix[lane]={'suites':27,'per_suite':selected,'cases':records,'build_cases':spec['build_cases']}
 attempts=[];observed={};driver_hashes=set()
 for name in c['hybrid_attempts']:
  attempt=rel(name);result=load(attempt/'result.json');required.add(attempt/'result.json')
  need(result['status']=='PASS_ACTUAL_BROADER_V2_HYBRID_HANDOFF' and result['original_commit']==before['original_commit'] and result['original_core_recompiled'] is False and result['original_profile_or_process_access'] is False,'Actual original hybrid attempt pending')
  need(result['manifest_sha256']==before['pinned_inputs']['hybrid-interop/manifest.json'],'Unknown hybrid recipe authority')
  for row in result['commands']:
   need(row['exit_code']==0,'Actual hybrid command failure')
   for kind in ('stdout','stderr'):
    path=attempt/'generated'/(row['name']+'.'+kind);need(sha(path)==row[kind+'_sha256'],'Changed actual original/raw handoff');required.add(path)
   if '-native-' in row['name']:driver_hashes.add(sha(Path(row['argv'][0])))
  need(driver_hashes=={result['native_driver_sha256']},'Native handoff driver changed after actual execution')
  for key,row in result['cases'].items():
   need(key not in observed and {x['mode'] for x in row['observations']}=={'partial','complete'},'Duplicate/incomplete actual hybrid case');observed[key]=row
  need(result['actual_cases']==len(result['cases']),'Wrong actual original case count');attempts.append({'path':name,'sha256':sha(attempt/'result.json'),'actual_cases':result['actual_cases']})
 need(set(observed)=={'tail-v2-32k','ordered-hybrid-v1-32k','ordered-hybrid-v2-32k','ordered-v2-64k'},'Actual hybrid4 handoffs pending')
 need(re.search(r'^PASS\s*:\s*\w+::explicitRecoveryRequiresConfirmationAndMatchingPerTorrentResult\(\)',pass_text[('gcc','scheduler-dialog')],re.M),'Actual recovery/editor confirmation test PASS pending')
 capture_spec=c['recovery_capture'];capture=rel(capture_spec['path']);capture_case=matrix['gcc']['per_suite']['scheduler-dialog'];need(capture_spec['case']==capture_case['case'] and capture_spec['source_manifest_sha256']==capture_case['source_manifest_sha256'] and sha(capture)==capture_spec['sha256'],'Root-bound recovery capture must match the credited actual GCC case');png=raw(capture);need(png[:8]==b'\x89PNG\r\n\x1a\n' and len(png)<=8*1024*1024 and png[12:16]==b'IHDR','Actual recovery PNG required');required.add(capture)
 capture_fact={'path':str(capture.relative_to(W)),'sha256':sha(capture),'bytes':len(png),'width':int.from_bytes(png[16:20],'big'),'height':int.from_bytes(png[20:24],'big')};need(0<capture_fact['width']<=8192 and 0<capture_fact['height']<=8192,'Invalid capture dimensions')
 texts=[v for (lane,suite),v in pass_text.items() if lane=='gcc' and suite=='file-operations'];work_lines=re.findall(r'payload-work[^\r\n]*','\n'.join(texts));need(len(work_lines)>=4,'Actual passing payload read-work observations pending')
 webseed=any(re.search(r'^PASS\s*:\s*\w+::actualSocks5RemoteWebSeedPayload\(\)',text,re.M) for (lane,suite),text in pass_text.items() if suite=='network-proxy-owner')
 need(webseed,'Controlled actual SOCKS5 hostname webseed PASS pending; future provider is not authority')
 for name in c['additional_receipts']:required.add(rel(name))
 for p in required:raw(p)
 for name,digest in before['original'].items():need(sha(R/name)==digest,'Shared metadata changed before finalization: '+name)
 for name,digest in before['native'].items():need(not (N/name).exists() if digest is None else sha(N/name)==digest,'Native metadata before pin changed: '+name)
 need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==before['original_commit'] and sha(R/'.git/index')==before['original_index_sha256'],'Original ordinary HEAD/index changed')
 need(not E.exists() and not (R/REVIEW).exists(),'Fresh evidence/review destination required')
 return {'status':'PASS_BOUNDED_BATCH1','source_commit':source,'candidate':CANDIDATE,'components':phases,'transitions':transitions,'matrix':matrix,'actual_hybrid_cases':4,'hybrid_attempts':attempts,'recovery_capture':capture_fact,'observed_payload_read_work':work_lines,'controlled_socks5_hostname_webseed_payload':webseed,'future_provider_webseed_authority':False,'all_CF_parents_open':True,'continue_all_remaining':True},before,required

def retain(required):
 files={};allowed={'.py','.cpp','.hpp','.h','.java','.cmake','.md','.json','.xml','.log','.txt','.patch','.stdout','.stderr'}
 def add(p,required=False):
  if not p.is_file() or p.is_symlink():need(not required,'Excluded required input');return
  name=str(p.relative_to(W));parts=p.relative_to(W).parts
  skip=any(x in {'classes','empty-sourcepath','CMakeFiles','compiler-tmp','provider-webseed','__pycache__','.git'} for x in parts)
  skip=skip or not (p.suffix in allowed or (required and p.suffix=='.png'))
  with p.open('rb') as f:skip=skip or f.read(8).startswith((b'\x7fELF',b'!<arch>\n',b'\xca\xfe\xba\xbe'))
  need(not skip or not required,'Required evidence excluded: '+name)
  if not skip:need(p.stat().st_size<=64*1024*1024,'Bulky input outside bounded evidence');files[name]=p
 for root in ROOTS:
  for p in sorted((W/root).rglob('*')):add(p)
 for p in sorted(W.glob('batch1-*')):
  if p.is_file():add(p)
 for name in ('check.py','compile.py','run_matrix_checks.py','run_batch1_build.py','run_batch1_remaining.py','compose_batch1.py','adopt_batch1.py','prepare_batch1_plan.py'):add(W/name)
 for p in required:add(p,True)
 need(sum(p.stat().st_size for p in files.values())<=128*1024*1024,'Evidence unexpectedly broad; exclude generated cohorts/payloads')
 members={k:{'sha256':sha(p),'bytes':p.stat().st_size} for k,p in sorted(files.items())};encoded=(json.dumps({'root':str(W),'files':members},separators=(',',':'))+'\n').encode()
 path=E/'retained-inputs.tar.gz'
 with path.open('xb') as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as archive:
  for name,p in sorted(files.items()):
   data=raw(p);need(hashlib.sha256(data).hexdigest()==members[name]['sha256'],'Evidence changed during retention');entry=tarfile.TarInfo('inputs/'+name);entry.size=len(data);entry.mode=0o644;archive.addfile(entry,io.BytesIO(data))
  entry=tarfile.TarInfo('MEMBERS.json');entry.size=len(encoded);entry.mode=0o644;archive.addfile(entry,io.BytesIO(encoded))
 return {'path':path.name,'sha256':sha(path),'bytes':path.stat().st_size,'members':len(members),'member_manifest_sha256':hashlib.sha256(encoded).hexdigest()}

def prepend(text,note):
 at=text.index('\n')+1;return text[:at]+'\n'+note+'\n\n'+text[at:]
def tracking(proof,before):
 need(len(re.findall(r'^- \[ \] \*\*CF-0[1-8] ',(R/'migration/tasks/COMPATIBILITY-FOLLOWUPS.md').read_text(),re.M))==8,'Broad CF parents must remain open')
 source=proof['source_commit'];summary=('Bounded compatibility batch1 is qualified at native `'+source+'`: 27 effective affected suites per GCC/Clang/leak-enabled sanitizer lane, selected individually from actual source-bound PASS rows; four actual original Java partial/complete hybrid/v2 handoffs; controlled SOCKS5 hostname webseed payload and deterministic file-operation read-work observations; Scheduler interrupted-intent recovery/editor capture. Failed attempts remain uncredited history. Continue all remaining work autonomously with batched checks. All CF01–CF08 remain open. Future webseed provider source is unbuilt/unapproved and supplies no batch1 authority; this is no whole-client/performance/release closure.')
 docs={}
 for name in before['original']:
  if name.endswith('upstreams.lock.json'):continue
  old=(R/name).read_text()
  if name=='migration/ACTIVE.md':
   docs[name]=('# Active migration work — 2026-10-26\n\n'+summary+'\n\nLatest qualified native source: `'+source+'`.\nEvidence: [batch1](evidence/20261026-compatibility-batch1/REVIEW.md).\nDurable state: `build/compatibility-20261026/checkpoint.json`.\n\nContinue [all remaining compatibility work](tasks/COMPATIBILITY-FOLLOWUPS.md); archive controls, alias/default providers and the future webseed candidate stay separate until reviewed, adopted and qualified. Native main only; root owns adoption/commits/publication and at most three compiler jobs total. Preserve original BiglyBT/profile/payloads/ordinary HEAD/index; generated owned endpoints/profiles only. Retain the previously qualified dist until a new provider/runtime passes its separate applicable qualification. No system installation is needed.\n')
  else:docs[name]=prepend(old,summary+'\n\n[Batch1 evidence]('+('../evidence/' if name.startswith('migration/tasks/') else 'evidence/' if name.startswith('migration/') else 'migration/evidence/')+'20261026-compatibility-batch1/verification.json).')
 lock=load(R/'migration/upstreams.lock.json');original_lock=json.loads(json.dumps(lock))
 for row in lock['components']:
  if row['id'] not in COMPONENTS:continue
  phase,purpose=COMPONENTS[row['id']];commit=proof['components'][phase]
  for actual,kind in [(commit,purpose),(source,'integration')]:
   value={'repository':'https://github.com/d00rsfan/BiglyBTC.git','commit':actual,'purpose':kind}
   if value not in row['native_commits']:row['native_commits'].append(value)
  for field,value in [('review_records',REVIEW),('evidence',E_REL+'/verification.json')]:
   if value not in row[field]:row[field].append(value)
 for old,new in zip(original_lock['components'],lock['components']):
  for key in ('state','source_coverage','target_paths'):need(old.get(key)==new.get(key),'Broad completion/target drift forbidden')
 need(original_lock['external_dependencies']==lock['external_dependencies'],'Future provider must not receive an authority record')
 docs['migration/upstreams.lock.json']=json.dumps(lock,indent=2,ensure_ascii=False)+'\n'
 docs[REVIEW]='# Compatibility batch1 — 2026-10-26\n\n'+summary+'\n\nQualification is per suite and source transition; it does not claim identical full snapshots after a test-only correction. Full actual rows/cases, failures, byte-work observations, capture and hybrid command receipts are in [verification](../../evidence/20261026-compatibility-batch1/verification.json); bulky maps/raw logs are compressed once with a member hash map. Original BiglyBT cb8c6cb9bb97916cbc7e80338a017200ffc3e71f and SpeedScheduler 1ee6a53dae017696d2f0002e4a0d74f5a9476af5 baselines and broad null coverage remain unchanged. Prior evidence is referenced, not duplicated.\n'
 for name,text in docs.items():p=R/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 checkpoint=load(W/'checkpoint.json');checkpoint.update(status='BATCH1_QUALIFIED_CONTINUE_ALL_REMAINING',native_main=source,latest_qualified_source=source,batch1_evidence=E_REL+'/verification.json',all_CF_parents_open=True)
 put(W/'checkpoint.json',checkpoint)
 readme=H/'output/README.md';readme.parent.mkdir(parents=True,exist_ok=True);readme.write_text((N/'README.md').read_text()+'\n## Bounded compatibility qualification — 2026-10-26\n\n'+summary+'\n')
 exports={name:{'source':str(R/name),'before_sha256':before['native'].get(name),'sha256':sha(R/name)} for name in docs}
 exports['README.md']={'source':str(readme),'before_sha256':before['native']['README.md'],'sha256':sha(readme)}
 put(W/'batch1-metadata-plan.json',{'schema':1,'source_commit':source,'exports':exports,'continue_all_remaining':True})

def export(write):
 p=load(W/'batch1-metadata-plan.json');need(git('rev-parse','HEAD').decode().strip()==p['source_commit'] and not git('status','--porcelain','--untracked-files=all').strip(),'Metadata export requires clean qualified source parent')
 for name,row in p['exports'].items():
  need(name in set(load(H/'before.json')['original'])|{REVIEW,'README.md'} or name.startswith(E_REL+'/'),'Exact metadata-only export allowlist');need(sha(Path(row['source']))==row['sha256'],'Changed prepared metadata')
  target=N/name;need(not target.exists() if row['before_sha256'] is None else sha(target)==row['before_sha256'],'Native metadata before pin changed')
 if write:
  for name,row in p['exports'].items():target=N/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(row['source'],target);need(sha(target)==row['sha256'],'Export bytes mismatch')
  put(W/'batch1-metadata-export.json',{'status':'PASS_EXACT_METADATA_EXPORT','source_commit':p['source_commit'],'paths_sha256':{k:v['sha256'] for k,v in p['exports'].items()}})
 print(json.dumps({'status':'PASS_METADATA_EXPORT' if write else 'PASS_METADATA_EXPORT_PLAN','paths':len(p['exports'])}))
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--completion',type=Path,default=H/'completion.json');parser.add_argument('--write',action='store_true');parser.add_argument('--export',action='store_true');args=parser.parse_args()
 if args.export:return export(args.write)
 try:proof,before,required=verify(load(args.completion.resolve(strict=True)))
 except (FileNotFoundError,KeyError,ValueError) as error:print(json.dumps({'status':'PENDING_ACTUAL_ROOT_GATES','reason':str(error)}));raise SystemExit(2)
 if args.write:
  required.add(args.completion.resolve(strict=True));E.mkdir(parents=True,exist_ok=False);put(E/'INCOMPLETE.json',{'status':'RETENTION_IN_PROGRESS'});proof['retention']=retain(required);put(E/'verification.json',proof)
  (E/'REVIEW.md').write_text('# Bounded compatibility batch1\n\nActual source `'+proof['source_commit']+'`; effective27 suites per lane, actual hybrid4 and recorded work/capture. Continue all remaining work; allCF parents remain open. See verification.json and compressed member map; prior evidence migration/evidence/20261025-proxy-scheduler remains the basis, not duplicated.\n')
  tracking(proof,before);(E/'INCOMPLETE.json').unlink()
  artifacts={str(p.relative_to(E)):sha(p) for p in sorted(E.rglob('*')) if p.is_file()};put(E/'artifacts.json',artifacts)
  plan=load(W/'batch1-metadata-plan.json')
  for p in sorted(E.rglob('*')):
   if p.is_file():plan['exports'][str(p.relative_to(R))]={'source':str(p),'before_sha256':None,'sha256':sha(p)}
  put(W/'batch1-metadata-plan.json',plan)
 print(json.dumps({'status':proof['status'],'source_commit':proof['source_commit'],'effective_suites_per_lane':27,'actual_hybrid_cases':4,'write':args.write}))
if __name__=='__main__':main()
