Broader v2/hybrid handoff, source-only — native base9e7f43ec14476bb8091c803a2b37c490b46d4435

The existing qualified selected2 is an aligned single-file hybrid V1/V2 profile
pair. Creator6 proves actual parser/Merkle/creator fields, not manager recheck.
Earlier supplementary/BMP UTF16 multifile probes were layout-only. The shipped
identity/swarm/layout/ManagedStorage gates already express these admitted shapes;
this package adds missing actual profile/transfer qualification rather than
weakening those production gates or changing the approved provider.

Adopt ONE changed native source, tests/selected_hybrid_handoff_driver.cpp, using its
exact before/after hashes and changes.patch. Its old CLI remains unchanged. Small
generalizations admit actual pure-v2 plus bounded power-of-two16KiB..1MiB pieces,
and avoid absent-v1 lookups. Every existing raw-info/provider/swarm/geometry/claim,
actual owner transfer, strict retirement, retained seeding and payload assertion
stays. No new CMake target, production code, provider ABI/approval or dependency
change. A source reversal check restores the complete current driver byte-for-byte.

Four fresh generated cases (not executed or credited here): pure-v2 single tail32KiB;
UTF16 multifile hybrid explicitly selectedV1 and selectedV2 at32KiB; pure-v2 UTF16
multifile64KiB. Multifile inputs include a real empty FIRST slot and aligned nonempty
files, so they exercise the previously layout-only ordering/empty index path without
silently reclassifying the already-reproduced original last-empty8/9 limitation.
Both hybrid selections share EXACT info bytes/full identities. Original manager
APIs prepare partial payloads, set nondefault original priorities/limits and an
unknown map attribute, then stop. Existing maintained Java READY/output helpers
are copied byte-exact. All original subject classes come from the unchanged retained
cb8 Java17 cohort; helper javac never recompiles them. No Maven/Core rebuild.

Root after its cohesive configure/build (respect the shared three-job budget):

  cmake --build "$BUILD" --target biglybtc-selected-hybrid-handoff-driver --parallel 3
  python3 -B /home/yurii/Java/BiglyBT/build/compatibility-20261026/hybrid-interop/oracle/run.py --driver "$BUILD/tests/biglybtc-selected-hybrid-handoff-driver" --output /home/yurii/Java/BiglyBT/build/compatibility-20261026/hybrid-interop/runs/run-r1

The existing target is confined to the approved Qualified payload-counter/provider
lane. Runtime proof has no old/stock/version fallback. Reuse the current positive
selected-swarm-admission/original-identity-callers suites in the coherent matrix;
no additional argument-free CTest is registered. --case NAME can restrict a later
fresh diagnostic attempt after failure, preserving the first output; values are
listed by source argparse. No test/Java/driver execution was performed by the author.

The recipe self-checks capsule/helper pins, retained original classes, exact tuples
from handoff.decode and original reference fence. Each case performs native partial
and complete transfer followed by ACTUAL Java READY rechecks: exact full/selected
hashes and raw info/layers, original slot offsets/names/pads/empty entries, cumulative
actual deltas, per-file verified byte intersections, priorities/skip/storage policy,
global config and unknown metadata/attribute values. Complete mode additionally
requires retained native uploading to an independent selected owned receiver and
actual original logical payload reads. Every new bitmap/progress check is STRICT:
no8/9 allowlist or expected-output generator is added. No original running profile,
public peer/tracker/bootstrap, public discovery, or live original application access.

The subprocess runner retains commands/exit/timing/log hashes, gives45s heartbeats,
kills/joins only its own timed-out child group, and archives its exact generated
root/helpers/logs in finally on success or failure. The archive preserves original
absolute-path text for diagnosis; attempts regenerate fresh roots rather than reuse
moved archives as live profiles. Actual results/counts remain pending root runs.

CF02 stays OPEN: the existing original real-tail+pad+last-empty recheck limitation
remains explicit; no original algorithm patch is proposed. Automatic identity/state
migration, simultaneous alternate-key admissions/shared payload ownership, arbitrary
explicit32-key Java writing, magnet-switch identities and untested original profile
options are not granted by this handoff. Existing aliases/collisions remain denied
before effects by current production. Future blockers found by these strict actual
runs must be diagnosed at their source, not normalized into passing progress.
