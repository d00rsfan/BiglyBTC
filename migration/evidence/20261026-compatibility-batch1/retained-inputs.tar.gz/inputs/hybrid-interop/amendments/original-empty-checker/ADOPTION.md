Independent nonempty pure-V2 64 KiB positive; source-only amendment.

Preserve immutable failed original-empty-first run and original-empty-first checker run. Three cases now have actual strict partial+complete success across the retained attempts: tail-v2-32k, ordered-hybrid-v1-32k, ordered-hybrid-v2-nonempty-32k. Do not rerun them for this amendment.

The fourth original shape fails on exactly piece0: original baseline already reports0010 while the full first64KiB source piece was written; native verifies1011, then original reports0011. Metadata, indices, intent and the persisted cumulative counters match. Actual payload first64KiB remains byte-equal to the unchanged expected file. Pinned PieceMapperImpl adds the real empty first file as a zero-length first piece-map entry; DMCheckerImpl uses that entry as V2 file length and limits the two-entry hash buffer to zero. This is an actual original checking boundary; no native fix/normalization or waived expected bit is added.

The unchanged old ordered-v2-64k shape remains explicitly selectable and strict. New ordered-v2-nonempty-64k independently creates two nonempty files using actual cb8 creation, with the same Java UTF16 name order and64KiB pieces. All common exact selected/full identities, unknown/raw metadata, counters, bitmap, per-slot logical progress, source policy, retained seeding and geometry comparisons remain unchanged. Default positive set uses the separately named replacement; it grants no success credit to either known failing original empty-first selected-V2 shape. Frozen native d6e driver, fences, retained5432cohort, helper observation checks and timeouts unchanged.

Root-only affected command (no native rebuild):
```
python3 -B /home/yurii/Java/BiglyBT/build/compatibility-20261026/hybrid-interop/amendments/original-empty-checker/oracle/run.py --driver BUILD/tests/biglybtc-selected-hybrid-handoff-driver --output /home/yurii/Java/BiglyBT/build/compatibility-20261026/hybrid-interop/amendments/original-empty-checker/runs/run-r1 --case ordered-v2-nonempty-64k
```

No subjects/compiler/tests were executed by author. No CF02 closure.
