"""Exact maintained actual-output parser/checks; no expected hash implementation."""

def need(ok, why):
    if not ok:
        raise ValueError(why)


def rows(text):
    result = {'indices': {}, 'files': {}}
    for line in text.splitlines():
        r = line.split('\t')
        if r[0] == 'V2_META':
            need(len(r) == 9 and 'metadata' not in result, 'Bad actual metadata facts')
            result['metadata'] = dict(zip(('type', 'effective', 'selected', 'v1', 'v2', 'piece', 'pieces', 'logicalBytes'), r[1:]))
            for key in ('type', 'effective', 'piece', 'pieces', 'logicalBytes'):
                result['metadata'][key] = int(result['metadata'][key])
        elif r[0] == 'V2_INDEX':
            need(len(r) == 6 and int(r[1]) not in result['indices'], 'Bad actual source index')
            result['indices'][int(r[1])] = {'offset': int(r[2]), 'bytes': int(r[3]), 'pad': r[4] == 'true',
                'path': bytes.fromhex(r[5]).decode('utf-8')}
        elif r[0] == 'V2_READY':
            need(len(r) == 4 and 'ready' not in result, 'Bad actual READY facts')
            result['ready'] = {'done': int(r[1]), 'total': int(r[2]), 'bits': r[3]}
        elif r[0] == 'V2_PROGRESS':
            need(len(r) == 8 and 'progress' not in result, 'Bad actual original progress facts')
            result['progress'] = dict(zip(('completedLogical', 'totalLogical', 'remainingLogical',
                'completedPayload', 'completedPadding', 'totalPayload', 'totalPadding'), map(int, r[1:])))
        elif r[0] == 'V2_FILE':
            need(len(r) == 10 and int(r[1]) not in result['files'], 'Bad actual original file')
            result['files'][int(r[1])] = {'offset': int(r[2]), 'bytes': int(r[3]), 'pad': r[4] == 'true',
                'priority': int(r[5]), 'skipped': r[6] == 'true', 'kind': int(r[7]), 'downloaded': int(r[8]),
                'path': bytes.fromhex(r[9]).decode('utf-8')}
        elif r[0] == 'V2_INTENT':
            need(len(r) == 6 and 'intent' not in result, 'Bad actual intent'); result['intent'] = r[1:]
        elif r[0] == 'V2_COUNTERS':
            need(len(r) == 3 and 'counters' not in result, 'Bad actual original counters'); result['counters'] = tuple(map(int, r[1:]))
        elif r[0] == 'V2_ORIGINAL_STOPPED':
            need(len(r) == 1 and 'stopped' not in result, 'Bad original stop'); result['stopped'] = True
    need('metadata' in result and result['indices'], 'Missing actual source metadata')
    return result


def checked(value):
    need({'ready', 'files', 'intent', 'counters', 'progress', 'stopped'} <= value.keys(), 'Incomplete actual original READY observation')
    ready = value['ready']
    need(ready['total'] == value['metadata']['pieces'] and len(ready['bits']) == ready['total']
         and set(ready['bits']) <= {'0', '1'} and ready['bits'].count('1') == ready['done'], 'Bad original checked bitmap')
    need(set(value['files']) == set(value['indices']), 'Original file indices changed during actual reload')
    progress = value['progress']
    need(all(0 <= n <= (1 << 63) - 1 for n in progress.values()), 'Actual original progress is negative/overflowed')
    need(progress['completedLogical'] == progress['totalLogical'] - progress['remainingLogical']
         == progress['completedPayload'] + progress['completedPadding']
         and progress['totalLogical'] == progress['totalPayload'] + progress['totalPadding']
         == value['metadata']['logicalBytes'], 'Actual original logical/payload/padding observations disagree')
    need(progress['completedPayload'] == sum(f['downloaded'] for f in value['files'].values() if not f['pad'])
         and progress['completedPadding'] == sum(f['downloaded'] for f in value['files'].values() if f['pad'])
         and progress['totalPayload'] == sum(f['bytes'] for f in value['indices'].values() if not f['pad'])
         and progress['totalPadding'] == sum(f['bytes'] for f in value['indices'].values() if f['pad']),
         'Actual original per-file getters disagree with observed progress totals')
    return value

