import com.biglybt.core.Core;
import com.biglybt.core.disk.DiskManagerFileInfo;
import com.biglybt.core.disk.DiskManagerPiece;
import com.biglybt.core.download.DownloadManager;
import com.biglybt.core.download.DownloadManagerInitialisationAdapter;
import com.biglybt.core.torrent.TOTorrent;
import com.biglybt.core.torrent.TOTorrentFactory;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/** Explicit generated inputs and unchanged original creator/manager calls only. */
public final class HybridProfileOracle {
    private static void need(boolean value, String why) {
        if (!value) { throw new IllegalStateException(why); }
    }
    private static byte[] pattern(int count, int seed) {
        byte[] result = new byte[count];
        for (int i = 0; i < count; ++i) { result[i] = (byte)((i * 31 + i / 257 + seed) % 251); }
        return result;
    }
    private static void opaque(TOTorrent torrent) {
        Map<String, Object> future = new HashMap<String, Object>();
        future.put("bytes", new byte[]{0, -1, 4, 0});
        future.put("list", Arrays.asList(Long.valueOf(-7), "future-π".getBytes(StandardCharsets.UTF_8)));
        torrent.setAdditionalMapProperty("unknown.future.plugin", future);
        Map<String, Object> privateProperties = new HashMap<String, Object>();
        privateProperties.put("unknown.selected.fixture", Arrays.asList(Long.valueOf(11), new byte[]{0, -2, 9}));
        torrent.setAdditionalMapProperty("azureus_private_properties", privateProperties);
        torrent.setCreationDate(0);
    }
    private static TOTorrent create(Path payload, int type, int piece) throws Exception {
        TOTorrent torrent = TOTorrentFactory.createFromFileOrDirWithFixedPieceLength(type, payload.toFile(),
            new URL("http://127.0.0.1:1/announce"), false, piece).create();
        opaque(torrent); return torrent;
    }
    private static void generate(Path output) throws Exception {
        need(!Files.exists(output), "Fresh generated directory"); Files.createDirectories(output);
        Path tail = output.resolve("tail/payload-tail.bin"); Files.createDirectories(tail.getParent());
        Files.write(tail, pattern(5 * 32768 + 123, 3));
        create(tail, TOTorrent.TT_V2, 32768).serialiseToBEncodedFile(output.resolve("tail.torrent").toFile());
        for (boolean hybrid : new boolean[]{true, false}) {
            String label = hybrid ? "hybrid" : "v2";
            Path payload = output.resolve(label + "/ordered-π"); Files.createDirectories(payload);
            // A real empty FIRST file is retained. Supplementary/BMP names
            // intentionally exercise actual original UTF16 file-tree ordering.
            Files.write(payload.resolve("00-empty.bin"), new byte[0]);
            Files.write(payload.resolve("\uD800\uDC00-first.bin"), pattern(hybrid ? 65536 : 131072, 7));
            Files.write(payload.resolve("\uE000-second.bin"), pattern(hybrid ? 98304 : 131072, 13));
            TOTorrent source = create(payload, hybrid ? TOTorrent.TT_V1_V2 : TOTorrent.TT_V2, hybrid ? 32768 : 65536);
            if (hybrid) {
                source.selectHybridHashType(TOTorrent.TT_V1).serialiseToBEncodedFile(output.resolve("hybrid-v1.torrent").toFile());
                source.selectHybridHashType(TOTorrent.TT_V2).serialiseToBEncodedFile(output.resolve("hybrid-v2.torrent").toFile());
            } else { source.serialiseToBEncodedFile(output.resolve("v2-multi.torrent").toFile()); }
        }
        // Separate positive shape: cb8 hybrid hash fixup dereferences a null
        // zero-length-file tree before assigning later roots. The original
        // empty-first fixture above is kept unchanged and remains selectable.
        Path nonempty = output.resolve("hybrid-nonempty/ordered-π"); Files.createDirectories(nonempty);
        Files.write(nonempty.resolve("\uD800\uDC00-first.bin"), pattern(65536, 7));
        Files.write(nonempty.resolve("\uE000-second.bin"), pattern(98304, 13));
        TOTorrent nonemptyHybrid = create(nonempty, TOTorrent.TT_V1_V2, 32768);
        nonemptyHybrid.selectHybridHashType(TOTorrent.TT_V1).serialiseToBEncodedFile(output.resolve("hybrid-nonempty-v1.torrent").toFile());
        nonemptyHybrid.selectHybridHashType(TOTorrent.TT_V2).serialiseToBEncodedFile(output.resolve("hybrid-nonempty-v2.torrent").toFile());
        System.out.println("ACTUAL_ORIGINAL_EXTENDED_FIXTURES_CREATED");
    }
    private static void prepare(Path root, int port, Path expected) throws Exception {
        need(expected.toRealPath().startsWith(root.getParent()) && !Files.isSymbolicLink(expected), "Only owned expected bytes");
        Files.createDirectories(root.resolve("payload"));
        Core core = EngineOracle.configuredCore(port); boolean started = false;
        try {
            core.start(); started = true;
            DownloadManager manager = core.getGlobalManager().addDownloadManager(root.resolve("input.torrent").toString(), null,
                root.resolve("payload").toString(), DownloadManager.STATE_STOPPED, true, false,
                new DownloadManagerInitialisationAdapter() {
                    public int getActions() { return ACT_NONE; }
                    public void initialised(DownloadManager download, boolean seeding) {
                        download.getDownloadState().setNetworks(new String[]{"Public"});
                        download.getDownloadState().setPeerSources(new String[]{"Plugin", "Incoming"});
                    }
                });
            need(manager != null, "Actual original accepted metadata");
            Map<String, Object> futureState = new HashMap<String, Object>();
            futureState.put("raw", new byte[]{0, -1, 5});
            futureState.put("count", Long.valueOf(123));
            manager.getDownloadState().setMapAttribute("unknown.hybrid.interop", futureState);
            long piece = manager.getTorrent().getPieceLength();
            need(piece >= 16384 && piece <= 1024 * 1024, "Bounded actual fixture piece size");
            for (DiskManagerFileInfo file : manager.getDiskManagerFileInfoSet().getFiles()) {
                if (file.getTorrentFile().isPadFile()) { continue; }
                need(file.setStorageType(DiskManagerFileInfo.ST_LINEAR), "Actual linear file policy");
                file.setSkipped(false); file.setPriority(file.getIndex() % 2 == 0 ? -1 : 3);
                Path wanted = manager.getTorrent().isSimpleTorrent() ? expected : expected.resolve(file.getTorrentFile().getRelativePath());
                byte[] bytes = Files.readAllBytes(wanted); need(bytes.length == file.getLength(), "Actual source file length");
                Path actual = file.getFile(true).toPath().toAbsolutePath().normalize();
                need(actual.startsWith(root.resolve("payload")) && !Files.isSymbolicLink(actual), "Generated payload destination");
                Files.createDirectories(actual.getParent());
                int first = (int)Math.min(bytes.length, piece - file.getTorrentFile().getOffsetInTorrent() % piece);
                Files.write(actual, Arrays.copyOf(bytes, first));
            }
            manager.getStats().setDownloadRateLimitBytesPerSecond(131072);
            manager.getStats().setUploadRateLimitBytesPerSecond(65536);
            manager.initialize(); long deadline = System.nanoTime() + 90000000000L;
            while (manager.getState() != DownloadManager.STATE_READY) {
                need(manager.getState() != DownloadManager.STATE_ERROR && System.nanoTime() < deadline,
                    "Actual original initial READY: " + manager.getErrorDetails()); Thread.sleep(25);
            }
            int done = 0; DiskManagerPiece[] pieces = manager.getDiskManager().getPieces();
            for (DiskManagerPiece value : pieces) { if (value.isDone()) { ++done; } }
            need(done > 0 && done < pieces.length, "Actual initial profile has verified partial progress");
            manager.stopIt(DownloadManager.STATE_STOPPED, false, false);
        } finally { if (started) { core.stop(); } }
        System.out.println("ACTUAL_ORIGINAL_PARTIAL_PROFILE_STOPPED");
    }
    private static void run(String[] args) throws Exception {
        need(System.getSecurityManager() instanceof ReferenceFence, "Unchanged ReferenceFence required");
        Class.forName("com.biglybt.core.util.Debug");
        Path root = Paths.get(System.getProperty("biglybtc.test.root")).toRealPath();
        need(root.getParent() != null && root.getParent().getParent().equals(Paths.get("/tmp"))
            && root.getParent().getFileName().toString().startsWith("biglybtc-managed-handoff-hybrid-"), "Generated private case/generation only");
        if (args.length == 2 && args[0].equals("generate")) {
            Path output = Paths.get(args[1]).toAbsolutePath().normalize(); need(output.startsWith(root), "Owned generation"); generate(output);
        } else if (args.length == 3 && args[0].equals("prepare")) {
            prepare(root, Integer.parseInt(args[1]), Paths.get(args[2]).toRealPath());
        } else { throw new IllegalArgumentException("generate OUTPUT | prepare LISTEN EXPECTED"); }
    }
    public static void main(String[] args) {
        try { run(args); System.exit(0); }
        catch (Throwable error) { error.printStackTrace(); System.exit(2); }
    }
}
