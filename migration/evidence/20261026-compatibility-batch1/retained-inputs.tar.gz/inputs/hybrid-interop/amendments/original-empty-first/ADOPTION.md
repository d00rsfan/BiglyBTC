Source-only original-empty-first characterization and independent positive shape.

Actual run-r1 completed tail-v2-32k and ordered-hybrid-v1-32k. Retain those exact results; do not rerun them. The empty-first selected-V2 hybrid fails inside unchanged cb8 before any native command: lazy V2 root fixup dereferences the absent zero-length-file hash tree and aborts before later roots are installed; getSecret2 returns null, and actual GM load rejects the row. The failed strict one-download assertion remains unchanged and the old case remains explicitly runnable. No original/native normalization or waived comparison is added. This is an original-profile compatibility boundary, also relevant to future companion creation; no source-selected-V2 hybrid with a real empty file will be offered by that writer.

The separate ordered-hybrid-v2-nonempty-32k positive uses actual original creation, the same supplementary/BMP UTF16 ordering, 32 KiB pieces, and two strictly positive-length files. All shared partial/complete, unknown/raw-info preservation, counters, piece bitmap, seeding, geometry and selected-swarm assertions are unchanged. The original three prior shapes retain their exact generation code; pure-v2 empty-first remains a strict unexecuted case. All fence/cohort/helper/timeout and cleanup/archive logic is unchanged. Default choices replace only the known original-failing positive with the separately named new shape; the known failed shape remains selectable and receives no success waiver.

Root-only affected execution (existing driver unchanged, no native rebuild):

```
python3 -B /home/yurii/Java/BiglyBT/build/compatibility-20261026/hybrid-interop/amendments/original-empty-first/oracle/run.py --driver BUILD/tests/biglybtc-selected-hybrid-handoff-driver --output /home/yurii/Java/BiglyBT/build/compatibility-20261026/hybrid-interop/amendments/original-empty-first/runs/run-r1 --case ordered-hybrid-v2-nonempty-32k --case ordered-v2-64k
```

No compiler/JVM/subjects/tests were executed while authoring this amendment. Original frozen capsule, failed attempt and two successful receipts remain untouched. This does not close CF02.
