#!/usr/bin/env python3
"""Root-run broader original/native/original v2 and selected hybrid handoffs."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
JAVA = Path('/usr/lib/jvm/java-17-openjdk-amd64/bin')
ROOT = Path('/home/yurii/Java/BiglyBT')


def need(value, why):
    if not value:
        raise ValueError(why)


def sha(path):
    need(path.is_file() and not path.is_symlink(), 'Regular reviewed input: ' + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files(root):
    result = {}
    for path in sorted(root.rglob('*')):
        need(not path.is_symlink(), 'No generated/cohort symlink: ' + str(path))
        if path.is_file():
            info = path.stat()
            need(stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid() and info.st_nlink == 1,
                 'Owned generated/cohort regular leaf')
            result[path.relative_to(root).as_posix()] = sha(path)
    return result


def main():
    choices = ('tail-v2-32k', 'ordered-hybrid-v1-32k', 'ordered-hybrid-v2-32k', 'ordered-v2-64k')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--driver', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--case', action='append', choices=choices)
    args = parser.parse_args()
    manifest = json.loads((HERE.parent / 'manifest.json').read_bytes())
    for name, digest in manifest['artifacts'].items():
        need(sha(HERE.parent / name) == digest, 'Changed immutable capsule: ' + name)
    inputs = json.loads((HERE / 'inputs.json').read_bytes())
    for name, digest in inputs['files'].items():
        need(sha(Path(name)) == digest, 'Changed original/helper input: ' + name)
    retained = json.loads(Path(inputs['retention']).read_bytes())
    classes = Path(inputs['classes'])
    need(retained['source_commit'] == inputs['original_commit'] and retained['recompiled'] is False
         and files(classes) == retained['file_sha256'], 'Exact retained original Java17 cohort required')
    driver = args.driver.resolve(strict=True)
    need(not args.driver.is_symlink() and os.access(driver, os.X_OK), 'Actual approved batched driver required')
    destination = args.output.absolute()
    need(destination.is_relative_to(HERE.parent / 'runs') and not destination.exists()
         and destination.resolve() == destination, 'Fresh owned durable attempt under capsule/runs required')
    destination.mkdir(mode=0o700, parents=True)
    work = Path(tempfile.mkdtemp(prefix='biglybtc-managed-handoff-hybrid-', dir='/tmp'))
    for name in ('classes', 'empty-sourcepath', 'generation'):
        (work / name).mkdir(mode=0o700)
    env = {key: value for key, value in os.environ.items() if key not in
           ('CLASSPATH', 'JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'LD_PRELOAD', 'LD_AUDIT')}
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    commands, cases = [], {}
    result = {'status': 'RUNNING', 'manifest_sha256': sha(HERE.parent / 'manifest.json'),
              'original_commit': inputs['original_commit'], 'native_driver_sha256': sha(driver),
              'original_core_recompiled': False, 'original_profile_or_process_access': False}

    def run(name, argv, cwd, timeout=180):
        row = {'name': name, 'argv': list(map(str, argv)), 'cwd': str(cwd), 'timeout': timeout}
        commands.append(row)
        (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        with (work / (name + '.stdout')).open('xb') as out, (work / (name + '.stderr')).open('xb') as err:
            started = time.monotonic()
            child = subprocess.Popen(row['argv'], cwd=cwd, env=env, stdout=out, stderr=err, start_new_session=True)
            try:
                while child.poll() is None:
                    remaining = timeout - (time.monotonic() - started)
                    need(remaining > 0, 'Deadline: ' + name)
                    try:
                        child.wait(timeout=min(45, remaining))
                    except subprocess.TimeoutExpired:
                        print('Hybrid handoff active: ' + name, flush=True)
            finally:
                if child.poll() is None:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait()
                row.update(exit_code=child.returncode, seconds=time.monotonic() - started)
                out.flush(); err.flush()
                row.update(stdout_sha256=sha(work / (name + '.stdout')), stderr_sha256=sha(work / (name + '.stderr')))
                (work / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        need(child.returncode == 0, 'Actual command failed; raw logs retained: ' + name)
        return (work / (name + '.stdout')).read_text()

    try:
        sources = [ROOT / 'migration/fixtures/java/ReferenceFence.java', ROOT / 'migration/fixtures/java/EngineOracle.java',
                   HERE / 'V2MetadataOracle.java', HERE / 'V2ManagedOracle.java', HERE / 'HybridProfileOracle.java']
        run('javac-thin-helpers', [JAVA / 'javac', '-J-XX:ActiveProcessorCount=1', '--release', '8', '-encoding', 'UTF-8',
            '-proc:none', '-implicit:none', '-sourcepath', work / 'empty-sourcepath', '-cp', classes,
            '-d', work / 'classes', *sources], work, 90)
        helpers = files(work / 'classes')
        need(set(helpers) == {'ReferenceFence.class', 'EngineOracle.class', 'EngineOracle$1.class', 'V2MetadataOracle.class',
            'V2ManagedOracle.class', 'V2ManagedOracle$1.class', 'V2ManagedOracle$2.class', 'HybridProfileOracle.class',
            'HybridProfileOracle$1.class'}, 'Only the exact thin helper outputs are permitted')
        sys.path.insert(0, str(HERE))
        from observations import rows, checked
        sys.path.insert(0, str(ROOT / 'migration/tools'))
        from peer_interop import jvm, unused_port
        from handoff import decode
        cp = str(work / 'classes') + os.pathsep + str(classes)

        def java(name, case, helper, *arguments, ports=()):
            return run(name, [*jvm(case, cp, ports), helper, *arguments], case)

        def state(path):
            raw = path.read_bytes()
            need(len(raw) <= 4 * 1024 * 1024, 'Bounded actual metadata/state')
            if raw.startswith(b'\x1f\x8b'):
                raw = gzip.decompress(raw)
            need(len(raw) <= 4 * 1024 * 1024, 'Bounded decoded actual state')
            return decode(raw)  # Exactly (document, raw spans), never a mapping alone.

        generation = work / 'generation'
        java('generate', generation, 'HybridProfileOracle', 'generate', generation / 'fixtures')
        fixture = generation / 'fixtures'
        specs = {
            'tail-v2-32k': ('tail.torrent', fixture / 'tail/payload-tail.bin', 'v2', 32768),
            'ordered-hybrid-v1-32k': ('hybrid-v1.torrent', fixture / 'hybrid/ordered-π', 'v1', 32768),
            'ordered-hybrid-v2-32k': ('hybrid-v2.torrent', fixture / 'hybrid/ordered-π', 'v2', 32768),
            'ordered-v2-64k': ('v2-multi.torrent', fixture / 'v2/ordered-π', 'v2', 65536)}
        first, left = state(fixture / 'hybrid-v1.torrent')
        second, right = state(fixture / 'hybrid-v2.torrent')
        need(left[(b'info',)] == right[(b'info',)] and first != second,
             'Actual alternate original selections must retain identical raw info')
        generation_before = files(fixture)
        selected_cases = args.case if args.case else list(choices)
        need(len(set(selected_cases)) == len(selected_cases), 'No duplicate runtime cases')
        for name in selected_cases:
            metadata_name, expected, version, piece = specs[name]
            case = work / name
            case.mkdir(mode=0o700)
            shutil.copyfile(fixture / metadata_name, case / 'input.torrent')
            payload_before = files(expected) if expected.is_dir() else {expected.name: sha(expected)}
            metadata_before = sha(case / 'input.torrent')
            port = unused_port()
            java(name + '-prepare', case, 'HybridProfileOracle', 'prepare', port, expected, ports=(port,))
            port = unused_port()
            initial = checked(rows(java(name + '-baseline', case, 'V2ManagedOracle', port, expected, 'inspect', -1, ports=(port,))))
            facts, indices = initial['metadata'], initial['indices']
            total = initial['ready']['total']
            need(facts['piece'] == piece and facts['v2'] != '-' and 0 < initial['ready']['done'] < total,
                 'Actual original variable-piece profile must be partially checked')
            need(facts['selected'] == (facts['v1'] if version == 'v1' else facts['v2'][:40]), 'Actual original selected key differs')
            if name.startswith('ordered'):
                names = [item['path'] for item in indices.values() if not item['pad']]
                need(any(item['bytes'] == 0 and not item['pad'] for item in indices.values())
                     and names.index('𐀀-first.bin') < names.index('\ue000-second.bin'), 'Actual Java UTF16 order/empty slot absent')
            candidates = [i for i, bit in enumerate(initial['ready']['bits']) if bit == '0' and i < total - 1
                and any(not f['pad'] and f['offset'] < (i + 1) * piece and f['offset'] + f['bytes'] > i * piece for f in indices.values())]
            need(candidates, 'Actual missing real non-tail piece required')
            omitted = candidates[-1]
            profile = case / 'profile'
            active = profile / 'active' / (facts['selected'] + '.dat')
            _, original_spans = state(active)
            preserve = ((b'info',), (b'unknown.future.plugin',), (b'azureus_private_properties', b'unknown.selected.fixture'),
                        (b'attributes', b'unknown.hybrid.interop'))
            need(all(key in original_spans for key in preserve), 'Actual original preserved opaque fixture sections')
            preserve += tuple(key for key in ((b'piece layers',),) if key in original_spans)
            observations = []
            for mode in ('partial', 'complete'):
                config_before = (profile / 'biglybt.config').read_bytes()
                before, _ = state(profile / 'downloads.config')
                previous = before[b'downloads'][0]
                output = case / ('native-' + mode)
                run(name + '-native-' + mode, [driver, work, profile, case / 'input.torrent', expected, output, mode, omitted], case)
                native = json.loads((output / 'result.json').read_bytes())
                need(native['hash'] == facts['selected'] and native['selected_version'] == version and native['swarm_marker'] == 1
                     and native['full_v1'] == facts['v1'] and native['full_v2'] == facts['v2']
                     and native['seed_swarm_v1'] is (version == 'v1') and native['seed_swarm_v2'] is (version == 'v2')
                     and native['session_joined'] and native['storage_released'] and int(native['received']) > 0
                     and native['pieces'] == total - (mode == 'partial') and native['total_pieces'] == total,
                     'Actual selected native transfer/verification/retirement identity differs')
                if mode == 'complete':
                    need(int(native['retained_seed_received']) > 0 and native['receiver_swarm_v1'] is (version == 'v1')
                         and native['receiver_swarm_v2'] is (version == 'v2'), 'Actual independently selected retained seeding absent')
                else:
                    need(native['receiver_swarm_v1'] is None and native['receiver_swarm_v2'] is None, 'No fabricated partial receiver')
                need(len(native['original_files']) == len(indices), 'Original slot count changed')
                engine = native['engine_files']
                need(len(engine) == len(indices) + int(native['engine_trailing_pad']), 'Unexpected engine slot difference')
                for i, source in indices.items():
                    a, b = native['original_files'][i], engine[i]
                    need(a['index'] == b['index'] == i and int(a['offset']) == int(b['offset']) == source['offset']
                         and int(a['bytes']) == int(b['bytes']) == source['bytes'] and a['pad'] == b['pad'] == source['pad']
                         and a['path'] == source['path'], 'Actual original/provider indexed ranges differ')
                if native['engine_trailing_pad']:
                    tail = engine[-1]
                    need(facts['v1'] == '-' and facts['logicalBytes'] % piece != 0 and tail['pad'] is True
                         and int(tail['offset']) == facts['logicalBytes'] and int(tail['bytes']) == piece - facts['logicalBytes'] % piece,
                         'Only exact actual pure-v2 synthetic tail is admitted')
                need(native['engine_trailing_pad'] is (name == 'tail-v2-32k'), 'Intended tail/fully aligned fixture changed')
                current_doc, _ = state(profile / 'downloads.config')
                current = current_doc[b'downloads'][0]
                need(current[b'downloaded'] == previous.get(b'downloaded', 0) + int(native['received'])
                     and current[b'uploaded'] == previous.get(b'uploaded', 0) + int(native['sent']), 'Actual cumulative deltas not preserved')
                saved, spans = state(active)
                need(all(spans.get(key) == original_spans[key] for key in preserve), 'Native rewrote raw info/layers or opaque values')
                counts = saved[b'attributes'][b'filedownloaded'][b'downloaded']
                need(len(counts) == len(indices) and all(type(n) is int and 0 <= n <= indices[i]['bytes'] for i, n in enumerate(counts)), 'Per-original-slot progress out of bounds')
                need(sum(counts) == current[b'completedbytes'] == int(native['completed'])
                     and int(native['bytes']) == facts['logicalBytes'], 'Actual logical verified progress differs')
                need((profile / 'biglybt.config').read_bytes() == config_before, 'Native changed original global config')
                port = unused_port()
                actual = checked(rows(java(name + '-java-' + mode, case, 'V2ManagedOracle', port, expected,
                    'bytes' if mode == 'complete' else 'inspect', -1, ports=(port,))))
                bitmap = ''.join('0' if mode == 'partial' and i == omitted else '1' for i in range(total))
                need(actual['metadata'] == facts and actual['indices'] == indices and actual['intent'] == initial['intent']
                     and actual['counters'] == (current[b'downloaded'], current[b'uploaded']) and actual['ready']['bits'] == bitmap,
                     'Strict actual Java identity/intent/counters/rechecked pieces mismatch')
                need(actual['progress']['completedLogical'] == sum(counts)
                     and actual['progress']['completedPayload'] == sum(counts[i] for i, f in indices.items() if not f['pad']),
                     'Strict actual Java logical/payload progress differs')
                for i, actual_file in actual['files'].items():
                    need(actual_file['downloaded'] == counts[i], 'Actual original indexed downloaded amount differs')
                    if not actual_file['pad']:
                        need(all(actual_file[key] == initial['files'][i][key] for key in ('priority', 'skipped', 'kind')),
                             'Actual original selected policy changed')
                need(sha(case / 'input.torrent') == metadata_before
                     and (files(expected) if expected.is_dir() else {expected.name: sha(expected)}) == payload_before,
                     'Metadata or expected payload input changed')
                observations.append({'mode': mode, 'native': native, 'actual_original': actual})
            cases[name] = {'baseline': initial, 'omitted_real_piece': omitted, 'observations': observations}
            result['cases'] = cases
            (work / 'progress.json').write_text(json.dumps(result, indent=2) + '\n')
            print('PASS actual broader handoff: ' + name, flush=True)
        need(files(fixture) == generation_before and files(work / 'classes') == helpers, 'Generation/helper changed')
        result.update(status='PASS_ACTUAL_BROADER_V2_HYBRID_HANDOFF', cases=cases, actual_cases=len(cases),
                      helper_class_sha256=helpers, scope=manifest['scope'])
    except BaseException as error:
        result.update(status='FAIL', error=repr(error), cases=cases)
        raise
    finally:
        result['commands'] = commands
        result['logs_sha256'] = {p.name: sha(p) for p in sorted(work.glob('*.std*'))}
        try:
            need(files(classes) == retained['file_sha256'], 'Original cohort changed')
        except BaseException as error:
            result.update(status='FAIL_COHORT', cohort_error=repr(error))
            raise
        finally:
            (work / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
            # Only this exact generated root is collected; no scans of /tmp.
            files(work)
            shutil.copytree(work, destination / 'generated')
            (destination / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
            shutil.rmtree(work)
            print('Retained hybrid attempt: ' + str(destination), flush=True)


if __name__ == '__main__':
    main()
