from pathlib import Path
import hashlib,json,shutil,subprocess
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');c=w/'batch1-composed';m=json.loads((c/'manifest.json').read_text());h=lambda v:hashlib.sha256(v).hexdigest();g=lambda *a:subprocess.check_output(['git',*a],cwd=n)
assert h((c/'manifest.json').read_bytes())=='21fd9d19a972f1fff1a9b1808ff87d6fdb74258cb16b585b606815e14ecd6bdd';assert g('rev-parse','HEAD').decode().strip()==m['base'];assert g('branch','--show-current').decode().strip()=='main';assert not g('status','--porcelain').strip()
for p,d in m['before_sha256'].items():assert h((n/p).read_bytes())==d and h((c/'staging'/p).read_bytes())==m['source_sha256'][p],p
for p in m['source_sha256']:shutil.copy2(c/'staging'/p,n/p)
subprocess.run(['git','diff','--check'],cwd=n,check=True)
messages={'fileops':'Reuse pinned file digests across unchanged operation stages','network':'Guard proxy webseed and IPv6 routes before admission','hybrid':'Extend actual hybrid handoffs to v2 and multifile profiles','scheduler':'Review and settle interrupted Scheduler actions explicitly'};records=[]
for group,paths in m['groups'].items():
 parent=g('rev-parse','HEAD').decode().strip();subprocess.run(['git','add','--',*paths],cwd=n,check=True);assert set(g('diff','--cached','--name-only').decode().splitlines())==set(paths)
 for p in paths:assert h(g('show',':'+p))==m['source_sha256'][p],p
 subprocess.run(['git','-c','user.name=Codex','-c','user.email=codex@localhost','-c','commit.gpgsign=false','commit','-m',messages[group]],cwd=n,check=True)
 s=g('rev-parse','HEAD').decode().strip();r={'source_commit':s,'parent':parent,'phase':group,'paths_sha256':{p:m['source_sha256'][p] for p in paths},'all_staged_blob_bytes_verified':True,'status':'SOURCE_CANDIDATE_AWAITING_BATCH_QUALIFICATION'};(w/('batch1-'+group+'-commit.json')).write_text(json.dumps(r,indent=2)+'\n');records.append(r)
assert not g('status','--porcelain').strip();r={'source_commit':records[-1]['source_commit'],'base':m['base'],'paths':len(m['source_sha256']),'components':{r['phase']:r['source_commit'] for r in records},'source_sha256':m['source_sha256'],'all_staged_blob_bytes_verified':True};(w/'batch1-adoption.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='source_sha256'}))
