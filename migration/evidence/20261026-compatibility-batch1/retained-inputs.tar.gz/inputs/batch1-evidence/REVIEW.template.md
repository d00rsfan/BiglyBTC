# Compatibility batch1 — pending actual qualification

Four source components: fileops db256d08e280140f64bd4e4d25ec5a26b0b9380d; network6d2a20a6ceb59601afe86104fdbcb0c85e0130e5; hybrid driver a5613ed5fba8be76bec7a22d1b15c4edc09f0d01; Scheduler699835f1fe9a5ba0b699dd7e06db2dc6aac9f9ed. Final source and 27 effective suites per lane, actual original hybrid4, controlled webseed/work-byte facts and recovery capture stay pending until actual finalizer gates pass. Initial capture setup failure is retained; focused same-source PASS can replace only that suite.

All remaining work stays active. AllCF parents remain open; no full-client/release/performance, unprovided ETA/tag/lightweight providers, causal/public-wire or future webseed provider approval is claimed. Original BiglyBT cb8c6cb9bb97916cbc7e80338a017200ffc3e71f and SpeedScheduler1ee6a53dae017696d2f0002e4a0d74f5a9476af5 baselines remain unchanged. Prior proxy/Scheduler evidence is referenced, not copied.
