# Owned proxy routes and source-proven refusal

Base9e7. Final capsule manifest-r3. Three paths, no CMake changes. Existing proxy
owner suite adds actual authenticated SOCKS5 remote .invalid tracker and webseed
payload routes; origin accepts only owned proxy source127.0.0.3 and verifies ranges.
No local DNS-probe, public endpoint, original profile or external service is used.

Pinned private provider b0e source torrent.cpp6468..6511 only omits local webseed
resolution for SOCKS5, unlike patched http_connection.cpp which also handles4a.
Refuse all4a URL/HTTP webseeds before admission: a numeric URL can redirect to an
unresolved hostname too. Disabled webseeds are removed normally; ordinary4a peer
routes stay supported. A future exact-source provider extension must qualify both
lookup and redirect paths before this refusal can be relaxed. Old provider records
remain immutable. No bare marker/caller Boolean will suffice.

URL IPv6 literals also now require original IPv6 permission; failures leave params
unchanged. Pure and qualified-owner regression assertions cover both changes.
The endpoint fixtures establish route/frame/payload outcomes, not absence of every
DNS packet. No executed test, fullCF03 or provider shipping claim in this capsule.
