from pathlib import Path
import hashlib,json,shutil,difflib
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');paths=['preview/native/engine/network_policy.cpp','preview/native/tests/network_proxy_owner_tests.cpp','preview/native/tests/network_policy_tests.cpp'];before={p:(n/p).read_text() for p in paths};after=dict(before)
p=paths[0];s=after[p];s=s.replace('UrlKind urlKind(std::string_view url, std::string_view field) {','UrlKind urlKind(std::string_view url, std::string_view field, bool ipv6 = true, bool numericOnly = false) {');needle='    require(host.find(\':\') != std::string_view::npos, Code::InvalidConfiguration, field);';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    require(ipv6, Code::Unsupported, "URL / IPv6 disabled");');needle='  require(kind != UrlKind::Udp || !port.empty(), Code::InvalidConfiguration, field);';assert s.count(needle)==1;s=s.replace(needle,'  if (numericOnly) { (void)numericAddress(host, "SOCKS4a webseed hostname"); }\n'+needle);s=s.replace('urlKind(next.trackers[i], "tracker URL")','urlKind(next.trackers[i], "tracker URL", p.ipv6)');s=s.replace('require(urlKind(seed, "webseed URL") != UrlKind::Udp, Code::Unsupported, "webseed URL");','''// This pinned provider's HTTP connection supports remote SOCKS4a names,
        // but torrent::resolve_web_seed only bypasses local DNS for SOCKS5.
        // Keep numeric webseeds; reject hostnames before session admission.
        const bool numericOnly = p.proxy.peers && p.proxy.kind == NetworkProxyKind::Socks4a;
        require(urlKind(seed, "webseed URL", p.ipv6, numericOnly) != UrlKind::Udp,
            Code::Unsupported, "webseed URL");''');after[p]=s
p=paths[1];s=after[p];s=s.replace('void trackerSource(test::OwnedEngineFixture& fixture, quint16 port, bool domain) {','void trackerSource(test::OwnedEngineFixture& fixture, quint16 port, bool domain, const QByteArray& name = "localhost") {');s=s.replace('(domain ? "localhost" : "127.0.0.1")','(domain ? name : QByteArray("127.0.0.1"))');needle='class Socks final : public QObject {';assert needle in s
origin=r'''constexpr auto RemoteSeedName = "seed.biglybtc.invalid";
class WebSeed final : public QObject {
public:
  QTcpServer server{this};
  QByteArray payload, failure;
  unsigned requests = 0;
  quint64 sent = 0;
  explicit WebSeed(QByteArray value) : payload(std::move(value)) {
    test::require(server.listen(QHostAddress::LocalHost, 0), "owned webseed listen");
    connect(&server, &QTcpServer::newConnection, this, [this] {
      while (server.hasPendingConnections()) {
        auto* socket = server.nextPendingConnection();
        if (socket->peerAddress() != QHostAddress("127.0.0.3")) {
          failure = "webseed direct fallback"; socket->abort(); continue;
        }
        auto buffer = std::make_shared<QByteArray>();
        connect(socket, &QTcpSocket::disconnected, socket, &QObject::deleteLater);
        connect(socket, &QTcpSocket::readyRead, socket, [this, socket, buffer] {
          *buffer += socket->readAll();
          if (buffer->size() > 16384) { failure = "webseed header bound"; socket->abort(); return; }
          if (!buffer->contains("\r\n\r\n")) return;
          if (++requests > 32 || !buffer->startsWith("GET /sample.bin HTTP/1.1\r\n")
              || !buffer->contains(QByteArray("Host: ") + RemoteSeedName + ':')) {
            failure = "unplanned webseed request"; socket->abort(); return;
          }
          qint64 first = 0, last = payload.size() - 1; bool ranged = false;
          for (const auto& line : buffer->split('\n')) {
            if (!line.toLower().startsWith("range: bytes=")) continue;
            const auto range = line.mid(13).trimmed(); const auto dash = range.indexOf('-');
            bool firstOk = false, lastOk = true;
            first = range.first(dash).toLongLong(&firstOk);
            if (dash >= 0 && dash + 1 < range.size()) { last = range.mid(dash + 1).toLongLong(&lastOk); }
            if (dash <= 0 || !firstOk || !lastOk || first < 0 || last < first || last >= payload.size()) {
              failure = "unplanned webseed range"; socket->abort(); return;
            }
            ranged = true;
          }
          const auto body = payload.mid(first, last - first + 1); sent += body.size();
          QByteArray header = ranged ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n";
          if (ranged) { header += "Content-Range: bytes " + QByteArray::number(first) + '-' + QByteArray::number(last)
              + '/' + QByteArray::number(payload.size()) + "\r\n"; }
          header += "Content-Length: " + QByteArray::number(body.size()) + "\r\nAccept-Ranges: bytes\r\nConnection: close\r\n\r\n";
          socket->write(header + body); socket->disconnectFromHost(); buffer->clear();
        });
      }
    });
  }
  void stopOwned() noexcept { abortOwnedSockets(server); }
};
'''
s=s.replace(needle,origin+needle);s=s.replace('  const quint16 seedPort, trackerPort;','  const quint16 seedPort, trackerPort;\n  quint16 webSeedPort = 0;\n  QByteArray trackerName = "localhost";');s=s.replace('domain && host == "localhost" && port == trackerPort','domain && host == trackerName && port == trackerPort');needle='    if (!tracker && !peer) { bad(channel, "unplanned proxy destination"); return; }';assert s.count(needle)==1;s=s.replace(needle,'    const bool webseed = v5 && domain && host == RemoteSeedName && webSeedPort && port == webSeedPort;\n    if (!tracker && !peer && !webseed) { bad(channel, "unplanned proxy destination"); return; }');s=s.replace('QHostAddress(tracker ? "127.0.0.1" : "127.0.0.2")','QHostAddress((tracker || webseed) ? "127.0.0.1" : "127.0.0.2")');s=s.replace('  engine::PersistentSession& owner;\n  bool closed','  engine::PersistentSession& owner;\n  WebSeed* webseed = nullptr;\n  bool closed');s=s.replace('    proxy.stopOwned(); tracker.stopOwned();','    proxy.stopOwned(); tracker.stopOwned(); if (webseed) webseed->stopOwned();')
# Replace the old localhost tracker row with an actual unresolvable remote name.
s=s.replace('Tracker tracker(seed->listen_port(), v5); Socks proxy(v5, seed->listen_port(), tracker.server.serverPort());\n    trackerSource(fixture, tracker.server.serverPort(), v5);','Tracker tracker(seed->listen_port(), v5); Socks proxy(v5, seed->listen_port(), tracker.server.serverPort());\n    if (v5) { proxy.trackerName = "tracker.biglybtc.invalid"; }\n    trackerSource(fixture, tracker.server.serverPort(), v5, proxy.trackerName);');s=s.replace('route.host == "localhost" && route.domain','route.host == "tracker.biglybtc.invalid" && route.domain')
needle='#if defined(__linux__) && __has_include(<libtorrent/biglybtc_socks4a.hpp>)';assert s.count(needle)==1
new=r'''  void actualSocks5RemoteWebSeedPayload() {
    test::OwnedEngineFixture fixture(false);
    WebSeed origin(fixture.files.front().expected); Tracker tracker(1, false);
    Socks proxy(true, 0, tracker.server.serverPort()); proxy.webSeedPort = origin.server.serverPort();
    auto state = core::Document::parse(test::read(fixture.stateFile).toStdString()); QVERIFY(state);
    const auto url = QByteArray("http://") + RemoteSeedName + ':' + QByteArray::number(proxy.webSeedPort) + "/sample.bin";
    QVERIFY(state->replaceValue("url-list", bytes(url).toStdString()));
    test::write(fixture.stateFile, QByteArray::fromStdString(state->serialize()));
    auto config = configuration(proxy.server.serverPort(), true, false);
    const auto originalConfig = config.serialize();
    auto policy = engine::readNetworkPolicy(&config, {engine::NetworkMode::Normal}); QVERIFY(policy);
    policy->listenPort = 0; policy->httpTrackers = false;
    auto lease = storage::ProfileLease::acquire(fixture.native()); QVERIFY(lease);
    auto owner = engine::PersistentSession::create({450, 451, 1}); QVERIFY(owner);
    OwnerExit exit{tracker, proxy, **owner, &origin};
    QVERIFY((*owner)->configureNetwork(*policy)); QVERIFY((*owner)->startIdle(*lease));
    QVERIFY((*owner)->startManaged(*lease, {*fixture.hash, 0, true, false}));
    std::optional<engine::AccountingError> pollFailure;
    const auto completed = [&] {
      const auto polled = (*owner)->poll(); if (!polled) pollFailure = polled.error();
      const auto rows = (*owner)->managedDownloads(); return rows.size() == 1 && rows[0].complete && rows[0].received > 0;
    };
    QTRY_VERIFY2_WITH_TIMEOUT(completed(), qPrintable(facts(**owner, tracker, proxy, pollFailure)
        + QStringLiteral(" | webseed requests=%1 sent=%2 error=%3").arg(origin.requests).arg(origin.sent).arg(QString::fromLatin1(origin.failure))), 30000);
    QVERIFY2(origin.failure.isEmpty(), origin.failure.constData()); QVERIFY2(proxy.failure.isEmpty(), proxy.failure.constData());
    QVERIFY(origin.requests > 0 && origin.sent >= static_cast<quint64>(fixture.files.front().expected.size()));
    QCOMPARE(tracker.requests, 0U); QVERIFY(proxy.authAttempts > 0);
    QVERIFY(std::ranges::any_of(proxy.routes, [](const auto& route) {
      return route.host == RemoteSeedName && route.domain && route.local == QHostAddress("127.0.0.3")
          && route.queuedToSeed > 0 && route.queuedToClient > 0;
    }));
    QCOMPARE(config.serialize(), originalConfig);
    const auto closed = exit.close(); QVERIFY(closed.sessionJoined && closed.retirement.storageReleased);
    QVERIFY(fixture.accountingIntact());
  }
'''
s=s.replace(needle,new+needle)
needle='  void actualVerifiedSocks4IdentityAndRemoteNameRoutes_data() {';assert needle in s
new=r'''  void socks4aWebSeedNamesFailBeforeAnyRoute() {
    const auto capability = engine::verifiedSocks4Capability(); QVERIFY(capability);
    auto config = configuration(1080, false, false);
    QVERIFY(config.replaceValue("Proxy.Data.SOCKS.version", bytes("V4a").toStdString()));
    const auto policy = engine::readNetworkPolicy(&config,
        {.mode = engine::NetworkMode::Normal, .socks4Capability = capability}); QVERIFY(policy);
    for (bool httpSeed : {false, true}) {
      lt::add_torrent_params params;
      auto& seeds = httpSeed ? params.http_seeds : params.url_seeds;
      seeds = {"http://seed.biglybtc.invalid/data"};
      const auto beforeFlags = params.flags;
      const auto rejected = engine::applyTorrentNetworkPolicy(*policy, {}, params);
      QVERIFY(!rejected); QCOMPARE(rejected.error().code, engine::NetworkPolicyErrorCode::Unsupported);
      QCOMPARE(rejected.error().field, std::string("SOCKS4a webseed hostname"));
      QCOMPARE(seeds, std::vector<std::string>{"http://seed.biglybtc.invalid/data"}); QCOMPARE(params.flags, beforeFlags);
      seeds = {"http://127.0.0.1:8080/data"}; QVERIFY(engine::applyTorrentNetworkPolicy(*policy, {}, params));
      QCOMPARE(seeds.size(), std::size_t{1});
      seeds = {"http://seed.biglybtc.invalid/data"};
      engine::TorrentNetworkSelection disabled; disabled.webSeeds = false;
      QVERIFY(engine::applyTorrentNetworkPolicy(*policy, disabled, params)); QVERIFY(seeds.empty());
    }
  }
'''
s=s.replace(needle,new+needle);after[p]=s
p=paths[2];s=after[p];needle='    run("private metadata and stronger resume restrictions", [] {';assert needle in s
new='''    run("IPv6 literal sources require the original IPv6 permission", [] {
      const auto ipv4 = normal();
      for (bool tracker : {false, true}) {
        lt::add_torrent_params params;
        auto& urls = tracker ? params.trackers : params.url_seeds;
        urls = {"http://[::1]:8080/data"};
        const auto beforeFlags = params.flags;
        const auto denied = engine::applyTorrentNetworkPolicy(ipv4, {}, params);
        CHECK(!denied && denied.error().code == Code::Unsupported);
        CHECK(urls == std::vector<std::string>{"http://[::1]:8080/data"} && params.flags == beforeFlags);
        auto ipv6 = ipv4; ipv6.ipv6 = true;
        CHECK(engine::applyTorrentNetworkPolicy(ipv6, {}, params));
        CHECK(urls.size() == 1);
      }
    });
'''
s=s.replace(needle,new+needle);after[p]=s
for p in paths:
 for directory,value in [('before',before[p]),('staging',after[p])]:
  t=w/directory/p;t.parent.mkdir(parents=True,exist_ok=True);assert not t.exists();t.write_text(value)
(w/'changes.patch').write_text(''.join(''.join(difflib.unified_diff(before[p].splitlines(True),after[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in paths))
h=lambda s:hashlib.sha256(s.encode()).hexdigest();m={'schema':1,'base':'9e7f43ec14476bb8091c803a2b37c490b46d4435','status':'SOURCE_ONLY_NOT_BUILT','before_sha256':{p:h(before[p]) for p in paths},'source_sha256':{p:h(after[p]) for p in paths},'scope':'Reject unqualified4a webseed local-DNS path and IPv6 literals when disabled; actual owned SOCKS5 .invalid tracker/webseed routes; no DNS absence/public network claim.'};(w/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'paths':len(paths),'manifest_sha256':h((w/'manifest.json').read_text())}))
