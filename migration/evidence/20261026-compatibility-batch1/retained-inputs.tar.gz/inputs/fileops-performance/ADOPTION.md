# Bounded file-operation digest reuse

Base native main: `9e7f43ec14476bb8091c803a2b37c490b46d4435`.
Apply the four staged files/patches, then append `tests-cmake.fragment.cmake` to the existing file-operations test target. No public API, journal format, scope/confirmation, config CAS, control validation or recovery mapping changes. All existing test bodies/assertions remain exact.

The cache retains up to eight opened payload descriptors plus one active hash read. A hit requires the exact post-hash dev/inode/size/mode/uid/link count/mtime/ctime in both the secure named path and retained fd. New or changed metadata, evicted receipts and a newly decoded recovery plan require a full read. Own hardlinks change ctime/link count and therefore deliberately require rehash. No link-count-based proof refresh exists. File bytes are never taken from verified-piece state or a previous client session.

Source-derived read schedules for a stable one-file operation of B physical bytes, to verify with the authored real read/read_chk counters:

| Operation | Previous payload reads | Candidate payload reads |
| --- | --- | --- |
| Same-device hardlink move | 3B | 2B |
| Relink | 2B destination | B destination |
| Delete | 2B | B |
| Forced copy | 5B source + B scratch | 2B source + B scratch |

These are expected byte schedules, not executed measurements or CPU claims. Cache eviction can reduce or remove the saving for larger file sets; correctness falls back to the old hashing path. Tests cover both recovery boundaries, actual changed same-inode bytes with restored mtime before link/after publication, document CAS, confirmation, bounded eviction and equal-byte inode replacement. Counters identify real opened payload inodes; fortified reads retain libc checks.

Root-only qualification: build existing `biglybtc-file-operations-tests` in the selected cache, then run only `ctest --test-dir CACHE --output-on-failure -R '^file-operations$'`. Retain stdout `payload-work` facts/XML/log and actual source/compiler receipt. Existing Host/storage handoffs can join the root's coherent batch; no broad rerun is requested by this capsule. No author build/test/benchmark run occurred.

Next CF-06 candidates from the still-open checklist: archive-file deletion controls; explicit shared/merge/overwrite storage ownership workflows and repair UX; advanced/virtual/multi-source creation. These need separate user-facing contracts and original handoffs, not broader trust in this cache. CF-08 compositor/public interoperability and comparable CPU/memory measurements remain open.
