# Apply-scoped digest receipts

Apply after frozen `fileops-performance/manifest.json` b212e320. Three exact replacements/patches; no additional CMake change. Base capsule remains unchanged.

`applyFileOperation` binds an rvalue reference to the caller's object; it does not consume its `impl_`. A local scope guard now clears all cached descriptors on every normal/exceptional exit after binding the plan. It leaves `attempted`, confirmation, journal, recovery and retry decisions unchanged. A recovered local plan still naturally destroys its independent cache.

The new tests hold the original successful and JournalSynced-failed prepared object alive, count only its actual payload inode in `/proc/self/fd` before/after apply, require return to baseline, and still recover the failed durable operation and compare payload bytes. This would fail the base cache implementation without the guard. No build/test execution by author.
