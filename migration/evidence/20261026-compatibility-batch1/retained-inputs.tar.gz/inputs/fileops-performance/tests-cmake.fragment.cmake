# Append to the existing biglybtc-file-operations-tests registration only.
# Keep existing --wrap=linkat and every assertion/TIMEOUT unchanged.
target_link_options(biglybtc-file-operations-tests PRIVATE
  "LINKER:--wrap=read" "LINKER:--wrap=__read_chk")
