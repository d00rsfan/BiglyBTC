#include "file_operations.hpp"
#include "file_policy_commands.hpp"
#include "encoded_document.hpp"
#include "file_operation_io.hpp"
#include <openssl/evp.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <type_traits>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace fs=std::filesystem;
namespace st=biglybtc::storage;
namespace core=biglybtc::core;
namespace {
void check(bool value,const char* why){if(!value){throw std::runtime_error(why);}}
template<class T>T take(std::expected<T,st::Error>&& value){if(!value){throw std::runtime_error(value.error().message);}if constexpr(!std::is_void_v<T>){return std::move(*value);}}
std::string b(std::string_view value){return std::to_string(value.size())+':'+std::string(value);}
core::Document doc(std::string bytes){auto out=core::Document::parse(std::move(bytes),st::compatibleConfigLimits());check(out.has_value(),"parse fixture");return std::move(*out);}
void put(core::Document& d,std::string_view key,std::string value){check(d.replaceValue(key,std::move(value)).has_value(),"edit fixture");}
std::string read(const fs::path& path){std::ifstream input(path,std::ios::binary);check(bool(input),"read fixture");return {std::istreambuf_iterator<char>(input),{}};}
void write(const fs::path& path,std::string_view bytes){fs::create_directories(path.parent_path());std::ofstream output(path,std::ios::binary);output.write(bytes.data(),static_cast<std::streamsize>(bytes.size()));check(bool(output),"write fixture");}
std::string sha1(std::string_view bytes){std::array<unsigned char,EVP_MAX_MD_SIZE> raw{};unsigned size=0;check(EVP_Digest(bytes.data(),bytes.size(),raw.data(),&size,EVP_sha1(),nullptr)==1&&size==20,"fixture sha1");return {reinterpret_cast<const char*>(raw.data()),size};}
struct Area{fs::path root;Area(){char path[]="/tmp/biglybtc-fileops-XXXXXX";const auto* made=::mkdtemp(path);check(made,"mkdtemp");root=made;}~Area(){std::error_code e;fs::remove_all(root,e);}};
struct Record{core::TorrentHash hash;std::string row,metadata;fs::path state,archive,save;std::vector<fs::path> files;std::vector<std::string> values;};
Record record(const fs::path& profile,const fs::path& save,std::string name,bool multi,std::string second="world!"){
  Record out;out.save=save;out.values=multi?std::vector<std::string>{"hello",std::move(second)}:std::vector<std::string>{"hello"};std::string all;for(const auto& v:out.values){all+=v;}std::string pieces;for(std::size_t i=0;i<all.size();i+=4){pieces+=sha1(std::string_view(all).substr(i,std::min<std::size_t>(4,all.size()-i)));}
  std::string info="d";if(multi){info+="5:filesl";for(std::size_t i=0;i<out.values.size();++i){const auto file=i?"second.bin":"first.bin";info+="d6:lengthi"+std::to_string(out.values[i].size())+"e4:pathl"+b(file)+"ee";out.files.push_back(save/name/file);}info+='e';}else{info+="6:lengthi5e";out.files.push_back(save/name);}info+="4:name"+b(name)+"12:piece lengthi4e6:pieces"+b(pieces)+'e';auto hash=core::TorrentHash::parse(sha1(info));check(hash.has_value(),"fixture hash");out.hash=*hash;
  auto state=doc("d4:info"+info+"e");std::string stores="l";for(std::size_t i=0;i<out.values.size();++i){stores+="1:L";}auto attrs=doc("de");put(attrs,"storetypes",stores+'e');put(attrs,"opaque.state","li7e3:rawe");put(attrs,"resumecomplete","i2e");put(state,"attributes",attrs.serialize());auto data=doc("de");put(data,"resume data",b(std::string(pieces.size()/20,'\1')));put(data,"valid","i1e");auto resume=doc("de");put(resume,"data",data.serialize());put(state,"resume",resume.serialize());out.metadata=state.serialize();out.state=profile/"active"/(out.hash.hex()+".dat");out.archive=profile.parent_path()/(name+".torrent");write(out.state,out.metadata);write(out.archive,out.metadata);
  for(std::size_t i=0;i<out.files.size();++i){write(out.files[i],out.values[i]);}auto row=doc("de");put(row,"torrent",b(out.archive.string()));put(row,"torrent_hash",b(sha1(info)));put(row,"save_dir",b(save.string()));put(row,"save_file",b(name));put(row,"state","i0e");put(row,"forceStart","i1e");put(row,"downloaded","i11e");put(row,"file_priorities",multi?"li1ei2ee":"li1ee");put(row,"opaque.row","d4:keep3:rawe");out.row=row.serialize();return out;
}
struct Fixture{Area area;fs::path profile,source,destination;Record selected;st::ProfileLease lease;
  explicit Fixture(bool multi=false,bool threePieceSecond=false):profile(area.root/"profile"),source(area.root/"source"),destination(area.root/"destination"),selected(record(profile,source,multi?"bundle":"file.bin",multi,threePieceSecond?"world!tail":"world!")),lease(take(st::ProfileLease::acquire(profile))){fs::create_directories(destination);inventory();}
  void inventory(std::string extra={}){write(profile/"downloads.config","d9:downloadsl"+selected.row+extra+"e6:opaque3:rawe");}
  st::PreparedFileOperation plan(st::FileOperationKind kind){return take(st::prepareFileOperation(lease,{selected.hash,kind,kind==st::FileOperationKind::Relocate||kind==st::FileOperationKind::Relink?std::optional<fs::path>(destination):std::nullopt}));}
};
// Actual source and destination bytes use real filesystem IO. Only the link
// syscall result is injected, to deterministically exercise the EXDEV copy path.
bool forceCopy=false;dev_t copyFromDev=0,copyToDev=0;ino_t copyFromIno=0,copyToIno=0;unsigned copyHits=0;
st::FileOperationStage interruptAt=st::FileOperationStage::Completed;bool interruptArmed=false;
void interrupt(st::FileOperationStage stage){if(interruptArmed&&stage==interruptAt){interruptArmed=false;throw std::runtime_error("injected stage interruption");}}
std::string hashBytes(const core::TorrentHash& hash){const auto bytes=hash.bytes();return {reinterpret_cast<const char*>(bytes.data()),bytes.size()};}
std::string pauseRow(const core::TorrentHash& hash,bool force,std::int64_t owner){auto row=doc("de");put(row,"hash",b(hashBytes(hash)));put(row,"force",force?"i1e":"i0e");put(row,"owner","i"+std::to_string(owner)+'e');put(row,"opaque.pause","li7e3:rawe");return row.serialize();}
void keepAndDelete(){
  {Fixture f;const auto bytes=read(f.selected.files[0]),archive=read(f.selected.archive);auto p=f.plan(st::FileOperationKind::RemoveKeepData);check(p.preview().presentFiles==1&&p.preview().presentBytes==5,"keep preview facts");auto confirmation=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));auto result=take(st::applyFileOperation(f.lease,std::move(p),confirmation));check(result.filesDeleted==0&&read(f.selected.files[0])==bytes&&read(f.selected.archive)==archive,"keep preserves bytes/archive");check(!fs::exists(f.selected.state)&&!st::hasPendingFileOperation(f.lease),"active state removed last and journal gone");auto inventory=doc(read(f.profile/"downloads.config"));check(inventory.find("downloads")->children.empty()&&inventory.find("opaque")->bytes=="raw","selected row removed unknown preserved");}
  {Fixture f(true);write(f.source/"bundle/foreign.txt","foreign");auto p=f.plan(st::FileOperationKind::RemoveDeleteData);check(p.preview().presentFiles==2,"delete plan exact leaf count");check(!st::confirmFileOperation(p,p.preview().approvalScopeDigest,false),"delete requires explicit confirmation");check(fs::exists(f.selected.files[0]),"rejection no mutation");auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,true));auto r=take(st::applyFileOperation(f.lease,std::move(p),c));check(r.filesDeleted==2&&!fs::exists(f.selected.files[0])&&!fs::exists(f.selected.files[1])&&read(f.source/"bundle/foreign.txt")=="foreign"&&fs::exists(f.selected.archive),"delete touches only owned listed leaves");}
  // Mixed original pause encodings: remove only this torrent's dictionary and
  // legacy byte ownership, retaining exact survivor rows and opaque fields.
  for(const auto kind:{st::FileOperationKind::RemoveKeepData,st::FileOperationKind::RemoveDeleteData}){
    Fixture f;const auto other=record(f.profile,f.area.root/"other","survivor.bin",false);f.inventory(other.row);auto inventory=doc(read(f.profile/"downloads.config"));const auto survivors=b(hashBytes(other.hash))+pauseRow(other.hash,false,19);put(inventory,"pause_data","l"+pauseRow(f.selected.hash,true,7)+b(hashBytes(f.selected.hash))+survivors+'e');write(f.profile/"downloads.config",inventory.serialize());auto p=f.plan(kind);auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,true));take(st::applyFileOperation(f.lease,std::move(p),c));auto after=doc(read(f.profile/"downloads.config"));check(core::encodeValue(*after.find("pause_data")).value()=="l"+survivors+'e',"remove mixed target pauses preserves exact survivor/opaque bytes");auto parsed=core::readLibrary(after);check(parsed&&parsed->downloads.size()==1&&parsed->downloads[0].hash==other.hash&&parsed->paused.size()==2&&std::ranges::all_of(parsed->paused,[&](const auto& row){return row.hash==other.hash;}),"removed target has no orphan pause in either encoding");check(after.find("opaque")->bytes=="raw"&&read(other.files[0])==other.values[0],"pause removal preserves inventory unknown and survivor data");
  }
  {
    Fixture f;const auto other=record(f.profile,f.area.root/"other","survivor.bin",false);f.inventory(other.row);auto inventory=doc(read(f.profile/"downloads.config"));const auto target=pauseRow(f.selected.hash,true,7)+b(hashBytes(f.selected.hash));put(inventory,"pause_data","l"+target+pauseRow(other.hash,false,19)+'e');write(f.profile/"downloads.config",inventory.serialize());auto p=f.plan(st::FileOperationKind::RemoveKeepData);auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));interruptAt=st::FileOperationStage::JournalSynced;interruptArmed=true;check(!st::applyFileOperation(f.lease,std::move(p),c,interrupt)&&st::hasPendingFileOperation(f.lease),"pause recovery has durable confirmed journal before publication");
    auto changed=doc(read(f.profile/"downloads.config"));put(changed,"pause_data","l"+pauseRow(f.selected.hash,false,7)+b(hashBytes(f.selected.hash))+pauseRow(other.hash,false,19)+'e');write(f.profile/"downloads.config",changed.serialize());auto conflict=st::recoverFileOperation(f.lease);check(!conflict&&conflict.error().code==st::ErrorCode::Conflict&&st::hasPendingFileOperation(f.lease)&&fs::exists(f.selected.state)&&read(f.selected.files[0])=="hello","changed modern target pause refuses recovery before effects");
    const auto survivorPauses=b(hashBytes(other.hash))+pauseRow(other.hash,true,29);put(changed,"pause_data","l"+target+survivorPauses+'e');auto otherRow=doc(other.row);put(otherRow,"downloaded","i99e");put(changed,"downloads","l"+f.selected.row+otherRow.serialize()+'e');write(f.profile/"downloads.config",changed.serialize());auto recovered=take(st::recoverFileOperation(f.lease));check(recovered&&recovered->recovered&&!st::hasPendingFileOperation(f.lease),"sparse recovery removes selected mixed pauses");auto after=doc(read(f.profile/"downloads.config"));check(core::encodeValue(*after.find("pause_data")).value()=="l"+survivorPauses+'e',"recovery preserves independently changed survivor pause/opaque fields");auto parsed=core::readLibrary(after);check(parsed&&parsed->downloads.size()==1&&parsed->downloads[0].hash==other.hash&&parsed->downloads[0].downloaded==99&&parsed->paused.size()==2&&std::ranges::all_of(parsed->paused,[&](const auto& row){return row.hash==other.hash;}),"sparse recovery retains unrelated row checkpoint and no target ownership");check(after.find("opaque")->bytes=="raw"&&read(f.selected.files[0])=="hello"&&read(other.files[0])==other.values[0],"recovered Keep preserves both payloads and unknown root");
  }

}
void relocationRecoveryPreservesBothUntilPublication(){
  Fixture f(true);
  const std::string emptyGzip("\x1f\x8b\x08\x00\x00\x00\x00\x00\x02\xff\x4b\x49\x05\x00\x8b\x29\x90\x7d\x02\x00\x00\x00",22);
  auto cache=take(st::EncodedDocument::parse(emptyGzip).transform_error([](auto){return st::Error{st::ErrorCode::InvalidFormat,"cache fixture"};}));
  auto original=doc(f.selected.metadata);auto attributes=doc(*core::encodeValue(*original.find("attributes")));put(attributes,"opaque.cache","li99e3:rawe");
  const auto key=f.selected.hash.bytes();const std::string hash(reinterpret_cast<const char*>(key.data()),key.size());
  check(cache.replaceValue("state","ld4:hash"+b(hash)+"10:attributes"+attributes.serialize()+"ee").has_value(),"cache target fixture");
  check(cache.replaceValue("unrelated.checkpoint","i1e").has_value(),"cache unknown fixture");
  write(f.profile/"active/cache.dat",*cache.serialize());auto p=f.plan(st::FileOperationKind::Relocate);const auto scope=p.preview().approvalScopeDigest;auto c=take(st::confirmFileOperation(p,scope,false));interruptAt=st::FileOperationStage::DestinationPublished;interruptArmed=true;auto failed=st::applyFileOperation(f.lease,std::move(p),c,interrupt);check(!failed&&st::hasPendingFileOperation(f.lease),"interrupted move retains journal");for(std::size_t i=0;i<f.selected.files.size();++i){check(read(f.selected.files[i])==f.selected.values[i],"old Java root remains complete before publication");}
  auto cacheNow=take(st::EncodedDocument::parse(read(f.profile/"active/cache.dat")).transform_error([](auto){return st::Error{st::ErrorCode::InvalidFormat,"cache reload"};}));
  check(cacheNow.replaceValue("unrelated.checkpoint","i88e").has_value(),"unrelated cache checkpoint");write(f.profile/"active/cache.dat",*cacheNow.serialize());
  auto other=record(f.profile,f.area.root/"other","other.bin",false);auto inventory=doc(read(f.profile/"downloads.config"));auto rows=std::string("l");for(const auto& row:inventory.find("downloads")->children){rows+=*core::encodeValue(row,st::compatibleConfigLimits());}auto updatedOther=doc(other.row);put(updatedOther,"downloaded","i99e");rows+=updatedOther.serialize()+'e';put(inventory,"downloads",rows);write(f.profile/"downloads.config",inventory.serialize());
  auto recovered=take(st::recoverFileOperation(f.lease));check(recovered&&recovered->recovered&&recovered->filesMoved==2,"move recovery succeeds");for(std::size_t i=0;i<f.selected.files.size();++i){check(!fs::exists(f.selected.files[i])&&read(f.destination/f.selected.files[i].lexically_relative(f.source))==f.selected.values[i],"destination published before source removal");}
  auto afterCache=take(st::EncodedDocument::parse(read(f.profile/"active/cache.dat")).transform_error([](auto){return st::Error{st::ErrorCode::InvalidFormat,"cache final"};}));
  check(afterCache.document().find("state")->children.empty()&&afterCache.document().find("unrelated.checkpoint")->integer==88,"sparse cache recovery keeps unrelated checkpoint");
  auto after=doc(read(f.profile/"downloads.config"));auto library=core::readLibrary(after);check(library&&library->downloads.size()==2&&library->downloads[0].saveDirectory==f.destination.string()&&library->downloads[1].downloaded==99,"sparse recovery keeps unrelated checkpoint");auto state=take(st::EncodedDocument::parse(read(f.selected.state)).transform_error([](auto){return st::Error{st::ErrorCode::InvalidFormat,"state parse"};}));check(state.document().find("resume")->find("data")->find("valid")->integer==0&&state.document().find("attributes")->find("opaque.state")&&state.document().find("attributes")->find("opaque.cache"),"move preserves unknown state and requires recheck");
}
void relinkAndScope(){
  Fixture f;write(f.destination/"file.bin","other");auto p=f.plan(st::FileOperationKind::Relink);check(p.preview().requiresRecheck&&p.preview().presentFiles==1,"relink facts");auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));take(st::applyFileOperation(f.lease,std::move(p),c));check(read(f.source/"file.bin")=="hello"&&read(f.destination/"file.bin")=="other","relink does not move/delete data");
  Fixture growing;write(growing.source/"file.bin","he");auto first=growing.plan(st::FileOperationKind::Relocate);const auto accepted=first.preview().approvalScopeDigest,oldCas=first.preview().executionCasDigest;write(growing.source/"file.bin","hello");auto inventory=doc(read(growing.profile/"downloads.config"));auto row=doc(growing.selected.row);put(row,"downloaded","i55e");put(inventory,"downloads","l"+row.serialize()+'e');write(growing.profile/"downloads.config",inventory.serialize());auto fresh=growing.plan(st::FileOperationKind::Relocate);check(fresh.preview().approvalScopeDigest==accepted&&fresh.preview().executionCasDigest!=oldCas,"scope tolerates same-inode growth/counter checkpoint");check(st::confirmFileOperation(fresh,accepted,false).has_value(),"fresh CAS accepts stable approved scope");std::stop_source stop;stop.request_stop();auto confirmation=take(st::confirmFileOperation(fresh,accepted,false));check(!st::applyFileOperation(growing.lease,std::move(fresh),confirmation,nullptr,stop.get_token())&&!st::hasPendingFileOperation(growing.lease),"cancel before journal leaves no mutation");
}
void protectionAndConflicts(){
  Fixture f;auto state=doc(read(f.selected.state));auto attrs=doc(*core::encodeValue(*state.find("attributes")));put(attrs,"flags","i64e");put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveDeleteData,{}}),"source0x40 flag forbids deletion");
  Fixture shared;auto inventory=doc(read(shared.profile/"downloads.config"));auto row=doc(shared.selected.row);put(row,"torrent_hash",b(std::string(20,'z')));put(inventory,"downloads","l"+shared.selected.row+row.serialize()+'e');write(shared.profile/"downloads.config",inventory.serialize());check(!st::prepareFileOperation(shared.lease,{shared.selected.hash,st::FileOperationKind::RemoveDeleteData,{}}),"overlapping library root rejects");
  Fixture unsafe;fs::remove(unsafe.selected.files[0]);fs::create_symlink(unsafe.selected.archive,unsafe.selected.files[0]);check(!st::prepareFileOperation(unsafe.lease,{unsafe.selected.hash,st::FileOperationKind::RemoveDeleteData,{}}),"payload symlink rejects without following");
  Fixture collision;write(collision.destination/"file.bin","foreign");check(!st::prepareFileOperation(collision.lease,{collision.selected.hash,st::FileOperationKind::Relocate,collision.destination}),"move never overwrites destination");
}

void attributes(Fixture& f,std::string stores,std::optional<std::string> links={},std::string suffix={}){
  auto state=doc(read(f.selected.state));auto attrs=doc(*core::encodeValue(*state.find("attributes")));put(attrs,"storetypes",std::move(stores));if(links){put(attrs,"filelinks2",*links);}if(!suffix.empty()){put(attrs,"incompfilesuffix",b(suffix));}put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());
}
fs::path control(const Fixture& f,std::size_t index,bool reorder=false){return f.profile/"active"/f.selected.hash.hex()/("fmfile"+std::to_string(index)+".dat"+(reorder?".2":""));}
void nonlinearControlsAndRecovery(){
  // offset5, length10, piece4: three reordered slots may occupy3+2*4=11
  // physical bytes. These bytes are moved opaquely, not decoded as linear data.
  {
    Fixture f(true,true);attributes(f,"l1:L1:Re");fs::resize_file(f.selected.files[1],11);const std::string physical=std::string("world!tail")+std::string(1,'\0');const auto c=control(f,1,true);write(c,"opaque reordered control");write(fs::path(c.string()+".bak"),"prior control");write(c.parent_path()/"foreign.dat","foreign state");
    auto plan=f.plan(st::FileOperationKind::Relocate);check(plan.preview().files[1].logicalBytes==10&&plan.preview().files[1].actualBytes==11&&plan.preview().presentBytes==16&&plan.preview().presentFiles==2,"nonlinear preview separates logical/physical payload and excludes control leaves");auto confirmation=take(st::confirmFileOperation(plan,plan.preview().approvalScopeDigest,false));interruptAt=st::FileOperationStage::DestinationPublished;interruptArmed=true;check(!st::applyFileOperation(f.lease,std::move(plan),confirmation,interrupt)&&st::hasPendingFileOperation(f.lease),"reorder move has durable recoverable publication");
    auto other=record(f.profile,f.area.root/"unrelated","other.bin",false);auto inv=doc(read(f.profile/"downloads.config"));auto changed=doc(other.row);put(changed,"downloaded","i97e");put(inv,"downloads","l"+f.selected.row+changed.serialize()+'e');write(f.profile/"downloads.config",inv.serialize());
    auto result=take(st::recoverFileOperation(f.lease));check(result&&result->filesMoved==2&&result->recovered&&read(f.destination/"bundle/second.bin")==physical&&!fs::exists(f.selected.files[1]),"reorder move recovery preserves complete physical bytes");check(read(c)=="opaque reordered control"&&read(fs::path(c.string()+".bak"))=="prior control"&&read(c.parent_path()/"foreign.dat")=="foreign state","profile-anchored controls and foreign state never relocate");auto library=take(core::readLibrary(doc(read(f.profile/"downloads.config"))).transform_error([](auto){return st::Error{st::ErrorCode::InvalidFormat,"library"};}));check(library.downloads[1].downloaded==97,"nonlinear recovery keeps unrelated checkpoint");
  }
  {
    Fixture f;attributes(f,"l1:Ce");write(f.selected.files[0],"x");const auto c=control(f,0);write(c,"opaque compact control");write(fs::path(c.string()+".bak"),"prior compact");write(c.parent_path()/"foreign","untouched");auto p=f.plan(st::FileOperationKind::RemoveKeepData);auto accepted=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));take(st::applyFileOperation(f.lease,std::move(p),accepted));check(read(f.selected.files[0])=="x"&&!fs::exists(c)&&!fs::exists(fs::path(c.string()+".bak"))&&read(c.parent_path()/"foreign")=="untouched","keep data removes only indexed compact control state, without recursive cleanup");
  }
  {
    Fixture f(true,true);attributes(f,"l1:L1:Xe");write(f.selected.files[1],"123456789AB");write(f.destination/"bundle/first.bin","hello");write(f.destination/"bundle/second.bin","abcdefghijk");const auto c=control(f,1,true);write(c,"opaque X control");auto p=f.plan(st::FileOperationKind::Relink);auto confirmation=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));take(st::applyFileOperation(f.lease,std::move(p),confirmation));check(read(c)=="opaque X control"&&read(f.selected.files[1])=="123456789AB"&&read(f.destination/"bundle/second.bin")=="abcdefghijk","relink preserves profile control and both physical trees");auto remove=take(st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveDeleteData,{}}));auto approved=take(st::confirmFileOperation(remove,remove.preview().approvalScopeDigest,true));take(st::applyFileOperation(f.lease,std::move(remove),approved));check(!fs::exists(c)&&!fs::exists(f.destination/"bundle/second.bin")&&read(f.selected.files[1])=="123456789AB","delete follows current nonlinear mapping and removes known control only");
  }
}
void nonlinearBoundaryRefusals(){
  {Fixture f(true);attributes(f,"l1:L1:Re");write(f.selected.files[1],"1234567");check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveDeleteData,{}})&&read(f.selected.files[1])=="1234567"&&!st::hasPendingFileOperation(f.lease),"two-piece reorder remains linear and rejects physical bytes beyond logical length");}

  for(const auto intent:{"ld5:indexi0eee","i1e"}){Fixture f;auto state=doc(read(f.selected.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));put(attrs,"BiglyBTC.compactConversion",intent);put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());const auto before=read(f.selected.state);check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveKeepData,{}})&&read(f.selected.state)==before&&read(f.selected.files[0])=="hello"&&!st::hasPendingFileOperation(f.lease),"pending or malformed compact-conversion intent refuses before effects");}

  {Fixture f(true,true);attributes(f,"l1:L1:Re");write(f.selected.files[1],"123456789ABC");check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveDeleteData,{}})&&read(f.selected.files[1])=="123456789ABC"&&!st::hasPendingFileOperation(f.lease),"reordered bytes above exact geometry bound refuse before mutation");}
  {Fixture f;attributes(f,"l1:Ce");write(f.selected.files[0],"x");const auto c=control(f,0);write(fs::path(c.string()+".saving"),"pending");check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveKeepData,{}})&&read(f.selected.files[0])=="x","unresolved control saving refuses even Keep");}
  {Fixture f;const auto c=control(f,0);fs::create_directories(c.parent_path());fs::create_symlink(f.selected.archive,c);check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveKeepData,{}})&&fs::exists(f.selected.state),"control symlink is never followed/deleted");}
  {Fixture f;attributes(f,"l1:Re");const auto c=control(f,0,true);write(c,"before");auto p=f.plan(st::FileOperationKind::RemoveDeleteData);auto confirmation=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,true));write(c,"changed");auto result=st::applyFileOperation(f.lease,std::move(p),confirmation);check(!result&&result.error().code==st::ErrorCode::Conflict&&!st::hasPendingFileOperation(f.lease)&&read(f.selected.files[0])=="hello"&&read(c)=="changed","control CAS refuses changed state before any payload deletion");}
}
void authenticatedExternalLinks(){
// Insert both blocks inside authenticatedExternalLinks() in file_operations_tests.cpp.
  {
    Fixture f; const auto external=f.area.root/"external/negative"; write(external,"hello");
    const auto original=f.selected.files[0].string();
    attributes(f,"l1:Le","l"+b("0\n/stale-indexed-from\n"+(f.area.root/"unused").string())
        +b("-1\n"+original+"\n"+external.string())
        +b("-1\n"+external.string()+"\n"+(f.area.root/"not-authorized").string())+'e');
    auto plan=f.plan(st::FileOperationKind::RemoveKeepData);
    check(plan.preview().files.size()==1&&plan.preview().files[0].source==external,
        "file-operation preview shares exact original-base negative migration, not chained links");
    auto confirmation=take(st::confirmFileOperation(plan,plan.preview().approvalScopeDigest,false));
    take(st::applyFileOperation(f.lease,std::move(plan),confirmation));
    check(read(external)=="hello"&&read(f.selected.files[0])=="hello"&&!fs::exists(f.selected.state)
        &&!fs::exists(f.area.root/"not-authorized"),
        "RemoveKeep uses authenticated migrated source and preserves original and external payload bytes");
  }
  {
    Fixture f; const auto forbidden=f.profile/"not-payload"; write(forbidden,"hello");
    attributes(f,"l1:Le","l"+b("-1\n"+f.selected.files[0].string()+"\n"+forbidden.string())+'e');
    const auto state=read(f.selected.state),inventory=read(f.profile/"downloads.config");
    check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveKeepData,{}})
        &&read(forbidden)=="hello"&&read(f.selected.state)==state&&read(f.profile/"downloads.config")==inventory
        &&!st::hasPendingFileOperation(f.lease),"negative index never bypasses held-profile exclusion or mutates on failed authority");
  }

  {Fixture f;auto state=doc(read(f.selected.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));put(attrs,"filelinks","l3:rawe");put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());auto p=f.plan(st::FileOperationKind::Relocate);auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));take(st::applyFileOperation(f.lease,std::move(p),c));auto after=doc(read(f.selected.state));check(core::encodeValue(*after.find("attributes")->find("filelinks")).value()=="l3:rawe"&&read(f.destination/"file.bin")=="hello","deprecated filelinks remains opaque and never overrides actual base/filelinks2 mapping");}

  for(const auto kind:{st::FileOperationKind::RemoveKeepData,st::FileOperationKind::RemoveDeleteData}){
    Fixture f;const auto external=f.area.root/"external/actual";write(external,"hello");attributes(f,"l1:Le","l"+b("0\n"+f.selected.files[0].string()+"\n"+external.string())+'e');auto p=f.plan(kind);auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,true));take(st::applyFileOperation(f.lease,std::move(p),c));check(fs::exists(external)==(kind==st::FileOperationKind::RemoveKeepData)&&read(f.selected.files[0])=="hello","Keep/Delete target only authenticated external leaf, not abandoned logical base");
  }
  {
    Fixture f;const auto external=f.area.root/"external/actual";write(external,"hello");write(f.destination/"file.bin","there");attributes(f,"l1:Le","l"+b("0\n"+f.selected.files[0].string()+"\n"+external.string())+'e');auto p=f.plan(st::FileOperationKind::Relink);auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));take(st::applyFileOperation(f.lease,std::move(p),c));check(read(external)=="hello"&&read(f.destination/"file.bin")=="there","external relink leaves old actual leaf intact and binds normal destination");
  }

  {
    Fixture f;const auto external=f.area.root/"external/renamed.az!";write(external,"hello");fs::remove(f.selected.files[0]);const auto links="l"+b("0\n"+f.selected.files[0].string()+"\n"+external.string())+'e';attributes(f,"l1:Le",links,".az!");auto state=doc(read(f.selected.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));put(attrs,"dnd_sf",b("not-scanned"));put(attrs,"dnd_pfx",b("raw-prefix"));put(attrs,"dnd_al",b((f.area.root/"not-created").string()));put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());auto p=f.plan(st::FileOperationKind::Relocate);check(p.preview().files[0].source==external&&p.preview().files[0].destination==f.destination/"file.bin.az!","external source approval maps to normal destination plus incomplete suffix");auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));interruptAt=st::FileOperationStage::DestinationPublished;interruptArmed=true;check(!st::applyFileOperation(f.lease,std::move(p),c,interrupt),"external relocation interruption retained");auto result=take(st::recoverFileOperation(f.lease));check(result&&result->filesMoved==1&&!fs::exists(external)&&read(f.destination/"file.bin.az!")=="hello","external exact source recovery uses no parent traversal");auto movedState=doc(read(f.selected.state));check(movedState.find("attributes")->find("dnd_sf")->bytes=="not-scanned"&&movedState.find("attributes")->find("dnd_pfx")->bytes=="raw-prefix"&&!fs::exists(f.area.root/"not-created"),"DND policies preserved opaquely, never guessed as extra payload roots");
  }
  {
    Fixture f;const auto external=f.area.root/"external/one";write(external,"hello");attributes(f,"l1:Le","l"+b("0\n"+f.selected.files[0].string()+"\n"+external.string())+'e');auto other=record(f.profile,f.area.root/"other","other.bin",false);auto state=doc(read(other.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));put(attrs,"filelinks2","l"+b("0\n"+other.files[0].string()+"\n"+external.string())+'e');put(state,"attributes",attrs.serialize());write(other.state,state.serialize());f.inventory(other.row);check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveDeleteData,{}})&&read(external)=="hello","another torrent explicit link shares source and blocks destructive operation");
  }
  for(const auto scope:{"profile","git","symlink"}){
    Fixture f;fs::path external;if(std::string_view(scope)=="profile"){external=f.profile/"unrelated-data";write(external,"hello");}else if(std::string_view(scope)=="git"){external=f.area.root/".git/owned";write(external,"hello");}else{const auto real=f.area.root/"real";write(real/"owned","hello");fs::create_directory_symlink(real,f.area.root/"alias");external=f.area.root/"alias/owned";}attributes(f,"l1:Le","l"+b("0\n"+f.selected.files[0].string()+"\n"+external.string())+'e');check(!st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveKeepData,{}})&&fs::exists(f.selected.state),"external profile/git/symlink boundary refuses even non-mutating Keep preparation");
  }
}

void legacyRootsAndDefaultStoreRecovery(){
  for(const bool dictionary:{false,true}) {
    Fixture f;auto row=doc(f.selected.row);std::string legacy="d";
    for(std::size_t i=0;i<row.root().children.size();i+=2){const auto& key=row.root().children[i];if(key.bytes=="save_dir"||key.bytes=="save_file"){continue;}legacy+=*core::encodeValue(key)+*core::encodeValue(row.root().children[i+1]);}
    legacy+=b("path")+b(f.selected.files[0].string())+'e';
    write(f.profile/"downloads.config",dictionary?"d"+b("legacy.download")+legacy+b("opaque")+b("raw")+'e':"d9:downloadsl"+legacy+"e6:opaque3:rawe");
    auto state=doc(read(f.selected.state));auto attrs=doc("d12:opaque.stateli7e3:rawee");put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());
    const auto inventoryBefore=read(f.profile/"downloads.config"),stateBefore=read(f.selected.state);auto p=f.plan(st::FileOperationKind::Relocate);check(read(f.profile/"downloads.config")==inventoryBefore&&read(f.selected.state)==stateBefore,"legacy/default prepare stays read-only");check(p.preview().sourceRoot==f.selected.files[0]&&p.preview().files[0].source==f.selected.files[0],"legacy exact root in preview");auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));interruptAt=st::FileOperationStage::DestinationPublished;interruptArmed=true;check(!st::applyFileOperation(f.lease,std::move(p),c,interrupt)&&st::hasPendingFileOperation(f.lease),"legacy move durable before source removal");
    write(f.profile/"biglybt.config","d27:Enable reorder storage modei1e27:Reorder storage mode min MBi0ee");
    const auto result=take(st::recoverFileOperation(f.lease));check(result&&result->filesMoved==1&&read(f.destination/"file.bin")=="hello"&&!fs::exists(f.selected.files[0]),"recovery uses captured physical policy rather than changed config");auto inventory=doc(read(f.profile/"downloads.config"));auto library=core::readLibrary(inventory);check(library&&library->downloads.size()==1&&library->legacyMap==dictionary&&library->downloads[0].saveDirectory==f.destination.string()&&library->downloads[0].saveFile=="file.bin"&&inventory.find("opaque")->bytes=="raw","target migration retains inventory form and opaque data");
    const auto current=doc(read(f.selected.state));check(current.find("attributes")->find("storetypes")->children[0].bytes=="L"&&current.find("attributes")->find("opaque.state"),"move writes captured desired defaults and preserves unknown attributes");
  }
  {Fixture f;auto row=doc(f.selected.row);std::string legacy="d";for(std::size_t i=0;i<row.root().children.size();i+=2){const auto& key=row.root().children[i];if(key.bytes=="save_dir"||key.bytes=="save_file"){continue;}legacy+=*core::encodeValue(key)+*core::encodeValue(row.root().children[i+1]);}legacy+=b("save_dir")+b(f.source.string())+'e';write(f.profile/"downloads.config","d"+b("old")+legacy+b("opaque")+b("raw")+'e');auto p=f.plan(st::FileOperationKind::RemoveKeepData);const auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));take(st::applyFileOperation(f.lease,std::move(p),c));auto after=doc(read(f.profile/"downloads.config"));check(!after.find("old")&&after.find("opaque")->bytes=="raw"&&read(f.selected.files[0])=="hello","legacy dictionary keep removes only selected row and retains data");}
}

void pendingReorderedCompletionGuards(){
  const auto redo=[](std::string_view field){return "d"+b("BiglyBTC.reorderedCompletion")+std::string(field)+'e';};
  const std::vector<std::string> unsafe={redo("d7:versioni1ee"),redo("i0e"),redo("le"),"d"+b("BiglyBTC.reorderedCompletion")};
  for(const auto kind:{st::FileOperationKind::RemoveKeepData,st::FileOperationKind::RemoveDeleteData,st::FileOperationKind::Relocate,st::FileOperationKind::Relink}){
    for(const bool backup:{false,true}){for(const auto& raw:unsafe){Fixture f;attributes(f,"l1:Re");if(kind==st::FileOperationKind::Relink){write(f.destination/"file.bin","hello");}auto path=control(f,0,true);if(backup){path+=std::string(".bak");}write(path,raw);const auto inventory=read(f.profile/"downloads.config"),state=read(f.selected.state);auto result=st::prepareFileOperation(f.lease,{f.selected.hash,kind,kind==st::FileOperationKind::Relocate||kind==st::FileOperationKind::Relink?std::optional<fs::path>(f.destination):std::nullopt});check(!result&&result.error().code==st::ErrorCode::Conflict&&result.error().message.find("reordered completion")!=std::string::npos,"native redo in authoritative primary/backup refuses all operation kinds");check(read(f.selected.files[0])=="hello"&&read(path)==raw&&read(f.profile/"downloads.config")==inventory&&read(f.selected.state)==state&&!st::hasPendingFileOperation(f.lease),"redo preparation refuses before payload/document/journal effects");}}
  }
  const auto cleared=[](){std::string map(4,'\0');map+=std::string(4,static_cast<char>(0xff));return "d3:leni5e4:nexti1e6:pieces"+b(map)+b("BiglyBTC.reorderedCompletion")+"dee";};
  {Fixture f;attributes(f,"l1:Re");const auto c=control(f,0,true);write(c,cleared());write(c.string()+".bak",redo("d7:versioni1ee"));auto p=f.plan(st::FileOperationKind::RemoveKeepData);const auto accept=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));take(st::applyFileOperation(f.lease,std::move(p),accept));check(read(f.selected.files[0])=="hello"&&!fs::exists(c)&&!fs::exists(c.string()+".bak"),"valid cleared primary permits obsolete pending backup and exact cleanup");}
  {Fixture f;attributes(f,"l1:Re");const auto c=control(f,0,true);write(c,"opaque malformed primary");write(c.string()+".bak",redo("d7:versioni1ee"));auto result=st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveKeepData,{}});check(!result&&result.error().message.find("reordered completion")!=std::string::npos&&read(f.selected.files[0])=="hello","malformed primary cannot authorize pending backup transport");}
  {Fixture f(true,true);attributes(f,"l1:L1:Re");const auto c=control(f,1,true);std::string map(8,'\0');map+=std::string(4,static_cast<char>(0xff));write(c,"d3:leni10e4:nexti1e6:pieces"+b(map)+b("BiglyBTC.reorderedCompletion")+"dee");write(c.string()+".bak",redo("d7:versioni1ee"));auto result=st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::RemoveKeepData,{}});check(!result&&result.error().message.find("reordered completion")!=std::string::npos&&read(f.selected.files[1])=="world!tail","invalid duplicate map cannot supersede pending backup even with cleared native key");}
  for(const bool recovery:{false,true}){Fixture f;attributes(f,"l1:Re");const auto c=control(f,0,true);write(c,cleared());auto p=f.plan(st::FileOperationKind::RemoveDeleteData);const auto accept=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,true));
    if(recovery){interruptAt=st::FileOperationStage::JournalSynced;interruptArmed=true;check(!st::applyFileOperation(f.lease,std::move(p),accept,interrupt)&&st::hasPendingFileOperation(f.lease),"accepted pre-effect removal journal retained");write(c,redo("d7:versioni1ee"));auto result=st::recoverFileOperation(f.lease);check(!result&&result.error().message.find("reordered completion")!=std::string::npos&&read(f.selected.files[0])=="hello"&&fs::exists(f.selected.state)&&st::hasPendingFileOperation(f.lease),"recovery independently refuses newly pending native redo before effects");}
    else{write(c,redo("d7:versioni1ee"));auto result=st::applyFileOperation(f.lease,std::move(p),accept);check(!result&&result.error().message.find("reordered completion")!=std::string::npos&&read(f.selected.files[0])=="hello"&&!st::hasPendingFileOperation(f.lease),"apply revalidates redo before creating operation journal");}
  }
}

void selectionPoliciesMoveAndRecover(){
  const auto setDnd=[](Fixture& f){
    auto state=doc(read(f.selected.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));
    put(attrs,"dnd_sf",b("dnd"));put(attrs,"dnd_pfx",b("skip_"));put(attrs,"incompfilesuffix",b(".part"));
    put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());
  };
  {
    Fixture f;setDnd(f);const auto old=f.selected.files[0],dnd=old.parent_path()/"dnd/skip_file.bin.part";
    take(st::setFilePolicies(f.lease,f.selected.hash,std::vector<biglybtc::compat::FilePolicy>{{true,0}}));
    check(!fs::exists(old)&&read(dnd)=="hello"&&!st::hasPendingFileOperation(f.lease),"Skip moves authenticated incomplete bytes into original DND subfolder");
    auto state=doc(read(f.selected.state));const auto* attrs=state.find("attributes");
    check(attrs->find("storetypes")->children[0].bytes=="L"&&attrs->find("opaque.state")
        &&attrs->find("filelinks2")->children[0].bytes.ends_with(dnd.string()),"Plain skip retains linear storage, unknown attributes and exact physical link");
    take(st::setFilePolicies(f.lease,f.selected.hash,std::vector<biglybtc::compat::FilePolicy>{{false,0}}));
    const auto restored=old.parent_path()/"skip_file.bin.part";
    check(!fs::exists(dnd)&&read(restored)=="hello"&&!fs::exists(old),"Unskip restores parent while retaining name; completion alone removes DND prefix/suffix");
  }
  {
    Fixture f(true);auto state=doc(read(f.selected.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));
    const auto alternate=f.area.root/"alternate";put(attrs,"dnd_al",b(alternate.string()));put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());
    const auto first=read(f.selected.files[0]),second=read(f.selected.files[1]);
    take(st::setFilePolicies(f.lease,f.selected.hash,std::vector<biglybtc::compat::FilePolicy>{{false,0},{true,0}}));
    const auto target=alternate/f.selected.files[1].filename();
    check(read(f.selected.files[0])==first&&read(target)==second&&!fs::exists(f.selected.files[1]),"Alternate DND moves only selected actual file, preserving sibling payload");
    take(st::setFilePolicies(f.lease,f.selected.hash,std::vector<biglybtc::compat::FilePolicy>{{false,0},{false,0}}));
    check(read(f.selected.files[1])==second&&!fs::exists(target),"Unskip restores alternate DND payload using exact original file parent");
  }
  for(const auto point:{st::FileOperationStage::DestinationPublished,st::FileOperationStage::StatePublished,
      st::FileOperationStage::InventoryPublished,st::FileOperationStage::SourceRemoved}){
    Fixture f;setDnd(f);auto other=record(f.profile,f.area.root/"other","survivor.bin",false);f.inventory(other.row);
    auto inventory=doc(read(f.profile/"downloads.config"));const auto original=*core::encodeValue(inventory.find("downloads")->children[0]);
    auto p=take(st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::SetFilePolicies,{},"d1:01:0e",original}));
    auto confirmation=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));
    interruptAt=point;interruptArmed=true;check(!st::applyFileOperation(f.lease,std::move(p),confirmation,interrupt)
        &&st::hasPendingFileOperation(f.lease),"Selection interruption keeps exact existing recovery journal");
    inventory=doc(read(f.profile/"downloads.config"));auto survivor=doc(*core::encodeValue(inventory.find("downloads")->children[1]));
    put(survivor,"downloaded","i97e");put(inventory,"downloads","l"+*core::encodeValue(inventory.find("downloads")->children[0])+survivor.serialize()+'e');
    write(f.profile/"downloads.config",inventory.serialize());
    auto recovered=take(st::recoverFileOperation(f.lease));const auto target=f.selected.files[0].parent_path()/"dnd/skip_file.bin.part";
    check(recovered&&recovered->kind==st::FileOperationKind::SetFilePolicies&&read(target)=="hello"
        &&!fs::exists(f.selected.files[0])&&!st::hasPendingFileOperation(f.lease),"DND recovery settles exact moved bytes without duplicate movement");
    const auto after=doc(read(f.profile/"downloads.config"));auto selected=biglybtc::compat::originalFilePolicy(after.find("downloads")->children[0],1);
    check(selected&&selected->front().skipped&&after.find("downloads")->children[1].find("downloaded")->integer==97
        &&read(other.files[0])==other.values[0],"Selection sparse recovery preserves unrelated checkpoint and survivor payload");
  }
}

void selectionCollisionAndStaleSource(){
  {
    Fixture f;attributes(f,"l1:Ce");write(f.selected.files[0],"x");const auto marker=control(f,0);write(marker,"d7:versioni0e6:lengthi5ee");
    auto state=doc(read(f.selected.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));put(attrs,"dnd_sf",b("dnd"));put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());
    const auto before=read(f.selected.state),raw=read(f.profile/"downloads.config");auto inventory=doc(raw);
    auto p=take(st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::SetFilePolicies,{},"d1:01:0e",*core::encodeValue(inventory.find("downloads")->children[0])}));
    auto accepted=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));interruptAt=st::FileOperationStage::DestinationPublished;interruptArmed=true;
    check(!st::applyFileOperation(f.lease,std::move(p),accepted,interrupt),"nonlinear selection interrupted with control inventory retained");
    check(fs::remove(marker),"owned control removed to test recovery conflict");auto recovered=st::recoverFileOperation(f.lease);
    check(!recovered&&recovered.error().code==st::ErrorCode::Conflict&&st::hasPendingFileOperation(f.lease)
        &&read(f.selected.state)==before&&read(f.profile/"downloads.config")==raw&&read(f.selected.files[0])=="x",
        "Selection recovery never uses removal's absent-control shortcut");
  }
  {
    Fixture f;auto state=doc(read(f.selected.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));
    put(attrs,"dnd_sf",b("dnd"));put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());
    const auto target=f.selected.files[0].parent_path()/"dnd/file.bin";write(target,"other");
    take(st::setFilePolicies(f.lease,f.selected.hash,std::vector<biglybtc::compat::FilePolicy>{{true,0}}));
    check(read(target)=="other"&&read(f.selected.files[0])=="hello","Occupied DND destination is never overwritten; original source stays put");
  }
  {
    Fixture f;auto inventory=doc(read(f.profile/"downloads.config"));const auto original=*core::encodeValue(inventory.find("downloads")->children[0]);
    auto changed=doc(original);put(changed,"position","i9e");put(inventory,"downloads","l"+changed.serialize()+'e');write(f.profile/"downloads.config",inventory.serialize());
    const auto before=read(f.selected.state),raw=read(f.profile/"downloads.config");
    auto result=st::prepareFileOperation(f.lease,{f.selected.hash,st::FileOperationKind::SetFilePolicies,{},"d1:01:0e",original});
    check(!result&&result.error().code==st::ErrorCode::Conflict&&read(f.selected.state)==before
        &&read(f.profile/"downloads.config")==raw&&read(f.selected.files[0])=="hello"&&!st::hasPendingFileOperation(f.lease),
        "Stale selected-row source rejects before state, policy or payload changes");
  }
  {
    Fixture f;auto state=doc(read(f.selected.state)),attrs=doc(*core::encodeValue(*state.find("attributes")));
    put(attrs,"dnd_sf",b("../outside"));put(state,"attributes",attrs.serialize());write(f.selected.state,state.serialize());
    const auto before=read(f.selected.state),raw=read(f.profile/"downloads.config");
    auto result=st::setFilePolicies(f.lease,f.selected.hash,std::vector<biglybtc::compat::FilePolicy>{{true,0}});
    check(!result&&read(f.selected.state)==before&&read(f.profile/"downloads.config")==raw&&read(f.selected.files[0])=="hello"
        &&!st::hasPendingFileOperation(f.lease),"DND path traversal never becomes relocation authority");
  }
}

void realCopyBranch(){
  Fixture f;struct stat from{},to{};check(::stat(f.source.c_str(),&from)==0&&::stat(f.destination.c_str(),&to)==0,"copy fixture dirs");copyFromDev=from.st_dev;copyFromIno=from.st_ino;copyToDev=to.st_dev;copyToIno=to.st_ino;copyHits=0;forceCopy=true;auto p=f.plan(st::FileOperationKind::Relocate);auto c=take(st::confirmFileOperation(p,p.preview().approvalScopeDigest,false));auto result=st::applyFileOperation(f.lease,std::move(p),c);forceCopy=false;take(std::move(result));check(copyHits>0&&read(f.destination/"file.bin")=="hello"&&!fs::exists(f.source/"file.bin"),"EXDEV fallback copies actual bytes and removes source only after publication");
}
}
extern "C" int __real_linkat(int,const char*,int,const char*,int);
extern "C" int __wrap_linkat(int a,const char* x,int b,const char* y,int flags){struct stat from{},to{};if(forceCopy&&std::string_view(x)=="file.bin"&&std::string_view(y)=="file.bin"&&::fstat(a,&from)==0&&::fstat(b,&to)==0&&from.st_dev==copyFromDev&&from.st_ino==copyFromIno&&to.st_dev==copyToDev&&to.st_ino==copyToIno){++copyHits;errno=EXDEV;return -1;}return __real_linkat(a,x,b,y,flags);}
int main(){try{selectionPoliciesMoveAndRecover();selectionCollisionAndStaleSource();keepAndDelete();relocationRecoveryPreservesBothUntilPublication();relinkAndScope();protectionAndConflicts();realCopyBranch();nonlinearControlsAndRecovery();nonlinearBoundaryRefusals();authenticatedExternalLinks();legacyRootsAndDefaultStoreRecovery();pendingReorderedCompletionGuards();std::cout<<"ten generated file-operation families passed\n";return 0;}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
