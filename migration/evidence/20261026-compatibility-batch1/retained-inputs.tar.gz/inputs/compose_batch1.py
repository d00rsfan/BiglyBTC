from pathlib import Path
import hashlib,json,shutil,subprocess
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');h=lambda x:hashlib.sha256(x).hexdigest();out=w/'batch1-composed';assert not out.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=n,text=True).strip()=='9e7f43ec14476bb8091c803a2b37c490b46d4435';assert not subprocess.check_output(['git','status','--porcelain'],cwd=n,text=True).strip()
specs=[('fileops','fileops-performance/manifest.json','b212e320d2ac6d5731093f59ee5d5757755495a1fcea8dffd8b145fa429ef95f'),('fileops','fileops-performance/amendments/apply-receipt-lifetime/manifest.json','c97795850a58d08bd62a897d0ae534429296f728753f2f2bd25969b894c8fa99'),('network','network/manifest-r3.json','4f806abbaa7954ad0dacaab72e14b71b5adc9b1408c6dbfc98906c6e5e7e3111'),('hybrid','hybrid-interop/manifest.json','d6aeaca5d6c415dd671180700487aa04d6f7408c4c19df9e2d2f2e7bb4474277'),('scheduler','scheduler-recovery/manifest.json','45462f7b1a684f1c7dc06ad5b3681b850906249fb569921089a884b380dfae36'),('scheduler','scheduler-recovery/amendments/recovery-capture/manifest.json','d002c7f3c242c66ec52312a24901bf4ab7b2b6f8ddeb6384a272593cadf788f1')]
values={};before={};groups={};records=[]
for group,rel,digest in specs:
 p=w/rel;c=p.parent;assert h(p.read_bytes())==digest,rel;m=json.loads(p.read_text())
 for k in ['files_sha256','artifacts_sha256','artifacts']:
  for leaf,sha in m.get(k,{}).items():assert h((c/leaf).read_bytes())==sha,(rel,leaf)
 for leaf,sha in m['before_sha256'].items():
  assert leaf.startswith('preview/native/') and '..' not in Path(leaf).parts
  actual=values.get(leaf,(n/leaf).read_bytes());assert h(actual)==sha,(rel,leaf,'before')
  if leaf not in before:before[leaf]=h((n/leaf).read_bytes())
  assert leaf not in groups or groups[leaf]==group;groups[leaf]=group
  data=(c/m.get('source_directory','staging')/leaf).read_bytes();assert h(data)==m['source_sha256'][leaf],(rel,leaf,'after');values[leaf]=data
 records.append({'group':group,'manifest':rel,'sha256':digest})
leaf='preview/native/tests/CMakeLists.txt';before[leaf]=h((n/leaf).read_bytes());values[leaf]=(n/leaf).read_bytes()+b'\n'+(w/'fileops-performance/tests-cmake.fragment.cmake').read_bytes();groups[leaf]='fileops'
for leaf,data in values.items():
 p=out/'staging'/leaf;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
m={'schema':1,'base':'9e7f43ec14476bb8091c803a2b37c490b46d4435','status':'COMPOSED_SOURCE_ONLY','before_sha256':before,'source_sha256':{p:h(v) for p,v in values.items()},'groups':{g:sorted(p for p,v in groups.items() if v==g) for g in ['fileops','network','hybrid','scheduler']},'capsules':records};(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'paths':len(values),'groups':{g:len(v) for g,v in m['groups'].items()},'manifest_sha256':h((out/'manifest.json').read_bytes())}))
for leaf in ['compile.py','check.py']:
 src=w.parent/'storage-20261025'/leaf;dst=w/leaf;assert not dst.exists();shutil.copy2(src,dst)
