from pathlib import Path
import concurrent.futures,json,os,subprocess,time
w=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');builds={'gcc':'build/persistent-peer-accounting-20261021/bound-gcc','clang':'build/saved-services-20261018/clang','san':'build/saved-services-20261018/sanitized-desktop'}
def wait(stem):
 p=w/(stem+'-receipt.json');end=time.monotonic()+7200
 while not p.exists():
  assert time.monotonic()<end,stem;time.sleep(2)
 r=json.loads(p.read_text());assert r['exit']==0,(stem,r);return r

def test(lane):
 env=os.environ.copy()
 if lane=='gcc':env['BIGLYBTC_SCHEDULER_CAPTURE_DIRECTORY']=str(w/'captures/batch1-gcc')
 subprocess.run(['python3','-B',str(w/'run_matrix_checks.py'),'batch1-'+lane+'-tests-r1',builds[lane],'batch1-plan.json'],cwd=w.parents[1],env=env,check=True)
 return {'lane':lane,'status':'PASS','case':'batch1-'+lane+'-tests-r1'}
def gcc():wait('batch1-gcc-build-r1');return test('gcc')
def clang():
 wait('batch1-gcc-build-r1');subprocess.run(['python3','-B',str(w/'run_batch1_build.py'),'batch1-clang-build-r1',builds['clang'],'2'],cwd=w.parents[1],check=True);return test('clang')
def san():wait('batch1-san-build-r1');return test('san')
def oracle():
 wait('batch1-gcc-build-r1');out=w/'hybrid-interop/runs/run-r1';script=w/'hybrid-interop/oracle/run.py';cmd=['nice','-n','5','python3','-B',str(script),'--driver',str(n/builds['gcc']/'tests/biglybtc-selected-hybrid-handoff-driver'),'--output',str(out)];start=time.monotonic()
 with(w/'batch1-hybrid-oracle-r1.log').open('x') as f:r=subprocess.run(cmd,cwd=script.parent.parent,stdout=f,stderr=subprocess.STDOUT)
 (w/'batch1-hybrid-oracle-r1-receipt.json').write_text(json.dumps({'command':cmd,'exit':r.returncode,'seconds':round(time.monotonic()-start,2)},indent=2)+'\n');assert r.returncode==0,'Actual hybrid oracle failed; raw log retained';return {'lane':'actual-java-hybrid4','status':'PASS','result':str(out.relative_to(w))}
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 fs={pool.submit(fn):fn.__name__ for fn in [gcc,clang,san,oracle]}
 for f in concurrent.futures.as_completed(fs):
  try:r=f.result()
  except Exception as e:r={'lane':fs[f],'status':'FAIL','error':repr(e)}
  results.append(r);(w/'batch1-remaining-status.json').write_text(json.dumps({'results':results},indent=2)+'\n');print(json.dumps(r),flush=True)
assert all(r['status']=='PASS' for r in results),results
