#pragma once
#define BIGLYBTC_PERSISTENT_RUNTIME_BOUND 1
namespace biglybtc::engine::detail::runtime_binding {
inline constexpr char artifact[] = "/home/yurii/Java/BiglyBT/build/compatibility-20261026/provider-webseed/install/lib/libtorrent-rasterbar.so.2.0.12";
inline constexpr char sha256[] = "d33c17c73c3c377cedd88256b0b48e472b2de55f0a95a890e2837556e1d1002a";
inline constexpr char manifest[] = "ea82f78982a1428eb64067719cf30bbca7cfd09dd2abfcf8f76024f6e6ed41d5";
inline constexpr unsigned long long bytes = 9085128ULL;
}
