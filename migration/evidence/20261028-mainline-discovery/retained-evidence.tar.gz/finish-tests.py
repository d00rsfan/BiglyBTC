from pathlib import Path
import sys,os,subprocess,json,time,hashlib,xml.etree.ElementTree as E
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/mainline-discovery-20261028';lane=sys.argv[1]
B={'gcc':N/'build/persistent-peer-accounting-20261021/bound-gcc','clang':N/'build/saved-services-20261018/clang','san':N/'build/saved-services-20261018/sanitized-desktop'}[lane]
prior=W/('native-'+lane+('-r3' if lane!='san' else ''));out=W/('magnet-followup-'+lane);out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=list(E.fromstring((prior/'tests.xml').read_bytes()).iter('testcase'));assert [x.get('name') for x in old if x.find('failure') is not None]==['managed-magnet'];passed=[x.get('name') for x in old if x.find('failure') is None];assert all(x.find('skipped') is None and x.find('error') is None for x in old)
images={name:B/'tests'/('biglybtc-'+name+'-tests' if name!='owned-fixture-read-diagnostic' else 'biglybtc-owned-fixture-read-tests') for name in passed}
if lane=='gcc':images.update({'BiglyBTC':B/'app/BiglyBTC','BiglyBTC-headless':B/'app/BiglyBTC-headless','preview-smoke':B/'biglybtc-preview-smoke'})
before={k:sha(v) for k,v in images.items()};source=subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD'],text=True).strip();base='7ebca694ed5300e7e2d97a4107faae99f993ae7f';assert subprocess.check_output(['git','-C',str(N),'diff','--name-only',base,source],text=True).splitlines()==['preview/native/tests/managed_magnet_tests.cpp']
env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1');env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None)
if lane=='san':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
rows=[]
for name,cmd in [('build',['nice','-n','5','cmake','--build',str(B),'--parallel','1','--target','biglybtc-managed-magnet-tests']),('tests',['ctest','--test-dir',str(B),'-R','^managed-magnet$','--output-on-failure','--output-junit',str(out/'tests.xml')])]:
 t=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 rows.append({'name':name,'command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-t,3)});(out/'commands.json').write_text(json.dumps({'source_commit':source,'commands':rows},indent=2)+'\n');print(lane,name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
actual=list(E.fromstring((out/'tests.xml').read_bytes()).iter('testcase'));assert len(actual)==1 and actual[0].get('name')=='managed-magnet' and all(actual[0].find(x) is None for x in ('failure','error','skipped'))
after={k:sha(v) for k,v in images.items()};assert before==after
result={'status':'PASS_WITH_EXPLICIT_UNCHANGED_SUCCESS_REUSE','lane':lane,'application_source':base,'test_followup_source':source,'prior_actual_process_exit':8,'prior_suites':len(old),'reused_successful_suites':passed,'new_actual_suites':['managed-magnet'],'effective_suites':len(old),'unchanged_images_sha256':before,'new_magnet_image_sha256':sha(B/'tests/biglybtc-managed-magnet-tests'),'prior_receipt':str(prior/'commands.json'),'note':'No whole-group rerun or synthetic exit0; old failed processes remain failed'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(lane,'effective PASS',len(old),flush=True)
