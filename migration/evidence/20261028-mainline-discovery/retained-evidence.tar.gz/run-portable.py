from pathlib import Path
import os,subprocess,time,json,hashlib,re,shutil,tempfile,xml.etree.ElementTree as ET
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/mainline-discovery-20261028';P=R/'build/network-reliability-20261028/provider-socks-lifecycle';B=N/'build/persistent-peer-accounting-20261021/bound-gcc';out=W/'private-runtime';out.mkdir(exist_ok=False);candidate=out/'candidate';rows=[];env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1');env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,cmd,expected=0,timeout=240):
 t=time.monotonic()
 with (out/(name+'.log')).open('wb') as f:p=subprocess.run(list(map(str,cmd)),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 rows.append(dict(name=name,command=list(map(str,cmd)),exit=p.returncode,expected_exit=expected,seconds=round(time.monotonic()-t,3)));(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==expected,name
run('stage',['python3',N/'preview/migration/tools/stage_preview.py','--build',B,'--output',candidate,'--libtorrent-package',N/'build/dependencies/packages/libtorrent-rasterbar2.0t64_2.0.12-1_amd64.deb','--source-libtorrent',P/'install/lib/libtorrent-rasterbar.so.2.0.12','--private-socks-provider-manifest',N/'preview/native/engine/runtime-binding/provider-socks-runtime.json'])
private=candidate/'usr/lib/biglybtc';env['LD_LIBRARY_PATH']=os.pathsep.join(map(str,[private/'lib',private/'qt/lib',candidate/'dependencies/libtorrent/usr/lib/x86_64-linux-gnu']));env['QT_PLUGIN_PATH']=str(private/'qt/plugins');env['QT_QPA_PLATFORM_PLUGIN_PATH']=str(private/'qt/plugins/platforms')
provider=private/'lib/libtorrent-rasterbar.so.2.0.12';assert sha(provider)==sha(P/'install/lib/libtorrent-rasterbar.so.2.0.12')
manifest=candidate/'BUILD_MANIFEST.json';pin=sha(manifest);d=json.loads(manifest.read_bytes())
for rel,expected in d['files_sha256'].items():assert sha(candidate/rel)==expected,rel
support=out/'test-support';support.mkdir();qt_test=Path('/opt/Qt/6.12.0/gcc_64/lib/libQt6Test.so.6').resolve();shutil.copyfile(qt_test,support/'libQt6Test.so.6');assert sha(qt_test)==sha(support/'libQt6Test.so.6');env['LD_LIBRARY_PATH']=str(support)+os.pathsep+env['LD_LIBRARY_PATH']
(out/'test-support.json').write_text(json.dumps({'source':str(qt_test),'sha256':sha(qt_test)},indent=2)+'\n')
bins=out/'owner-tests';bins.mkdir();names=['biglybtc-mainline-dht-tests','biglybtc-managed-magnet-tests','biglybtc-preview-smoke'];loaders={}
for name in names:
 src=B/name if name=='biglybtc-preview-smoke' else B/'tests'/name;target=bins/name;shutil.copyfile(src,target);target.chmod(0o755);assert sha(src)==sha(target)
 linked=subprocess.check_output(['ldd',str(target)],env=env,text=True);assert 'not found' not in linked and '/opt/Qt' not in linked;loaded=re.findall(r'^\s*(lib(?:Qt6[^ ]*|torrent-rasterbar[^ ]*)) => (/.*?) \(',linked,re.M);assert loaded and all((Path(path).resolve().is_relative_to(candidate.resolve()) or Path(path).resolve()==support/'libQt6Test.so.6') for _,path in loaded);loaders[name]={lib:str(Path(path).resolve()) for lib,path in loaded}
(out/'private-loaders.json').write_text(json.dumps(loaders,indent=2)+'\n')
sample=Path(tempfile.mkdtemp(prefix='biglybtc-preview-',dir='/tmp'));sample.rmdir();run('prepare-owned-profile',[candidate/'BiglyBTC-preview','--prepare',sample]);
for key in ('XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR'):
 directory=sample/key.lower();directory.mkdir(mode=0o700);env[key]=str(directory)
env.update(BIGLYBTC_PREVIEW_PROFILE=str(sample/'profile'),BIGLYBTC_PREVIEW_CAPTURE=str(sample/'classic-preview.png'),LD_DEBUG='libs')
run('normal-launcher-usage',[candidate/'BiglyBTC'],expected=2,timeout=30)
run('offline-preview-owned-stop',['timeout','--signal=TERM','--kill-after=5s','8s',candidate/'BiglyBTC-preview'],expected=124,timeout=20)
initialised={}
for name in ('normal-launcher-usage','offline-preview-owned-stop'):
 paths=[Path(x.strip()).resolve() for x in re.findall(r'calling init:\s*([^\n]+)',(out/(name+'.log')).read_text(errors='replace'))];assert provider.resolve() in paths and (private/'qt/lib/libQt6Core.so.6').resolve() in paths
 if name=='offline-preview-owned-stop':assert (private/'qt/plugins/platforms/libqoffscreen.so').resolve() in paths
 initialised[name]=[str(x) for x in paths if x.is_relative_to(candidate.resolve())]
(out/'actual-loader-init.json').write_text(json.dumps(initialised,indent=2)+'\n');env.pop('LD_DEBUG')
for name in names:
 run(name,[bins/name,'-o',str(out/(name+'.txt'))+',txt','-o',str(out/(name+'.xml'))+',junitxml'],timeout=300)
 cases=list(ET.fromstring((out/(name+'.xml')).read_bytes()).iter('testcase'));assert cases and not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped')),name
assert sha(manifest)==pin
for rel,expected in d['files_sha256'].items():assert sha(candidate/rel)==expected,rel
result={'status':'PASS_PRIVATE_RELOCATED_RUNTIME','candidate':str(candidate),'manifest_sha256':pin,'verified_leaves':len(d['files_sha256']),'provider_sha256':sha(provider),'actual_test_binaries':names,'normal_usage_exit':2,'offline_preview_controlled_exit':124,'loader_init_verified':True,'sample':str(sample),'shipping_approved':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PRIVATE_RUNTIME_PASS',len(d['files_sha256']),'leaves',flush=True)
