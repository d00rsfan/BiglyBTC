SOURCE ONLY. No author compile/run. Owned numeric-loopback protocol fixture, no Qt, payload forwarding, public DNS, retries or sleeps. The only resolver input is the proxy127.0.0.1; destination.invalid names are merely SOCKS wire bytes.

Causal boundary: libtorrent proxy_base.hpp wrap_allocator_t forwards the final handler associated executor. GateExecutor intercepts its first REAL resolver completion delivery and calls stream.close before invoking the wrapped resolver callback. close must have returned with the socket closed. On old source the ec0 continuation then reopens the proxy socket and emits exactly05010001000000000000 (CONNECT0.0.0.0:0). A successful method reply/CONNECT reply comes only from our owned protocol parser; no destination connection occurs.

Controls: ordinary name/port must traverse real auth/CONNECT, and fresh same-stream reuse after the cancelled chain completely drains must traverse a different exact name/port. Each actual user handler must run exactly once. Fixed mode requires operation_aborted, no proxy accept or CONNECT, closed socket at completion, both controls valid. Old observation mode requires the exact reopened zero-CONNECT causal trace, not arbitrary failure. The5s timers are failure bounds, never evidence of a missing route. Three phases, no owned threads; cancellation closes every owned socket and drains all callbacks. Concurrent reuse/shared-buffer overlap and error-callback reentry are intentionally not tested here.

Reusable configure/build (root only; source+install must refer to the SAME reviewed provider; fresh build dirs):
cmake -S /home/yurii/Java/BiglyBT/build/network-reliability-20261028/cancel-fixture -B "$CANCEL_BUILD" -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=/usr/bin/g++-16 -DCANCEL_PROVIDER_INSTALL="$CANCEL_INSTALL" -DCANCEL_PROVIDER_SOURCE="$CANCEL_SOURCE" -DCMAKE_PREFIX_PATH="$CANCEL_INSTALL;/home/yurii/Java/BiglyBTC/build/dependencies/sysroot/usr"
cmake --build "$CANCEL_BUILD" --parallel 1

Baseline paths:
CANCEL_SOURCE=/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027/provider-traffic-v3/source
CANCEL_INSTALL=/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027/provider-traffic-v3/install
Run baseline executable explicitly with --expect-legacy. Exit0 reports OBSERVED_LEGACY_CANCEL_REOPEN_ZERO_CONNECT; this is diagnostic defect evidence, not provider qualification.

For the future separately built/installed lifecycle provider, configure another fresh build with its exact source/install. CTest name socks-cancellation runs --expect-fixed; retain actual build command/log/binary/source/SDK pins and verbose test output/XML. CMake compares both stream headers byte-for-byte source vs installed and uses only the requested package-config directory. Exact proxy_base.cpp is compiled into this standalone executable because its ctor/dtor are intentionally not exported by the DSO. All async stream implementation comes from the selected installed SDK; no patched header is mixed with the old binary.
