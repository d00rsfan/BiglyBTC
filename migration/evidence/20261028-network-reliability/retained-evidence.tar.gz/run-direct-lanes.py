from pathlib import Path
import subprocess,os,json,time,xml.etree.ElementTree as ET
R=Path('/home/yurii/Java/BiglyBT');W=R/'build/network-reliability-20261028';P=W/'provider-socks-lifecycle'
for lane,compiler,flags in [('clang','/usr/bin/clang++-24',''),('san','/usr/bin/g++-16','-fsanitize=address,undefined -fno-omit-frame-pointer -fno-sanitize-recover=all')]:
 out=W/('direct-'+lane);out.mkdir(exist_ok=False);rows=[];env=os.environ.copy();env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None)
 if lane=='san':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
 steps=[('configure',['cmake','-S',str(P/'cancel-fixture'),'-B',str(out/'build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER='+compiler,'-DCMAKE_CXX_FLAGS='+flags,'-DCMAKE_PREFIX_PATH=/home/yurii/Java/BiglyBTC/build/dependencies/sysroot/usr','-DCANCEL_PROVIDER_INSTALL='+str(P/'install'),'-DCANCEL_PROVIDER_SOURCE='+str(P/'source')]),('build',['nice','-n','5','cmake','--build',str(out/'build'),'--parallel','1']),('tests',['ctest','--test-dir',str(out/'build'),'--output-on-failure','--output-junit',str(out/'tests.xml')])]
 for name,cmd in steps:
  t=time.monotonic()
  with (out/(name+'.log')).open('wb') as f:d=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  rows.append({'name':name,'command':cmd,'exit':d.returncode,'seconds':round(time.monotonic()-t,3)});(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print('direct-'+lane,name,d.returncode,flush=True)
  if d.returncode:raise SystemExit(d.returncode)
 tests=list(ET.fromstring((out/'tests.xml').read_bytes()).iter('testcase'));assert len(tests)==1 and tests[0].get('name')=='socks-cancellation' and all(tests[0].find(x) is None for x in ('failure','error','skipped'))
 (out/'direct-detail.log').write_bytes((out/'build/Testing/Temporary/LastTest.log').read_bytes());(out/'result.json').write_text(json.dumps({'status':'PASS','lane':lane,'actual_suites':1,'actual_phase_cases':7,'sanitizer_environment':{k:v for k,v in env.items() if k in ('ASAN_OPTIONS','UBSAN_OPTIONS')}},indent=2)+'\n')
