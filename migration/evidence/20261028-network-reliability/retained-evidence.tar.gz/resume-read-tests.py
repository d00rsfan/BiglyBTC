from pathlib import Path
import json,hashlib,os,subprocess,time,xml.etree.ElementTree as ET
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/network-reliability-20261028';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fix=json.loads((W/'read-fixture-correction-commit.json').read_bytes());head=fix['commit'];assert subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD'],text=True).strip()==head
lanes={'gcc':(N/'build/persistent-peer-accounting-20261021/bound-gcc',W/'native-gcc-r2'),'clang':(N/'build/saved-services-20261018/clang',W/'native-clang'),'san':(N/'build/saved-services-20261018/sanitized-desktop',W/'native-san')}
for lane,(cache,old) in lanes.items():
 subject=cache/'tests/biglybtc-owned-fixture-read-tests';images={p:pin for p,pin in fix['other_images_before'][lane].items() if p!=str(subject)}
 assert all(sha(Path(p))==pin for p,pin in images.items());out=W/('read-followup-'+lane);env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1');env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None)
 if lane=='san':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
 if lane=='gcc':
  rows=json.loads((out/'commands.json').read_bytes());assert [r['name'] for r in rows]==['build','tests'] and all(r['exit']==0 for r in rows)
 else:
  out.mkdir(exist_ok=False);rows=[]
  for name,cmd in [('build',['nice','-n','5','cmake','--build',str(cache),'--parallel','1','--target','biglybtc-owned-fixture-read-tests']),('tests',['ctest','--test-dir',str(cache),'-R','^owned-fixture-read-diagnostic$','--output-on-failure','--output-junit',str(out/'tests.xml')])]:
   t=time.monotonic()
   with (out/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
   rows.append({'name':name,'command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-t,3)});(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print('read-followup-'+lane,name,p.returncode,flush=True)
   if p.returncode:raise SystemExit(p.returncode)
 cases=list(ET.fromstring((out/'tests.xml').read_bytes()).iter('testcase'));assert len(cases)==1 and all(cases[0].find(x) is None for x in ('failure','error','skipped'));assert all(sha(Path(p))==pin for p,pin in images.items())
 previous=json.loads((old/'commands.json').read_bytes());raw=list(ET.fromstring((old/'tests.xml').read_bytes()).iter('testcase'));passed=[c.get('name') for c in raw if all(c.find(t) is None for t in ('failure','error','skipped'))];assert len(passed)==(16 if lane=='gcc' else 2)
 result={'status':'PASS_WITH_EXPLICIT_UNCHANGED_SUCCESS_REUSE','lane':lane,'final_test_source_commit':head,'actual_new_suite':'owned-fixture-read-diagnostic','actual_new_test_binary_sha256':sha(subject),'other_images_byte_identical':images,'reused_successful_suites':passed,'prior_whole_test_exit':8,'prior_source_commit':previous['source_commit'],'raw_result':str(old/'tests.xml'),'association_recovery':'Changed read test mistakenly included in GCC unchanged-image cohort; excluded only that expected changed subject, all other image bytes match. Existing successful GCC build/test receipts reused without executions.'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('effective-'+lane,len(passed)+1,'suites PASS; only read suite rerun',flush=True)
(W/'read-association-recovery.json').write_text(json.dumps({'status':'PROOF_COHORT_CORRECTED_WITHOUT_GCC_EXECUTION','root_cause':'Expected changed read subject was included in a generic unchanged-target snapshot','corrected':'Exclude exactly the rebuilt read subject; preserve/check every other recorded image','gcc_reexecutions':0},indent=2)+'\n')
