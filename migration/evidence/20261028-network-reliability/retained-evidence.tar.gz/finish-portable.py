from pathlib import Path
import os,subprocess,json,hashlib,shutil,time,xml.etree.ElementTree as ET
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/network-reliability-20261028';out=W/'private-runtime';candidate=out/'candidate';private=candidate/'usr/lib/biglybtc';B=N/'build/persistent-peer-accounting-20261021/bound-gcc';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for lane in ('gcc','clang','san'):assert json.loads((W/('read-followup-'+lane)/'result.json').read_bytes())['status']=='PASS_WITH_EXPLICIT_UNCHANGED_SUCCESS_REUSE'
old=json.loads((out/'commands.json').read_bytes());rows=[];reuse=['biglybtc-network-proxy-owner-tests','biglybtc-network-binding-owner-tests','biglybtc-persistent-session-tests','biglybtc-provider-payload-counter-tests']
for name in reuse:
 assert any(c['name']==name and c['exit']==0 for c in old);assert sha(out/'owner-tests'/name)==sha(B/'tests'/name)
 cases=list(ET.fromstring((out/(name+'.xml')).read_bytes()).iter('testcase'));assert cases and not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped'))
assert any(c['name']=='stage' and c['exit']==0 for c in old) and any(c['name']=='normal-launcher-usage' and c['exit']==2 for c in old) and any(c['name']=='offline-preview-owned-stop' and c['exit']==124 for c in old)
sample=Path(next(c['command'][-1] for c in old if c['name']=='prepare-owned-profile'));assert sample.parent==Path('/tmp') and sample.name.startswith('biglybtc-preview-') and (sample/'profile').is_dir()
env=os.environ.copy();env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None);env.pop('LD_DEBUG',None);env.update(QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1',LD_LIBRARY_PATH=os.pathsep.join(map(str,[out/'test-support',private/'lib',private/'qt/lib',candidate/'dependencies/libtorrent/usr/lib/x86_64-linux-gnu'])),QT_PLUGIN_PATH=str(private/'qt/plugins'),QT_QPA_PLATFORM_PLUGIN_PATH=str(private/'qt/plugins/platforms'),BIGLYBTC_PREVIEW_PROFILE=str(sample/'profile'),BIGLYBTC_PREVIEW_CAPTURE=str(sample/'classic-preview.png'))
for key in ('XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_RUNTIME_DIR'):env[key]=str(sample/key.lower())
test_support=json.loads((out/'test-support.json').read_bytes());assert sha(out/'test-support/libQt6Test.so.6')==test_support['sha256']
for name in ['biglybtc-owned-fixture-read-tests','biglybtc-preview-smoke']:
 source=B/name if name=='biglybtc-preview-smoke' else B/'tests'/name;target=out/'owner-tests'/name
 if name=='biglybtc-preview-smoke':assert sha(source)==sha(target)
 else:shutil.copyfile(source,target);target.chmod(0o755)
 cmd=[str(target),'-o',str(out/(name+'-followup.txt'))+',txt','-o',str(out/(name+'-followup.xml'))+',junitxml'];t=time.monotonic()
 with (out/(name+'-followup-process.log')).open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 rows.append({'name':name,'command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-t,3)});(out/'followup-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print('portable-followup',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 cases=list(ET.fromstring((out/(name+'-followup.xml')).read_bytes()).iter('testcase'));assert cases and not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped'))
 if name=='biglybtc-preview-smoke':assert len(cases)>=13
manifest=candidate/'BUILD_MANIFEST.json';m=json.loads(manifest.read_bytes())
for rel,pin in m['files_sha256'].items():assert sha(candidate/rel)==pin,rel
result={'status':'PASS_PRIVATE_RUNTIME_WITH_EXPLICIT_TEST_FIXTURE_FOLLOWUP','candidate':str(candidate),'manifest_sha256':sha(manifest),'verified_leaves':len(m['files_sha256']),'provider_sha256':sha(private/'lib/libtorrent-rasterbar.so.2.0.12'),'reused_actual_positive_suites':reuse,'new_read_diagnostic_suite':True,'new_smoke_suite':True,'prior_whole_process_result':'Failed new directory fixture assumption; retained, not relabelled','application_build_source':'ec948313479d6cb351cd8ed4724d551f5ff54f4e','final_test_source':json.loads((W/'read-fixture-correction-commit.json').read_bytes())['commit'],'normal_usage_exit':2,'offline_preview_controlled_exit':124,'private_loader_init_verified':True,'shipping_approved':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print('PRIVATE_RUNTIME_PASS_WITH_EXPLICIT_FOLLOWUP',len(m['files_sha256']),'leaves',flush=True)
