from pathlib import Path
import hashlib,json,shutil
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/network-reliability-20261028';P=W/'provider-socks-lifecycle';B=N/'preview/native/engine/runtime-binding';S=W/'binding-staging';S.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((P/'source-build-record.json').read_bytes());record_sha=sha(P/'source-build-record.json')
manifest={k:record[k] for k in ('schema','causal_qualified','source_root','build_root','install_root','artifact','artifact_sha256','artifact_bytes')};manifest.update(purpose='source-bound-qualification-only',source_build_record='provider-socks-source-build-record.json',source_build_record_sha256=record_sha)
(S/'provider-socks-runtime.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copyfile(P/'source-build-record.json',S/'provider-socks-source-build-record.json');manifest_sha=sha(S/'provider-socks-runtime.json')
s=(B/'verify_runtime_manifest_traffic.py').read_text().replace("MANIFEST_SHA = '5901b34eeb25370106bdbf6185a80f0c86c62a837bf2e455f5619921db665760'",f"MANIFEST_SHA = '{manifest_sha}'").replace("RECORD_SHA = '91218c17d3e74bb79a0fea0cfbbf3734e3422895e59f46fad4cb6b17e2927fd0'",f"RECORD_SHA = '{record_sha}'")
s=s.replace("PARENT_HELPER_SHA = 'd53a3efa5160764ac48212c0ce0c85aa0fad4e1d1760ea13c3c9f2e2aa6a0bf0'",f"PARENT_HELPER_SHA = '{sha(B/'verify_runtime_manifest_traffic.py')}'")
s=s.replace("CANDIDATE = '/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027/provider-traffic-v3'",f"CANDIDATE = '{P}'")
s=s.replace("with_name('verify_runtime_manifest_queue.py')","with_name('verify_runtime_manifest_traffic.py')").replace("old.parent().parent_helpers()","old.parent().parent().parent_helpers()")
s=s.replace('provider-traffic-source-build-record.json','provider-socks-source-build-record.json').replace("path.parent/'provider-queue-runtime.json'","path.parent/'provider-traffic-runtime.json'")
s=s.replace("('traffic-tests',{'traffic-v3-owned-corrupt-duplicate'})]", "('traffic-tests',{'traffic-v3-owned-corrupt-duplicate'}),('cancel-tests',{'socks-cancellation'})]")
s=s.replace("'traffic-configure','traffic-build','traffic-tests']", "'traffic-configure','traffic-build','traffic-tests','cancel-configure','cancel-build','cancel-tests']")
s=s.replace("'provider_traffic_v3':True", "'provider_traffic_v3':True,'provider_socks_cancellation':True")
s=s.replace('Exact additive queue observer','Exact additive SOCKS cancellation').replace('biglybtc_traffic_parent','biglybtc_socks_parent')
(S/'verify_runtime_manifest_socks.py').write_text(s)
# Each old selector and cohort remains immutable; this new one selects only its pinned artifact.
stager=N/'preview/migration/tools/stage_preview.py';text=stager.read_text();start=text.index('# Additive exact traffic-V3 lane.');end=text.index('\ndef main(',start)
block=text[start:end].replace('PRIVATE_TRAFFIC','PRIVATE_SOCKS').replace('private_traffic','private_socks').replace('provider-traffic-source-build-record.json','provider-socks-source-build-record.json').replace('verify_runtime_manifest_traffic.py','verify_runtime_manifest_socks.py')
old_sha='98279a468e0fa5147876b6f22f8947f432c294dfc02fb50cf179fc9472b3b51f';block=block.replace(old_sha,record['artifact_sha256']).replace('9090088',str(record['artifact_bytes'])).replace('5901b34eeb25370106bdbf6185a80f0c86c62a837bf2e455f5619921db665760',manifest_sha).replace('/home/yurii/Java/BiglyBT/build/compatibility-chapter-20261027/provider-traffic-v3',str(P))
records=json.loads('{}');ns={'__file__':str(stager)};exec(compile(text[:text.index('def private_traffic_source_libtorrent')],str(stager),'exec'),ns)
records={'provider-socks-source-build-record.json':record_sha,**ns['PRIVATE_TRAFFIC_RECORDS']};verifiers={'verify_runtime_manifest_socks.py':sha(S/'verify_runtime_manifest_socks.py'),**ns['PRIVATE_TRAFFIC_VERIFIERS']}
lines=block.splitlines();lines=[('PRIVATE_SOCKS_RECORDS = '+repr(records)) if l.startswith('PRIVATE_SOCKS_RECORDS = ') else ('PRIVATE_SOCKS_VERIFIERS = '+repr(verifiers)) if l.startswith('PRIVATE_SOCKS_VERIFIERS = ') else l for l in lines];block='\n'.join(lines)+'\n'
block=block.replace('"provider_queue_observer": True, "provider_traffic_v3": True,','"provider_queue_observer": True, "provider_traffic_v3": True, "provider_socks_cancellation": True,')
block=block.replace('PRIVATE_SOCKS_RECORDS["provider-queue-source-build-record.json"]','PRIVATE_SOCKS_RECORDS["provider-traffic-source-build-record.json"]').replace('source-built-private-socks4a-webseed-queue-traffic-v3','source-built-private-socks-cancellation-traffic-v3')
text=text[:end]+ '\n'+block+text[end:]
anchor='    args = parser.parse_args()';text=text.replace(anchor,'    parser.add_argument("--private-socks-provider-manifest", type=Path,\n        help="Private qualification only: exact cancellation-fixed source/SDK/history cohort")\n'+anchor)
anchor='    if args.private_traffic_provider_manifest is not None:'
new='    if args.private_socks_provider_manifest is not None:\n        if any(value is not None for value in (args.private_traffic_provider_manifest, args.private_webseed_provider_manifest, args.private_source_provider_manifest, args.source_provider_manifest)):\n            parser.error("Select one explicit private or existing provider manifest")\n        if args.source_libtorrent is None:\n            parser.error("--private-socks-provider-manifest also requires --source-libtorrent")\n'
text=text.replace(anchor,new+anchor,1)
text=text.replace('            if args.private_traffic_provider_manifest is not None:', '            if args.private_socks_provider_manifest is not None:\n                source = private_socks_source_libtorrent(args.source_libtorrent, args.private_socks_provider_manifest, args.build)\n            elif args.private_traffic_provider_manifest is not None:',1)
text=text.replace('        if args.private_traffic_provider_manifest is not None:\n            provider =', '        if args.private_socks_provider_manifest is not None:\n            provider = install_private_socks_libtorrent(destination, dependency, *source)\n        elif args.private_traffic_provider_manifest is not None:\n            provider =',1)
text=text.replace('or args.private_traffic_provider_manifest is not None:', 'or args.private_traffic_provider_manifest is not None or args.private_socks_provider_manifest is not None:')
(S/'stage_preview.py').write_text(text)
(P/'binding-identities.json').write_text(json.dumps({'record_sha256':record_sha,'manifest_sha256':manifest_sha,'artifact_sha256':record['artifact_sha256'],'artifact_bytes':record['artifact_bytes'],'helper_sha256':sha(S/'verify_runtime_manifest_socks.py')},indent=2)+'\n')
print('Binding/stager staged against actual provider source/artifact record; not adopted')
