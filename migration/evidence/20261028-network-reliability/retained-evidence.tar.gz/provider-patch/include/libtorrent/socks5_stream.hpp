/*

Copyright (c) 2007, 2009-2010, 2013-2020, Arvid Norberg
Copyright (c) 2016, Alden Torres
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the distribution.
    * Neither the name of the author nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef TORRENT_SOCKS5_STREAM_HPP_INCLUDED
#define TORRENT_SOCKS5_STREAM_HPP_INCLUDED

#include <functional>
#include <memory>
#include <vector>

#include "libtorrent/proxy_base.hpp"
#include "libtorrent/biglybtc_socks4a.hpp"
#include "libtorrent/address.hpp"
#include "libtorrent/aux_/ip_helpers.hpp" // for is_ip_address
#include "libtorrent/assert.hpp"
#include "libtorrent/debug.hpp"
#include "libtorrent/string_util.hpp" // for to_string
#include "libtorrent/socket_io.hpp"

namespace libtorrent {

namespace socks_error {

	// SOCKS5 error values. If an error_code has the
	// socks error category (get_socks_category()), these
	// are the error values.
	enum socks_error_code
	{
		no_error = 0,
		unsupported_version,
		unsupported_authentication_method,
		unsupported_authentication_version,
		authentication_error,
		username_required,
		general_failure,
		command_not_supported,
		no_identd,
		identd_error,

		num_errors
	};

	// internal
	TORRENT_EXPORT boost::system::error_code make_error_code(socks_error_code e);

} // namespace socks_error
}

namespace boost {
namespace system {

	template<> struct is_error_code_enum<libtorrent::socks_error::socks_error_code>
	{ static const bool value = true; };

}
}

namespace libtorrent {

// returns the error_category for SOCKS5 errors
TORRENT_EXPORT boost::system::error_category& socks_category();

#if TORRENT_ABI_VERSION == 1
TORRENT_DEPRECATED
inline boost::system::error_category& get_socks_category()
{ return socks_category(); }
#endif

class socks5_stream : public proxy_base
{
	// Socket operations retain their buffers until completion, including
	// when close() is followed immediately by another connect.
	struct connect_attempt
	{
		std::vector<char> buffer;
	};
	using attempt_ptr = std::shared_ptr<connect_attempt>;

public:

	// commands
	enum {
		socks5_connect = 1,
		socks5_udp_associate = 3
	};

	socks5_stream(socks5_stream&&) = default;
	explicit socks5_stream(io_context& io_context)
		: proxy_base(io_context)
		, m_version(5)
		, m_command(socks5_connect)
	{}

	void set_version(int v) { m_version = v; }

	void set_command(int c)
	{
		TORRENT_ASSERT(c == socks5_connect || c == socks5_udp_associate);
		m_command = c;
	}

	void set_username(std::string const& user
		, std::string const& password)
	{
		m_user = user;
		m_password = password;
	}

	void set_dst_name(std::string const& host)
	{
		// if this assert trips, set_dst_name() is called with an IP address rather
		// than a hostname. Instead, resolve the IP into an address and pass it to
		// async_connect instead
		TORRENT_ASSERT(!aux::is_ip_address(host));
		m_dst_name = host;
		// The private 4a path rejects an overlong name in socks_connect rather
		// than silently changing its destination. The factory sets version first.
		if (m_dst_name.size() > 255 && m_version != biglybtc_socks4a_version)
			m_dst_name.resize(255);
	}

	void cancel()
	{
		m_attempt.reset();
		m_resolver.cancel();
		proxy_base::cancel();
	}

	void cancel(error_code& ec)
	{
		m_attempt.reset();
		m_resolver.cancel();
		proxy_base::cancel(ec);
	}

	void close(error_code& ec)
	{
		m_attempt.reset();
		m_dst_name.clear();
		proxy_base::close(ec);
	}

#ifndef BOOST_NO_EXCEPTIONS
	void close()
	{
		m_attempt.reset();
		m_dst_name.clear();
		proxy_base::close();
	}
#endif

	// TODO: 2 add async_connect() that takes a hostname and port as well
	template <class Handler>
	void async_connect(endpoint_type const& endpoint, Handler handler)
	{
		// make sure we don't try to connect to INADDR_ANY. binding is fine,
		// and using a hostname is fine on SOCKS version 5.
		TORRENT_ASSERT(endpoint.address() != address()
			|| (!m_dst_name.empty() && (m_version == 5 || m_version == biglybtc_socks4a_version)));

		auto attempt = std::make_shared<connect_attempt>();
		endpoint_type const remote = endpoint;
		// Supersede the old handshake before closing its transport. Pending
		// callbacks retain their own buffers and cannot advance this attempt.
		// Preserve the caller's newly configured destination name.
		m_attempt.reset();
		error_code ignored;
		proxy_base::close(ignored);
		m_attempt = attempt;
		m_remote_endpoint = remote;

		// the connect is split up in the following steps:
		// 1. resolve name of proxy server
		// 2. connect to proxy server
		// 3. if version == 5:
		//   3.1 send SOCKS5 authentication method message
		//   3.2 read SOCKS5 authentication response
		//   3.3 send username+password
		// 4. send SOCKS command message

		ADD_OUTSTANDING_ASYNC("socks5_stream::name_lookup");
		m_resolver.async_resolve(m_hostname, to_string(m_port).data(), wrap_allocator(
			[this, attempt](error_code const& ec, tcp::resolver::results_type ips, Handler hn) {
				name_lookup(ec, std::move(ips), attempt, std::move(hn));
			}, std::move(handler)));
	}

private:

	// A resolver success already queued when close() runs must not reopen
	// the socket or serialize a cleared destination.
	template <typename Handler>
	bool check_attempt(error_code const& e, attempt_ptr const& attempt, Handler&& h)
	{
		if (m_attempt != attempt)
		{
			std::forward<Handler>(h)(error_code(boost::asio::error::operation_aborted));
			return true;
		}
		if (!e) return false;
		finish_attempt(attempt, e, std::forward<Handler>(h));
		return true;
	}

	template <typename Handler>
	void finish_attempt(attempt_ptr const& attempt, error_code const& e, Handler&& h)
	{
		if (m_attempt != attempt)
		{
			std::forward<Handler>(h)(error_code(boost::asio::error::operation_aborted));
			return;
		}
		m_attempt.reset();
		if (e)
		{
			m_dst_name.clear();
			error_code ignored;
			proxy_base::close(ignored);
		}
		// The callback may destroy or reconnect the stream. All cleanup,
		// including protocol-error cleanup, precedes it.
		std::forward<Handler>(h)(e);
	}

	template <typename Handler>
	void name_lookup(error_code const& e, tcp::resolver::results_type ips
		, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::name_lookup");
		if (check_attempt(e, attempt, std::move(h))) return;

		auto i = ips.begin();
		if (!m_sock.is_open())
		{
			error_code ec;
			m_sock.open(i->endpoint().protocol(), ec);
			if (check_attempt(ec, attempt, std::move(h))) return;
		}

		// TODO: we could bind the socket here, since we know what the
		// target endpoint is of the proxy
		ADD_OUTSTANDING_ASYNC("socks5_stream::connected");
		m_sock.async_connect(i->endpoint(), wrap_allocator(
			[this, attempt](error_code const& ec, Handler hn)
			{ connected(ec, attempt, std::move(hn)); }, std::move(h)));
	}

	template <typename Handler>
	void connected(error_code const& e, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::connected");
		if (check_attempt(e, attempt, std::move(h))) return;

		using namespace libtorrent::aux;
		if (m_version == 5)
		{
			// send SOCKS5 authentication methods
			attempt->buffer.resize(m_user.empty()?3:4);
			char* p = &attempt->buffer[0];
			write_uint8(5, p); // SOCKS VERSION 5
			if (m_user.empty())
			{
				write_uint8(1, p); // 1 authentication method (no auth)
				write_uint8(0, p); // no authentication
			}
			else
			{
				write_uint8(2, p); // 2 authentication methods
				write_uint8(0, p); // no authentication
				write_uint8(2, p); // username/password
			}
			ADD_OUTSTANDING_ASYNC("socks5_stream::handshake1");
			async_write(m_sock, boost::asio::buffer(attempt->buffer), wrap_allocator(
				[this, attempt](error_code const& ec, std::size_t, Handler hn) {
					handshake1(ec, attempt, std::move(hn));
				}, std::move(h)));
		}
		else if (m_version == 4 || m_version == biglybtc_socks4a_version)
		{
			socks_connect(attempt, std::move(h));
		}
		else
		{
			finish_attempt(attempt, error_code(socks_error::unsupported_version), std::move(h));
		}
	}

	template <typename Handler>
	void handshake1(error_code const& e, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::handshake1");
		if (check_attempt(e, attempt, std::move(h))) return;

		ADD_OUTSTANDING_ASYNC("socks5_stream::handshake2");
		attempt->buffer.resize(2);
		async_read(m_sock, boost::asio::buffer(attempt->buffer), wrap_allocator(
			[this, attempt](error_code const& ec, std::size_t, Handler hn) {
				handshake2(ec, attempt, std::move(hn));
			}, std::move(h)));
	}

	template <typename Handler>
	void handshake2(error_code const& e, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::handshake2");
		if (check_attempt(e, attempt, std::move(h))) return;

		using namespace libtorrent::aux;

		char* p = &attempt->buffer[0];
		int version = read_uint8(p);
		int method = read_uint8(p);

		if (version < m_version)
		{
			finish_attempt(attempt, error_code(socks_error::unsupported_version), std::move(h));
			return;
		}

		if (method == 0)
		{
			socks_connect(attempt, std::move(h));
		}
		else if (method == 2)
		{
			if (m_user.empty())
			{
				finish_attempt(attempt, error_code(socks_error::username_required), std::move(h));
				return;
			}

			// start sub-negotiation
			attempt->buffer.resize(m_user.size() + m_password.size() + 3);
			p = &attempt->buffer[0];
			write_uint8(1, p);
			TORRENT_ASSERT(m_user.size() < 0x100);
			write_uint8(uint8_t(m_user.size()), p);
			write_string(m_user, p);
			TORRENT_ASSERT(m_password.size() < 0x100);
			write_uint8(uint8_t(m_password.size()), p);
			write_string(m_password, p);

			ADD_OUTSTANDING_ASYNC("socks5_stream::handshake3");
			async_write(m_sock, boost::asio::buffer(attempt->buffer), wrap_allocator(
				[this, attempt](error_code const& ec, std::size_t const, Handler hn) {
					handshake3(ec, attempt, std::move(hn));
				}, std::move(h)));
		}
		else
		{
			finish_attempt(attempt, error_code(socks_error::unsupported_authentication_method), std::move(h));
			return;
		}
	}

	template <typename Handler>
	void handshake3(error_code const& e, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::handshake3");
		if (check_attempt(e, attempt, std::move(h))) return;

		ADD_OUTSTANDING_ASYNC("socks5_stream::handshake4");
		attempt->buffer.resize(2);
		async_read(m_sock, boost::asio::buffer(attempt->buffer), wrap_allocator(
			[this, attempt](error_code const& ec, std::size_t, Handler hn) {
				handshake4(ec, attempt, std::move(hn));
			}, std::move(h)));
	}

	template <typename Handler>
	void handshake4(error_code const& e, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::handshake4");
		if (check_attempt(e, attempt, std::move(h))) return;

		using namespace libtorrent::aux;

		char* p = &attempt->buffer[0];
		int version = read_uint8(p);
		int status = read_uint8(p);

		if (version != 1)
		{
			finish_attempt(attempt, error_code(socks_error::unsupported_authentication_version), std::move(h));
			return;
		}

		if (status != 0)
		{
			finish_attempt(attempt, error_code(socks_error::authentication_error), std::move(h));
			return;
		}

		std::vector<char>().swap(attempt->buffer);
		socks_connect(attempt, std::move(h));
	}

	template <typename Handler>
	void socks_connect(attempt_ptr const& attempt, Handler h)
	{
		if (check_attempt(error_code{}, attempt, std::move(h))) return;

		using namespace libtorrent::aux;

		if (m_version == 5)
		{
			// send SOCKS5 connect command
			attempt->buffer.resize(6 + (!m_dst_name.empty()
				? m_dst_name.size() + 1
				:(aux::is_v4(m_remote_endpoint) ? 4 : 16)));
			char* p = &attempt->buffer[0];
			write_uint8(5, p); // SOCKS VERSION 5
			write_uint8(std::uint8_t(m_command), p); // CONNECT command
			write_uint8(0, p); // reserved
			if (!m_dst_name.empty())
			{
				write_uint8(3, p); // address type
				TORRENT_ASSERT(m_dst_name.size() < 0x100);
				write_uint8(uint8_t(m_dst_name.size()), p);
				std::copy(m_dst_name.begin(), m_dst_name.end(), p);
				p += m_dst_name.size();
			}
			else
			{
				// we either need a hostname or a valid endpoint
				TORRENT_ASSERT(m_remote_endpoint.address() != address());

				write_uint8(aux::is_v4(m_remote_endpoint) ? 1 : 4, p); // address type
				write_address(m_remote_endpoint.address(), p);
			}
			write_uint16(m_remote_endpoint.port(), p);
		}
		else if (m_version == 4 || m_version == biglybtc_socks4a_version)
		{
			bool const remote_name = m_version == biglybtc_socks4a_version;
			if (m_command != socks5_connect || m_user.find('\0') != std::string::npos
				|| (!remote_name && !m_dst_name.empty()))
			{
				finish_attempt(attempt, error_code(boost::asio::error::invalid_argument), std::move(h));
				return;
			}
			// SOCKS4 uses numeric IPv4. SOCKS4a carries the bounded destination
			// as a NUL-terminated name after USERID, never a local DNS fallback.
			if (!remote_name && !aux::is_v4(m_remote_endpoint))
			{
				finish_attempt(attempt, error_code(boost::asio::error::address_family_not_supported), std::move(h));
				return;
			}
			std::string const host = remote_name
				? (m_dst_name.empty() ? m_remote_endpoint.address().to_string() : m_dst_name)
				: std::string{};
			if (remote_name && (host.empty() || host.size() > 255
				|| host.find('\0') != std::string::npos
				|| (m_dst_name.empty() && m_remote_endpoint.address().is_unspecified())))
			{
				finish_attempt(attempt, error_code(boost::asio::error::invalid_argument), std::move(h));
				return;
			}
			attempt->buffer.resize(m_user.size() + 9 + (remote_name ? host.size() + 1 : 0));
			char* p = &attempt->buffer[0];
			write_uint8(4, p); // SOCKS VERSION 4
			write_uint8(std::uint8_t(m_command), p); // CONNECT command
			write_uint16(m_remote_endpoint.port(), p);
			write_uint32(remote_name ? 1 : m_remote_endpoint.address().to_v4().to_uint(), p);
			std::copy(m_user.begin(), m_user.end(), p);
			p += m_user.size();
			write_uint8(0, p); // USERID terminator
			if (remote_name)
			{
				std::copy(host.begin(), host.end(), p); p += host.size();
				write_uint8(0, p); // SOCKS4a destination terminator
			}
		}
		else
		{
			finish_attempt(attempt, error_code(socks_error::unsupported_version), std::move(h));
			return;
		}

		ADD_OUTSTANDING_ASYNC("socks5_stream::connect1");
		async_write(m_sock, boost::asio::buffer(attempt->buffer), wrap_allocator(
			[this, attempt](error_code const& ec, std::size_t, Handler hn) {
				connect1(ec, attempt, std::move(hn));
			}, std::move(h)));
	}

	template <typename Handler>
	void connect1(error_code const& e, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::connect1");
		if (check_attempt(e, attempt, std::move(h))) return;

		if (m_version == 5)
			attempt->buffer.resize(6 + 4); // assume an IPv4 address
		else if (m_version == 4 || m_version == biglybtc_socks4a_version)
			attempt->buffer.resize(8);

		ADD_OUTSTANDING_ASYNC("socks5_stream::connect2");
		async_read(m_sock, boost::asio::buffer(attempt->buffer), wrap_allocator(
			[this, attempt](error_code const& ec, std::size_t, Handler hn) {
				connect2(ec, attempt, std::move(hn));
			}, std::move(h)));
	}

	template <typename Handler>
	void connect2(error_code const& e, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::connect2");
		if (check_attempt(e, attempt, std::move(h))) return;

		using namespace libtorrent::aux;

		char const* p = &attempt->buffer[0];
		int const version = read_uint8(p);
		int const response = read_uint8(p);

		if (m_version == 5)
		{
			if (version < m_version)
			{
				finish_attempt(attempt, error_code(socks_error::unsupported_version), std::move(h));
				return;
			}
			if (response != 0)
			{
				error_code ec(socks_error::general_failure);
				switch (response)
				{
					case 2: ec = boost::asio::error::no_permission; break;
					case 3: ec = boost::asio::error::network_unreachable; break;
					case 4: ec = boost::asio::error::host_unreachable; break;
					case 5: ec = boost::asio::error::connection_refused; break;
					case 6: ec = boost::asio::error::timed_out; break;
					case 7: ec = socks_error::command_not_supported; break;
					case 8: ec = boost::asio::error::address_family_not_supported; break;
				}
				finish_attempt(attempt, ec, std::move(h));
				return;
			}
			p += 1; // reserved
			int const atyp = read_uint8(p);
			// read the proxy IP it was bound to (this is variable length depending
			// on address type)
			if (atyp == 1)
			{
				std::vector<char>().swap(attempt->buffer);
				finish_attempt(attempt, e, std::move(h));
				return;
			}
			std::size_t extra_bytes = 0;
			if (atyp == 4)
			{
				// IPv6
				extra_bytes = 12;
			}
			else if (atyp == 3)
			{
				// hostname with length prefix
				extra_bytes = read_uint8(p) - 3;
			}
			else
			{
				finish_attempt(attempt, error_code(boost::asio::error::address_family_not_supported), std::move(h));
				return;
			}
			attempt->buffer.resize(attempt->buffer.size() + extra_bytes);

			ADD_OUTSTANDING_ASYNC("socks5_stream::connect3");
			TORRENT_ASSERT(extra_bytes > 0);
			async_read(m_sock, boost::asio::buffer(&attempt->buffer[attempt->buffer.size() - extra_bytes], extra_bytes)
				, wrap_allocator([this, attempt](error_code const& ec, std::size_t, Handler hn) {
					connect3(ec, attempt, std::move(hn));
				}, std::move(h)));
		}
		else if (m_version == 4 || m_version == biglybtc_socks4a_version)
		{
			if (version != 0)
			{
				finish_attempt(attempt, error_code(socks_error::general_failure), std::move(h));
				return;
			}

			// access granted
			if (response == 90)
			{
				std::vector<char>().swap(attempt->buffer);
				finish_attempt(attempt, e, std::move(h));
				return;
			}

			error_code ec(socks_error::general_failure);
			switch (response)
			{
				case 91: ec = boost::asio::error::connection_refused; break;
				case 92: ec = socks_error::no_identd; break;
				case 93: ec = socks_error::identd_error; break;
			}
			finish_attempt(attempt, ec, std::move(h));
		}
	}

	template <typename Handler>
	void connect3(error_code const& e, attempt_ptr const& attempt, Handler h)
	{
		COMPLETE_ASYNC("socks5_stream::connect3");
		using namespace libtorrent::aux;

		if (check_attempt(e, attempt, std::move(h))) return;

		std::vector<char>().swap(attempt->buffer);
		finish_attempt(attempt, e, std::move(h));
	}

	// Only this handshake may advance the socket.
	attempt_ptr m_attempt;
	// proxy authentication
	std::string m_user;
	std::string m_password;
	std::string m_dst_name;

	int m_version;

	// the socks command to send for this connection (connect or udp associate)
	int m_command;
};

}

#endif
