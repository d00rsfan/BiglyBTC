Read-only proxy audit: native e48d70de, proxy source9385de07 remains unchanged.
Each accepted socket gets a fresh Channel/pending buffer; greeting/authentication
consumption and IPv4/domain/port offsets are correct. Parsed zero IPv4/port requires
zero bytes in the request buffer. Accepted peer/local endpoints are not used to
construct this destination. CMD3 returns before CMD1 route parsing. OwnerExit
closes listeners and blocks every owned socket's signals before abort/join; that
path does not edit parsed destinations. No concrete fixture-manufactured zero
endpoint or parser correction is supported. Keep strict route checks. Capture
request prefix plus channel/socket identity if provider lifecycle evidence still
cannot resolve the cause; do not whitelist0:0.

Read helper only: valid bytes/empty reads stay unchanged. Failed open already
throws; message now carries UTF8 path, operation, QFile error, immediately saved
errno snapshot and Qt errorString. Failed readAll now throws instead of accepting
failed/partial bytes. errno is captured before formatting; Qt errorString remains
the authoritative engine explanation (errno can be absent/stale for nonnative
file engines). No retries/stat probes/production IO changes.

Three tiny Linux-only generated-fixture regressions: missing leaf/ENOENT, genuine
empty file, owned directory accepted by open but rejected by read/EISDIR. Root
builds/runs; source-only authoring gives no execution credit. No LT session is
constructed by these methods; the existing fixture header merely needs SDK types.
Copy staging/tests/* to native preview/native/tests; append CMake.fragment once.
