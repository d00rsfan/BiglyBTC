from pathlib import Path
import os,subprocess,time,json,hashlib,shutil,xml.etree.ElementTree as ET
R=Path('/home/yurii/Java/BiglyBT');N=R.parent/'BiglyBTC';W=R/'build/network-reliability-20261028';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();lanes={'gcc':(N/'build/persistent-peer-accounting-20261021/bound-gcc',W/'native-gcc-r2'),'clang':(N/'build/saved-services-20261018/clang',W/'native-clang'),'san':(N/'build/saved-services-20261018/sanitized-desktop',W/'native-san')}
# All source-frozen batches must finish before changing the one test file.
records={};images={}
for lane,(cache,old) in lanes.items():
 commands=json.loads((old/'commands.json').read_bytes());assert commands['commands'][-1]['name']=='tests' and commands['commands'][-1]['exit']==8,lane
 cases=list(ET.fromstring((old/'tests.xml').read_bytes()).iter('testcase'));bad=[c.get('name') for c in cases if any(c.find(x) is not None for x in ('failure','error','skipped'))];assert bad==['owned-fixture-read-diagnostic'],(lane,bad)
 passed=[c.get('name') for c in cases if c.get('name') not in bad];assert len(passed)==(16 if lane=='gcc' else 2)
 paths=[cache/'tests/biglybtc-network-proxy-owner-tests',cache/'tests/biglybtc-network-binding-owner-tests']
 if lane=='gcc':paths += [cache/'app/BiglyBTC',cache/'app/BiglyBTC-headless',cache/'tests/biglybtc-managed-download-tests',cache/'tests/biglybtc-persistent-session-tests',cache/'tests/biglybtc-selected-swarm-admission-tests',cache/'tests/biglybtc-provider-payload-counter-tests',cache/'tests/biglybtc-provider-socks-runtime-deployment-driver']
 
 if lane=='gcc':
  targets=next(c['command'] for c in commands['commands'] if c['name']=='build');targets=targets[targets.index('--target')+1:]
  for name in targets:
   for option in (cache/'tests'/name,cache/'tests'/('lib'+name+'.so')):
    if option.is_file() and option not in paths:paths.append(option)
  for name in ('BiglyBTC-plugin-azlocprov.so','BiglyBTC-plugin-SpeedScheduler.so'):
   if (cache/'app'/name).is_file():paths.append(cache/'app'/name)
 images[lane]={str(p):sha(p) for p in paths};records[lane]={'reused_successful_suites':passed,'prior_whole_test_exit':8,'prior_source_commit':commands['source_commit'],'raw_result':str(old/'tests.xml')}
assert not subprocess.check_output(['git','-C',str(N),'status','--porcelain'],text=True).strip()
source=W/'read-diagnostic-r2/staging/tests/owned_fixture_read_tests.cpp';expected=json.loads((W/'read-diagnostic-r2/manifest.json').read_bytes());target=N/'preview/native/tests/owned_fixture_read_tests.cpp';before=sha(target);after=sha(source)
assert before==expected['before_sha256']['tests/owned_fixture_read_tests.cpp'] and after==expected['source_sha256']['tests/owned_fixture_read_tests.cpp'];assert sha(N/'preview/native/tests/owned_engine_fixture.hpp')==expected['unchanged_helper']['sha256']
for rel,pin in expected['artifacts_sha256'].items():assert sha(W/'read-diagnostic-r2'/rel)==pin,rel
shutil.copyfile(source,target);subprocess.run(['git','-C',str(N),'diff','--check'],check=True);subprocess.run(['git','-C',str(N),'add','--','preview/native/tests/owned_fixture_read_tests.cpp'],check=True);subprocess.run(['git','-C',str(N),'-c','user.name=Codex','-c','user.email=codex@localhost','-c','commit.gpgsign=false','commit','-m','Exercise actual Qt read failures with an owned inode'],check=True,stdout=subprocess.DEVNULL);head=subprocess.check_output(['git','-C',str(N),'rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','-C',str(N),'diff','--name-only','ec948313479d6cb351cd8ed4724d551f5ff54f4e',head],text=True).splitlines()==['preview/native/tests/owned_fixture_read_tests.cpp']
(W/'read-fixture-correction-commit.json').write_text(json.dumps({'commit':head,'before_sha256':before,'after_sha256':after,'production_unchanged':True,'other_images_before':images},indent=2)+'\n');print('read-fixture-commit',head,flush=True)
for lane,(cache,old) in lanes.items():
 out=W/('read-followup-'+lane);out.mkdir(exist_ok=False);rows=[];env=os.environ.copy();env.update(QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1');env.pop('LD_PRELOAD',None);env.pop('LD_AUDIT',None)
 if lane=='san':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
 for name,cmd in [('build',['nice','-n','5','cmake','--build',str(cache),'--parallel','1','--target','biglybtc-owned-fixture-read-tests']),('tests',['ctest','--test-dir',str(cache),'-R','^owned-fixture-read-diagnostic$','--output-on-failure','--output-junit',str(out/'tests.xml')])]:
  t=time.monotonic()
  with (out/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  rows.append({'name':name,'command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-t,3)});(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print('read-followup-'+lane,name,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
 cases=list(ET.fromstring((out/'tests.xml').read_bytes()).iter('testcase'));assert len(cases)==1 and all(cases[0].find(x) is None for x in ('failure','error','skipped'));assert all(sha(Path(p))==pin for p,pin in images[lane].items())
 record={'status':'PASS_WITH_EXPLICIT_UNCHANGED_SUCCESS_REUSE','lane':lane,'final_test_source_commit':head,'actual_new_suite':'owned-fixture-read-diagnostic','actual_new_test_binary_sha256':sha(cache/'tests/biglybtc-owned-fixture-read-tests'),'other_images_byte_identical':images[lane],**records[lane]};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');print('effective-'+lane,len(record['reused_successful_suites'])+1,'suites PASS (only read suite rerun)',flush=True)
