// Direct provider qualification only: actual owned TCP blocks, hash failure,
// duplicate discard and before-reset callback. No private torrent class access.
#include <libtorrent/biglybtc_payload_counters.hpp>
#include <libtorrent/add_torrent_params.hpp>
#include <libtorrent/bencode.hpp>
#include <libtorrent/create_torrent.hpp>
#include <libtorrent/extensions.hpp>
#include <libtorrent/file_storage.hpp>
#include <libtorrent/hasher.hpp>
#include <libtorrent/session.hpp>
#include <libtorrent/settings_pack.hpp>
#include <libtorrent/torrent_handle.hpp>
#include <libtorrent/torrent_info.hpp>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <poll.h>
#include <unistd.h>
#include <algorithm>
#include <cstdlib>
#include <libtorrent/torrent_status.hpp>
#include <libtorrent/address.hpp>
#include <array>
#include <atomic>
#include <chrono>
#include <cstring>
#include <filesystem>
#include <future>
#include <iostream>
#include <iterator>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
namespace lt=libtorrent;
using namespace std::chrono_literals;
constexpr int Piece=16384;
void need(bool value,const char* why){if(!value){throw std::runtime_error(why);}}
std::uint32_t number(const char* p){std::uint32_t value=0;std::memcpy(&value,p,4);return ntohl(value);}
void integer(std::string& s,std::uint32_t value){value=htonl(value);s.append(reinterpret_cast<const char*>(&value),4);}
struct Peer {
  int listener=-1;unsigned short port=0;std::atomic<bool> stop{false};
  std::atomic<unsigned> good{0},duplicate{0},corrupt{0};std::thread thread;
  std::array<char,20> hash{};std::mutex mutex;std::string failure;
  explicit Peer(const lt::sha1_hash& value){
    std::copy(value.begin(),value.end(),hash.begin());listener=::socket(AF_INET,SOCK_STREAM|SOCK_CLOEXEC,0);need(listener>=0,"Owned peer socket");
    sockaddr_in address{};address.sin_family=AF_INET;address.sin_addr.s_addr=::inet_addr("127.0.0.2");
    need(::bind(listener,reinterpret_cast<sockaddr*>(&address),sizeof(address))==0&&::listen(listener,1)==0,"Owned peer bind/listen");
    socklen_t bytes=sizeof(address);need(::getsockname(listener,reinterpret_cast<sockaddr*>(&address),&bytes)==0,"Owned peer port");port=ntohs(address.sin_port);
    thread=std::thread([this]{run();});
  }
  ~Peer(){stop=true;if(thread.joinable()){thread.join();}if(listener>=0){::close(listener);}}
  bool send(int client,const std::string& data){
    for(std::size_t n=0;n<data.size()&&!stop;){const auto bytes=::send(client,data.data()+n,data.size()-n,MSG_NOSIGNAL);if(bytes<=0){return false;}n+=static_cast<std::size_t>(bytes);}return !stop;
  }
  void piece(int client,int index,int offset,int bytes,char value){
    std::string data;integer(data,static_cast<std::uint32_t>(9+bytes));data.push_back(7);integer(data,index);integer(data,offset);data.append(static_cast<std::size_t>(bytes),value);need(send(client,data),"Owned payload send");
  }
  void run() noexcept {try{
    int client=-1;while(!stop&&client<0){pollfd ready{listener,POLLIN,0};if(::poll(&ready,1,50)>0){client=::accept4(listener,nullptr,nullptr,SOCK_CLOEXEC);}}
    if(client<0){return;}struct Close{int fd;~Close(){::close(fd);}} close{client};
    timeval timeout{1,0};::setsockopt(client,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
    bool handshake=false;int goodPiece=-1;std::string input;std::array<char,32768> buffer{};
    while(!stop){pollfd ready{client,POLLIN,0};if(::poll(&ready,1,50)<=0){continue;}const auto count=::recv(client,buffer.data(),buffer.size(),0);if(count<=0){break;}input.append(buffer.data(),static_cast<std::size_t>(count));
      if(!handshake){
        if(input.size()<68){continue;}need(static_cast<unsigned char>(input[0])==19&&input.substr(1,19)=="BitTorrent protocol","Actual owned plain handshake header");need(std::equal(hash.begin(),hash.end(),input.data()+28),"Actual owned handshake swarm");
        std::string reply(1,char(19));reply+="BitTorrent protocol";reply.append(8,'\0');reply.append(hash.data(),hash.size());reply.append("-BV3-OWNED-PEER-00001",20);need(reply.size()==68&&send(client,reply),"Owned handshake reply");
        std::string bitfield;integer(bitfield,2);bitfield.push_back(5);bitfield.push_back(char(0xc0));need(send(client,bitfield),"Owned bitfield");
        std::string unchoke;integer(unchoke,1);unchoke.push_back(1);need(send(client,unchoke),"Owned unchoke");input.erase(0,68);handshake=true;
      }
      while(input.size()>=4){const auto bytes=number(input.data());need(bytes<=32768,"Bounded owned message");if(input.size()<4+bytes){break;}
        if(bytes==13&&static_cast<unsigned char>(input[4])==6){const auto index=number(input.data()+5),offset=number(input.data()+9),length=number(input.data()+13);need(index<2&&offset==0&&length==Piece,"Actual owned request geometry");
          if(goodPiece<0){goodPiece=static_cast<int>(index);piece(client,goodPiece,0,Piece,'Q');++good;piece(client,goodPiece,0,Piece,'Q');++duplicate;}
          else if(static_cast<int>(index)!=goodPiece&&corrupt==0){piece(client,static_cast<int>(index),0,Piece,'X');++corrupt;}
        }
        input.erase(0,4+bytes);
      }
    }
  }catch(const std::exception& error){std::lock_guard<std::mutex> lock(mutex);failure=error.what();}}
};
struct Frame {
  std::promise<lt::BiglybtcTrafficCountersV3> positive,beforeReset,reset;
  std::atomic<bool> positiveSet{false},beforeSet{false},resetSet{false},failed{false};
  std::atomic<std::int64_t> lastFailed{-1},lastRedundant{-1},lastReceived{-1};
};
struct Reader final:lt::torrent_plugin {
  lt::torrent_handle handle;std::shared_ptr<Frame> frame;
  Reader(lt::torrent_handle h,std::shared_ptr<Frame> f):handle(std::move(h)),frame(std::move(f)){}
  lt::BiglybtcTrafficCountersV3 read(){lt::BiglybtcTrafficCountersV3 value{};if(lt::biglybtc_read_traffic_counters_v3(&handle,&value,sizeof(value))!=0||value.reserved||value.traffic.reserved||value.traffic.payload.reserved){frame->failed=true;}return value;}
  void tick() override {
    const auto value=read();
    frame->lastFailed=value.failed_bytes;frame->lastRedundant=value.redundant_bytes;frame->lastReceived=value.traffic.payload.received;
    if(value.bad_known&&value.failed_bytes>=Piece&&value.redundant_bytes>=Piece&&!frame->positiveSet.exchange(true)){frame->positive.set_value(value);}
    if(frame->beforeSet&&value.bad_known&&value.failed_bytes==0&&value.redundant_bytes==0&&!frame->resetSet.exchange(true)){frame->reset.set_value(value);}
  }
  bool on_resume() override {
    const auto value=read();
    if(value.bad_known&&value.failed_bytes>=Piece&&value.redundant_bytes>=Piece&&!frame->beforeSet.exchange(true)){frame->beforeReset.set_value(value);}
    return false;
  }
};
int main(){try{
  need(lt::biglybtc_payload_counter_abi_v1()==1&&lt::biglybtc_traffic_counter_abi_v2()==2&&lt::biglybtc_traffic_counter_abi_v3()==3,"Old/new markers");
  need(sizeof(lt::BiglybtcPayloadCountersV1)==24&&sizeof(lt::BiglybtcTrafficCountersV2)==48&&sizeof(lt::BiglybtcTrafficCountersV3)==72,"Old/new layouts");
  lt::BiglybtcTrafficCountersV3 untouched;std::memset(&untouched,0x5a,sizeof(untouched));const auto original=untouched;lt::torrent_handle invalid;
  need(lt::biglybtc_read_traffic_counters_v3(nullptr,&untouched,sizeof(untouched))==1&&std::memcmp(&untouched,&original,sizeof(original))==0,"Null leaves output unchanged");
  need(lt::biglybtc_read_traffic_counters_v3(&invalid,&untouched,sizeof(untouched)-1)==1&&std::memcmp(&untouched,&original,sizeof(original))==0,"Wrong size leaves output unchanged");
  need(lt::biglybtc_read_traffic_counters_v3(&invalid,&untouched,sizeof(untouched))==2&&std::memcmp(&untouched,&original,sizeof(original))==0,"Invalid handle unchanged");
  std::array<char,64> pattern{};std::strcpy(pattern.data(),"/tmp/biglybtc-bad-traffic-XXXXXX");const auto owned=::mkdtemp(pattern.data());need(owned,"Owned root");
  const std::filesystem::path root(owned);struct Cleanup{std::filesystem::path path;~Cleanup(){std::error_code error;std::filesystem::remove_all(path,error);}} cleanup{root};
  lt::file_storage files;files.add_file("actual.bin",2*Piece);lt::create_torrent creator(files,Piece,lt::create_torrent::v1_only);const std::string payload(Piece,'Q');
  for(int i=0;i<2;++i){creator.set_hash(lt::piece_index_t{i},lt::hasher(payload.data(),Piece).final());}
  std::vector<char> raw;lt::bencode(std::back_inserter(raw),creator.generate());lt::error_code error;auto info=std::make_shared<lt::torrent_info>(raw.data(),static_cast<int>(raw.size()),error);need(!error,"Actual metadata");Peer peer(info->info_hashes().v1);
  lt::settings_pack settings;settings.set_str(lt::settings_pack::listen_interfaces,"127.0.0.1:0");settings.set_str(lt::settings_pack::outgoing_interfaces,"127.0.0.1");settings.set_str(lt::settings_pack::dht_bootstrap_nodes,"");
  for(auto key:{lt::settings_pack::enable_dht,lt::settings_pack::enable_lsd,lt::settings_pack::enable_upnp,lt::settings_pack::enable_natpmp,lt::settings_pack::enable_incoming_utp,lt::settings_pack::enable_outgoing_utp}){settings.set_bool(key,false);}
  // This fixture implements the plain numeric TCP peer protocol, not MSE.
  settings.set_int(lt::settings_pack::out_enc_policy,lt::settings_pack::pe_disabled);settings.set_int(lt::settings_pack::in_enc_policy,lt::settings_pack::pe_disabled);
  lt::session owner(settings);auto frame=std::make_shared<Frame>();auto positive=frame->positive.get_future(),before=frame->beforeReset.get_future(),reset=frame->reset.get_future();
  lt::add_torrent_params parameters;parameters.ti=info;parameters.save_path=root.string();parameters.flags&=~(lt::torrent_flags::paused|lt::torrent_flags::auto_managed|lt::torrent_flags::seed_mode);parameters.flags|=lt::torrent_flags::disable_dht|lt::torrent_flags::disable_lsd|lt::torrent_flags::disable_pex;
  parameters.extensions.push_back([frame](const lt::torrent_handle& handle,lt::client_data_t){return std::make_shared<Reader>(handle,frame);});auto handle=owner.add_torrent(parameters,error);need(!error&&handle.is_valid(),"Actual admission");
  need(lt::biglybtc_read_traffic_counters_v3(&handle,&untouched,sizeof(untouched))==3&&std::memcmp(&untouched,&original,sizeof(original))==0,"Wrong executor unchanged");
  handle.connect_peer(lt::tcp::endpoint(lt::make_address("127.0.0.2"),peer.port));
  const auto positiveReady=positive.wait_for(15s)==std::future_status::ready;
  if(!positiveReady){std::lock_guard<std::mutex> lock(peer.mutex);std::cerr<<"observed failed="<<frame->lastFailed<<" redundant="<<frame->lastRedundant<<" received="<<frame->lastReceived<<" wire good/duplicate/corrupt="<<peer.good<<'/'<<peer.duplicate<<'/'<<peer.corrupt<<" peer="<<peer.failure<<'\n';}
  need(positiveReady,"Real corrupt+duplicate counters");const auto actual=positive.get();
  need(actual.traffic.payload.received>=2*Piece&&actual.failed_bytes>=Piece&&actual.redundant_bytes>=Piece&&actual.bad_known==1,"Actual bad payload and protocol observations");
  handle.pause();const auto until=std::chrono::steady_clock::now()+5s;while(!(handle.status().flags & lt::torrent_flags::paused)&&std::chrono::steady_clock::now()<until){std::this_thread::sleep_for(10ms);}need(bool(handle.status().flags & lt::torrent_flags::paused),"Actual paused");handle.resume();
  need(before.wait_for(5s)==std::future_status::ready,"Before actual reset callback");const auto sealed=before.get();need(sealed.failed_bytes>=actual.failed_bytes&&sealed.redundant_bytes>=actual.redundant_bytes,"Exact old epoch survives until existing callback");
  need(reset.wait_for(5s)==std::future_status::ready,"Actual reset raw counters");const auto cleared=reset.get();need(cleared.failed_bytes==0&&cleared.redundant_bytes==0&&!frame->failed,"Actual zero new epoch");
  owner.remove_torrent(handle);{auto joined=owner.abort();}
  need(peer.good==1&&peer.duplicate==1&&peer.corrupt==1,"Actual owned wire work");
  std::cout<<"PASS trafficV3 actual owned corrupt/duplicate "<<actual.failed_bytes<<'/'<<actual.redundant_bytes<<" before-reset "<<sealed.failed_bytes<<'/'<<sealed.redundant_bytes<<" new-epoch0/0; V1/V2 unchanged\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
