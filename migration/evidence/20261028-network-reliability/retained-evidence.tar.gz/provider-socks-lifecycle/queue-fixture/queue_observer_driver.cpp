// Root-run direct candidate-provider fixture; no native RuntimeGuard dependency.
// Real owned numeric HTTP tracker and actual regular-file piece verification.
#include <libtorrent/biglybtc_queue_observer.hpp>
#include <libtorrent/biglybtc_payload_counters.hpp>
#include <libtorrent/biglybtc_swarm.hpp>
#include <libtorrent/add_torrent_params.hpp>
#include <libtorrent/alert_types.hpp>
#include <libtorrent/announce_entry.hpp>
#include <libtorrent/bencode.hpp>
#include <libtorrent/create_torrent.hpp>
#include <libtorrent/extensions.hpp>
#include <libtorrent/file_storage.hpp>
#include <libtorrent/hasher.hpp>
#include <libtorrent/session.hpp>
#include <libtorrent/session_params.hpp>
#include <libtorrent/settings_pack.hpp>
#include <libtorrent/torrent_info.hpp>
#include <arpa/inet.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstring>
#include <cstdlib>
#include <iterator>
#include <string>
#include <filesystem>
#include <fstream>
#include <future>
#include <iostream>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <vector>
namespace lt=libtorrent;
static_assert(std::chrono::steady_clock::is_steady,"Observer timestamps require explicit steady clock");
using Kind=lt::BiglybtcQueueEventKindV1;
void need(bool value,const char* why){if(!value){throw std::runtime_error(why);}}
struct Tracker {
 int listener=-1;unsigned short port=0;std::atomic<bool> done{false},fail{false};
 std::mutex mutex;std::condition_variable changed;bool held=false,entered=false,released=false;unsigned scrapes=0,announces=0;std::string failure;
 std::thread worker;
 Tracker(){
  listener=::socket(AF_INET,SOCK_STREAM|SOCK_CLOEXEC,0);need(listener>=0,"Owned tracker socket");
  sockaddr_in address{};address.sin_family=AF_INET;address.sin_addr.s_addr=::inet_addr("127.0.0.2");
  need(::bind(listener,reinterpret_cast<sockaddr*>(&address),sizeof(address))==0&&::listen(listener,8)==0,"Owned tracker bind/listen");
  socklen_t bytes=sizeof(address);need(::getsockname(listener,reinterpret_cast<sockaddr*>(&address),&bytes)==0,"Owned tracker port");port=ntohs(address.sin_port);
  worker=std::thread([this]{run();});
 }
 ~Tracker(){done=true;release();if(worker.joinable()){worker.join();}if(listener>=0){::close(listener);}}
 void hold(){std::lock_guard<std::mutex> lock(mutex);held=true;entered=false;released=false;}
 void release(){std::lock_guard<std::mutex> lock(mutex);released=true;changed.notify_all();}
 bool waitEntered(){std::unique_lock<std::mutex> lock(mutex);return changed.wait_for(lock,std::chrono::seconds(10),[&]{return entered;});}
 void run() noexcept {try {
  while(!done){pollfd ready{listener,POLLIN,0};if(::poll(&ready,1,50)<=0){continue;}int client=::accept4(listener,nullptr,nullptr,SOCK_CLOEXEC);if(client<0){continue;}
   struct Close{int fd;~Close(){::close(fd);}} close{client};timeval timeout{3,0};::setsockopt(client,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));::setsockopt(client,SOL_SOCKET,SO_SNDTIMEO,&timeout,sizeof(timeout));
   std::string request;std::array<char,2048> buffer{};
   while(request.find("\r\n\r\n")==std::string::npos&&request.size()<16384){const auto n=::recv(client,buffer.data(),buffer.size(),0);if(n<=0){break;}request.append(buffer.data(),static_cast<std::size_t>(n));}
   const bool scrape=request.rfind("GET /scrape?",0)==0,announce=request.rfind("GET /announce?",0)==0;
   need(scrape||announce,"Unexpected owned tracker route");
   {std::unique_lock<std::mutex> lock(mutex);if(scrape){++scrapes;if(held){entered=true;changed.notify_all();need(changed.wait_for(lock,std::chrono::seconds(10),[&]{return released||done.load();}),"Owned response gate");held=false;}}else{++announces;}}
   lt::entry root;
   if(scrape){const auto query=request.substr(0,request.find(' ' ,4));const auto key=query.find("info_hash=");need(key!=std::string::npos,"Actual scrape infohash");std::string hash;
    for(std::size_t i=key+10;i<query.size()&&query[i]!='&';++i){if(query[i]=='%'){need(i+2<query.size(),"Escaped hash");const auto digit=[](char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;};int a=digit(query[++i]),b=digit(query[++i]);need(a>=0&&b>=0,"Hash hex");hash.push_back(static_cast<char>(a*16+b));}else{hash.push_back(query[i]);}}
    need(hash.size()==20,"Actual full selected scrape key");root["files"][hash]["complete"]=3;root["files"][hash]["incomplete"]=11;root["files"][hash]["downloaded"]=0;
   }else{root["interval"]=3600;root["complete"]=5;root["incomplete"]=7;root["peers"]=std::string();}
   std::string body;lt::bencode(std::back_inserter(body),root);const bool reject=scrape&&fail.exchange(false);
   const std::string reply=std::string(reject?"HTTP/1.1 500 Controlled\r\n":"HTTP/1.1 200 OK\r\n")+"Connection: close\r\nContent-Length: "+std::to_string(body.size())+"\r\n\r\n"+body;
   for(std::size_t sent=0;sent<reply.size();){const auto n=::send(client,reply.data()+sent,reply.size()-sent,MSG_NOSIGNAL);if(n<=0){break;}sent+=static_cast<std::size_t>(n);}
  }
 }catch(const std::exception& error){std::lock_guard<std::mutex> lock(mutex);failure=error.what();changed.notify_all();}}
};
struct Sink final:lt::BiglybtcQueueObserverV1 {
 std::mutex mutex;std::condition_variable changed;std::vector<lt::BiglybtcQueueEventV1> events;bool overflow=false;
 void observe(const lt::BiglybtcQueueEventV1& value) noexcept override {try {std::lock_guard<std::mutex> lock(mutex);if(events.size()==128){overflow=true;}else{events.push_back(value);}changed.notify_all();}catch(...){overflow=true;}}
 bool wait(Kind kind,unsigned count=1){std::unique_lock<std::mutex> lock(mutex);return changed.wait_for(lock,std::chrono::seconds(10),[&]{unsigned n=0;for(const auto& e:events){n+=e.kind==static_cast<unsigned>(kind);}return n>=count;});}
 lt::BiglybtcQueueEventV1 last(Kind kind){std::lock_guard<std::mutex> lock(mutex);for(auto i=events.rbegin();i!=events.rend();++i){if(i->kind==static_cast<unsigned>(kind)){return *i;}}throw std::runtime_error("Missing actual event");}
};
int main(int argc,char** argv){try {
 const bool v2=argc>=2&&std::string(argv[1])=="v2";const bool ownedLoopbackScrape=argc==3&&std::string(argv[2])=="--owned-loopback-scrape";need((argc==1||(argc>=2&&(v2||std::string(argv[1])=="v1")))&&(argc<=2||ownedLoopbackScrape),"Use [v1|v2] [--owned-loopback-scrape]");const unsigned version=v2?2u:1u;
 need(lt::biglybtc_payload_counter_abi_v1()==1&&lt::biglybtc_traffic_counter_abi_v2()==2&&lt::biglybtc_queue_observer_abi_v1()==1,"Unchanged old markers/new ABI1");
 need(sizeof(lt::BiglybtcQueueEventV1)==96,"Queue POD size");
 std::array<char,64> pattern{};std::strcpy(pattern.data(),"/tmp/biglybtc-queue-observer-XXXXXX");const auto name=::mkdtemp(pattern.data());need(name,"Owned root");const std::filesystem::path root(name);struct Cleanup{std::filesystem::path path;~Cleanup(){std::error_code e;std::filesystem::remove_all(path,e);}} cleanup{root};
 const std::string payload(16384,'Q');{std::ofstream f(root/"actual.bin",std::ios::binary);f.write(payload.data(),payload.size());need(bool(f),"Real payload write");}
 lt::file_storage files;files.add_file("actual.bin",payload.size());lt::create_torrent creator(files,16384,v2?lt::create_torrent::v2_only:lt::create_torrent::v1_only);
 if(v2){creator.set_hash2(lt::file_index_t{0},lt::piece_index_t::diff_type{0},lt::hasher256(payload.data(),static_cast<int>(payload.size())).final());}
 else{creator.set_hash(lt::piece_index_t{0},lt::hasher(payload.data(),static_cast<int>(payload.size())).final());}
 Tracker tracker;creator.add_tracker("http://127.0.0.2:"+std::to_string(tracker.port)+"/announce");std::vector<char> raw;lt::bencode(std::back_inserter(raw),creator.generate());lt::error_code error;auto metadata=std::make_shared<lt::torrent_info>(raw.data(),static_cast<int>(raw.size()),error);need(!error,"Actual metadata");
 lt::settings_pack settings;settings.set_str(lt::settings_pack::listen_interfaces,"127.0.0.1:0");settings.set_str(lt::settings_pack::outgoing_interfaces,"127.0.0.1");settings.set_str(lt::settings_pack::dht_bootstrap_nodes,"");
 for(auto key:{lt::settings_pack::enable_dht,lt::settings_pack::enable_lsd,lt::settings_pack::enable_upnp,lt::settings_pack::enable_natpmp,lt::settings_pack::enable_outgoing_tcp,lt::settings_pack::enable_incoming_utp,lt::settings_pack::enable_outgoing_utp}){settings.set_bool(key,false);}
 // Test-only opt-in: LT SSRF deliberately denies transformed /scrape on loopback.
 if(ownedLoopbackScrape){settings.set_bool(lt::settings_pack::ssrf_mitigation,false);}
 settings.set_int(lt::settings_pack::alert_mask,static_cast<int>(lt::alert_category::error|lt::alert_category::tracker|lt::alert_category::status));
 lt::session session(settings);auto sink=std::make_shared<Sink>();std::promise<unsigned> attached;auto installed=attached.get_future();
 lt::add_torrent_params parameters;parameters.ti=metadata;parameters.save_path=root.string();parameters.flags&=~(lt::torrent_flags::paused|lt::torrent_flags::auto_managed|lt::torrent_flags::seed_mode);
 parameters.flags|=v2?lt::biglybtc_v2_only:lt::biglybtc_v1_only;
 parameters.extensions.push_back([sink,&attached](const lt::torrent_handle& handle,lt::client_data_t){std::shared_ptr<lt::BiglybtcQueueObserverV1> observer=sink;attached.set_value(lt::biglybtc_attach_queue_observer_v1(&handle,&observer));return std::shared_ptr<lt::torrent_plugin>{};});
 auto handle=session.add_torrent(parameters,error);need(!error&&handle.is_valid(),"Actual admission");need(installed.wait_for(std::chrono::seconds(10))==std::future_status::ready&&installed.get()==0,"Actual executor registration");
 std::shared_ptr<lt::BiglybtcQueueObserverV1> observer=sink;need(lt::biglybtc_attach_queue_observer_v1(&handle,&observer)==static_cast<unsigned>(lt::BiglybtcQueueObserverStatusV1::WrongThread),"Wrong thread refusal");
 need(sink->wait(Kind::StartedSeed)&&sink->wait(Kind::Announce),"Actual verified lifecycle/announce");const auto announce=sink->last(Kind::Announce);need(announce.seeds==5&&announce.peers==7&&announce.protocol==version&&announce.request>0&&announce.request_started_nanoseconds>0&&announce.request_started_nanoseconds<=announce.observed_nanoseconds,"Actual raw announce/request facts");
 tracker.hold();handle.scrape_tracker();
 if(!tracker.waitEntered()){
  {std::lock_guard<std::mutex> lock(tracker.mutex);std::cerr<<"tracker diagnostic announces="<<tracker.announces<<" scrapes="<<tracker.scrapes<<" failure="<<tracker.failure<<'\n';}
  {std::lock_guard<std::mutex> lock(sink->mutex);for(const auto& e:sink->events){std::cerr<<"observer diagnostic kind="<<e.kind<<" request="<<e.request<<" protocol="<<e.protocol<<" seeds="<<e.seeds<<" peers="<<e.peers<<'\n';}}
  std::vector<lt::alert*> alerts;session.pop_alerts(&alerts);unsigned shown=0;
  for(const auto* alert:alerts){if(++shown>32){break;}std::cerr<<"LT diagnostic "<<alert->what()<<" "<<alert->message().substr(0,512)<<'\n';
   if(const auto* failure=lt::alert_cast<lt::tracker_error_alert>(alert)){std::cerr<<"tracker error code="<<failure->error.value()<<" category="<<failure->error.category().name()<<'\n';}
   if(const auto* failure=lt::alert_cast<lt::scrape_failed_alert>(alert)){std::cerr<<"scrape error code="<<failure->error.value()<<" category="<<failure->error.category().name()<<" message="<<failure->error.message()<<'\n';}}
  const auto trackers=handle.trackers();for(const auto& entry:trackers){std::cerr<<"tracker endpoint count="<<entry.endpoints.size()<<'\n';for(const auto& endpoint:entry.endpoints){std::cerr<<"tracker endpoint enabled="<<endpoint.enabled<<'\n';}}
  throw std::runtime_error("Real scrape reached tracker");
 }handle.pause();need(sink->wait(Kind::Stopped),"Actual pause before held reply");const auto stopped=sink->last(Kind::Stopped);tracker.release();need(sink->wait(Kind::Scrape),"Actual delayed scrape");const auto scrape=sink->last(Kind::Scrape);need(scrape.seeds==3&&scrape.peers==11&&scrape.request_started_nanoseconds<stopped.observed_nanoseconds&&scrape.observed_nanoseconds>=stopped.observed_nanoseconds&&scrape.request>announce.request,"Exact spanning request provenance");need(scrape.tracker_sha256==announce.tracker_sha256,"Same exact URL digest");
 tracker.fail=true;handle.scrape_tracker();need(sink->wait(Kind::ScrapeFailed),"Actual controlled failure");const auto failure=sink->last(Kind::ScrapeFailed);need(failure.request>scrape.request&&failure.protocol==version,"Failure has exact request identity");
 handle.resume();need(sink->wait(Kind::StartedSeed,2),"Actual restart lifecycle");tracker.hold();handle.scrape_tracker();need(tracker.waitEntered(),"Actual pending removal request");session.remove_torrent(handle);tracker.release();{auto joined=session.abort();}
 {std::lock_guard<std::mutex> lock(sink->mutex);need(!sink->overflow,"Bounded capture");std::uint64_t last=0;for(const auto& e:sink->events){need(e.sequence>last,"Real monotone event sequence");last=e.sequence;}}
 {std::lock_guard<std::mutex> lock(tracker.mutex);need(tracker.failure.empty()&&tracker.scrapes>=3&&tracker.announces>0,"Actual tracker protocol observations");}
 std::ifstream f(root/"actual.bin",std::ios::binary);std::string after((std::istreambuf_iterator<char>(f)),{});need(after==payload,"Payload unchanged");
 std::cout<<"PASS selected-v"<<version<<" actual tracker announce/scrape/failure/pause/restart/removal; ABI1; owned numeric only\n";return 0;
 }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
