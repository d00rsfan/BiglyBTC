from pathlib import Path
import subprocess,json,time,os,sys
p=Path(__file__).resolve().parent;n=Path('/home/yurii/Java/BiglyBTC');dep=n/'build/dependencies/sysroot/usr';rows=json.loads((p/'commands.json').read_bytes()) if '--qualify-only' in sys.argv else []
def run(name,args):
 t=time.monotonic()
 with (p/(name+'.log')).open('wb') as f: result=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=p,timeout=2400)
 row=dict(name=name,args=list(map(str,args)),exit=result.returncode,seconds=round(time.monotonic()-t,3));rows.append(row);(p/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
if '--qualify-only' not in sys.argv:
 run('configure',['cmake','-S',str(p/'source'),'-B',str(p/'build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-16','-DCMAKE_CXX_STANDARD=23','-DCMAKE_CXX_STANDARD_REQUIRED=ON','-DCMAKE_CXX_EXTENSIONS=OFF','-DCMAKE_INSTALL_PREFIX='+str(p/'install'),'-DCMAKE_INSTALL_LIBDIR=lib','-DCMAKE_PREFIX_PATH='+str(dep)+';/opt/Qt/6.12.0/gcc_64','-DCMAKE_POLICY_DEFAULT_CMP0167=NEW','-DBUILD_SHARED_LIBS=ON','-Dbuild_tests=ON','-Dbuild_examples=OFF','-Dbuild_tools=OFF','-Dpython-bindings=OFF','-Dlogging=ON','-Di2p=ON','-Ddht=ON','-Dencryption=ON','-Ddeprecated-functions=ON'])
 run('build',['nice','-n','5','cmake','--build',str(p/'build'),'--parallel','2','--target','torrent-rasterbar','test_biglybtc_swarm','test_biglybtc_utf16_info','test_biglybtc_traffic_counters'])
 run('install',['cmake','--install',str(p/'build')])
if '--build-only' in sys.argv: raise SystemExit(0)
run('provider-tests',['ctest','--test-dir',str(p/'build'),'-R','^test_biglybtc_(swarm|utf16_info|traffic_counters)$','--output-on-failure','--output-junit',str(p/'provider-tests.xml')])
for fixture in ['queue','socks4a','traffic','cancel']:
 run(fixture+'-configure',['cmake','-S',str(p/(fixture+'-fixture')),'-B',str(p/(fixture+'-build')),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_COMPILER=/usr/bin/g++-16','-DCMAKE_PREFIX_PATH='+str(p/'install')+';'+str(dep)+';/opt/Qt/6.12.0/gcc_64','-DCMAKE_POLICY_DEFAULT_CMP0167=NEW','-DCANCEL_PROVIDER_INSTALL='+str(p/'install'),'-DCANCEL_PROVIDER_SOURCE='+str(p/'source')])
 run(fixture+'-build',['nice','-n','5','cmake','--build',str(p/(fixture+'-build')),'--parallel','2'])
 run(fixture+'-tests',['ctest','--test-dir',str(p/(fixture+'-build')),'--output-on-failure','--output-junit',str(p/(fixture+'-tests.xml'))])
