from pathlib import Path
import hashlib,json,re,subprocess,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent;OLD=P.parents[1]/'compatibility-chapter-20261027/provider-traffic-v3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tree=lambda root:{p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
parent=json.loads((OLD/'source-build-record.json').read_bytes());assert sha(OLD/'source-build-record.json')==json.loads((P/'parent.json').read_bytes())['record_sha256']
for key,root in [('source_inputs_sha256','source'),('installed_sha256','install'),('build_files_sha256','build')]:
 for rel,pin in parent[key].items():assert sha(OLD/root/rel)==pin,('changed parent',root,rel)
expected=dict(parent['source_inputs_sha256']);rel='include/libtorrent/socks5_stream.hpp';amend=json.loads((P/'patch-review.json').read_bytes());assert expected[rel]==amend['before_sha256'];expected[rel]=amend['after_sha256'];assert tree(P/'source')==expected
installed=tree(P/'install');headers={k:v for k,v in installed.items() if k.startswith('include/')};assert len(headers)==277 and all(expected.get(k)==v for k,v in headers.items())
artifact=P/'install/lib/libtorrent-rasterbar.so.2.0.12'
for name,args in [('exports',['nm','-D','--defined-only',str(artifact)]),('dynamic',['readelf','-d',str(artifact)])]:(P/(name+'.txt')).write_bytes(subprocess.check_output(args))
exports=[fields[2].split('@')[0] for line in (P/'exports.txt').read_text().splitlines() if len(fields:=line.split())==3 and fields[1] in ('T','W')];assert all(exports.count(name)==1 for name in parent['required_exports']);assert {x for x in exports if x.startswith('biglybtc_')}=={x for x in parent['required_exports'] if x.startswith('biglybtc_')};assert re.findall(r'\(SONAME\).*\[([^\]]+)\]',(P/'dynamic.txt').read_text())==['libtorrent-rasterbar.so.2.0']
qual={}
for name,names in [('provider-tests',{'test_biglybtc_swarm','test_biglybtc_utf16_info','test_biglybtc_traffic_counters'}),('queue-tests',{'queue-observer-v1','queue-observer-v2'}),('socks4a-tests',{'socks4a-provider'}),('traffic-tests',{'traffic-v3-owned-corrupt-duplicate'}),('cancel-tests',{'socks-cancellation'})]:
 relative=name+'.xml';rows=list(ET.fromstring((P/relative).read_bytes()).iter('testcase'));assert len(rows)==len(names) and {r.get('name') for r in rows}==names;assert not any(r.find(t) is not None for r in rows for t in ('failure','error','skipped'));qual[name]={'names':sorted(names),'xml':relative,'xml_sha256':sha(P/relative)}
cache={}
for line in (P/'build/CMakeCache.txt').read_text().splitlines():
 if '=' in line and not line.startswith(('#','//')):
  k,v=line.split('=',1);cache[k.split(':')[0]]=v
assert all(cache[k]==v for k,v in parent['abi_cache'].items())
commands=json.loads((P/'commands.json').read_bytes());names=['configure','build','install','provider-tests']+[f'{f}-{s}' for f in ['queue','socks4a','traffic','cancel'] for s in ['configure','build','tests']];assert [x['name'] for x in commands]==names and all(x['exit']==0 for x in commands)
(P/'effective-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for fixture in ('queue','socks4a','traffic','cancel'):(P/(fixture+'-detail.log')).write_bytes((P/(fixture+'-build/Testing/Temporary/LastTest.log')).read_bytes())
exclude={'source','build','install','queue-build','socks4a-build','traffic-build','cancel-build'}
evidence={p.relative_to(P).as_posix():sha(p) for p in P.rglob('*') if p.is_file() and not any(s in exclude for s in p.relative_to(P).parts) and p.name not in ('source-build-record.json','root-review.json','binding-identities.json')}
record=dict(schema=1,status='BUILT_AND_DIRECTLY_TESTED_CANDIDATE_NOT_APPROVED',causal_qualified=False,native_runtime_approved=False,upstream_commit=parent['upstream_commit'],parent_record_sha256=sha(OLD/'source-build-record.json'),source_root=str(P/'source'),build_root=str(P/'build'),install_root=str(P/'install'),artifact=str(artifact),artifact_sha256=sha(artifact),artifact_bytes=artifact.stat().st_size,source_inputs_sha256=expected,source_sha256={k:expected[k] for k in sorted(set(parent['source_sha256'])|{rel})},installed_sha256=installed,build_files_sha256={k:sha(P/'build'/k) for k in ('.ninja_log','CMakeCache.txt','build.ninja','install_manifest.txt')},source_build_rules_sha256=parent['source_build_rules_sha256'],bundled_dependency_sha256=parent['bundled_dependency_sha256'],required_exports=parent['required_exports'],direct_qualification=qual,abi_cache=parent['abi_cache'],evidence_sha256=evidence,effective_commands_sha256=sha(P/'effective-commands.json'))
(P/'source-build-record.json').write_text(json.dumps(record,indent=2)+'\n');review={'status':'EXACT_SOURCE_SDK_ARTIFACT_AND_DIRECT_TESTS_REVIEWED','record_sha256':sha(P/'source-build-record.json'),'artifact_sha256':record['artifact_sha256'],'source_leaves':len(expected),'sdk_headers':len(headers),'install_leaves':len(installed),'required_exports':len(parent['required_exports']),'direct_test_cases':sum(len(q['names']) for q in qual.values()),'parent_immutable':True,'shipping_approved':False};(P/'root-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review))
