SOURCE ONLY. Immutable extension of cancel-fixture/de286ef2; the original baseline remains unchanged and has actual --expect-legacy proof. No author build/run/provider/native/shared edits.

Run fixed mode via CTest socks-cancellation or owned-socks-cancellation --expect-fixed. The inherited ordinary/domain, resolver-delivery close and drained same-stream reuse checks remain. Only after their exact fixed predicates pass are these additional cases admitted:

1. Close and immediately start a NEW named async_connect INSIDE first real resolver continuation delivery, before the old continuation enters. Old user callback must receive operation_aborted exactly once, fresh callback success exactly once, only the new domain/port may reach the proxy, total1accepted transport.
2. Same interleaving INSIDE associated-executor delivery4: actual method-reply read completion (resolver1/connect2/method-write3/method-read4). Require actual old authentication reply scheduled, no CONNECT yet, close reset socket/endpoint, then newasyncconnect before oldhandler. The old captured attempt/buffer is still retained by its read/composed callback; require oldabort/newsuccess, exactly2accepted transports but only1newdomain CONNECT. Only expected EOF/aborted/reset from that exact old auth connection is ignored during teardown.
3. Owned proxy sends actual method reply04,00 on the first connection. Reconnect from INSIDE its exact unsupported_version error callback. Socket and public remote endpoint must already be closed/reset before the user callback, and no subsequent old cleanup may cancel the new resolver. Olderror/newsuccess exactly once,2accepts/1fresh CONNECT.
4. Explicit valid CMD3 UDP_ASSOCIATE with default0.0.0.0:0 must succeed, actual wire05030001000000000000. The owned proxy really binds a numeric-loopback UDP socket and replies with its actual port; no UDP forwarding/payload is claimed. CMD1 zero remains forbidden by inherited cancelled-case predicates.

All phases use one io_context, numeric127.0.0.1 proxy and ephemeral owned listeners, no public DNS/endpoints, retries, sleeps or test hooks in provider. Each phase retains5s deadline; CTest40s only covers the seven sequential phases with cleanup. Close/cancel drain owned sockets and callbacks; no owned threads. cancel() without close and arbitrary concurrent writes remain separate untested contracts.

Legacy mode still runs only the inherited three phases and requires exact reopenedzeroCONNECT. It does not run overlapping old-buffer scenarios on the known broken provider. A broken fixed-mode precondition fails before new overlap cases.

Configure as with the original fixture, but -S points HERE and -B is fresh:
cmake -S /home/yurii/Java/BiglyBT/build/network-reliability-20261028/cancel-fixture-r2 -B "$CANCEL_BUILD" -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=/usr/bin/g++-16 -DCANCEL_PROVIDER_INSTALL="$CANCEL_INSTALL" -DCANCEL_PROVIDER_SOURCE="$CANCEL_SOURCE" -DCMAKE_PREFIX_PATH="$CANCEL_INSTALL;/home/yurii/Java/BiglyBTC/build/dependencies/sysroot/usr"
cmake --build "$CANCEL_BUILD" --parallel 1
ctest --test-dir "$CANCEL_BUILD" --verbose --output-on-failure -R '^socks-cancellation$' --no-tests=error --output-junit "$CANCEL_XML"

CMake validates both stream headers source==installed, selects exact explicit provider package config and compiles only its private proxy_base.cpp ctor/dtor alongside the fixture. Do not mix patched SDK with baseline install. Release matches the reviewed installed provider; no extra assertion-suppression flags are added. Root retains actual source/SDK/binary/build/log/XML pins and decides qualification.
